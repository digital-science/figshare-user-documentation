
# PrivateLinkResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **location** | **kotlin.String** | Url for private link |  |
| **htmlLocation** | **kotlin.String** | HTML url for private link |  |
| **token** | **kotlin.String** | Token for private link |  |



