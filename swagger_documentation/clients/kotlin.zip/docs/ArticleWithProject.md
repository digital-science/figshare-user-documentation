
# ArticleWithProject

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **projectId** | **kotlin.Long** | Project id for this article. |  |
| **id** | **kotlin.Long** | Unique identifier for article |  |
| **title** | **kotlin.String** | Title of article |  |
| **doi** | **kotlin.String** | DOI |  |
| **handle** | **kotlin.String** | Handle |  |
| **url** | **kotlin.String** | Api endpoint for article |  |
| **urlPublicHtml** | **kotlin.String** | Public site endpoint for article |  |
| **urlPublicApi** | **kotlin.String** | Public Api endpoint for article |  |
| **urlPrivateHtml** | **kotlin.String** | Private site endpoint for article |  |
| **urlPrivateApi** | **kotlin.String** | Private Api endpoint for article |  |
| **timeline** | [**Timeline**](Timeline.md) |  |  |
| **thumb** | **kotlin.String** | Thumbnail image |  |
| **definedType** | **kotlin.Long** | Type of article identifier |  |
| **definedTypeName** | **kotlin.String** | Name of the article type identifier |  |
| **resourceDoi** | **kotlin.String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. |  |
| **resourceTitle** | **kotlin.String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. |  |
| **createdDate** | **kotlin.String** | Date when article was created |  |



