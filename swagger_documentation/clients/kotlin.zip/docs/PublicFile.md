
# PublicFile

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** | File id |  |
| **name** | **kotlin.String** | File name |  |
| **propertySize** | **kotlin.Int** | File size |  |
| **isLinkOnly** | **kotlin.Boolean** | True if file is hosted somewhere else |  |
| **downloadUrl** | **kotlin.String** | Url for file download |  |
| **suppliedMd5** | **kotlin.String** | File supplied md5 |  |
| **computedMd5** | **kotlin.String** | File computed md5 |  |
| **mimetype** | **kotlin.String** | MIME Type of the file, it defaults to an empty string |  [optional] |



