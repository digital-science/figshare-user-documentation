
# ProjectCollaborator

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **status** | **kotlin.String** | Status of collaborator invitation |  |
| **roleName** | **kotlin.String** | Collaborator role |  |
| **userId** | **kotlin.Int** | Collaborator id |  |
| **name** | **kotlin.String** | Collaborator name |  |



