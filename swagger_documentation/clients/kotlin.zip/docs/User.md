
# User

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | User id |  |
| **firstName** | **kotlin.String** | First Name |  |
| **lastName** | **kotlin.String** | Last Name |  |
| **name** | **kotlin.String** | Full Name |  |
| **isActive** | **kotlin.Boolean** | Account activity status |  |
| **urlName** | **kotlin.String** | Name that appears in website url |  |
| **isPublic** | **kotlin.Boolean** | Account public status |  |
| **jobTitle** | **kotlin.String** | User Job title |  |
| **orcidId** | **kotlin.String** | Orcid associated to this User |  |



