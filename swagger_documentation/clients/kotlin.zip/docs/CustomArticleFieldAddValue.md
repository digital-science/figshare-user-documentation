
# CustomArticleFieldAddValue

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |



