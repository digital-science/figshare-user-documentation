
# Role

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | Role id |  |
| **name** | **kotlin.String** | Role name |  |
| **category** | **kotlin.String** | Role category |  |
| **description** | **kotlin.String** | Role description |  |



