
# ProjectCollaboratorInvite

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **roleName** | [**inline**](#RoleName) | Role of the the collaborator inside the project |  |
| **userId** | **kotlin.Long** | User id of the collaborator |  [optional] |
| **email** | **kotlin.String** | Collaborator email |  [optional] |
| **comment** | **kotlin.String** | Text sent when inviting the user to the project |  [optional] |


<a id="RoleName"></a>
## Enum: role_name
| Name | Value |
| ---- | ----- |
| roleName | viewer, collaborator |



