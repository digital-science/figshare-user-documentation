
# CategoriesCreator

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **categories** | **kotlin.collections.List&lt;kotlin.Long&gt;** | List of category ids |  |



