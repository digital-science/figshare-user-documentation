
# CategoriesCreator

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **categories** | **kotlin.collections.List&lt;kotlin.Int&gt;** | List of category ids |  |



