
# Location

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **location** | **kotlin.String** | Url for item |  |



