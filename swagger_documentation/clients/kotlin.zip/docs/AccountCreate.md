
# AccountCreate

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **email** | **kotlin.String** | Email of account |  |
| **lastName** | **kotlin.String** | Last Name |  |
| **firstName** | **kotlin.String** | First Name |  [optional] |
| **groupId** | **kotlin.Long** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups |  [optional] |
| **institutionUserId** | **kotlin.String** | Institution user id |  [optional] |
| **symplecticUserId** | **kotlin.String** | Symplectic user id |  [optional] |
| **quota** | **kotlin.Long** | Account quota |  [optional] |
| **isActive** | **kotlin.Boolean** | Is account active |  [optional] |



