
# PrivateLink

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.String** | Private link id |  |
| **isActive** | **kotlin.Boolean** | True if private link is active |  |
| **expiresDate** | **kotlin.String** | Date when link will expire |  |
| **htmlLocation** | **kotlin.String** | HTML url for private link |  |



