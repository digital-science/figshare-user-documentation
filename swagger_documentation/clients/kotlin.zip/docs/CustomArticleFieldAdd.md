
# CustomArticleFieldAdd

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** | Custom  metadata name |  |
| **&#x60;value&#x60;** | [**kotlin.Any**](.md) | Custom metadata value (can be either a string or an array of strings) |  |



