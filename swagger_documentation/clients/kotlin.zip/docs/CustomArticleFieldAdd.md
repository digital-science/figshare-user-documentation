
# CustomArticleFieldAdd

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** | Custom  metadata name |  |
| **&#x60;value&#x60;** | [**CustomArticleFieldAddValue**](CustomArticleFieldAddValue.md) |  |  |



