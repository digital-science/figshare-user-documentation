# AuthorsApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**privateAuthorDetails**](AuthorsApi.md#privateAuthorDetails) | **GET** /account/authors/{author_id} | Author details |
| [**privateAuthorsSearch**](AuthorsApi.md#privateAuthorsSearch) | **POST** /account/authors/search | Search Authors |


<a id="privateAuthorDetails"></a>
# **privateAuthorDetails**
> AuthorComplete privateAuthorDetails(authorId)

Author details

View author details

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = AuthorsApi()
val authorId : kotlin.Long = 789 // kotlin.Long | Author unique identifier
try {
    val result : AuthorComplete = apiInstance.privateAuthorDetails(authorId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AuthorsApi#privateAuthorDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AuthorsApi#privateAuthorDetails")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **authorId** | **kotlin.Long**| Author unique identifier | |

### Return type

[**AuthorComplete**](AuthorComplete.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateAuthorsSearch"></a>
# **privateAuthorsSearch**
> kotlin.collections.List&lt;AuthorComplete&gt; privateAuthorsSearch(search)

Search Authors

Search for authors

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = AuthorsApi()
val search : PrivateAuthorsSearch =  // PrivateAuthorsSearch | Search Parameters
try {
    val result : kotlin.collections.List<AuthorComplete> = apiInstance.privateAuthorsSearch(search)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AuthorsApi#privateAuthorsSearch")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AuthorsApi#privateAuthorsSearch")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**PrivateAuthorsSearch**](PrivateAuthorsSearch.md)| Search Parameters | [optional] |

### Return type

[**kotlin.collections.List&lt;AuthorComplete&gt;**](AuthorComplete.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

