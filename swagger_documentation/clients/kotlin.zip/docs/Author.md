
# Author

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | Author id |  |
| **fullName** | **kotlin.String** | Author full name |  |
| **firstName** | **kotlin.String** | Author first name |  |
| **lastName** | **kotlin.String** | Author last name |  |
| **isActive** | **kotlin.Boolean** | True if author has published items |  |
| **urlName** | **kotlin.String** | Author url name |  |
| **orcidId** | **kotlin.String** | Author Orcid |  |



