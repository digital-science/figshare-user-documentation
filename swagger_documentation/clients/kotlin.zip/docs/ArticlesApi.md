# ArticlesApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**accountArticlePublish**](ArticlesApi.md#accountArticlePublish) | **POST** /account/articles/{article_id}/publish | Private Article Publish |
| [**accountArticleReport**](ArticlesApi.md#accountArticleReport) | **GET** /account/articles/export | Account Article Report |
| [**accountArticleReportGenerate**](ArticlesApi.md#accountArticleReportGenerate) | **POST** /account/articles/export | Initiate a new Report |
| [**accountArticleUnpublish**](ArticlesApi.md#accountArticleUnpublish) | **POST** /account/articles/{article_id}/unpublish | Public Article Unpublish |
| [**articleDetails**](ArticlesApi.md#articleDetails) | **GET** /articles/{article_id} | View article details |
| [**articleFileDetails**](ArticlesApi.md#articleFileDetails) | **GET** /articles/{article_id}/files/{file_id} | Article file details |
| [**articleFiles**](ArticlesApi.md#articleFiles) | **GET** /articles/{article_id}/files | List article files |
| [**articleVersionConfidentiality**](ArticlesApi.md#articleVersionConfidentiality) | **GET** /articles/{article_id}/versions/{version_id}/confidentiality | Public Article Confidentiality for article version |
| [**articleVersionDetails**](ArticlesApi.md#articleVersionDetails) | **GET** /articles/{article_id}/versions/{version_id} | Article details for version |
| [**articleVersionEmbargo**](ArticlesApi.md#articleVersionEmbargo) | **GET** /articles/{article_id}/versions/{version_id}/embargo | Public Article Embargo for article version |
| [**articleVersionFiles**](ArticlesApi.md#articleVersionFiles) | **GET** /articles/{article_id}/versions/{version_id}/files | Public Article version files |
| [**articleVersionPartialUpdate**](ArticlesApi.md#articleVersionPartialUpdate) | **PATCH** /account/articles/{article_id}/versions/{version_id} | Partially update article version |
| [**articleVersionUpdate**](ArticlesApi.md#articleVersionUpdate) | **PUT** /account/articles/{article_id}/versions/{version_id} | Update article version |
| [**articleVersionUpdateThumb**](ArticlesApi.md#articleVersionUpdateThumb) | **PUT** /account/articles/{article_id}/versions/{version_id}/update_thumb | Update article version thumbnail |
| [**articleVersions**](ArticlesApi.md#articleVersions) | **GET** /articles/{article_id}/versions | List article versions |
| [**articlesList**](ArticlesApi.md#articlesList) | **GET** /articles | Public Articles |
| [**articlesSearch**](ArticlesApi.md#articlesSearch) | **POST** /articles/search | Public Articles Search |
| [**privateArticleAuthorDelete**](ArticlesApi.md#privateArticleAuthorDelete) | **DELETE** /account/articles/{article_id}/authors/{author_id} | Delete article author |
| [**privateArticleAuthorsAdd**](ArticlesApi.md#privateArticleAuthorsAdd) | **POST** /account/articles/{article_id}/authors | Add article authors |
| [**privateArticleAuthorsList**](ArticlesApi.md#privateArticleAuthorsList) | **GET** /account/articles/{article_id}/authors | List article authors |
| [**privateArticleAuthorsReplace**](ArticlesApi.md#privateArticleAuthorsReplace) | **PUT** /account/articles/{article_id}/authors | Replace article authors |
| [**privateArticleCategoriesAdd**](ArticlesApi.md#privateArticleCategoriesAdd) | **POST** /account/articles/{article_id}/categories | Add article categories |
| [**privateArticleCategoriesList**](ArticlesApi.md#privateArticleCategoriesList) | **GET** /account/articles/{article_id}/categories | List article categories |
| [**privateArticleCategoriesReplace**](ArticlesApi.md#privateArticleCategoriesReplace) | **PUT** /account/articles/{article_id}/categories | Replace article categories |
| [**privateArticleCategoryDelete**](ArticlesApi.md#privateArticleCategoryDelete) | **DELETE** /account/articles/{article_id}/categories/{category_id} | Delete article category |
| [**privateArticleConfidentialityDelete**](ArticlesApi.md#privateArticleConfidentialityDelete) | **DELETE** /account/articles/{article_id}/confidentiality | Delete article confidentiality |
| [**privateArticleConfidentialityDetails**](ArticlesApi.md#privateArticleConfidentialityDetails) | **GET** /account/articles/{article_id}/confidentiality | Article confidentiality details |
| [**privateArticleConfidentialityUpdate**](ArticlesApi.md#privateArticleConfidentialityUpdate) | **PUT** /account/articles/{article_id}/confidentiality | Update article confidentiality |
| [**privateArticleCreate**](ArticlesApi.md#privateArticleCreate) | **POST** /account/articles | Create new Article |
| [**privateArticleDelete**](ArticlesApi.md#privateArticleDelete) | **DELETE** /account/articles/{article_id} | Delete article |
| [**privateArticleDetails**](ArticlesApi.md#privateArticleDetails) | **GET** /account/articles/{article_id} | Article details |
| [**privateArticleDownload**](ArticlesApi.md#privateArticleDownload) | **GET** /account/articles/{article_id}/download | Private Article Download |
| [**privateArticleEmbargoDelete**](ArticlesApi.md#privateArticleEmbargoDelete) | **DELETE** /account/articles/{article_id}/embargo | Delete Article Embargo |
| [**privateArticleEmbargoDetails**](ArticlesApi.md#privateArticleEmbargoDetails) | **GET** /account/articles/{article_id}/embargo | Article Embargo Details |
| [**privateArticleEmbargoUpdate**](ArticlesApi.md#privateArticleEmbargoUpdate) | **PUT** /account/articles/{article_id}/embargo | Update Article Embargo |
| [**privateArticleFile**](ArticlesApi.md#privateArticleFile) | **GET** /account/articles/{article_id}/files/{file_id} | Single File |
| [**privateArticleFileDelete**](ArticlesApi.md#privateArticleFileDelete) | **DELETE** /account/articles/{article_id}/files/{file_id} | File Delete |
| [**privateArticleFilesList**](ArticlesApi.md#privateArticleFilesList) | **GET** /account/articles/{article_id}/files | List article files |
| [**privateArticlePartialUpdate**](ArticlesApi.md#privateArticlePartialUpdate) | **PATCH** /account/articles/{article_id} | Partially update article |
| [**privateArticlePrivateLink**](ArticlesApi.md#privateArticlePrivateLink) | **GET** /account/articles/{article_id}/private_links | List private links |
| [**privateArticlePrivateLinkCreate**](ArticlesApi.md#privateArticlePrivateLinkCreate) | **POST** /account/articles/{article_id}/private_links | Create private link |
| [**privateArticlePrivateLinkDelete**](ArticlesApi.md#privateArticlePrivateLinkDelete) | **DELETE** /account/articles/{article_id}/private_links/{link_id} | Disable private link |
| [**privateArticlePrivateLinkUpdate**](ArticlesApi.md#privateArticlePrivateLinkUpdate) | **PUT** /account/articles/{article_id}/private_links/{link_id} | Update private link |
| [**privateArticleReserveDoi**](ArticlesApi.md#privateArticleReserveDoi) | **POST** /account/articles/{article_id}/reserve_doi | Private Article Reserve DOI |
| [**privateArticleReserveHandle**](ArticlesApi.md#privateArticleReserveHandle) | **POST** /account/articles/{article_id}/reserve_handle | Private Article Reserve Handle |
| [**privateArticleResource**](ArticlesApi.md#privateArticleResource) | **POST** /account/articles/{article_id}/resource | Private Article Resource |
| [**privateArticleUpdate**](ArticlesApi.md#privateArticleUpdate) | **PUT** /account/articles/{article_id} | Update article |
| [**privateArticleUploadComplete**](ArticlesApi.md#privateArticleUploadComplete) | **POST** /account/articles/{article_id}/files/{file_id} | Complete Upload |
| [**privateArticleUploadInitiate**](ArticlesApi.md#privateArticleUploadInitiate) | **POST** /account/articles/{article_id}/files | Initiate Upload |
| [**privateArticlesList**](ArticlesApi.md#privateArticlesList) | **GET** /account/articles | Private Articles |
| [**privateArticlesSearch**](ArticlesApi.md#privateArticlesSearch) | **POST** /account/articles/search | Private Articles search |
| [**publicArticleDownload**](ArticlesApi.md#publicArticleDownload) | **GET** /articles/{article_id}/download | Public Article Download |
| [**publicArticleVersionDownload**](ArticlesApi.md#publicArticleVersionDownload) | **GET** /articles/{article_id}/versions/{version_id}/download | Public Article Version Download |


<a id="accountArticlePublish"></a>
# **accountArticlePublish**
> Location accountArticlePublish(articleId)

Private Article Publish

- If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
try {
    val result : Location = apiInstance.accountArticlePublish(articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#accountArticlePublish")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#accountArticlePublish")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article unique identifier | |

### Return type

[**Location**](Location.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="accountArticleReport"></a>
# **accountArticleReport**
> kotlin.collections.List&lt;AccountReport&gt; accountArticleReport(groupId)

Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val groupId : kotlin.Long = 789 // kotlin.Long | A group ID to filter by
try {
    val result : kotlin.collections.List<AccountReport> = apiInstance.accountArticleReport(groupId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#accountArticleReport")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#accountArticleReport")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **groupId** | **kotlin.Long**| A group ID to filter by | [optional] |

### Return type

[**kotlin.collections.List&lt;AccountReport&gt;**](AccountReport.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="accountArticleReportGenerate"></a>
# **accountArticleReportGenerate**
> AccountReport accountArticleReportGenerate()

Initiate a new Report

Initiate a new Article Report for this Account. There is a limit of 1 report per day.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
try {
    val result : AccountReport = apiInstance.accountArticleReportGenerate()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#accountArticleReportGenerate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#accountArticleReportGenerate")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="accountArticleUnpublish"></a>
# **accountArticleUnpublish**
> accountArticleUnpublish(articleId, reason)

Public Article Unpublish

Allows authorized users to unpublish an article.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val reason : ArticleUnpublishData =  // ArticleUnpublishData | Article unpublish data
try {
    apiInstance.accountArticleUnpublish(articleId, reason)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#accountArticleUnpublish")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#accountArticleUnpublish")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **reason** | [**ArticleUnpublishData**](ArticleUnpublishData.md)| Article unpublish data | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="articleDetails"></a>
# **articleDetails**
> ArticleComplete articleDetails(articleId)

View article details

View an article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article Unique identifier
try {
    val result : ArticleComplete = apiInstance.articleDetails(articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articleDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articleDetails")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article Unique identifier | |

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="articleFileDetails"></a>
# **articleFileDetails**
> PublicFile articleFileDetails(articleId, fileId)

Article file details

File by id

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article Unique identifier
val fileId : kotlin.Long = 789 // kotlin.Long | File Unique identifier
try {
    val result : PublicFile = apiInstance.articleFileDetails(articleId, fileId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articleFileDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articleFileDetails")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article Unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **fileId** | **kotlin.Long**| File Unique identifier | |

### Return type

[**PublicFile**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="articleFiles"></a>
# **articleFiles**
> kotlin.collections.List&lt;PublicFile&gt; articleFiles(articleId, page, pageSize, limit, offset)

List article files

Files list for article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article Unique identifier
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
try {
    val result : kotlin.collections.List<PublicFile> = apiInstance.articleFiles(articleId, page, pageSize, limit, offset)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articleFiles")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articleFiles")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article Unique identifier | |
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**kotlin.collections.List&lt;PublicFile&gt;**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="articleVersionConfidentiality"></a>
# **articleVersionConfidentiality**
> ArticleConfidentiality articleVersionConfidentiality(articleId, versionId)

Public Article Confidentiality for article version

Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article Unique identifier
val versionId : kotlin.Long = 789 // kotlin.Long | Version Number
try {
    val result : ArticleConfidentiality = apiInstance.articleVersionConfidentiality(articleId, versionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articleVersionConfidentiality")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articleVersionConfidentiality")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article Unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **versionId** | **kotlin.Long**| Version Number | |

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="articleVersionDetails"></a>
# **articleVersionDetails**
> ArticleComplete articleVersionDetails(articleId, versionId)

Article details for version

Article with specified version

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article Unique identifier
val versionId : kotlin.Long = 789 // kotlin.Long | Article Version Number
try {
    val result : ArticleComplete = apiInstance.articleVersionDetails(articleId, versionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articleVersionDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articleVersionDetails")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article Unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **versionId** | **kotlin.Long**| Article Version Number | |

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="articleVersionEmbargo"></a>
# **articleVersionEmbargo**
> ArticleEmbargo articleVersionEmbargo(articleId, versionId)

Public Article Embargo for article version

Embargo for article version

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article Unique identifier
val versionId : kotlin.Long = 789 // kotlin.Long | Version Number
try {
    val result : ArticleEmbargo = apiInstance.articleVersionEmbargo(articleId, versionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articleVersionEmbargo")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articleVersionEmbargo")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article Unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **versionId** | **kotlin.Long**| Version Number | |

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="articleVersionFiles"></a>
# **articleVersionFiles**
> kotlin.collections.List&lt;PublicFile&gt; articleVersionFiles(articleId, versionId, page, pageSize, limit, offset)

Public Article version files

Article version file details

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article Unique identifier
val versionId : kotlin.Long = 789 // kotlin.Long | Article Version Unique identifier
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
try {
    val result : kotlin.collections.List<PublicFile> = apiInstance.articleVersionFiles(articleId, versionId, page, pageSize, limit, offset)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articleVersionFiles")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articleVersionFiles")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article Unique identifier | |
| **versionId** | **kotlin.Long**| Article Version Unique identifier | |
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**kotlin.collections.List&lt;PublicFile&gt;**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="articleVersionPartialUpdate"></a>
# **articleVersionPartialUpdate**
> LocationWarningsUpdate articleVersionPartialUpdate(articleId, versionId, article)

Partially update article version

Partially updating an article version by passing only the fields to change.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val versionId : kotlin.Long = 789 // kotlin.Long | Article version identifier
val article : ArticleVersionUpdate =  // ArticleVersionUpdate | Subset of article version fields to update
try {
    val result : LocationWarningsUpdate = apiInstance.articleVersionPartialUpdate(articleId, versionId, article)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articleVersionPartialUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articleVersionPartialUpdate")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| **versionId** | **kotlin.Long**| Article version identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md)| Subset of article version fields to update | |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="articleVersionUpdate"></a>
# **articleVersionUpdate**
> LocationWarningsUpdate articleVersionUpdate(articleId, versionId, article)

Update article version

Updating an article version by passing body parameters.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val versionId : kotlin.Long = 789 // kotlin.Long | Article version identifier
val article : ArticleVersionUpdate =  // ArticleVersionUpdate | Article description
try {
    val result : LocationWarningsUpdate = apiInstance.articleVersionUpdate(articleId, versionId, article)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articleVersionUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articleVersionUpdate")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| **versionId** | **kotlin.Long**| Article version identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md)| Article description | |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="articleVersionUpdateThumb"></a>
# **articleVersionUpdateThumb**
> articleVersionUpdateThumb(articleId, versionId, fileId)

Update article version thumbnail

For a given public article version update the article thumbnail by choosing one of the associated files

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val versionId : kotlin.Long = 789 // kotlin.Long | Article version identifier
val fileId : FileId =  // FileId | File ID
try {
    apiInstance.articleVersionUpdateThumb(articleId, versionId, fileId)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articleVersionUpdateThumb")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articleVersionUpdateThumb")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| **versionId** | **kotlin.Long**| Article version identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **fileId** | [**FileId**](FileId.md)| File ID | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="articleVersions"></a>
# **articleVersions**
> kotlin.collections.List&lt;ArticleVersions&gt; articleVersions(articleId)

List article versions

List public article versions

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article Unique identifier
try {
    val result : kotlin.collections.List<ArticleVersions> = apiInstance.articleVersions(articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articleVersions")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articleVersions")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article Unique identifier | |

### Return type

[**kotlin.collections.List&lt;ArticleVersions&gt;**](ArticleVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="articlesList"></a>
# **articlesList**
> kotlin.collections.List&lt;Article&gt; articlesList(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, modifiedSince, group, resourceDoi, itemType, doi, handle)

Public Articles

Returns a list of public articles

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val xCursor : java.util.UUID = 38400000-8cf0-11bd-b23e-10b96e4ef00d // java.util.UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
val order : kotlin.String = order_example // kotlin.String | The field by which to order. Default varies by endpoint/resource.
val orderDirection : kotlin.String = orderDirection_example // kotlin.String | 
val institution : kotlin.Long = 789 // kotlin.Long | only return articles from this institution
val publishedSince : kotlin.String = publishedSince_example // kotlin.String | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
val modifiedSince : kotlin.String = modifiedSince_example // kotlin.String | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
val group : kotlin.Long = 789 // kotlin.Long | only return articles from this group
val resourceDoi : kotlin.String = resourceDoi_example // kotlin.String | Deprecated by related materials. Only return articles with this resource_doi
val itemType : kotlin.Long = 789 // kotlin.Long | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
val doi : kotlin.String = doi_example // kotlin.String | only return articles with this doi
val handle : kotlin.String = handle_example // kotlin.String | only return articles with this handle
try {
    val result : kotlin.collections.List<Article> = apiInstance.articlesList(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, modifiedSince, group, resourceDoi, itemType, doi, handle)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articlesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articlesList")
    e.printStackTrace()
}
```

### Parameters
| **xCursor** | **java.util.UUID**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **kotlin.String**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date] [enum: published_date, created_date, modified_date, views, shares, downloads, cites] |
| **orderDirection** | **kotlin.String**|  | [optional] [default to desc] [enum: asc, desc] |
| **institution** | **kotlin.Long**| only return articles from this institution | [optional] |
| **publishedSince** | **kotlin.String**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **modifiedSince** | **kotlin.String**| Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **group** | **kotlin.Long**| only return articles from this group | [optional] |
| **resourceDoi** | **kotlin.String**| Deprecated by related materials. Only return articles with this resource_doi | [optional] |
| **itemType** | **kotlin.Long**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] |
| **doi** | **kotlin.String**| only return articles with this doi | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **handle** | **kotlin.String**| only return articles with this handle | [optional] |

### Return type

[**kotlin.collections.List&lt;Article&gt;**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="articlesSearch"></a>
# **articlesSearch**
> kotlin.collections.List&lt;ArticleWithProject&gt; articlesSearch(xCursor, search)

Public Articles Search

Returns a list of public articles, filtered by the search parameters

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val xCursor : java.util.UUID = 38400000-8cf0-11bd-b23e-10b96e4ef00d // java.util.UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
val search : ArticleSearch =  // ArticleSearch | Search Parameters
try {
    val result : kotlin.collections.List<ArticleWithProject> = apiInstance.articlesSearch(xCursor, search)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#articlesSearch")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#articlesSearch")
    e.printStackTrace()
}
```

### Parameters
| **xCursor** | **java.util.UUID**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**ArticleSearch**](ArticleSearch.md)| Search Parameters | [optional] |

### Return type

[**kotlin.collections.List&lt;ArticleWithProject&gt;**](ArticleWithProject.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticleAuthorDelete"></a>
# **privateArticleAuthorDelete**
> privateArticleAuthorDelete(articleId, authorId)

Delete article author

De-associate author from article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val authorId : kotlin.Long = 789 // kotlin.Long | Article Author unique identifier
try {
    apiInstance.privateArticleAuthorDelete(articleId, authorId)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleAuthorDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleAuthorDelete")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **authorId** | **kotlin.Long**| Article Author unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleAuthorsAdd"></a>
# **privateArticleAuthorsAdd**
> privateArticleAuthorsAdd(articleId, authors)

Add article authors

Associate new authors with the article. This will add new authors to the list of already associated authors

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val authors : AuthorsCreator =  // AuthorsCreator | Authors description
try {
    apiInstance.privateArticleAuthorsAdd(articleId, authors)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleAuthorsAdd")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleAuthorsAdd")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **authors** | [**AuthorsCreator**](AuthorsCreator.md)| Authors description | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticleAuthorsList"></a>
# **privateArticleAuthorsList**
> kotlin.collections.List&lt;Author&gt; privateArticleAuthorsList(articleId)

List article authors

List article authors

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
try {
    val result : kotlin.collections.List<Author> = apiInstance.privateArticleAuthorsList(articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleAuthorsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleAuthorsList")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article unique identifier | |

### Return type

[**kotlin.collections.List&lt;Author&gt;**](Author.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleAuthorsReplace"></a>
# **privateArticleAuthorsReplace**
> privateArticleAuthorsReplace(articleId, authors)

Replace article authors

Associate new authors with the article. This will remove all already associated authors and add these new ones

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val authors : AuthorsCreator =  // AuthorsCreator | Authors description
try {
    apiInstance.privateArticleAuthorsReplace(articleId, authors)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleAuthorsReplace")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleAuthorsReplace")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **authors** | [**AuthorsCreator**](AuthorsCreator.md)| Authors description | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticleCategoriesAdd"></a>
# **privateArticleCategoriesAdd**
> privateArticleCategoriesAdd(articleId, categories)

Add article categories

Associate new categories with the article. This will add new categories to the list of already associated categories

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val categories : CategoriesCreator =  // CategoriesCreator | 
try {
    apiInstance.privateArticleCategoriesAdd(articleId, categories)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleCategoriesAdd")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleCategoriesAdd")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **categories** | [**CategoriesCreator**](CategoriesCreator.md)|  | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticleCategoriesList"></a>
# **privateArticleCategoriesList**
> kotlin.collections.List&lt;Category&gt; privateArticleCategoriesList(articleId)

List article categories

List article categories

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
try {
    val result : kotlin.collections.List<Category> = apiInstance.privateArticleCategoriesList(articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleCategoriesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleCategoriesList")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article unique identifier | |

### Return type

[**kotlin.collections.List&lt;Category&gt;**](Category.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleCategoriesReplace"></a>
# **privateArticleCategoriesReplace**
> privateArticleCategoriesReplace(articleId, categories)

Replace article categories

Associate new categories with the article. This will remove all already associated categories and add these new ones

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val categories : CategoriesCreator =  // CategoriesCreator | 
try {
    apiInstance.privateArticleCategoriesReplace(articleId, categories)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleCategoriesReplace")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleCategoriesReplace")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **categories** | [**CategoriesCreator**](CategoriesCreator.md)|  | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticleCategoryDelete"></a>
# **privateArticleCategoryDelete**
> privateArticleCategoryDelete(articleId, categoryId)

Delete article category

De-associate category from article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val categoryId : kotlin.Long = 789 // kotlin.Long | Category unique identifier
try {
    apiInstance.privateArticleCategoryDelete(articleId, categoryId)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleCategoryDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleCategoryDelete")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **categoryId** | **kotlin.Long**| Category unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleConfidentialityDelete"></a>
# **privateArticleConfidentialityDelete**
> privateArticleConfidentialityDelete(articleId)

Delete article confidentiality

Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
try {
    apiInstance.privateArticleConfidentialityDelete(articleId)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleConfidentialityDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleConfidentialityDelete")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleConfidentialityDetails"></a>
# **privateArticleConfidentialityDetails**
> ArticleConfidentiality privateArticleConfidentialityDetails(articleId)

Article confidentiality details

View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
try {
    val result : ArticleConfidentiality = apiInstance.privateArticleConfidentialityDetails(articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleConfidentialityDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleConfidentialityDetails")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article unique identifier | |

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleConfidentialityUpdate"></a>
# **privateArticleConfidentialityUpdate**
> privateArticleConfidentialityUpdate(articleId, reason)

Update article confidentiality

Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val reason : ConfidentialityCreator =  // ConfidentialityCreator | 
try {
    apiInstance.privateArticleConfidentialityUpdate(articleId, reason)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleConfidentialityUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleConfidentialityUpdate")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **reason** | [**ConfidentialityCreator**](ConfidentialityCreator.md)|  | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticleCreate"></a>
# **privateArticleCreate**
> LocationWarnings privateArticleCreate(article)

Create new Article

Create a new Article by sending article information

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val article : ArticleCreate =  // ArticleCreate | Article description
try {
    val result : LocationWarnings = apiInstance.privateArticleCreate(article)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleCreate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleCreate")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article** | [**ArticleCreate**](ArticleCreate.md)| Article description | |

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticleDelete"></a>
# **privateArticleDelete**
> privateArticleDelete(articleId)

Delete article

Delete an article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
try {
    apiInstance.privateArticleDelete(articleId)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleDelete")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleDetails"></a>
# **privateArticleDetails**
> ArticleCompletePrivate privateArticleDetails(articleId)

Article details

View a private article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
try {
    val result : ArticleCompletePrivate = apiInstance.privateArticleDetails(articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleDetails")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article unique identifier | |

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleDownload"></a>
# **privateArticleDownload**
> privateArticleDownload(articleId, folderPath)

Private Article Download

Download files from a private article preserving the folder structure

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val folderPath : kotlin.String = folderPath_example // kotlin.String | Folder path to download. If not provided, all files from the article will be downloaded
try {
    apiInstance.privateArticleDownload(articleId, folderPath)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleDownload")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleDownload")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **folderPath** | **kotlin.String**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a id="privateArticleEmbargoDelete"></a>
# **privateArticleEmbargoDelete**
> privateArticleEmbargoDelete(articleId)

Delete Article Embargo

Will lift the embargo for the specified article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
try {
    apiInstance.privateArticleEmbargoDelete(articleId)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleEmbargoDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleEmbargoDelete")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleEmbargoDetails"></a>
# **privateArticleEmbargoDetails**
> ArticleEmbargo privateArticleEmbargoDetails(articleId)

Article Embargo Details

View a private article embargo details

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
try {
    val result : ArticleEmbargo = apiInstance.privateArticleEmbargoDetails(articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleEmbargoDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleEmbargoDetails")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article unique identifier | |

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleEmbargoUpdate"></a>
# **privateArticleEmbargoUpdate**
> privateArticleEmbargoUpdate(articleId, embargo)

Update Article Embargo

Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val embargo : ArticleEmbargoUpdater =  // ArticleEmbargoUpdater | Embargo description
try {
    apiInstance.privateArticleEmbargoUpdate(articleId, embargo)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleEmbargoUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleEmbargoUpdate")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **embargo** | [**ArticleEmbargoUpdater**](ArticleEmbargoUpdater.md)| Embargo description | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticleFile"></a>
# **privateArticleFile**
> PrivateFile privateArticleFile(articleId, fileId)

Single File

View details of file for specified article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val fileId : kotlin.Long = 789 // kotlin.Long | File unique identifier
try {
    val result : PrivateFile = apiInstance.privateArticleFile(articleId, fileId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleFile")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleFile")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **fileId** | **kotlin.Long**| File unique identifier | |

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleFileDelete"></a>
# **privateArticleFileDelete**
> privateArticleFileDelete(articleId, fileId)

File Delete

Complete file upload

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val fileId : kotlin.Long = 789 // kotlin.Long | File unique identifier
try {
    apiInstance.privateArticleFileDelete(articleId, fileId)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleFileDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleFileDelete")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **fileId** | **kotlin.Long**| File unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleFilesList"></a>
# **privateArticleFilesList**
> kotlin.collections.List&lt;PrivateFile&gt; privateArticleFilesList(articleId, page, pageSize, limit, offset)

List article files

List private files

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
try {
    val result : kotlin.collections.List<PrivateFile> = apiInstance.privateArticleFilesList(articleId, page, pageSize, limit, offset)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleFilesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleFilesList")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**kotlin.collections.List&lt;PrivateFile&gt;**](PrivateFile.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticlePartialUpdate"></a>
# **privateArticlePartialUpdate**
> LocationWarningsUpdate privateArticlePartialUpdate(articleId, article)

Partially update article

Partially update an article by sending only the fields to change.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val article : ArticleUpdate =  // ArticleUpdate | Subset of article fields to update
try {
    val result : LocationWarningsUpdate = apiInstance.privateArticlePartialUpdate(articleId, article)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticlePartialUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticlePartialUpdate")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article** | [**ArticleUpdate**](ArticleUpdate.md)| Subset of article fields to update | |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticlePrivateLink"></a>
# **privateArticlePrivateLink**
> kotlin.collections.List&lt;PrivateLink&gt; privateArticlePrivateLink(articleId)

List private links

List private links

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
try {
    val result : kotlin.collections.List<PrivateLink> = apiInstance.privateArticlePrivateLink(articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticlePrivateLink")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticlePrivateLink")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article unique identifier | |

### Return type

[**kotlin.collections.List&lt;PrivateLink&gt;**](PrivateLink.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticlePrivateLinkCreate"></a>
# **privateArticlePrivateLinkCreate**
> PrivateLinkResponse privateArticlePrivateLinkCreate(articleId, privateLink)

Create private link

Create new private link for this article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val privateLink : PrivateLinkCreator =  // PrivateLinkCreator | 
try {
    val result : PrivateLinkResponse = apiInstance.privateArticlePrivateLinkCreate(articleId, privateLink)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticlePrivateLinkCreate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticlePrivateLinkCreate")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **privateLink** | [**PrivateLinkCreator**](PrivateLinkCreator.md)|  | [optional] |

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticlePrivateLinkDelete"></a>
# **privateArticlePrivateLinkDelete**
> privateArticlePrivateLinkDelete(articleId, linkId)

Disable private link

Disable/delete private link for this article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val linkId : kotlin.String = linkId_example // kotlin.String | Private link token
try {
    apiInstance.privateArticlePrivateLinkDelete(articleId, linkId)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticlePrivateLinkDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticlePrivateLinkDelete")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **linkId** | **kotlin.String**| Private link token | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticlePrivateLinkUpdate"></a>
# **privateArticlePrivateLinkUpdate**
> privateArticlePrivateLinkUpdate(articleId, linkId, privateLink)

Update private link

Update existing private link for this article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val linkId : kotlin.String = linkId_example // kotlin.String | Private link token
val privateLink : PrivateLinkCreator =  // PrivateLinkCreator | 
try {
    apiInstance.privateArticlePrivateLinkUpdate(articleId, linkId, privateLink)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticlePrivateLinkUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticlePrivateLinkUpdate")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| **linkId** | **kotlin.String**| Private link token | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **privateLink** | [**PrivateLinkCreator**](PrivateLinkCreator.md)|  | [optional] |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticleReserveDoi"></a>
# **privateArticleReserveDoi**
> ArticleDOI privateArticleReserveDoi(articleId)

Private Article Reserve DOI

Reserve DOI for article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
try {
    val result : ArticleDOI = apiInstance.privateArticleReserveDoi(articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleReserveDoi")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleReserveDoi")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article unique identifier | |

### Return type

[**ArticleDOI**](ArticleDOI.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleReserveHandle"></a>
# **privateArticleReserveHandle**
> ArticleHandle privateArticleReserveHandle(articleId)

Private Article Reserve Handle

Reserve Handle for article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
try {
    val result : ArticleHandle = apiInstance.privateArticleReserveHandle(articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleReserveHandle")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleReserveHandle")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Article unique identifier | |

### Return type

[**ArticleHandle**](ArticleHandle.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleResource"></a>
# **privateArticleResource**
> Location privateArticleResource(articleId, resource)

Private Article Resource

Edit article resource data.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val resource : Resource =  // Resource | Resource data
try {
    val result : Location = apiInstance.privateArticleResource(articleId, resource)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleResource")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleResource")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **resource** | [**Resource**](Resource.md)| Resource data | |

### Return type

[**Location**](Location.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticleUpdate"></a>
# **privateArticleUpdate**
> LocationWarningsUpdate privateArticleUpdate(articleId, article)

Update article

Update an article by passing full body parameters.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val article : ArticleUpdate =  // ArticleUpdate | Full article representation
try {
    val result : LocationWarningsUpdate = apiInstance.privateArticleUpdate(articleId, article)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleUpdate")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article** | [**ArticleUpdate**](ArticleUpdate.md)| Full article representation | |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticleUploadComplete"></a>
# **privateArticleUploadComplete**
> privateArticleUploadComplete(articleId, fileId)

Complete Upload

Complete file upload

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val fileId : kotlin.Long = 789 // kotlin.Long | File unique identifier
try {
    apiInstance.privateArticleUploadComplete(articleId, fileId)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleUploadComplete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleUploadComplete")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **fileId** | **kotlin.Long**| File unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticleUploadInitiate"></a>
# **privateArticleUploadInitiate**
> Location privateArticleUploadInitiate(articleId, file, page, pageSize, limit, offset)

Initiate Upload

Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val file : FileCreator =  // FileCreator | 
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
try {
    val result : Location = apiInstance.privateArticleUploadInitiate(articleId, file, page, pageSize, limit, offset)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticleUploadInitiate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticleUploadInitiate")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| **file** | [**FileCreator**](FileCreator.md)|  | |
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**Location**](Location.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateArticlesList"></a>
# **privateArticlesList**
> kotlin.collections.List&lt;Article&gt; privateArticlesList(page, pageSize, limit, offset)

Private Articles

Get Own Articles

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
try {
    val result : kotlin.collections.List<Article> = apiInstance.privateArticlesList(page, pageSize, limit, offset)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticlesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticlesList")
    e.printStackTrace()
}
```

### Parameters
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**kotlin.collections.List&lt;Article&gt;**](Article.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateArticlesSearch"></a>
# **privateArticlesSearch**
> kotlin.collections.List&lt;ArticleWithProject&gt; privateArticlesSearch(search)

Private Articles search

Returns a list of private articles filtered by the search parameters

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val search : PrivateArticleSearch =  // PrivateArticleSearch | Search Parameters
try {
    val result : kotlin.collections.List<ArticleWithProject> = apiInstance.privateArticlesSearch(search)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#privateArticlesSearch")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#privateArticlesSearch")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**PrivateArticleSearch**](PrivateArticleSearch.md)| Search Parameters | |

### Return type

[**kotlin.collections.List&lt;ArticleWithProject&gt;**](ArticleWithProject.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="publicArticleDownload"></a>
# **publicArticleDownload**
> publicArticleDownload(articleId, folderPath)

Public Article Download

Download files from a public article preserving the folder structure

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val folderPath : kotlin.String = folderPath_example // kotlin.String | Folder path to download. If not provided, all files from the article will be downloaded
try {
    apiInstance.publicArticleDownload(articleId, folderPath)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#publicArticleDownload")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#publicArticleDownload")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **folderPath** | **kotlin.String**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a id="publicArticleVersionDownload"></a>
# **publicArticleVersionDownload**
> publicArticleVersionDownload(articleId, versionId, folderPath)

Public Article Version Download

Download files from a certain version of an public article preserving the folder structure

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ArticlesApi()
val articleId : kotlin.Long = 789 // kotlin.Long | Article unique identifier
val versionId : kotlin.Long = 789 // kotlin.Long | Version Number
val folderPath : kotlin.String = folderPath_example // kotlin.String | Folder path to download. If not provided, all files from the article will be downloaded
try {
    apiInstance.publicArticleVersionDownload(articleId, versionId, folderPath)
} catch (e: ClientException) {
    println("4xx response calling ArticlesApi#publicArticleVersionDownload")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ArticlesApi#publicArticleVersionDownload")
    e.printStackTrace()
}
```

### Parameters
| **articleId** | **kotlin.Long**| Article unique identifier | |
| **versionId** | **kotlin.Long**| Version Number | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **folderPath** | **kotlin.String**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

