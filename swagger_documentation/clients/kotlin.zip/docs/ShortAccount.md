
# ShortAccount

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | Account id |  |
| **firstName** | **kotlin.String** | First Name |  |
| **lastName** | **kotlin.String** | Last Name |  |
| **institutionId** | **kotlin.Long** | Account institution |  |
| **email** | **kotlin.String** | User email |  |
| **active** | **kotlin.Long** | Account activity status |  |
| **institutionUserId** | **kotlin.String** | Account institution user id |  |
| **quota** | **kotlin.Long** | Total storage available to account, in bytes |  |
| **usedQuota** | **kotlin.Long** | Storage used by the account, in bytes |  |
| **userId** | **kotlin.Long** | User id associated with account, useful for example for adding the account as an author to an item |  |
| **orcidId** | **kotlin.String** | ORCID iD associated to account |  |
| **symplecticUserId** | **kotlin.String** | Symplectic ID associated to account |  |



