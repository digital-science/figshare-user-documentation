
# ProfileUpdateData

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **firstName** | **kotlin.String** | First name |  [optional] |
| **lastName** | **kotlin.String** | Last Name |  [optional] |
| **orcid** | **kotlin.String** | User ORCID |  [optional] |
| **jobTitle** | **kotlin.String** | User job title |  [optional] |
| **fieldsOfInterest** | **kotlin.collections.List&lt;kotlin.Long&gt;** | User fields of interest (category ids) |  [optional] |
| **fieldsOfInterestBySourceId** | **kotlin.collections.List&lt;kotlin.String&gt;** | User fields of interest (category source IDs), supersedes the fields_of_interest property |  [optional] |
| **location** | **kotlin.String** | User location |  [optional] |
| **facebook** | **kotlin.String** | User facebook URL |  [optional] |
| **x** | **kotlin.String** | User X (twitter) URL |  [optional] |
| **linkedin** | **kotlin.String** | User linkedin URL |  [optional] |
| **bio** | **kotlin.String** | User biographical information |  [optional] |
| **personalProfiles** | [**kotlin.collections.List&lt;ProfileUpdateDataPersonalProfilesInner&gt;**](ProfileUpdateDataPersonalProfilesInner.md) | Add up to 10 additional personal profile links |  [optional] |



