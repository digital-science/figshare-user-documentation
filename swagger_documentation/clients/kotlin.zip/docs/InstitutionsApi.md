# InstitutionsApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**accountInstitutionCuration**](InstitutionsApi.md#accountInstitutionCuration) | **GET** /account/institution/review/{curation_id} | Institution Curation Review |
| [**accountInstitutionCurations**](InstitutionsApi.md#accountInstitutionCurations) | **GET** /account/institution/reviews | Institution Curation Reviews |
| [**customFieldsList**](InstitutionsApi.md#customFieldsList) | **GET** /account/institution/custom_fields | Private account institution group custom fields |
| [**customFieldsUpload**](InstitutionsApi.md#customFieldsUpload) | **POST** /account/institution/custom_fields/{custom_field_id}/items/upload | Custom fields values files upload |
| [**getAccountInstitutionCurationComments**](InstitutionsApi.md#getAccountInstitutionCurationComments) | **GET** /account/institution/review/{curation_id}/comments | Institution Curation Review Comments |
| [**institutionArticles**](InstitutionsApi.md#institutionArticles) | **GET** /institutions/{institution_string_id}/articles/filter-by | Public Institution Articles |
| [**institutionHrfeedUpload**](InstitutionsApi.md#institutionHrfeedUpload) | **POST** /institution/hrfeed/upload | Private Institution HRfeed Upload |
| [**postAccountInstitutionCurationComments**](InstitutionsApi.md#postAccountInstitutionCurationComments) | **POST** /account/institution/review/{curation_id}/comments | POST Institution Curation Review Comment |
| [**privateAccountInstitutionUser**](InstitutionsApi.md#privateAccountInstitutionUser) | **GET** /account/institution/users/{account_id} | Private Account Institution User |
| [**privateCategoriesList**](InstitutionsApi.md#privateCategoriesList) | **GET** /account/categories | Private Account Categories |
| [**privateGroupEmbargoOptionsDetails**](InstitutionsApi.md#privateGroupEmbargoOptionsDetails) | **GET** /account/institution/groups/{group_id}/embargo_options | Private Account Institution Group Embargo Options |
| [**privateInstitutionAccount**](InstitutionsApi.md#privateInstitutionAccount) | **GET** /account/institution/accounts/{account_id} | Private Institution Account information |
| [**privateInstitutionAccountGroupRoleDelete**](InstitutionsApi.md#privateInstitutionAccountGroupRoleDelete) | **DELETE** /account/institution/roles/{account_id}/{group_id}/{role_id} | Delete Institution Account Group Role |
| [**privateInstitutionAccountGroupRoles**](InstitutionsApi.md#privateInstitutionAccountGroupRoles) | **GET** /account/institution/roles/{account_id} | List Institution Account Group Roles |
| [**privateInstitutionAccountGroupRolesCreate**](InstitutionsApi.md#privateInstitutionAccountGroupRolesCreate) | **POST** /account/institution/roles/{account_id} | Add Institution Account Group Roles |
| [**privateInstitutionAccountsCreate**](InstitutionsApi.md#privateInstitutionAccountsCreate) | **POST** /account/institution/accounts | Create new Institution Account |
| [**privateInstitutionAccountsList**](InstitutionsApi.md#privateInstitutionAccountsList) | **GET** /account/institution/accounts | Private Account Institution Accounts |
| [**privateInstitutionAccountsSearch**](InstitutionsApi.md#privateInstitutionAccountsSearch) | **POST** /account/institution/accounts/search | Private Account Institution Accounts Search |
| [**privateInstitutionAccountsUpdate**](InstitutionsApi.md#privateInstitutionAccountsUpdate) | **PUT** /account/institution/accounts/{account_id} | Update Institution Account |
| [**privateInstitutionArticles**](InstitutionsApi.md#privateInstitutionArticles) | **GET** /account/institution/articles | Private Institution Articles |
| [**privateInstitutionDetails**](InstitutionsApi.md#privateInstitutionDetails) | **GET** /account/institution | Private Account Institutions |
| [**privateInstitutionEmbargoOptionsDetails**](InstitutionsApi.md#privateInstitutionEmbargoOptionsDetails) | **GET** /account/institution/embargo_options | Private Account Institution embargo options |
| [**privateInstitutionGroupsList**](InstitutionsApi.md#privateInstitutionGroupsList) | **GET** /account/institution/groups | Private Account Institution Groups |
| [**privateInstitutionRolesList**](InstitutionsApi.md#privateInstitutionRolesList) | **GET** /account/institution/roles | Private Account Institution Roles |


<a id="accountInstitutionCuration"></a>
# **accountInstitutionCuration**
> CurationDetail accountInstitutionCuration(curationId)

Institution Curation Review

Retrieve a certain curation review by its ID

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val curationId : kotlin.Long = 789 // kotlin.Long | ID of the curation
try {
    val result : CurationDetail = apiInstance.accountInstitutionCuration(curationId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#accountInstitutionCuration")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#accountInstitutionCuration")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **curationId** | **kotlin.Long**| ID of the curation | |

### Return type

[**CurationDetail**](CurationDetail.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="accountInstitutionCurations"></a>
# **accountInstitutionCurations**
> Curation accountInstitutionCurations(groupId, articleId, status, limit, offset)

Institution Curation Reviews

Retrieve a list of curation reviews for this institution

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val groupId : kotlin.Long = 789 // kotlin.Long | Filter by the group ID
val articleId : kotlin.Long = 789 // kotlin.Long | Retrieve the reviews for this article
val status : kotlin.String = status_example // kotlin.String | Filter by the status of the review
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
try {
    val result : Curation = apiInstance.accountInstitutionCurations(groupId, articleId, status, limit, offset)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#accountInstitutionCurations")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#accountInstitutionCurations")
    e.printStackTrace()
}
```

### Parameters
| **groupId** | **kotlin.Long**| Filter by the group ID | [optional] |
| **articleId** | **kotlin.Long**| Retrieve the reviews for this article | [optional] |
| **status** | **kotlin.String**| Filter by the status of the review | [optional] [enum: pending, approved, rejected, closed] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**Curation**](Curation.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="customFieldsList"></a>
# **customFieldsList**
> kotlin.collections.List&lt;ShortCustomField&gt; customFieldsList(groupId)

Private account institution group custom fields

Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val groupId : kotlin.Long = 789 // kotlin.Long | Group_id
try {
    val result : kotlin.collections.List<ShortCustomField> = apiInstance.customFieldsList(groupId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#customFieldsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#customFieldsList")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **groupId** | **kotlin.Long**| Group_id | [optional] |

### Return type

[**kotlin.collections.List&lt;ShortCustomField&gt;**](ShortCustomField.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="customFieldsUpload"></a>
# **customFieldsUpload**
> kotlin.Any customFieldsUpload(customFieldId, externalFile)

Custom fields values files upload

Uploads a CSV containing values for a specific custom field of type &lt;b&gt;dropdown_large_list&lt;/b&gt;. More details in the &lt;a href&#x3D;\&quot;#custom_fields\&quot;&gt;Custom Fields section&lt;/a&gt;

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val customFieldId : kotlin.Long = 789 // kotlin.Long | Custom field identifier
val externalFile : java.io.File = BINARY_DATA_HERE // java.io.File | CSV file to be uploaded
try {
    val result : kotlin.Any = apiInstance.customFieldsUpload(customFieldId, externalFile)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#customFieldsUpload")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#customFieldsUpload")
    e.printStackTrace()
}
```

### Parameters
| **customFieldId** | **kotlin.Long**| Custom field identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **externalFile** | **java.io.File**| CSV file to be uploaded | [optional] |

### Return type

[**kotlin.Any**](kotlin.Any.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

<a id="getAccountInstitutionCurationComments"></a>
# **getAccountInstitutionCurationComments**
> CurationComment getAccountInstitutionCurationComments(curationId, limit, offset)

Institution Curation Review Comments

Retrieve a certain curation review&#39;s comments.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val curationId : kotlin.Long = 789 // kotlin.Long | ID of the curation
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
try {
    val result : CurationComment = apiInstance.getAccountInstitutionCurationComments(curationId, limit, offset)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#getAccountInstitutionCurationComments")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#getAccountInstitutionCurationComments")
    e.printStackTrace()
}
```

### Parameters
| **curationId** | **kotlin.Long**| ID of the curation | |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**CurationComment**](CurationComment.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="institutionArticles"></a>
# **institutionArticles**
> kotlin.collections.List&lt;Article&gt; institutionArticles(institutionStringId, resourceId, filename)

Public Institution Articles

Returns a list of articles belonging to the institution

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val institutionStringId : kotlin.String = institutionStringId_example // kotlin.String | 
val resourceId : kotlin.String = resourceId_example // kotlin.String | 
val filename : kotlin.String = filename_example // kotlin.String | 
try {
    val result : kotlin.collections.List<Article> = apiInstance.institutionArticles(institutionStringId, resourceId, filename)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#institutionArticles")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#institutionArticles")
    e.printStackTrace()
}
```

### Parameters
| **institutionStringId** | **kotlin.String**|  | |
| **resourceId** | **kotlin.String**|  | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **filename** | **kotlin.String**|  | |

### Return type

[**kotlin.collections.List&lt;Article&gt;**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="institutionHrfeedUpload"></a>
# **institutionHrfeedUpload**
> ResponseMessage institutionHrfeedUpload(hrfeed)

Private Institution HRfeed Upload

More info in the &lt;a href&#x3D;\&quot;#hr_feed\&quot;&gt;HR Feed section&lt;/a&gt;

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val hrfeed : java.io.File = BINARY_DATA_HERE // java.io.File | You can find an example in the Hr Feed section
try {
    val result : ResponseMessage = apiInstance.institutionHrfeedUpload(hrfeed)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#institutionHrfeedUpload")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#institutionHrfeedUpload")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **hrfeed** | **java.io.File**| You can find an example in the Hr Feed section | [optional] |

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

<a id="postAccountInstitutionCurationComments"></a>
# **postAccountInstitutionCurationComments**
> postAccountInstitutionCurationComments(curationId, curationComment)

POST Institution Curation Review Comment

Add a new comment to the review.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val curationId : kotlin.Long = 789 // kotlin.Long | ID of the curation
val curationComment : CurationCommentCreate =  // CurationCommentCreate | The content/value of the comment.
try {
    apiInstance.postAccountInstitutionCurationComments(curationId, curationComment)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#postAccountInstitutionCurationComments")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#postAccountInstitutionCurationComments")
    e.printStackTrace()
}
```

### Parameters
| **curationId** | **kotlin.Long**| ID of the curation | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **curationComment** | [**CurationCommentCreate**](CurationCommentCreate.md)| The content/value of the comment. | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateAccountInstitutionUser"></a>
# **privateAccountInstitutionUser**
> User privateAccountInstitutionUser(accountId)

Private Account Institution User

Retrieve institution user information using the account_id

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val accountId : kotlin.Long = 789 // kotlin.Long | Account identifier the user is associated to
try {
    val result : User = apiInstance.privateAccountInstitutionUser(accountId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateAccountInstitutionUser")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateAccountInstitutionUser")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **accountId** | **kotlin.Long**| Account identifier the user is associated to | |

### Return type

[**User**](User.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCategoriesList"></a>
# **privateCategoriesList**
> kotlin.collections.List&lt;CategoryList&gt; privateCategoriesList()

Private Account Categories

List institution categories (including parent Categories)

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
try {
    val result : kotlin.collections.List<CategoryList> = apiInstance.privateCategoriesList()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateCategoriesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateCategoriesList")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**kotlin.collections.List&lt;CategoryList&gt;**](CategoryList.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateGroupEmbargoOptionsDetails"></a>
# **privateGroupEmbargoOptionsDetails**
> kotlin.collections.List&lt;GroupEmbargoOptions&gt; privateGroupEmbargoOptionsDetails(groupId)

Private Account Institution Group Embargo Options

Account institution group embargo options details

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val groupId : kotlin.Long = 789 // kotlin.Long | Group identifier
try {
    val result : kotlin.collections.List<GroupEmbargoOptions> = apiInstance.privateGroupEmbargoOptionsDetails(groupId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateGroupEmbargoOptionsDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateGroupEmbargoOptionsDetails")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **groupId** | **kotlin.Long**| Group identifier | |

### Return type

[**kotlin.collections.List&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateInstitutionAccount"></a>
# **privateInstitutionAccount**
> Account privateInstitutionAccount(accountId)

Private Institution Account information

Private Institution Account information

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val accountId : kotlin.Long = 789 // kotlin.Long | Account identifier the user is associated to
try {
    val result : Account = apiInstance.privateInstitutionAccount(accountId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionAccount")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionAccount")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **accountId** | **kotlin.Long**| Account identifier the user is associated to | |

### Return type

[**Account**](Account.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateInstitutionAccountGroupRoleDelete"></a>
# **privateInstitutionAccountGroupRoleDelete**
> privateInstitutionAccountGroupRoleDelete(accountId, groupId, roleId)

Delete Institution Account Group Role

Delete Institution Account Group Role

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val accountId : kotlin.Long = 789 // kotlin.Long | Account identifier for which to remove the role
val groupId : kotlin.Long = 789 // kotlin.Long | Group identifier for which to remove the role
val roleId : kotlin.Long = 789 // kotlin.Long | Role identifier
try {
    apiInstance.privateInstitutionAccountGroupRoleDelete(accountId, groupId, roleId)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionAccountGroupRoleDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionAccountGroupRoleDelete")
    e.printStackTrace()
}
```

### Parameters
| **accountId** | **kotlin.Long**| Account identifier for which to remove the role | |
| **groupId** | **kotlin.Long**| Group identifier for which to remove the role | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **roleId** | **kotlin.Long**| Role identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateInstitutionAccountGroupRoles"></a>
# **privateInstitutionAccountGroupRoles**
> kotlin.Any privateInstitutionAccountGroupRoles(accountId)

List Institution Account Group Roles

List Institution Account Group Roles

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val accountId : kotlin.Long = 789 // kotlin.Long | Account identifier the user is associated to
try {
    val result : kotlin.Any = apiInstance.privateInstitutionAccountGroupRoles(accountId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionAccountGroupRoles")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionAccountGroupRoles")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **accountId** | **kotlin.Long**| Account identifier the user is associated to | |

### Return type

[**kotlin.Any**](kotlin.Any.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateInstitutionAccountGroupRolesCreate"></a>
# **privateInstitutionAccountGroupRolesCreate**
> privateInstitutionAccountGroupRolesCreate(accountId, account)

Add Institution Account Group Roles

Add Institution Account Group Roles

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val accountId : kotlin.Long = 789 // kotlin.Long | Account identifier the user is associated to
val account : kotlin.Any = Object // kotlin.Any | Account description
try {
    apiInstance.privateInstitutionAccountGroupRolesCreate(accountId, account)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionAccountGroupRolesCreate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionAccountGroupRolesCreate")
    e.printStackTrace()
}
```

### Parameters
| **accountId** | **kotlin.Long**| Account identifier the user is associated to | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **account** | **kotlin.Any**| Account description | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateInstitutionAccountsCreate"></a>
# **privateInstitutionAccountsCreate**
> AccountCreateResponse privateInstitutionAccountsCreate(account)

Create new Institution Account

Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val account : AccountCreate =  // AccountCreate | Account description
try {
    val result : AccountCreateResponse = apiInstance.privateInstitutionAccountsCreate(account)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionAccountsCreate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionAccountsCreate")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **account** | [**AccountCreate**](AccountCreate.md)| Account description | |

### Return type

[**AccountCreateResponse**](AccountCreateResponse.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateInstitutionAccountsList"></a>
# **privateInstitutionAccountsList**
> kotlin.collections.List&lt;ShortAccount&gt; privateInstitutionAccountsList(page, pageSize, limit, offset, isActive, institutionUserId, email, idLte, idGte)

Private Account Institution Accounts

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
val isActive : kotlin.Long = 789 // kotlin.Long | Filter by active status
val institutionUserId : kotlin.String = institutionUserId_example // kotlin.String | Filter by institution_user_id
val email : kotlin.String = email_example // kotlin.String | Filter by email
val idLte : kotlin.Long = 789 // kotlin.Long | Retrieve accounts with an ID lower or equal to the specified value
val idGte : kotlin.Long = 789 // kotlin.Long | Retrieve accounts with an ID greater or equal to the specified value
try {
    val result : kotlin.collections.List<ShortAccount> = apiInstance.privateInstitutionAccountsList(page, pageSize, limit, offset, isActive, institutionUserId, email, idLte, idGte)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionAccountsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionAccountsList")
    e.printStackTrace()
}
```

### Parameters
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **isActive** | **kotlin.Long**| Filter by active status | [optional] |
| **institutionUserId** | **kotlin.String**| Filter by institution_user_id | [optional] |
| **email** | **kotlin.String**| Filter by email | [optional] |
| **idLte** | **kotlin.Long**| Retrieve accounts with an ID lower or equal to the specified value | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **idGte** | **kotlin.Long**| Retrieve accounts with an ID greater or equal to the specified value | [optional] |

### Return type

[**kotlin.collections.List&lt;ShortAccount&gt;**](ShortAccount.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateInstitutionAccountsSearch"></a>
# **privateInstitutionAccountsSearch**
> kotlin.collections.List&lt;ShortAccount&gt; privateInstitutionAccountsSearch(search)

Private Account Institution Accounts Search

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val search : InstitutionAccountsSearch =  // InstitutionAccountsSearch | Search Parameters
try {
    val result : kotlin.collections.List<ShortAccount> = apiInstance.privateInstitutionAccountsSearch(search)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionAccountsSearch")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionAccountsSearch")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**InstitutionAccountsSearch**](InstitutionAccountsSearch.md)| Search Parameters | |

### Return type

[**kotlin.collections.List&lt;ShortAccount&gt;**](ShortAccount.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateInstitutionAccountsUpdate"></a>
# **privateInstitutionAccountsUpdate**
> privateInstitutionAccountsUpdate(accountId, account)

Update Institution Account

Update Institution Account

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val accountId : kotlin.Long = 789 // kotlin.Long | Account identifier the user is associated to
val account : AccountUpdate =  // AccountUpdate | Account description
try {
    apiInstance.privateInstitutionAccountsUpdate(accountId, account)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionAccountsUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionAccountsUpdate")
    e.printStackTrace()
}
```

### Parameters
| **accountId** | **kotlin.Long**| Account identifier the user is associated to | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **account** | [**AccountUpdate**](AccountUpdate.md)| Account description | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateInstitutionArticles"></a>
# **privateInstitutionArticles**
> kotlin.collections.List&lt;Article&gt; privateInstitutionArticles(page, pageSize, limit, offset, order, orderDirection, publishedSince, modifiedSince, status, resourceDoi, itemType, group)

Private Institution Articles

Get Articles from own institution. User must be administrator of the institution

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
val order : kotlin.String = order_example // kotlin.String | The field by which to order. Default varies by endpoint/resource.
val orderDirection : kotlin.String = orderDirection_example // kotlin.String | 
val publishedSince : kotlin.String = publishedSince_example // kotlin.String | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
val modifiedSince : kotlin.String = modifiedSince_example // kotlin.String | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
val status : kotlin.Long = 789 // kotlin.Long | only return collections with this status
val resourceDoi : kotlin.String = resourceDoi_example // kotlin.String | only return collections with this resource_doi
val itemType : kotlin.Long = 789 // kotlin.Long | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
val group : kotlin.Long = 789 // kotlin.Long | only return articles from this group
try {
    val result : kotlin.collections.List<Article> = apiInstance.privateInstitutionArticles(page, pageSize, limit, offset, order, orderDirection, publishedSince, modifiedSince, status, resourceDoi, itemType, group)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionArticles")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionArticles")
    e.printStackTrace()
}
```

### Parameters
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **kotlin.String**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date] [enum: published_date, modified_date] |
| **orderDirection** | **kotlin.String**|  | [optional] [default to desc] [enum: asc, desc] |
| **publishedSince** | **kotlin.String**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **modifiedSince** | **kotlin.String**| Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **status** | **kotlin.Long**| only return collections with this status | [optional] |
| **resourceDoi** | **kotlin.String**| only return collections with this resource_doi | [optional] |
| **itemType** | **kotlin.Long**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **group** | **kotlin.Long**| only return articles from this group | [optional] |

### Return type

[**kotlin.collections.List&lt;Article&gt;**](Article.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateInstitutionDetails"></a>
# **privateInstitutionDetails**
> Institution privateInstitutionDetails()

Private Account Institutions

Account institution details

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
try {
    val result : Institution = apiInstance.privateInstitutionDetails()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionDetails")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Institution**](Institution.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateInstitutionEmbargoOptionsDetails"></a>
# **privateInstitutionEmbargoOptionsDetails**
> kotlin.collections.List&lt;GroupEmbargoOptions&gt; privateInstitutionEmbargoOptionsDetails()

Private Account Institution embargo options

Account institution embargo options details

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
try {
    val result : kotlin.collections.List<GroupEmbargoOptions> = apiInstance.privateInstitutionEmbargoOptionsDetails()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionEmbargoOptionsDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionEmbargoOptionsDetails")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**kotlin.collections.List&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateInstitutionGroupsList"></a>
# **privateInstitutionGroupsList**
> kotlin.collections.List&lt;Group&gt; privateInstitutionGroupsList()

Private Account Institution Groups

Returns the groups for which the account has administrative privileges (assigned and inherited).

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
try {
    val result : kotlin.collections.List<Group> = apiInstance.privateInstitutionGroupsList()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionGroupsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionGroupsList")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**kotlin.collections.List&lt;Group&gt;**](Group.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateInstitutionRolesList"></a>
# **privateInstitutionRolesList**
> kotlin.collections.List&lt;Role&gt; privateInstitutionRolesList()

Private Account Institution Roles

Returns the roles available for groups and the institution group.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = InstitutionsApi()
try {
    val result : kotlin.collections.List<Role> = apiInstance.privateInstitutionRolesList()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling InstitutionsApi#privateInstitutionRolesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling InstitutionsApi#privateInstitutionRolesList")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**kotlin.collections.List&lt;Role&gt;**](Role.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

