
# CollectionPrivateLinkCreator

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **expiresDate** | **kotlin.String** | Date when this private link should expire - optional. By default private links expire in 365 days. |  [optional] |



