
# LocationWarningsUpdate

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **location** | **kotlin.String** | Url for entity |  |
| **warnings** | **kotlin.collections.List&lt;kotlin.String&gt;** | Issues encountered during the operation |  |



