
# FundingSearch

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **searchFor** | **kotlin.String** | Search term |  [optional] |



