# SymplecticApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**symplecticAccountArticles**](SymplecticApi.md#symplecticAccountArticles) | **GET** /symplectic/accounts/{external_user_id}/articles | Get articles for a specific account |
| [**symplecticAccountsIds**](SymplecticApi.md#symplecticAccountsIds) | **GET** /symplectic/accounts | Get changed accounts for Symplectic Elements |
| [**symplecticArticle**](SymplecticApi.md#symplecticArticle) | **GET** /symplectic/articles/{article_id} | Get article details for Symplectic Elements |
| [**symplecticChangedArticles**](SymplecticApi.md#symplecticChangedArticles) | **GET** /symplectic/articles | Get changed articles for Symplectic Elements |
| [**symplecticUserId**](SymplecticApi.md#symplecticUserId) | **GET** /symplectic/users/{user_id} | Get institutional user ID for a user |


<a id="symplecticAccountArticles"></a>
# **symplecticAccountArticles**
> kotlin.collections.List&lt;kotlin.Any&gt; symplecticAccountArticles(externalUserId, offset, limit, status, isEmbargoed)

Get articles for a specific account

Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id).

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = SymplecticApi()
val externalUserId : kotlin.String = externalUserId_example // kotlin.String | External user ID (symplectic_user_id or institution_user_id)
val offset : kotlin.Int = 56 // kotlin.Int | Number of results to skip for pagination
val limit : kotlin.Int = 56 // kotlin.Int | Maximum number of results to return
val status : kotlin.String = status_example // kotlin.String | Filter by article status
val isEmbargoed : kotlin.String = isEmbargoed_example // kotlin.String | Filter by embargo status
try {
    val result : kotlin.collections.List<kotlin.Any> = apiInstance.symplecticAccountArticles(externalUserId, offset, limit, status, isEmbargoed)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SymplecticApi#symplecticAccountArticles")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SymplecticApi#symplecticAccountArticles")
    e.printStackTrace()
}
```

### Parameters
| **externalUserId** | **kotlin.String**| External user ID (symplectic_user_id or institution_user_id) | |
| **offset** | **kotlin.Int**| Number of results to skip for pagination | [optional] [default to 0] |
| **limit** | **kotlin.Int**| Maximum number of results to return | [optional] [default to 10] |
| **status** | **kotlin.String**| Filter by article status | [optional] [enum: public, private, draft] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **isEmbargoed** | **kotlin.String**| Filter by embargo status | [optional] [enum: true, false] |

### Return type

[**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="symplecticAccountsIds"></a>
# **symplecticAccountsIds**
> kotlin.collections.List&lt;SymplecticAccountsIds200ResponseInner&gt; symplecticAccountsIds(since)

Get changed accounts for Symplectic Elements

Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = SymplecticApi()
val since : kotlin.String = 2015-01-01 00:00:00 // kotlin.String | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
try {
    val result : kotlin.collections.List<SymplecticAccountsIds200ResponseInner> = apiInstance.symplecticAccountsIds(since)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SymplecticApi#symplecticAccountsIds")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SymplecticApi#symplecticAccountsIds")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **since** | **kotlin.String**| ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | |

### Return type

[**kotlin.collections.List&lt;SymplecticAccountsIds200ResponseInner&gt;**](SymplecticAccountsIds200ResponseInner.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="symplecticArticle"></a>
# **symplecticArticle**
> kotlin.Any symplecticArticle(articleId)

Get article details for Symplectic Elements

Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = SymplecticApi()
val articleId : kotlin.Int = 56 // kotlin.Int | Article ID
try {
    val result : kotlin.Any = apiInstance.symplecticArticle(articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SymplecticApi#symplecticArticle")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SymplecticApi#symplecticArticle")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Int**| Article ID | |

### Return type

[**kotlin.Any**](kotlin.Any.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="symplecticChangedArticles"></a>
# **symplecticChangedArticles**
> kotlin.collections.List&lt;kotlin.Any&gt; symplecticChangedArticles(since, offset, limit, status, isEmbargoed)

Get changed articles for Symplectic Elements

Returns a list of articles for Symplectic Elements integration to synchronize article data.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = SymplecticApi()
val since : kotlin.String = 2015-01-01 00:00:00 // kotlin.String | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
val offset : kotlin.Int = 56 // kotlin.Int | Number of results to skip for pagination
val limit : kotlin.Int = 56 // kotlin.Int | Maximum number of results to return
val status : kotlin.String = status_example // kotlin.String | Filter by article status
val isEmbargoed : kotlin.String = isEmbargoed_example // kotlin.String | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type
try {
    val result : kotlin.collections.List<kotlin.Any> = apiInstance.symplecticChangedArticles(since, offset, limit, status, isEmbargoed)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SymplecticApi#symplecticChangedArticles")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SymplecticApi#symplecticChangedArticles")
    e.printStackTrace()
}
```

### Parameters
| **since** | **kotlin.String**| ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | |
| **offset** | **kotlin.Int**| Number of results to skip for pagination | [optional] [default to 0] |
| **limit** | **kotlin.Int**| Maximum number of results to return | [optional] [default to 10] |
| **status** | **kotlin.String**| Filter by article status | [optional] [enum: public, private, draft] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **isEmbargoed** | **kotlin.String**| Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type | [optional] [enum: true, false] |

### Return type

[**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="symplecticUserId"></a>
# **symplecticUserId**
> SymplecticUserId200Response symplecticUserId(userId)

Get institutional user ID for a user

Returns the institution user ID for a given user within the authenticated account&#39;s institution.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = SymplecticApi()
val userId : kotlin.Int = 56 // kotlin.Int | User ID
try {
    val result : SymplecticUserId200Response = apiInstance.symplecticUserId(userId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SymplecticApi#symplecticUserId")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SymplecticApi#symplecticUserId")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **userId** | **kotlin.Int**| User ID | |

### Return type

[**SymplecticUserId200Response**](SymplecticUserId200Response.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

