
# Institution

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | Institution id |  |
| **name** | **kotlin.String** | Institution name |  |



