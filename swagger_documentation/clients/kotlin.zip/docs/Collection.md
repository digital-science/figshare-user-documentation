
# Collection

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** | Collection id |  |
| **title** | **kotlin.String** | Collection title |  |
| **doi** | **kotlin.String** | Collection DOI |  |
| **handle** | **kotlin.String** | Collection Handle |  |
| **url** | **kotlin.String** | Api endpoint |  |
| **timeline** | [**Timeline**](Timeline.md) |  |  |



