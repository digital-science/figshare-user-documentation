
# ProjectComplete

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **funding** | **kotlin.String** | Project funding |  |
| **fundingList** | [**kotlin.collections.List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Project funding information |  |
| **description** | **kotlin.String** | Project description |  |
| **collaborators** | [**kotlin.collections.List&lt;Collaborator&gt;**](Collaborator.md) | List of project collaborators |  |
| **customFields** | [**kotlin.collections.List&lt;CustomArticleField&gt;**](CustomArticleField.md) | Project custom fields |  |
| **modifiedDate** | **kotlin.String** | Date when project was last modified |  |
| **createdDate** | **kotlin.String** | Date when project was created |  |
| **url** | **kotlin.String** | Api endpoint |  |
| **id** | **kotlin.Long** | Project id |  |
| **title** | **kotlin.String** | Project title |  |



