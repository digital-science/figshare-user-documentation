
# PrivateProjectArticle

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **files** | [**kotlin.collections.List&lt;PublicFile&gt;**](PublicFile.md) | List of up to 10 article files. |  |
| **embargoOptions** | [**kotlin.collections.List&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md) | List of embargo options |  |
| **customFields** | [**kotlin.collections.List&lt;CustomArticleField&gt;**](CustomArticleField.md) | List of custom fields values |  |
| **accountId** | **kotlin.Long** | ID of the account owning the article |  |
| **downloadDisabled** | **kotlin.Boolean** | If true, downloading of files for this article is disabled |  |
| **authors** | [**kotlin.collections.List&lt;Author&gt;**](Author.md) | List of authors |  |
| **figshareUrl** | **kotlin.String** | Article public url |  |
| **curationStatus** | **kotlin.String** | Curation status of the article |  |
| **citation** | **kotlin.String** | Article citation |  |
| **confidentialReason** | **kotlin.String** | Confidentiality reason |  |
| **isConfidential** | **kotlin.Boolean** | Article Confidentiality |  |
| **propertySize** | **kotlin.Long** | Article size |  |
| **funding** | **kotlin.String** | Article funding |  |
| **fundingList** | [**kotlin.collections.List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Article funding information |  |
| **tags** | **kotlin.collections.List&lt;kotlin.String&gt;** | List of article tags. Keywords can be used instead |  |
| **keywords** | **kotlin.collections.List&lt;kotlin.String&gt;** | List of article keywords. Tags can be used instead |  |
| **version** | **kotlin.Long** | Article version |  |
| **isMetadataRecord** | **kotlin.Boolean** | True if article has no files |  |
| **metadataReason** | **kotlin.String** | Article metadata reason |  |
| **status** | **kotlin.String** | Article status |  |
| **description** | **kotlin.String** | Article description |  |
| **isEmbargoed** | **kotlin.Boolean** | True if article is embargoed |  |
| **isPublic** | **kotlin.Boolean** | True if article is published |  |
| **createdDate** | **kotlin.String** | Date when article was created |  |
| **hasLinkedFile** | **kotlin.Boolean** | True if any files are linked to the article |  |
| **categories** | [**kotlin.collections.List&lt;Category&gt;**](Category.md) | List of categories selected for the article |  |
| **license** | [**License**](License.md) |  |  |
| **embargoTitle** | **kotlin.String** | Title for embargo |  |
| **embargoReason** | **kotlin.String** | Reason for embargo |  |
| **references** | **kotlin.collections.List&lt;kotlin.String&gt;** | List of references |  |
| **id** | **kotlin.Long** | Unique identifier for article |  |
| **title** | **kotlin.String** | Title of article |  |
| **doi** | **kotlin.String** | DOI |  |
| **handle** | **kotlin.String** | Handle |  |
| **url** | **kotlin.String** | Api endpoint for article |  |
| **urlPublicHtml** | **kotlin.String** | Public site endpoint for article |  |
| **urlPublicApi** | **kotlin.String** | Public Api endpoint for article |  |
| **urlPrivateHtml** | **kotlin.String** | Private site endpoint for article |  |
| **urlPrivateApi** | **kotlin.String** | Private Api endpoint for article |  |
| **timeline** | [**Timeline**](Timeline.md) |  |  |
| **thumb** | **kotlin.String** | Thumbnail image |  |
| **definedType** | **kotlin.Long** | Type of article identifier |  |
| **definedTypeName** | **kotlin.String** | Name of the article type identifier |  |
| **resourceDoi** | **kotlin.String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. |  |
| **resourceTitle** | **kotlin.String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. |  |
| **relatedMaterials** | [**kotlin.collections.List&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. |  [optional] |



