
# ProjectPrivate

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **role** | [**inline**](#Role) | Role inside this project |  |
| **storage** | [**inline**](#Storage) | Project storage type |  |
| **url** | **kotlin.String** | Api endpoint |  |
| **id** | **kotlin.Long** | Project id |  |
| **title** | **kotlin.String** | Project title |  |
| **createdDate** | **kotlin.String** | Date when project was created |  |
| **modifiedDate** | **kotlin.String** | Date when project was last modified |  |


<a id="Role"></a>
## Enum: role
| Name | Value |
| ---- | ----- |
| role | Owner, Collaborator, Viewer |


<a id="Storage"></a>
## Enum: storage
| Name | Value |
| ---- | ----- |
| storage | individual, group |



