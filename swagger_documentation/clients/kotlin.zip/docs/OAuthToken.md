
# OAuthToken

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **accessToken** | **kotlin.String** | The OAuth access token |  |
| **tokenType** | **kotlin.String** | The type of token issued |  |
| **expiresIn** | **kotlin.Long** | Token expiration time in seconds |  |
| **token** | **kotlin.String** | The OAuth access token |  [optional] |
| **refreshToken** | **kotlin.String** | The refresh token (only provided for certain grant types) |  [optional] |
| **scope** | **kotlin.String** | The scope of the access token |  [optional] |



