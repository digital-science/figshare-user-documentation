
# ArticlesCreator

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **articles** | **kotlin.collections.List&lt;kotlin.Long&gt;** | List of article ids |  |



