
# ProjectNote

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | Project note id |  |
| **userId** | **kotlin.Long** | User who wrote the note |  |
| **&#x60;abstract&#x60;** | **kotlin.String** | Note Abstract - short/truncated content |  |
| **userName** | **kotlin.String** | Username of the one who wrote the note |  |
| **createdDate** | **kotlin.String** | Date when note was created |  |
| **modifiedDate** | **kotlin.String** | Date when note was last modified |  |



