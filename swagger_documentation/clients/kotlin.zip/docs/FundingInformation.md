
# FundingInformation

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | Funding id |  |
| **title** | **kotlin.String** | The funding name |  |
| **grantCode** | **kotlin.String** | The grant code |  |
| **funderName** | **kotlin.String** | Funder&#39;s name |  |
| **isUserDefined** | **kotlin.Long** | Return 1 whether the grant has been introduced manually, 0 otherwise |  |
| **url** | **kotlin.String** | The grant url |  |



