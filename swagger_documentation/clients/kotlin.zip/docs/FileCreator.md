
# FileCreator

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **link** | **kotlin.String** | Url for an existing file that will not be uploaded to Figshare |  [optional] |
| **md5** | **kotlin.String** | MD5 sum pre-computed on client side. |  [optional] |
| **name** | **kotlin.String** | File name including the extension; can be omitted only for linked files. |  [optional] |
| **propertySize** | **kotlin.Long** | File size in bytes; can be omitted only for linked files. |  [optional] |
| **folderPath** | **kotlin.String** | Unix-style directory path of the file; only available if the file was uploaded within a folder structure |  [optional] |



