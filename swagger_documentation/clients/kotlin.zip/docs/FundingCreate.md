
# FundingCreate

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | A funding ID as returned by the Funding Search endpoint |  [optional] |
| **title** | **kotlin.String** | The title of the new user created funding |  [optional] |



