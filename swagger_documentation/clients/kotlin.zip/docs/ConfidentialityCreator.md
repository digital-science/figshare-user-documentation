
# ConfidentialityCreator

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **reason** | **kotlin.String** | Reason for confidentiality |  |



