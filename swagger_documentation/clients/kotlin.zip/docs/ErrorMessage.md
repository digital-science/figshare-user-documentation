
# ErrorMessage

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **code** | **kotlin.Long** | A machine friendly error code, used by the dev team to identify the error. |  [optional] |
| **message** | **kotlin.String** | A human friendly message explaining the error. |  [optional] |



