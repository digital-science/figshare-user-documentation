
# Resource

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.String** | ID of resource item |  [optional] |
| **title** | **kotlin.String** | Title of resource item |  [optional] |
| **doi** | **kotlin.String** | DOI of resource item |  [optional] |
| **link** | **kotlin.String** | Link of resource item |  [optional] |
| **status** | **kotlin.String** | Status of resource item |  [optional] |
| **version** | **kotlin.Long** | Version of resource item |  [optional] |



