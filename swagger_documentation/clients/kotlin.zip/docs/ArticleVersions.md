
# ArticleVersions

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **version** | **kotlin.Long** | Version number |  |
| **url** | **kotlin.String** | Api endpoint for the item version |  |



