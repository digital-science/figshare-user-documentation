
# AltmetricInstitution

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** | Institution id |  |
| **name** | **kotlin.String** | Institution name |  |
| **customDomain** | **kotlin.String** | Custom domain for the institution |  [optional] |



