
# CurationDetail

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **item** | [**ArticleComplete**](ArticleComplete.md) |  |  |
| **id** | **kotlin.Int** | The review id |  |
| **groupId** | **kotlin.Int** | The group in which the article is present. |  |
| **accountId** | **kotlin.Int** | The ID of the account of the owner of the article of this review. |  |
| **assignedTo** | **kotlin.Int** | The ID of the account to which this review is assigned. |  |
| **articleId** | **kotlin.Int** | The ID of the article of this review. |  |
| **version** | **kotlin.Int** | The Version number of the article in review. |  |
| **commentsCount** | **kotlin.Int** | The number of comments in the review. |  |
| **status** | [**inline**](#Status) | The status of the review. |  |
| **createdDate** | **kotlin.String** | The creation date of the review. |  |
| **modifiedDate** | **kotlin.String** | The date the review has been modified. |  |
| **requestNumber** | **kotlin.Int** | The request number of the review. |  |
| **resolutionComment** | **kotlin.String** | The resolution comment of the review. |  |


<a id="Status"></a>
## Enum: status
| Name | Value |
| ---- | ----- |
| status | pending, approved, rejected, closed |



