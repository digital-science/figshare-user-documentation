
# ArticleUnpublishData

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **reason** | **kotlin.String** | Reason of article unpublishing |  |



