# OtherApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**categoriesList**](OtherApi.md#categoriesList) | **GET** /categories | Public Categories |
| [**fileDownload**](OtherApi.md#fileDownload) | **GET** /file/download/{file_id} | Public File Download |
| [**itemTypesList**](OtherApi.md#itemTypesList) | **GET** /item_types | Item Types |
| [**licensesList**](OtherApi.md#licensesList) | **GET** /licenses | Public Licenses |
| [**privateAccount**](OtherApi.md#privateAccount) | **GET** /account | Private Account information |
| [**privateFundingSearch**](OtherApi.md#privateFundingSearch) | **POST** /account/funding/search | Search Funding |
| [**privateLicensesList**](OtherApi.md#privateLicensesList) | **GET** /account/licenses | Private Account Licenses |


<a id="categoriesList"></a>
# **categoriesList**
> kotlin.collections.List&lt;CategoryList&gt; categoriesList()

Public Categories

Returns a list of public categories

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = OtherApi()
try {
    val result : kotlin.collections.List<CategoryList> = apiInstance.categoriesList()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling OtherApi#categoriesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling OtherApi#categoriesList")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**kotlin.collections.List&lt;CategoryList&gt;**](CategoryList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="fileDownload"></a>
# **fileDownload**
> fileDownload(fileId)

Public File Download

Starts the download of a file

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = OtherApi()
val fileId : kotlin.Int = 56 // kotlin.Int | 
try {
    apiInstance.fileDownload(fileId)
} catch (e: ClientException) {
    println("4xx response calling OtherApi#fileDownload")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling OtherApi#fileDownload")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **fileId** | **kotlin.Int**|  | |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a id="itemTypesList"></a>
# **itemTypesList**
> kotlin.collections.List&lt;ItemType&gt; itemTypesList(groupId)

Item Types

Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = OtherApi()
val groupId : kotlin.Int = 56 // kotlin.Int | Identifier of the group for which the item types are requested
try {
    val result : kotlin.collections.List<ItemType> = apiInstance.itemTypesList(groupId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling OtherApi#itemTypesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling OtherApi#itemTypesList")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **groupId** | **kotlin.Int**| Identifier of the group for which the item types are requested | [optional] [default to 0] |

### Return type

[**kotlin.collections.List&lt;ItemType&gt;**](ItemType.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="licensesList"></a>
# **licensesList**
> kotlin.collections.List&lt;License&gt; licensesList()

Public Licenses

Returns a list of public licenses

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = OtherApi()
try {
    val result : kotlin.collections.List<License> = apiInstance.licensesList()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling OtherApi#licensesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling OtherApi#licensesList")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**kotlin.collections.List&lt;License&gt;**](License.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateAccount"></a>
# **privateAccount**
> Account privateAccount()

Private Account information

Account information for token/personal token

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = OtherApi()
try {
    val result : Account = apiInstance.privateAccount()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling OtherApi#privateAccount")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling OtherApi#privateAccount")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Account**](Account.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateFundingSearch"></a>
# **privateFundingSearch**
> kotlin.collections.List&lt;FundingInformation&gt; privateFundingSearch(search)

Search Funding

Search for fundings

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = OtherApi()
val search : FundingSearch =  // FundingSearch | Search Parameters
try {
    val result : kotlin.collections.List<FundingInformation> = apiInstance.privateFundingSearch(search)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling OtherApi#privateFundingSearch")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling OtherApi#privateFundingSearch")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**FundingSearch**](FundingSearch.md)| Search Parameters | [optional] |

### Return type

[**kotlin.collections.List&lt;FundingInformation&gt;**](FundingInformation.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateLicensesList"></a>
# **privateLicensesList**
> kotlin.collections.List&lt;License&gt; privateLicensesList()

Private Account Licenses

This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account&#39;s institution.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = OtherApi()
try {
    val result : kotlin.collections.List<License> = apiInstance.privateLicensesList()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling OtherApi#privateLicensesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling OtherApi#privateLicensesList")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**kotlin.collections.List&lt;License&gt;**](License.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

