
# CollectionSearch

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **resourceDoi** | **kotlin.String** | Only return collections with this resource_doi |  [optional] |
| **doi** | **kotlin.String** | Only return collections with this doi |  [optional] |
| **handle** | **kotlin.String** | Only return collections with this handle |  [optional] |
| **order** | [**inline**](#Order) | The field by which to order. |  [optional] |
| **searchFor** | **kotlin.String** | Search term |  [optional] |
| **page** | **kotlin.Long** | Page number. Used for pagination with page_size |  [optional] |
| **pageSize** | **kotlin.Long** | The number of results included on a page. Used for pagination with page |  [optional] |
| **limit** | **kotlin.Long** | Number of results included on a page. Used for pagination with query |  [optional] |
| **offset** | **kotlin.Long** | Where to start the listing (the offset of the first result). Used for pagination with limit |  [optional] |
| **orderDirection** | [**inline**](#OrderDirection) | Direction of ordering |  [optional] |
| **institution** | **kotlin.Int** | only return collections from this institution |  [optional] |
| **publishedSince** | **kotlin.String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ |  [optional] |
| **modifiedSince** | **kotlin.String** | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ |  [optional] |
| **group** | **kotlin.Int** | only return collections from this group |  [optional] |


<a id="Order"></a>
## Enum: order
| Name | Value |
| ---- | ----- |
| order | created_date, published_date, modified_date, views, shares, cites |


<a id="OrderDirection"></a>
## Enum: order_direction
| Name | Value |
| ---- | ----- |
| orderDirection | asc, desc |



