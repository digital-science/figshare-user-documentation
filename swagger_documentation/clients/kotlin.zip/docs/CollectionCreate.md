
# CollectionCreate

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **title** | **kotlin.String** | Title of collection |  |
| **funding** | **kotlin.String** | Grant number or funding authority |  [optional] |
| **fundingList** | [**kotlin.collections.List&lt;FundingCreate&gt;**](FundingCreate.md) | Funding creation / update items |  [optional] |
| **description** | **kotlin.String** | The collection description. In a publisher case, usually this is the remote collection description |  [optional] |
| **articles** | **kotlin.collections.List&lt;kotlin.Int&gt;** | List of articles to be associated with the collection |  [optional] |
| **authors** | [**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md) | List of authors to be associated with the collection. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint. |  [optional] |
| **categories** | **kotlin.collections.List&lt;kotlin.Long&gt;** | List of category ids to be associated with the collection(e.g [1, 23, 33, 66]) |  [optional] |
| **categoriesBySourceId** | **kotlin.collections.List&lt;kotlin.String&gt;** | List of category source ids to be associated with the collection, supersedes the categories property |  [optional] |
| **tags** | **kotlin.collections.List&lt;kotlin.String&gt;** | List of tags to be associated with the collection. Keywords can be used instead |  [optional] |
| **keywords** | **kotlin.collections.List&lt;kotlin.String&gt;** | List of tags to be associated with the collection. Tags can be used instead |  [optional] |
| **references** | **kotlin.collections.List&lt;kotlin.String&gt;** | List of links to be associated with the collection (e.g [\&quot;http://link1\&quot;, \&quot;http://link2\&quot;, \&quot;http://link3\&quot;]) |  [optional] |
| **relatedMaterials** | [**kotlin.collections.List&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. |  [optional] |
| **customFields** | [**kotlin.Any**](.md) | List of key, values pairs to be associated with the collection |  [optional] |
| **customFieldsList** | [**kotlin.collections.List&lt;CustomArticleFieldAdd&gt;**](CustomArticleFieldAdd.md) | List of custom fields values, supersedes custom_fields parameter |  [optional] |
| **doi** | **kotlin.String** | Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system. |  [optional] |
| **handle** | **kotlin.String** | Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system. |  [optional] |
| **resourceId** | **kotlin.String** | Not applicable to regular users. In a publisher case, this is the publisher article id |  [optional] |
| **resourceDoi** | **kotlin.String** | Not applicable to regular users. In a publisher case, this is the publisher article DOI. |  [optional] |
| **resourceLink** | **kotlin.String** | Not applicable to regular users. In a publisher case, this is the publisher article link |  [optional] |
| **resourceTitle** | **kotlin.String** | Not applicable to regular users. In a publisher case, this is the publisher article title. |  [optional] |
| **resourceVersion** | **kotlin.Int** | Not applicable to regular users. In a publisher case, this is the publisher article version |  [optional] |
| **groupId** | **kotlin.Long** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups |  [optional] |
| **timeline** | [**TimelineUpdate**](TimelineUpdate.md) |  |  [optional] |



