
# Collaborator

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **roleName** | **kotlin.String** | Collaborator role |  |
| **userId** | **kotlin.Int** | Collaborator id |  |
| **name** | **kotlin.String** | Collaborator name |  |



