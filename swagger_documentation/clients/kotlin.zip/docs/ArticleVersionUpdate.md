
# ArticleVersionUpdate

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **supplementaryFields** | [**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md) | List of supplementary fields to be associated with the article version |  [optional] |
| **internalMetadata** | [**kotlin.Any**](.md) | List of supplementary fields to be associated with the article version |  [optional] |



