
# CreateOAuthToken

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **clientId** | **kotlin.String** |  |  |
| **clientSecret** | **kotlin.String** |  |  |
| **grantType** | [**inline**](#GrantType) |  |  |
| **code** | **kotlin.String** | Required if grant_type is &#39;authorization_code&#39; |  [optional] |
| **refreshToken** | **kotlin.String** | Required if grant_type is &#39;refresh_token&#39; |  [optional] |
| **username** | **kotlin.String** | Required if grant_type is &#39;password&#39; |  [optional] |
| **password** | **kotlin.String** | Required if grant_type is &#39;password&#39; |  [optional] |


<a id="GrantType"></a>
## Enum: grant_type
| Name | Value |
| ---- | ----- |
| grantType | authorization_code, refresh_token, password, client_credentials |



