
# Project

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **url** | **kotlin.String** | Api endpoint |  |
| **id** | **kotlin.Long** | Project id |  |
| **title** | **kotlin.String** | Project title |  |
| **createdDate** | **kotlin.String** | Date when project was created |  |
| **modifiedDate** | **kotlin.String** | Date when project was last modified |  |



