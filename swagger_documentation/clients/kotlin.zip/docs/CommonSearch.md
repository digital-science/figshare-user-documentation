
# CommonSearch

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **searchFor** | **kotlin.String** | Search term |  [optional] |
| **page** | **kotlin.Int** | Page number. Used for pagination with page_size |  [optional] |
| **pageSize** | **kotlin.Int** | The number of results included on a page. Used for pagination with page |  [optional] |
| **limit** | **kotlin.Int** | Number of results included on a page. Used for pagination with query |  [optional] |
| **offset** | **kotlin.Int** | Where to start the listing (the offset of the first result). Used for pagination with limit |  [optional] |
| **orderDirection** | [**inline**](#OrderDirection) | Direction of ordering |  [optional] |
| **institution** | **kotlin.Int** | only return collections from this institution |  [optional] |
| **publishedSince** | **kotlin.String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ |  [optional] |
| **modifiedSince** | **kotlin.String** | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ |  [optional] |
| **group** | **kotlin.Int** | only return collections from this group |  [optional] |


<a id="OrderDirection"></a>
## Enum: order_direction
| Name | Value |
| ---- | ----- |
| orderDirection | asc, desc |



