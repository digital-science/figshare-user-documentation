
# PrivateAuthorsSearch

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **searchFor** | **kotlin.String** | Search term |  [optional] |
| **page** | **kotlin.Int** | Page number. Used for pagination with page_size |  [optional] |
| **pageSize** | **kotlin.Int** | The number of results included on a page. Used for pagination with page |  [optional] |
| **limit** | **kotlin.Int** | Number of results included on a page. Used for pagination with query |  [optional] |
| **offset** | **kotlin.Int** | Where to start the listing (the offset of the first result). Used for pagination with limit |  [optional] |
| **institutionId** | **kotlin.Int** | Return only authors associated to this institution |  [optional] |
| **orcid** | **kotlin.String** | Orcid of author |  [optional] |
| **groupId** | **kotlin.Int** | Return only authors in this group or subgroups of the group |  [optional] |
| **isActive** | **kotlin.Boolean** | Return only active authors if True |  [optional] |
| **isPublic** | **kotlin.Boolean** | Return only authors that have published items if True |  [optional] |



