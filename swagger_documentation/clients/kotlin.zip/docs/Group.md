
# Group

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | Group id |  |
| **name** | **kotlin.String** | Group name |  |
| **resourceId** | **kotlin.String** | Group resource id |  |
| **parentId** | **kotlin.Long** | Parent group if any |  |
| **associationCriteria** | **kotlin.String** | HR code associated with group, if code exists |  |



