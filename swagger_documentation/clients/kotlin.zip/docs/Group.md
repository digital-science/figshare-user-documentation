
# Group

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** | Group id |  |
| **name** | **kotlin.String** | Group name |  |
| **resourceId** | **kotlin.String** | Group resource id |  |
| **parentId** | **kotlin.Int** | Parent group if any |  |
| **associationCriteria** | **kotlin.String** | HR code associated with group, if code exists |  |



