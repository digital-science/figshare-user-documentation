# CollectionsApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**collectionArticles**](CollectionsApi.md#collectionArticles) | **GET** /collections/{collection_id}/articles | Public Collection Articles |
| [**collectionDetails**](CollectionsApi.md#collectionDetails) | **GET** /collections/{collection_id} | Collection details |
| [**collectionVersionDetails**](CollectionsApi.md#collectionVersionDetails) | **GET** /collections/{collection_id}/versions/{version_id} | Collection Version details |
| [**collectionVersions**](CollectionsApi.md#collectionVersions) | **GET** /collections/{collection_id}/versions | Collection Versions list |
| [**collectionsList**](CollectionsApi.md#collectionsList) | **GET** /collections | Public Collections |
| [**collectionsSearch**](CollectionsApi.md#collectionsSearch) | **POST** /collections/search | Public Collections Search |
| [**privateCollectionArticleDelete**](CollectionsApi.md#privateCollectionArticleDelete) | **DELETE** /account/collections/{collection_id}/articles/{article_id} | Delete collection article |
| [**privateCollectionArticlesAdd**](CollectionsApi.md#privateCollectionArticlesAdd) | **POST** /account/collections/{collection_id}/articles | Add collection articles |
| [**privateCollectionArticlesList**](CollectionsApi.md#privateCollectionArticlesList) | **GET** /account/collections/{collection_id}/articles | List collection articles |
| [**privateCollectionArticlesReplace**](CollectionsApi.md#privateCollectionArticlesReplace) | **PUT** /account/collections/{collection_id}/articles | Replace collection articles |
| [**privateCollectionAuthorDelete**](CollectionsApi.md#privateCollectionAuthorDelete) | **DELETE** /account/collections/{collection_id}/authors/{author_id} | Delete collection author |
| [**privateCollectionAuthorsAdd**](CollectionsApi.md#privateCollectionAuthorsAdd) | **POST** /account/collections/{collection_id}/authors | Add collection authors |
| [**privateCollectionAuthorsList**](CollectionsApi.md#privateCollectionAuthorsList) | **GET** /account/collections/{collection_id}/authors | List collection authors |
| [**privateCollectionAuthorsReplace**](CollectionsApi.md#privateCollectionAuthorsReplace) | **PUT** /account/collections/{collection_id}/authors | Replace collection authors |
| [**privateCollectionCategoriesAdd**](CollectionsApi.md#privateCollectionCategoriesAdd) | **POST** /account/collections/{collection_id}/categories | Add collection categories |
| [**privateCollectionCategoriesList**](CollectionsApi.md#privateCollectionCategoriesList) | **GET** /account/collections/{collection_id}/categories | List collection categories |
| [**privateCollectionCategoriesReplace**](CollectionsApi.md#privateCollectionCategoriesReplace) | **PUT** /account/collections/{collection_id}/categories | Replace collection categories |
| [**privateCollectionCategoryDelete**](CollectionsApi.md#privateCollectionCategoryDelete) | **DELETE** /account/collections/{collection_id}/categories/{category_id} | Delete collection category |
| [**privateCollectionCreate**](CollectionsApi.md#privateCollectionCreate) | **POST** /account/collections | Create collection |
| [**privateCollectionDelete**](CollectionsApi.md#privateCollectionDelete) | **DELETE** /account/collections/{collection_id} | Delete collection |
| [**privateCollectionDetails**](CollectionsApi.md#privateCollectionDetails) | **GET** /account/collections/{collection_id} | Collection details |
| [**privateCollectionPatch**](CollectionsApi.md#privateCollectionPatch) | **PATCH** /account/collections/{collection_id} | Partially update collection |
| [**privateCollectionPrivateLinkCreate**](CollectionsApi.md#privateCollectionPrivateLinkCreate) | **POST** /account/collections/{collection_id}/private_links | Create collection private link |
| [**privateCollectionPrivateLinkDelete**](CollectionsApi.md#privateCollectionPrivateLinkDelete) | **DELETE** /account/collections/{collection_id}/private_links/{link_id} | Disable private link |
| [**privateCollectionPrivateLinkDetails**](CollectionsApi.md#privateCollectionPrivateLinkDetails) | **GET** /account/collections/{collection_id}/private_links/{link_id} | View collection private link |
| [**privateCollectionPrivateLinkUpdate**](CollectionsApi.md#privateCollectionPrivateLinkUpdate) | **PUT** /account/collections/{collection_id}/private_links/{link_id} | Update collection private link |
| [**privateCollectionPrivateLinksList**](CollectionsApi.md#privateCollectionPrivateLinksList) | **GET** /account/collections/{collection_id}/private_links | List collection private links |
| [**privateCollectionPublish**](CollectionsApi.md#privateCollectionPublish) | **POST** /account/collections/{collection_id}/publish | Private Collection Publish |
| [**privateCollectionReserveDoi**](CollectionsApi.md#privateCollectionReserveDoi) | **POST** /account/collections/{collection_id}/reserve_doi | Private Collection Reserve DOI |
| [**privateCollectionReserveHandle**](CollectionsApi.md#privateCollectionReserveHandle) | **POST** /account/collections/{collection_id}/reserve_handle | Private Collection Reserve Handle |
| [**privateCollectionResource**](CollectionsApi.md#privateCollectionResource) | **POST** /account/collections/{collection_id}/resource | Private Collection Resource |
| [**privateCollectionUpdate**](CollectionsApi.md#privateCollectionUpdate) | **PUT** /account/collections/{collection_id} | Update collection |
| [**privateCollectionsList**](CollectionsApi.md#privateCollectionsList) | **GET** /account/collections | Private Collections List |
| [**privateCollectionsSearch**](CollectionsApi.md#privateCollectionsSearch) | **POST** /account/collections/search | Private Collections Search |


<a id="collectionArticles"></a>
# **collectionArticles**
> kotlin.collections.List&lt;Article&gt; collectionArticles(collectionId, page, pageSize, limit, offset)

Public Collection Articles

Returns a list of public collection articles

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection Unique identifier
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
try {
    val result : kotlin.collections.List<Article> = apiInstance.collectionArticles(collectionId, page, pageSize, limit, offset)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#collectionArticles")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#collectionArticles")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection Unique identifier | |
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**kotlin.collections.List&lt;Article&gt;**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="collectionDetails"></a>
# **collectionDetails**
> CollectionComplete collectionDetails(collectionId)

Collection details

View a collection

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection Unique identifier
try {
    val result : CollectionComplete = apiInstance.collectionDetails(collectionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#collectionDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#collectionDetails")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collectionId** | **kotlin.Long**| Collection Unique identifier | |

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="collectionVersionDetails"></a>
# **collectionVersionDetails**
> CollectionComplete collectionVersionDetails(collectionId, versionId)

Collection Version details

View details for a certain version of a collection

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection Unique identifier
val versionId : kotlin.Long = 789 // kotlin.Long | Version Number
try {
    val result : CollectionComplete = apiInstance.collectionVersionDetails(collectionId, versionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#collectionVersionDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#collectionVersionDetails")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection Unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **versionId** | **kotlin.Long**| Version Number | |

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="collectionVersions"></a>
# **collectionVersions**
> kotlin.collections.List&lt;CollectionVersions&gt; collectionVersions(collectionId)

Collection Versions list

Returns a list of public collection Versions

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection Unique identifier
try {
    val result : kotlin.collections.List<CollectionVersions> = apiInstance.collectionVersions(collectionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#collectionVersions")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#collectionVersions")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collectionId** | **kotlin.Long**| Collection Unique identifier | |

### Return type

[**kotlin.collections.List&lt;CollectionVersions&gt;**](CollectionVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="collectionsList"></a>
# **collectionsList**
> kotlin.collections.List&lt;Collection&gt; collectionsList(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, modifiedSince, group, resourceDoi, doi, handle)

Public Collections

Returns a list of public collections

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val xCursor : java.util.UUID = 38400000-8cf0-11bd-b23e-10b96e4ef00d // java.util.UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
val order : kotlin.String = order_example // kotlin.String | The field by which to order. Default varies by endpoint/resource.
val orderDirection : kotlin.String = orderDirection_example // kotlin.String | 
val institution : kotlin.Long = 789 // kotlin.Long | only return collections from this institution
val publishedSince : kotlin.String = publishedSince_example // kotlin.String | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD
val modifiedSince : kotlin.String = modifiedSince_example // kotlin.String | Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD
val group : kotlin.Long = 789 // kotlin.Long | only return collections from this group
val resourceDoi : kotlin.String = resourceDoi_example // kotlin.String | only return collections with this resource_doi
val doi : kotlin.String = doi_example // kotlin.String | only return collections with this doi
val handle : kotlin.String = handle_example // kotlin.String | only return collections with this handle
try {
    val result : kotlin.collections.List<Collection> = apiInstance.collectionsList(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, modifiedSince, group, resourceDoi, doi, handle)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#collectionsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#collectionsList")
    e.printStackTrace()
}
```

### Parameters
| **xCursor** | **java.util.UUID**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **kotlin.String**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date] [enum: published_date, created_date, modified_date, views, shares, cites] |
| **orderDirection** | **kotlin.String**|  | [optional] [default to desc] [enum: asc, desc] |
| **institution** | **kotlin.Long**| only return collections from this institution | [optional] |
| **publishedSince** | **kotlin.String**| Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional] |
| **modifiedSince** | **kotlin.String**| Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD | [optional] |
| **group** | **kotlin.Long**| only return collections from this group | [optional] |
| **resourceDoi** | **kotlin.String**| only return collections with this resource_doi | [optional] |
| **doi** | **kotlin.String**| only return collections with this doi | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **handle** | **kotlin.String**| only return collections with this handle | [optional] |

### Return type

[**kotlin.collections.List&lt;Collection&gt;**](Collection.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="collectionsSearch"></a>
# **collectionsSearch**
> kotlin.collections.List&lt;Collection&gt; collectionsSearch(xCursor, search)

Public Collections Search

Returns a list of public collections

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val xCursor : java.util.UUID = 38400000-8cf0-11bd-b23e-10b96e4ef00d // java.util.UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
val search : CollectionSearch =  // CollectionSearch | Search Parameters
try {
    val result : kotlin.collections.List<Collection> = apiInstance.collectionsSearch(xCursor, search)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#collectionsSearch")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#collectionsSearch")
    e.printStackTrace()
}
```

### Parameters
| **xCursor** | **java.util.UUID**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**CollectionSearch**](CollectionSearch.md)| Search Parameters | [optional] |

### Return type

[**kotlin.collections.List&lt;Collection&gt;**](Collection.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionArticleDelete"></a>
# **privateCollectionArticleDelete**
> privateCollectionArticleDelete(collectionId, articleId)

Delete collection article

De-associate article from collection

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val articleId : kotlin.Long = 789 // kotlin.Long | Collection article unique identifier
try {
    apiInstance.privateCollectionArticleDelete(collectionId, articleId)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionArticleDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionArticleDelete")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Collection article unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionArticlesAdd"></a>
# **privateCollectionArticlesAdd**
> Location privateCollectionArticlesAdd(collectionId, articles)

Add collection articles

Associate new articles with the collection. This will add new articles to the list of already associated articles

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val articles : ArticlesCreator =  // ArticlesCreator | Articles list
try {
    val result : Location = apiInstance.privateCollectionArticlesAdd(collectionId, articles)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionArticlesAdd")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionArticlesAdd")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articles** | [**ArticlesCreator**](ArticlesCreator.md)| Articles list | |

### Return type

[**Location**](Location.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionArticlesList"></a>
# **privateCollectionArticlesList**
> kotlin.collections.List&lt;Article&gt; privateCollectionArticlesList(collectionId, page, pageSize, limit, offset)

List collection articles

List collection articles

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
try {
    val result : kotlin.collections.List<Article> = apiInstance.privateCollectionArticlesList(collectionId, page, pageSize, limit, offset)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionArticlesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionArticlesList")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**kotlin.collections.List&lt;Article&gt;**](Article.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionArticlesReplace"></a>
# **privateCollectionArticlesReplace**
> privateCollectionArticlesReplace(collectionId, articles)

Replace collection articles

Associate new articles with the collection. This will remove all already associated articles and add these new ones

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val articles : ArticlesCreator =  // ArticlesCreator | Articles List
try {
    apiInstance.privateCollectionArticlesReplace(collectionId, articles)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionArticlesReplace")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionArticlesReplace")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articles** | [**ArticlesCreator**](ArticlesCreator.md)| Articles List | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionAuthorDelete"></a>
# **privateCollectionAuthorDelete**
> privateCollectionAuthorDelete(collectionId, authorId)

Delete collection author

Delete collection author

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val authorId : kotlin.Long = 789 // kotlin.Long | Collection Author unique identifier
try {
    apiInstance.privateCollectionAuthorDelete(collectionId, authorId)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionAuthorDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionAuthorDelete")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **authorId** | **kotlin.Long**| Collection Author unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionAuthorsAdd"></a>
# **privateCollectionAuthorsAdd**
> Location privateCollectionAuthorsAdd(collectionId, authors)

Add collection authors

Associate new authors with the collection. This will add new authors to the list of already associated authors

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val authors : AuthorsCreator =  // AuthorsCreator | List of authors
try {
    val result : Location = apiInstance.privateCollectionAuthorsAdd(collectionId, authors)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionAuthorsAdd")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionAuthorsAdd")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **authors** | [**AuthorsCreator**](AuthorsCreator.md)| List of authors | |

### Return type

[**Location**](Location.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionAuthorsList"></a>
# **privateCollectionAuthorsList**
> kotlin.collections.List&lt;Author&gt; privateCollectionAuthorsList(collectionId)

List collection authors

List collection authors

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
try {
    val result : kotlin.collections.List<Author> = apiInstance.privateCollectionAuthorsList(collectionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionAuthorsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionAuthorsList")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collectionId** | **kotlin.Long**| Collection unique identifier | |

### Return type

[**kotlin.collections.List&lt;Author&gt;**](Author.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionAuthorsReplace"></a>
# **privateCollectionAuthorsReplace**
> privateCollectionAuthorsReplace(collectionId, authors)

Replace collection authors

Associate new authors with the collection. This will remove all already associated authors and add these new ones

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val authors : AuthorsCreator =  // AuthorsCreator | List of authors
try {
    apiInstance.privateCollectionAuthorsReplace(collectionId, authors)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionAuthorsReplace")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionAuthorsReplace")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **authors** | [**AuthorsCreator**](AuthorsCreator.md)| List of authors | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionCategoriesAdd"></a>
# **privateCollectionCategoriesAdd**
> Location privateCollectionCategoriesAdd(collectionId, categories)

Add collection categories

Associate new categories with the collection. This will add new categories to the list of already associated categories

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val categories : CategoriesCreator =  // CategoriesCreator | Categories list
try {
    val result : Location = apiInstance.privateCollectionCategoriesAdd(collectionId, categories)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionCategoriesAdd")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionCategoriesAdd")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **categories** | [**CategoriesCreator**](CategoriesCreator.md)| Categories list | |

### Return type

[**Location**](Location.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionCategoriesList"></a>
# **privateCollectionCategoriesList**
> kotlin.collections.List&lt;Category&gt; privateCollectionCategoriesList(collectionId)

List collection categories

List collection categories

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
try {
    val result : kotlin.collections.List<Category> = apiInstance.privateCollectionCategoriesList(collectionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionCategoriesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionCategoriesList")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collectionId** | **kotlin.Long**| Collection unique identifier | |

### Return type

[**kotlin.collections.List&lt;Category&gt;**](Category.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionCategoriesReplace"></a>
# **privateCollectionCategoriesReplace**
> privateCollectionCategoriesReplace(collectionId, categories)

Replace collection categories

Associate new categories with the collection. This will remove all already associated categories and add these new ones

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val categories : CategoriesCreator =  // CategoriesCreator | Categories list
try {
    apiInstance.privateCollectionCategoriesReplace(collectionId, categories)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionCategoriesReplace")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionCategoriesReplace")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **categories** | [**CategoriesCreator**](CategoriesCreator.md)| Categories list | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionCategoryDelete"></a>
# **privateCollectionCategoryDelete**
> privateCollectionCategoryDelete(collectionId, categoryId)

Delete collection category

De-associate category from collection

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val categoryId : kotlin.Long = 789 // kotlin.Long | Collection category unique identifier
try {
    apiInstance.privateCollectionCategoryDelete(collectionId, categoryId)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionCategoryDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionCategoryDelete")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **categoryId** | **kotlin.Long**| Collection category unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionCreate"></a>
# **privateCollectionCreate**
> LocationWarnings privateCollectionCreate(collection)

Create collection

Create a new Collection by sending collection information

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collection : CollectionCreate =  // CollectionCreate | Collection description
try {
    val result : LocationWarnings = apiInstance.privateCollectionCreate(collection)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionCreate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionCreate")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection** | [**CollectionCreate**](CollectionCreate.md)| Collection description | |

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionDelete"></a>
# **privateCollectionDelete**
> privateCollectionDelete(collectionId)

Delete collection

Delete n collection

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection Unique identifier
try {
    apiInstance.privateCollectionDelete(collectionId)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionDelete")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collectionId** | **kotlin.Long**| Collection Unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionDetails"></a>
# **privateCollectionDetails**
> CollectionCompletePrivate privateCollectionDetails(collectionId)

Collection details

View a collection

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection Unique identifier
try {
    val result : CollectionCompletePrivate = apiInstance.privateCollectionDetails(collectionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionDetails")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collectionId** | **kotlin.Long**| Collection Unique identifier | |

### Return type

[**CollectionCompletePrivate**](CollectionCompletePrivate.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionPatch"></a>
# **privateCollectionPatch**
> LocationWarningsUpdate privateCollectionPatch(collectionId, collection)

Partially update collection

Partially update a collection by sending only the fields to change.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection Unique identifier
val collection : CollectionUpdate =  // CollectionUpdate | Subset of collection fields to update
try {
    val result : LocationWarningsUpdate = apiInstance.privateCollectionPatch(collectionId, collection)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionPatch")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionPatch")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection Unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection** | [**CollectionUpdate**](CollectionUpdate.md)| Subset of collection fields to update | |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionPrivateLinkCreate"></a>
# **privateCollectionPrivateLinkCreate**
> PrivateLinkResponse privateCollectionPrivateLinkCreate(collectionId, privateLink)

Create collection private link

Create new private link

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val privateLink : CollectionPrivateLinkCreator =  // CollectionPrivateLinkCreator | 
try {
    val result : PrivateLinkResponse = apiInstance.privateCollectionPrivateLinkCreate(collectionId, privateLink)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionPrivateLinkCreate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionPrivateLinkCreate")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **privateLink** | [**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md)|  | [optional] |

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionPrivateLinkDelete"></a>
# **privateCollectionPrivateLinkDelete**
> privateCollectionPrivateLinkDelete(collectionId, linkId)

Disable private link

Disable/delete private link for this collection

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val linkId : kotlin.String = linkId_example // kotlin.String | Private link token
try {
    apiInstance.privateCollectionPrivateLinkDelete(collectionId, linkId)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionPrivateLinkDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionPrivateLinkDelete")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **linkId** | **kotlin.String**| Private link token | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionPrivateLinkDetails"></a>
# **privateCollectionPrivateLinkDetails**
> PrivateLink privateCollectionPrivateLinkDetails(collectionId, linkId)

View collection private link

View existing private link for this collection

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val linkId : kotlin.String = linkId_example // kotlin.String | Private link token
try {
    val result : PrivateLink = apiInstance.privateCollectionPrivateLinkDetails(collectionId, linkId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionPrivateLinkDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionPrivateLinkDetails")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **linkId** | **kotlin.String**| Private link token | |

### Return type

[**PrivateLink**](PrivateLink.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionPrivateLinkUpdate"></a>
# **privateCollectionPrivateLinkUpdate**
> privateCollectionPrivateLinkUpdate(collectionId, linkId, privateLink)

Update collection private link

Update existing private link for this collection

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val linkId : kotlin.String = linkId_example // kotlin.String | Private link token
val privateLink : CollectionPrivateLinkCreator =  // CollectionPrivateLinkCreator | 
try {
    apiInstance.privateCollectionPrivateLinkUpdate(collectionId, linkId, privateLink)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionPrivateLinkUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionPrivateLinkUpdate")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| **linkId** | **kotlin.String**| Private link token | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **privateLink** | [**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md)|  | [optional] |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionPrivateLinksList"></a>
# **privateCollectionPrivateLinksList**
> kotlin.collections.List&lt;PrivateLink&gt; privateCollectionPrivateLinksList(collectionId)

List collection private links

List article private links

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
try {
    val result : kotlin.collections.List<PrivateLink> = apiInstance.privateCollectionPrivateLinksList(collectionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionPrivateLinksList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionPrivateLinksList")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collectionId** | **kotlin.Long**| Collection unique identifier | |

### Return type

[**kotlin.collections.List&lt;PrivateLink&gt;**](PrivateLink.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionPublish"></a>
# **privateCollectionPublish**
> Location privateCollectionPublish(collectionId)

Private Collection Publish

When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection Unique identifier
try {
    val result : Location = apiInstance.privateCollectionPublish(collectionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionPublish")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionPublish")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collectionId** | **kotlin.Long**| Collection Unique identifier | |

### Return type

[**Location**](Location.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionReserveDoi"></a>
# **privateCollectionReserveDoi**
> CollectionDOI privateCollectionReserveDoi(collectionId)

Private Collection Reserve DOI

Reserve DOI for collection

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection Unique identifier
try {
    val result : CollectionDOI = apiInstance.privateCollectionReserveDoi(collectionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionReserveDoi")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionReserveDoi")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collectionId** | **kotlin.Long**| Collection Unique identifier | |

### Return type

[**CollectionDOI**](CollectionDOI.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionReserveHandle"></a>
# **privateCollectionReserveHandle**
> CollectionHandle privateCollectionReserveHandle(collectionId)

Private Collection Reserve Handle

Reserve Handle for collection

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection Unique identifier
try {
    val result : CollectionHandle = apiInstance.privateCollectionReserveHandle(collectionId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionReserveHandle")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionReserveHandle")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collectionId** | **kotlin.Long**| Collection Unique identifier | |

### Return type

[**CollectionHandle**](CollectionHandle.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionResource"></a>
# **privateCollectionResource**
> Location privateCollectionResource(collectionId, resource)

Private Collection Resource

Edit collection resource data.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection unique identifier
val resource : Resource =  // Resource | Resource data
try {
    val result : Location = apiInstance.privateCollectionResource(collectionId, resource)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionResource")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionResource")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **resource** | [**Resource**](Resource.md)| Resource data | |

### Return type

[**Location**](Location.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionUpdate"></a>
# **privateCollectionUpdate**
> LocationWarningsUpdate privateCollectionUpdate(collectionId, collection)

Update collection

Update a collection by passing full body parameters.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val collectionId : kotlin.Long = 789 // kotlin.Long | Collection Unique identifier
val collection : CollectionUpdate =  // CollectionUpdate | Collection description
try {
    val result : LocationWarningsUpdate = apiInstance.privateCollectionUpdate(collectionId, collection)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionUpdate")
    e.printStackTrace()
}
```

### Parameters
| **collectionId** | **kotlin.Long**| Collection Unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection** | [**CollectionUpdate**](CollectionUpdate.md)| Collection description | |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateCollectionsList"></a>
# **privateCollectionsList**
> kotlin.collections.List&lt;Collection&gt; privateCollectionsList(page, pageSize, limit, offset, order, orderDirection)

Private Collections List

List private collections

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
val order : kotlin.String = order_example // kotlin.String | The field by which to order. Default varies by endpoint/resource.
val orderDirection : kotlin.String = orderDirection_example // kotlin.String | 
try {
    val result : kotlin.collections.List<Collection> = apiInstance.privateCollectionsList(page, pageSize, limit, offset, order, orderDirection)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionsList")
    e.printStackTrace()
}
```

### Parameters
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **kotlin.String**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date] [enum: published_date, modified_date, views, shares, cites] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **orderDirection** | **kotlin.String**|  | [optional] [default to desc] [enum: asc, desc] |

### Return type

[**kotlin.collections.List&lt;Collection&gt;**](Collection.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateCollectionsSearch"></a>
# **privateCollectionsSearch**
> kotlin.collections.List&lt;Collection&gt; privateCollectionsSearch(search)

Private Collections Search

Returns a list of private Collections

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = CollectionsApi()
val search : PrivateCollectionSearch =  // PrivateCollectionSearch | Search Parameters
try {
    val result : kotlin.collections.List<Collection> = apiInstance.privateCollectionsSearch(search)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CollectionsApi#privateCollectionsSearch")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CollectionsApi#privateCollectionsSearch")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**PrivateCollectionSearch**](PrivateCollectionSearch.md)| Search Parameters | |

### Return type

[**kotlin.collections.List&lt;Collection&gt;**](Collection.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

