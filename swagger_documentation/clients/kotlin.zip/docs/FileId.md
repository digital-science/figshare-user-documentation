
# FileId

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **fileId** | **kotlin.Int** | File ID |  [optional] |



