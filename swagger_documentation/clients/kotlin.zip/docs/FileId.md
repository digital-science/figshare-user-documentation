
# FileId

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **fileId** | **kotlin.Long** | File ID |  [optional] |



