
# TimelineUpdate

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **firstOnline** | **kotlin.String** | Online posted date |  [optional] |
| **publisherPublication** | **kotlin.String** | Publish date |  [optional] |
| **publisherAcceptance** | **kotlin.String** | Date when the item was accepted for publication |  [optional] |



