
# ProfileUpdateDataPersonalProfilesInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **label** | **kotlin.String** | Label for the personal profile link |  [optional] |
| **url** | **kotlin.String** | URL for the personal profile link |  [optional] |



