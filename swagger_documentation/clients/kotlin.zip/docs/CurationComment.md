
# CurationComment

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | The ID of the comment. |  |
| **accountId** | **kotlin.Long** | The ID of the account which generated this comment. |  |
| **type** | [**inline**](#Type) | The ID of the account which generated this comment. |  |
| **text** | **kotlin.String** | The value/content of the comment. |  |
| **createdDate** | **kotlin.String** | The creation date of the comment. |  |
| **modifiedDate** | **kotlin.String** | The date the comment has been modified. |  |


<a id="Type"></a>
## Enum: type
| Name | Value |
| ---- | ----- |
| type | comment, approved, rejected, closed |



