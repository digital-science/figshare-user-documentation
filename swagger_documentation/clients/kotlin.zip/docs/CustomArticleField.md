
# CustomArticleField

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** | Custom  metadata name |  |
| **&#x60;value&#x60;** | [**kotlin.Any**](.md) | Custom metadata value (can be either a string or an array of strings) |  |
| **fieldType** | [**inline**](#FieldType) | Custom field type |  |
| **settings** | [**kotlin.Any**](.md) | Settings for the custom field |  |
| **order** | **kotlin.Long** | Order of the custom field |  |
| **isMandatory** | **kotlin.Boolean** | Whether the field is mandatory or not |  |


<a id="FieldType"></a>
## Enum: field_type
| Name | Value |
| ---- | ----- |
| fieldType | text, textarea, dropdown, url, email, date, dropdown_large_list |



