
# AccountUpdate

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **groupId** | **kotlin.Int** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups |  |
| **isActive** | **kotlin.Boolean** | Is account active |  |



