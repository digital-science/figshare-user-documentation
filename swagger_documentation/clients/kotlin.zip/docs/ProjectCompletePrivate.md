
# ProjectCompletePrivate

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **funding** | **kotlin.String** | Project funding |  |
| **fundingList** | [**kotlin.collections.List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Project funding information |  |
| **description** | **kotlin.String** | Project description |  |
| **collaborators** | [**kotlin.collections.List&lt;Collaborator&gt;**](Collaborator.md) | List of project collaborators |  |
| **quota** | **kotlin.Long** | Project quota |  |
| **usedQuota** | **kotlin.Long** | Project used quota |  |
| **createdDate** | **kotlin.String** | Date when project was created |  |
| **modifiedDate** | **kotlin.String** | Date when project was last modified |  |
| **usedQuotaPrivate** | **kotlin.Long** | Project private quota used |  |
| **usedQuotaPublic** | **kotlin.Long** | Project public quota used |  |
| **groupId** | **kotlin.Long** | Group of project if any |  |
| **accountId** | **kotlin.Long** | ID of the account owning the project |  |
| **customFields** | [**kotlin.collections.List&lt;ShortCustomField&gt;**](ShortCustomField.md) | Collection custom fields |  |
| **role** | [**inline**](#Role) | Role inside this project |  |
| **storage** | [**inline**](#Storage) | Project storage type |  |
| **url** | **kotlin.String** | Api endpoint |  |
| **id** | **kotlin.Long** | Project id |  |
| **title** | **kotlin.String** | Project title |  |


<a id="Role"></a>
## Enum: role
| Name | Value |
| ---- | ----- |
| role | Owner, Collaborator, Viewer |


<a id="Storage"></a>
## Enum: storage
| Name | Value |
| ---- | ----- |
| storage | individual, group |



