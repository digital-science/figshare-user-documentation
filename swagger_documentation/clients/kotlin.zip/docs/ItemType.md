
# ItemType

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | The ID of the item type. |  |
| **name** | **kotlin.String** | The name of the item type |  |
| **stringId** | **kotlin.String** | The string identifier of the item type. |  |
| **icon** | **kotlin.String** | The string identifying the icon of the item type. |  |
| **publicDescription** | **kotlin.String** | The description of the item type. |  |
| **isSelectable** | **kotlin.Boolean** | The selectable status |  |
| **urlName** | **kotlin.String** | The URL name of the item type. |  |



