
# License

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **&#x60;value&#x60;** | **kotlin.Long** | License value |  |
| **name** | **kotlin.String** | License name |  |
| **url** | **kotlin.String** | License url |  |



