
# CollectionComplete

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **funding** | [**kotlin.collections.List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Collection funding information |  |
| **resourceId** | **kotlin.String** | Collection resource id |  |
| **resourceDoi** | **kotlin.String** | Collection resource doi |  |
| **resourceTitle** | **kotlin.String** | Collection resource title |  |
| **resourceLink** | **kotlin.String** | Collection resource link |  |
| **resourceVersion** | **kotlin.Long** | Collection resource version |  |
| **version** | **kotlin.Long** | Collection version |  |
| **description** | **kotlin.String** | Collection description |  |
| **categories** | [**kotlin.collections.List&lt;Category&gt;**](Category.md) | List of collection categories |  |
| **references** | **kotlin.collections.List&lt;kotlin.String&gt;** | List of collection references |  |
| **relatedMaterials** | [**kotlin.collections.List&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. |  |
| **tags** | **kotlin.collections.List&lt;kotlin.String&gt;** | List of collection tags. Keywords can be used instead |  |
| **keywords** | **kotlin.collections.List&lt;kotlin.String&gt;** | List of collection keywords. Tags can be used instead |  |
| **authors** | [**kotlin.collections.List&lt;Author&gt;**](Author.md) | List of collection authors |  |
| **institutionId** | **kotlin.Long** | Collection institution |  |
| **groupId** | **kotlin.Long** | Collection group |  |
| **articlesCount** | **kotlin.Long** | Number of articles in collection |  |
| **&#x60;public&#x60;** | **kotlin.Boolean** | True if collection is published |  |
| **citation** | **kotlin.String** | Collection citation |  |
| **customFields** | [**kotlin.collections.List&lt;CustomArticleField&gt;**](CustomArticleField.md) | Collection custom fields |  |
| **modifiedDate** | **kotlin.String** | Date when collection was last modified |  |
| **createdDate** | **kotlin.String** | Date when collection was created |  |
| **timeline** | [**Timeline**](Timeline.md) |  |  |
| **id** | **kotlin.Long** | Collection id |  |
| **title** | **kotlin.String** | Collection title |  |
| **doi** | **kotlin.String** | Collection DOI |  |
| **handle** | **kotlin.String** | Collection Handle |  |
| **url** | **kotlin.String** | Api endpoint |  |



