
# UploadInfo

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **token** | **kotlin.String** | token received after initializing a file upload |  [optional] |
| **md5** | **kotlin.String** | md5 provided on upload initialization |  [optional] |
| **propertySize** | **kotlin.Long** | size of file in bytes |  [optional] |
| **name** | **kotlin.String** | name of file on upload server |  [optional] |
| **status** | [**inline**](#Status) | Upload status |  [optional] |
| **parts** | [**kotlin.collections.List&lt;UploadFilePart&gt;**](UploadFilePart.md) | Uploads parts |  [optional] |


<a id="Status"></a>
## Enum: status
| Name | Value |
| ---- | ----- |
| status | PENDING, COMPLETED, ABORTED |



