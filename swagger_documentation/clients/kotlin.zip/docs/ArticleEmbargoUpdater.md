
# ArticleEmbargoUpdater

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **isEmbargoed** | **kotlin.Boolean** | Embargo status |  |
| **embargoDate** | **kotlin.String** | Date when the embargo expires and the article gets published, &#39;0&#39; value will set up permanent embargo |  |
| **embargoType** | [**inline**](#EmbargoType) | Embargo can be enabled at the article or the file level. Possible values: article, file |  |
| **embargoTitle** | **kotlin.String** | Title for embargo |  [optional] |
| **embargoReason** | **kotlin.String** | Reason for setting embargo |  [optional] |
| **embargoOptions** | [**kotlin.collections.List&lt;kotlin.Any&gt;**](kotlin.Any.md) | List of embargo permissions to be associated with the article. The list must contain &#x60;id&#x60; and can also contain &#x60;group_ids&#x60;(a field that only applies to &#39;logged_in&#39; permissions). The new list replaces old options in the database, and an empty list removes all permissions for this article. Administration permission has to be set up alone but logged in and IP range permissions can be set up together. |  [optional] |


<a id="EmbargoType"></a>
## Enum: embargo_type
| Name | Value |
| ---- | ----- |
| embargoType | article, file |



