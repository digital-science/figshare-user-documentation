
# Account

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | Account id |  |
| **firstName** | **kotlin.String** | First Name |  |
| **lastName** | **kotlin.String** | Last Name |  |
| **usedQuotaPrivate** | **kotlin.Long** | Account used private quota |  |
| **modifiedDate** | **kotlin.String** | Date of last account modification |  |
| **usedQuota** | **kotlin.Long** | Account total used quota |  |
| **createdDate** | **kotlin.String** | Date when account was created |  |
| **quota** | **kotlin.Long** | Account quota |  |
| **groupId** | **kotlin.Long** | Account group id |  |
| **institutionUserId** | **kotlin.String** | Account institution user id |  |
| **institutionId** | **kotlin.Long** | Account institution |  |
| **email** | **kotlin.String** | User email |  |
| **usedQuotaPublic** | **kotlin.Long** | Account public used quota |  |
| **pendingQuotaRequest** | **kotlin.Boolean** | True if a quota request is pending |  |
| **active** | **kotlin.Long** | Account activity status |  |
| **maximumFileSize** | **kotlin.Long** | Maximum upload size for account |  |
| **userId** | **kotlin.Long** | User id associated with account, useful for example for adding the account as an author to an item |  |
| **orcidId** | **kotlin.String** | ORCID iD associated to account |  |
| **symplecticUserId** | **kotlin.String** | Symplectic ID associated to account |  |



