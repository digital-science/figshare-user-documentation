# ProfilesApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**updateUserProfile**](ProfilesApi.md#updateUserProfile) | **PUT** /account/profile | Update public profile |
| [**updateUserProfilePicture**](ProfilesApi.md#updateUserProfilePicture) | **POST** /account/profile/{user_id}/picture | Update public profile picture |


<a id="updateUserProfile"></a>
# **updateUserProfile**
> kotlin.Any updateUserProfile(userProfileData, userId, institutionUserId)

Update public profile

Updates the fields of the user&#39;s public profile.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProfilesApi()
val userProfileData : ProfileUpdateData =  // ProfileUpdateData | 
val userId : kotlin.Long = 789 // kotlin.Long | User ID
val institutionUserId : kotlin.String = institutionUserId_example // kotlin.String | Institutional user ID
try {
    val result : kotlin.Any = apiInstance.updateUserProfile(userProfileData, userId, institutionUserId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProfilesApi#updateUserProfile")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProfilesApi#updateUserProfile")
    e.printStackTrace()
}
```

### Parameters
| **userProfileData** | [**ProfileUpdateData**](ProfileUpdateData.md)|  | |
| **userId** | **kotlin.Long**| User ID | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **institutionUserId** | **kotlin.String**| Institutional user ID | [optional] |

### Return type

[**kotlin.Any**](kotlin.Any.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="updateUserProfilePicture"></a>
# **updateUserProfilePicture**
> kotlin.Any updateUserProfilePicture(userId, profilePicture)

Update public profile picture

Updates the profile picture of the user&#39;s public profile.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProfilesApi()
val userId : kotlin.Long = 789 // kotlin.Long | User ID
val profilePicture : java.io.File = BINARY_DATA_HERE // java.io.File | User profile picture
try {
    val result : kotlin.Any = apiInstance.updateUserProfilePicture(userId, profilePicture)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProfilesApi#updateUserProfilePicture")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProfilesApi#updateUserProfilePicture")
    e.printStackTrace()
}
```

### Parameters
| **userId** | **kotlin.Long**| User ID | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **profilePicture** | **java.io.File**| User profile picture | |

### Return type

[**kotlin.Any**](kotlin.Any.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

