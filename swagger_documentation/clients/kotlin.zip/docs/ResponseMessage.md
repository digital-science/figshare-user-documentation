
# ResponseMessage

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **message** | **kotlin.String** | Response message text |  |



