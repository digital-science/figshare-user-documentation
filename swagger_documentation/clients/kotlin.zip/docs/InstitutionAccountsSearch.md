
# InstitutionAccountsSearch

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **searchFor** | **kotlin.String** | Search term |  [optional] |
| **isActive** | **kotlin.Long** | Filter by active status |  [optional] |
| **page** | **kotlin.Long** | Page number. Used for pagination with page_size |  [optional] |
| **pageSize** | **kotlin.Long** | The number of results included on a page. Used for pagination with page |  [optional] |
| **limit** | **kotlin.Long** | Number of results included on a page. Used for pagination with query |  [optional] |
| **offset** | **kotlin.Long** | Where to start the listing (the offset of the first result). Used for pagination with limit |  [optional] |
| **institutionUserId** | **kotlin.String** | filter by institution_user_id |  [optional] |
| **email** | **kotlin.String** | filter by email |  [optional] |



