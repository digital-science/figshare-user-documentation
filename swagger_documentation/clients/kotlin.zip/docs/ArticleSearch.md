
# ArticleSearch

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **resourceDoi** | **kotlin.String** | Only return articles with this resource_doi |  [optional] |
| **itemType** | **kotlin.Long** | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model |  [optional] |
| **doi** | **kotlin.String** | Only return articles with this doi |  [optional] |
| **handle** | **kotlin.String** | Only return articles with this handle |  [optional] |
| **projectId** | **kotlin.Long** | Only return articles in this project |  [optional] |
| **order** | [**inline**](#Order) | The field by which to order |  [optional] |
| **searchFor** | **kotlin.String** | Search term |  [optional] |
| **page** | **kotlin.Long** | Page number. Used for pagination with page_size |  [optional] |
| **pageSize** | **kotlin.Long** | The number of results included on a page. Used for pagination with page |  [optional] |
| **limit** | **kotlin.Long** | Number of results included on a page. Used for pagination with query |  [optional] |
| **offset** | **kotlin.Long** | Where to start the listing (the offset of the first result). Used for pagination with limit |  [optional] |
| **orderDirection** | [**inline**](#OrderDirection) | Direction of ordering |  [optional] |
| **institution** | **kotlin.Int** | only return collections from this institution |  [optional] |
| **publishedSince** | **kotlin.String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ |  [optional] |
| **modifiedSince** | **kotlin.String** | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ |  [optional] |
| **group** | **kotlin.Int** | only return collections from this group |  [optional] |


<a id="Order"></a>
## Enum: order
| Name | Value |
| ---- | ----- |
| order | created_date, published_date, modified_date, views, shares, downloads, cites |


<a id="OrderDirection"></a>
## Enum: order_direction
| Name | Value |
| ---- | ----- |
| orderDirection | asc, desc |



