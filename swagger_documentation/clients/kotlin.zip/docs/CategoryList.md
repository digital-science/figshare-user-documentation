
# CategoryList

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **isSelectable** | **kotlin.Boolean** | The selectable status |  |
| **hasChildren** | **kotlin.Boolean** | True if category has children |  |
| **parentId** | **kotlin.Long** | Parent category |  |
| **id** | **kotlin.Long** | Category id |  |
| **title** | **kotlin.String** | Category title |  |
| **path** | **kotlin.String** | Path to all ancestor ids |  |
| **sourceId** | **kotlin.String** | ID in original standard taxonomy |  |
| **taxonomyId** | **kotlin.Long** | Internal id of taxonomy the category is part of |  |



