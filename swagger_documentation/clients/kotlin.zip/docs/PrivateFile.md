
# PrivateFile

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **viewerType** | **kotlin.String** | File viewer type |  |
| **previewState** | **kotlin.String** | File preview state |  |
| **uploadUrl** | **kotlin.String** | Upload url for file |  |
| **uploadToken** | **kotlin.String** | Token for file upload |  |
| **isAttachedToPublicVersion** | **kotlin.Boolean** | True if the file is attached to a public item version |  |
| **id** | **kotlin.Long** | File id |  |
| **name** | **kotlin.String** | File name |  |
| **propertySize** | **kotlin.Long** | File size |  |
| **isLinkOnly** | **kotlin.Boolean** | True if file is hosted somewhere else |  |
| **downloadUrl** | **kotlin.String** | Url for file download |  |
| **suppliedMd5** | **kotlin.String** | File supplied md5 |  |
| **computedMd5** | **kotlin.String** | File computed md5 |  |
| **mimetype** | **kotlin.String** | MIME Type of the file, it defaults to an empty string |  [optional] |



