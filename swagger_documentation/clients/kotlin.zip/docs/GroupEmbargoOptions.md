
# GroupEmbargoOptions

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | Embargo option id |  |
| **type** | [**inline**](#Type) | Embargo permission type |  |
| **ipName** | **kotlin.String** | IP range name; value appears if type is ip_range |  |


<a id="Type"></a>
## Enum: type
| Name | Value |
| ---- | ----- |
| type | logged_in, ip_range, administrator |



