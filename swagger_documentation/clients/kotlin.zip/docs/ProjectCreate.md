
# ProjectCreate

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **title** | **kotlin.String** | The title for this project - mandatory. 3 - 1000 characters. |  |
| **description** | **kotlin.String** | Project description |  [optional] |
| **funding** | **kotlin.String** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. |  [optional] |
| **fundingList** | [**kotlin.collections.List&lt;FundingCreate&gt;**](FundingCreate.md) | Funding creation / update items |  [optional] |
| **groupId** | **kotlin.Long** | Only if project type is group. |  [optional] |
| **customFields** | [**kotlin.Any**](.md) | List of key, values pairs to be associated with the project |  [optional] |
| **customFieldsList** | [**kotlin.collections.List&lt;CustomArticleFieldAdd&gt;**](CustomArticleFieldAdd.md) | List of custom fields values, supersedes custom_fields parameter |  [optional] |



