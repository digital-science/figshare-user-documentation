# ProjectsApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**privateProjectArticleDelete**](ProjectsApi.md#privateProjectArticleDelete) | **DELETE** /account/projects/{project_id}/articles/{article_id} | Delete project article |
| [**privateProjectArticleDetails**](ProjectsApi.md#privateProjectArticleDetails) | **GET** /account/projects/{project_id}/articles/{article_id} | Project article details |
| [**privateProjectArticleFile**](ProjectsApi.md#privateProjectArticleFile) | **GET** /account/projects/{project_id}/articles/{article_id}/files/{file_id} | Project article file details |
| [**privateProjectArticleFiles**](ProjectsApi.md#privateProjectArticleFiles) | **GET** /account/projects/{project_id}/articles/{article_id}/files | Project article list files |
| [**privateProjectArticlesCreate**](ProjectsApi.md#privateProjectArticlesCreate) | **POST** /account/projects/{project_id}/articles | Create project article |
| [**privateProjectArticlesList**](ProjectsApi.md#privateProjectArticlesList) | **GET** /account/projects/{project_id}/articles | List project articles |
| [**privateProjectCollaboratorDelete**](ProjectsApi.md#privateProjectCollaboratorDelete) | **DELETE** /account/projects/{project_id}/collaborators/{user_id} | Remove project collaborator |
| [**privateProjectCollaboratorsInvite**](ProjectsApi.md#privateProjectCollaboratorsInvite) | **POST** /account/projects/{project_id}/collaborators | Invite project collaborators |
| [**privateProjectCollaboratorsList**](ProjectsApi.md#privateProjectCollaboratorsList) | **GET** /account/projects/{project_id}/collaborators | List project collaborators |
| [**privateProjectCreate**](ProjectsApi.md#privateProjectCreate) | **POST** /account/projects | Create project |
| [**privateProjectDelete**](ProjectsApi.md#privateProjectDelete) | **DELETE** /account/projects/{project_id} | Delete project |
| [**privateProjectDetails**](ProjectsApi.md#privateProjectDetails) | **GET** /account/projects/{project_id} | View project details |
| [**privateProjectLeave**](ProjectsApi.md#privateProjectLeave) | **POST** /account/projects/{project_id}/leave | Private Project Leave |
| [**privateProjectNote**](ProjectsApi.md#privateProjectNote) | **GET** /account/projects/{project_id}/notes/{note_id} | Project note details |
| [**privateProjectNoteDelete**](ProjectsApi.md#privateProjectNoteDelete) | **DELETE** /account/projects/{project_id}/notes/{note_id} | Delete project note |
| [**privateProjectNoteUpdate**](ProjectsApi.md#privateProjectNoteUpdate) | **PUT** /account/projects/{project_id}/notes/{note_id} | Update project note |
| [**privateProjectNotesCreate**](ProjectsApi.md#privateProjectNotesCreate) | **POST** /account/projects/{project_id}/notes | Create project note |
| [**privateProjectNotesList**](ProjectsApi.md#privateProjectNotesList) | **GET** /account/projects/{project_id}/notes | List project notes |
| [**privateProjectPartialUpdate**](ProjectsApi.md#privateProjectPartialUpdate) | **PATCH** /account/projects/{project_id} | Partially update project |
| [**privateProjectPublish**](ProjectsApi.md#privateProjectPublish) | **POST** /account/projects/{project_id}/publish | Private Project Publish |
| [**privateProjectUpdate**](ProjectsApi.md#privateProjectUpdate) | **PUT** /account/projects/{project_id} | Update project |
| [**privateProjectsList**](ProjectsApi.md#privateProjectsList) | **GET** /account/projects | Private Projects |
| [**privateProjectsSearch**](ProjectsApi.md#privateProjectsSearch) | **POST** /account/projects/search | Private Projects search |
| [**projectArticles**](ProjectsApi.md#projectArticles) | **GET** /projects/{project_id}/articles | Public Project Articles |
| [**projectDetails**](ProjectsApi.md#projectDetails) | **GET** /projects/{project_id} | Public Project |
| [**projectsList**](ProjectsApi.md#projectsList) | **GET** /projects | Public Projects |
| [**projectsSearch**](ProjectsApi.md#projectsSearch) | **POST** /projects/search | Public Projects Search |


<a id="privateProjectArticleDelete"></a>
# **privateProjectArticleDelete**
> privateProjectArticleDelete(projectId, articleId)

Delete project article

Delete project article

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val articleId : kotlin.Long = 789 // kotlin.Long | Project Article unique identifier
try {
    apiInstance.privateProjectArticleDelete(projectId, articleId)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectArticleDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectArticleDelete")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Project Article unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectArticleDetails"></a>
# **privateProjectArticleDetails**
> ArticleCompletePrivate privateProjectArticleDetails(projectId, articleId)

Project article details

Project article details

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val articleId : kotlin.Long = 789 // kotlin.Long | Project Article unique identifier
try {
    val result : ArticleCompletePrivate = apiInstance.privateProjectArticleDetails(projectId, articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectArticleDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectArticleDetails")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Project Article unique identifier | |

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectArticleFile"></a>
# **privateProjectArticleFile**
> PrivateFile privateProjectArticleFile(projectId, articleId, fileId)

Project article file details

Project article file details

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val articleId : kotlin.Long = 789 // kotlin.Long | Project Article unique identifier
val fileId : kotlin.Long = 789 // kotlin.Long | File unique identifier
try {
    val result : PrivateFile = apiInstance.privateProjectArticleFile(projectId, articleId, fileId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectArticleFile")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectArticleFile")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| **articleId** | **kotlin.Long**| Project Article unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **fileId** | **kotlin.Long**| File unique identifier | |

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectArticleFiles"></a>
# **privateProjectArticleFiles**
> kotlin.collections.List&lt;PrivateFile&gt; privateProjectArticleFiles(projectId, articleId)

Project article list files

List article files

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val articleId : kotlin.Long = 789 // kotlin.Long | Project Article unique identifier
try {
    val result : kotlin.collections.List<PrivateFile> = apiInstance.privateProjectArticleFiles(projectId, articleId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectArticleFiles")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectArticleFiles")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **articleId** | **kotlin.Long**| Project Article unique identifier | |

### Return type

[**kotlin.collections.List&lt;PrivateFile&gt;**](PrivateFile.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectArticlesCreate"></a>
# **privateProjectArticlesCreate**
> Location privateProjectArticlesCreate(projectId, article)

Create project article

Create a new Article and associate it with this project

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val article : ArticleProjectCreate =  // ArticleProjectCreate | Article description
try {
    val result : Location = apiInstance.privateProjectArticlesCreate(projectId, article)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectArticlesCreate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectArticlesCreate")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article** | [**ArticleProjectCreate**](ArticleProjectCreate.md)| Article description | |

### Return type

[**Location**](Location.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateProjectArticlesList"></a>
# **privateProjectArticlesList**
> kotlin.collections.List&lt;Article&gt; privateProjectArticlesList(projectId)

List project articles

List project articles

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
try {
    val result : kotlin.collections.List<Article> = apiInstance.privateProjectArticlesList(projectId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectArticlesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectArticlesList")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **projectId** | **kotlin.Long**| Project unique identifier | |

### Return type

[**kotlin.collections.List&lt;Article&gt;**](Article.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectCollaboratorDelete"></a>
# **privateProjectCollaboratorDelete**
> privateProjectCollaboratorDelete(projectId, userId)

Remove project collaborator

Remove project collaborator

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val userId : kotlin.Long = 789 // kotlin.Long | User unique identifier
try {
    apiInstance.privateProjectCollaboratorDelete(projectId, userId)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectCollaboratorDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectCollaboratorDelete")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **userId** | **kotlin.Long**| User unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectCollaboratorsInvite"></a>
# **privateProjectCollaboratorsInvite**
> ResponseMessage privateProjectCollaboratorsInvite(projectId, collaborator)

Invite project collaborators

Invite users to collaborate on project or view the project

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val collaborator : ProjectCollaboratorInvite =  // ProjectCollaboratorInvite | viewer or collaborator role. User user_id or email of user
try {
    val result : ResponseMessage = apiInstance.privateProjectCollaboratorsInvite(projectId, collaborator)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectCollaboratorsInvite")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectCollaboratorsInvite")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collaborator** | [**ProjectCollaboratorInvite**](ProjectCollaboratorInvite.md)| viewer or collaborator role. User user_id or email of user | |

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateProjectCollaboratorsList"></a>
# **privateProjectCollaboratorsList**
> kotlin.collections.List&lt;ProjectCollaborator&gt; privateProjectCollaboratorsList(projectId)

List project collaborators

List Project collaborators and invited users

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
try {
    val result : kotlin.collections.List<ProjectCollaborator> = apiInstance.privateProjectCollaboratorsList(projectId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectCollaboratorsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectCollaboratorsList")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **projectId** | **kotlin.Long**| Project unique identifier | |

### Return type

[**kotlin.collections.List&lt;ProjectCollaborator&gt;**](ProjectCollaborator.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectCreate"></a>
# **privateProjectCreate**
> CreateProjectResponse privateProjectCreate(project)

Create project

Create a new project

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val project : ProjectCreate =  // ProjectCreate | Project  description
try {
    val result : CreateProjectResponse = apiInstance.privateProjectCreate(project)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectCreate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectCreate")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **project** | [**ProjectCreate**](ProjectCreate.md)| Project  description | |

### Return type

[**CreateProjectResponse**](CreateProjectResponse.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateProjectDelete"></a>
# **privateProjectDelete**
> privateProjectDelete(projectId)

Delete project

A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project. 

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
try {
    apiInstance.privateProjectDelete(projectId)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectDelete")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **projectId** | **kotlin.Long**| Project unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectDetails"></a>
# **privateProjectDetails**
> ProjectCompletePrivate privateProjectDetails(projectId)

View project details

View a private project

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
try {
    val result : ProjectCompletePrivate = apiInstance.privateProjectDetails(projectId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectDetails")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **projectId** | **kotlin.Long**| Project unique identifier | |

### Return type

[**ProjectCompletePrivate**](ProjectCompletePrivate.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectLeave"></a>
# **privateProjectLeave**
> privateProjectLeave(projectId)

Private Project Leave

Please note: project&#39;s owner cannot leave the project.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
try {
    apiInstance.privateProjectLeave(projectId)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectLeave")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectLeave")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **projectId** | **kotlin.Long**| Project unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectNote"></a>
# **privateProjectNote**
> ProjectNotePrivate privateProjectNote(projectId, noteId)

Project note details

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val noteId : kotlin.Long = 789 // kotlin.Long | Note unique identifier
try {
    val result : ProjectNotePrivate = apiInstance.privateProjectNote(projectId, noteId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectNote")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectNote")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **noteId** | **kotlin.Long**| Note unique identifier | |

### Return type

[**ProjectNotePrivate**](ProjectNotePrivate.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectNoteDelete"></a>
# **privateProjectNoteDelete**
> privateProjectNoteDelete(projectId, noteId)

Delete project note

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val noteId : kotlin.Long = 789 // kotlin.Long | Note unique identifier
try {
    apiInstance.privateProjectNoteDelete(projectId, noteId)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectNoteDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectNoteDelete")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **noteId** | **kotlin.Long**| Note unique identifier | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectNoteUpdate"></a>
# **privateProjectNoteUpdate**
> privateProjectNoteUpdate(projectId, noteId, note)

Update project note

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val noteId : kotlin.Long = 789 // kotlin.Long | Note unique identifier
val note : ProjectNoteCreate =  // ProjectNoteCreate | Note message
try {
    apiInstance.privateProjectNoteUpdate(projectId, noteId, note)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectNoteUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectNoteUpdate")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| **noteId** | **kotlin.Long**| Note unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **note** | [**ProjectNoteCreate**](ProjectNoteCreate.md)| Note message | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateProjectNotesCreate"></a>
# **privateProjectNotesCreate**
> Location privateProjectNotesCreate(projectId, note)

Create project note

Create a new project note

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val note : ProjectNoteCreate =  // ProjectNoteCreate | Note message
try {
    val result : Location = apiInstance.privateProjectNotesCreate(projectId, note)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectNotesCreate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectNotesCreate")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **note** | [**ProjectNoteCreate**](ProjectNoteCreate.md)| Note message | |

### Return type

[**Location**](Location.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateProjectNotesList"></a>
# **privateProjectNotesList**
> kotlin.collections.List&lt;ProjectNote&gt; privateProjectNotesList(projectId, page, pageSize, limit, offset)

List project notes

List project notes

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
try {
    val result : kotlin.collections.List<ProjectNote> = apiInstance.privateProjectNotesList(projectId, page, pageSize, limit, offset)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectNotesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectNotesList")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**kotlin.collections.List&lt;ProjectNote&gt;**](ProjectNote.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectPartialUpdate"></a>
# **privateProjectPartialUpdate**
> privateProjectPartialUpdate(projectId, project)

Partially update project

Partially update a project; only provided fields will be changed.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val project : ProjectUpdate =  // ProjectUpdate | Fields to update
try {
    apiInstance.privateProjectPartialUpdate(projectId, project)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectPartialUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectPartialUpdate")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **project** | [**ProjectUpdate**](ProjectUpdate.md)| Fields to update | [optional] |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateProjectPublish"></a>
# **privateProjectPublish**
> ResponseMessage privateProjectPublish(projectId)

Private Project Publish

Publish a project. Possible after all items inside it are public

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
try {
    val result : ResponseMessage = apiInstance.privateProjectPublish(projectId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectPublish")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectPublish")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **projectId** | **kotlin.Long**| Project unique identifier | |

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectUpdate"></a>
# **privateProjectUpdate**
> privateProjectUpdate(projectId, project)

Update project

Updating an project by passing body parameters.

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project unique identifier
val project : ProjectUpdate =  // ProjectUpdate | Project description
try {
    apiInstance.privateProjectUpdate(projectId, project)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectUpdate")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project unique identifier | |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **project** | [**ProjectUpdate**](ProjectUpdate.md)| Project description | |

### Return type

null (empty response body)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="privateProjectsList"></a>
# **privateProjectsList**
> kotlin.collections.List&lt;ProjectPrivate&gt; privateProjectsList(page, pageSize, limit, offset, order, orderDirection, storage, roles)

Private Projects

List private projects

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
val order : kotlin.String = order_example // kotlin.String | The field by which to order.
val orderDirection : kotlin.String = orderDirection_example // kotlin.String | 
val storage : kotlin.String = storage_example // kotlin.String | only return collections from this institution
val roles : kotlin.String = roles_example // kotlin.String | Any combination of owner, collaborator, viewer separated by comma. Examples: \"owner\" or \"owner,collaborator\".
try {
    val result : kotlin.collections.List<ProjectPrivate> = apiInstance.privateProjectsList(page, pageSize, limit, offset, order, orderDirection, storage, roles)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectsList")
    e.printStackTrace()
}
```

### Parameters
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **kotlin.String**| The field by which to order. | [optional] [default to published_date] [enum: published_date, modified_date, views] |
| **orderDirection** | **kotlin.String**|  | [optional] [default to desc] [enum: asc, desc] |
| **storage** | **kotlin.String**| only return collections from this institution | [optional] [enum: group, individual] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **roles** | **kotlin.String**| Any combination of owner, collaborator, viewer separated by comma. Examples: \&quot;owner\&quot; or \&quot;owner,collaborator\&quot;. | [optional] |

### Return type

[**kotlin.collections.List&lt;ProjectPrivate&gt;**](ProjectPrivate.md)

### Authorization


Configure OAuth2:
    ApiClient.accessToken = ""

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="privateProjectsSearch"></a>
# **privateProjectsSearch**
> kotlin.collections.List&lt;ProjectPrivate&gt; privateProjectsSearch(search)

Private Projects search

Search inside the private projects

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val search : ProjectsSearch =  // ProjectsSearch | Search Parameters
try {
    val result : kotlin.collections.List<ProjectPrivate> = apiInstance.privateProjectsSearch(search)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#privateProjectsSearch")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#privateProjectsSearch")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**ProjectsSearch**](ProjectsSearch.md)| Search Parameters | [optional] |

### Return type

[**kotlin.collections.List&lt;ProjectPrivate&gt;**](ProjectPrivate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="projectArticles"></a>
# **projectArticles**
> kotlin.collections.List&lt;Article&gt; projectArticles(projectId, page, pageSize, limit, offset)

Public Project Articles

List articles in project

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project Unique identifier
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
try {
    val result : kotlin.collections.List<Article> = apiInstance.projectArticles(projectId, page, pageSize, limit, offset)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#projectArticles")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#projectArticles")
    e.printStackTrace()
}
```

### Parameters
| **projectId** | **kotlin.Long**| Project Unique identifier | |
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**kotlin.collections.List&lt;Article&gt;**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="projectDetails"></a>
# **projectDetails**
> ProjectComplete projectDetails(projectId)

Public Project

View a project

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val projectId : kotlin.Long = 789 // kotlin.Long | Project Unique identifier
try {
    val result : ProjectComplete = apiInstance.projectDetails(projectId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#projectDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#projectDetails")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **projectId** | **kotlin.Long**| Project Unique identifier | |

### Return type

[**ProjectComplete**](ProjectComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="projectsList"></a>
# **projectsList**
> kotlin.collections.List&lt;Project&gt; projectsList(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, group)

Public Projects

Returns a list of public projects

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val xCursor : java.util.UUID = 38400000-8cf0-11bd-b23e-10b96e4ef00d // java.util.UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
val page : kotlin.Long = 789 // kotlin.Long | Page number. Used for pagination with page_size
val pageSize : kotlin.Long = 789 // kotlin.Long | The number of results included on a page. Used for pagination with page
val limit : kotlin.Long = 789 // kotlin.Long | Number of results included on a page. Used for pagination with query
val offset : kotlin.Long = 789 // kotlin.Long | Where to start the listing (the offset of the first result). Used for pagination with limit
val order : kotlin.String = order_example // kotlin.String | The field by which to order. Default varies by endpoint/resource.
val orderDirection : kotlin.String = orderDirection_example // kotlin.String | 
val institution : kotlin.Long = 789 // kotlin.Long | only return collections from this institution
val publishedSince : kotlin.String = publishedSince_example // kotlin.String | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
val group : kotlin.Long = 789 // kotlin.Long | only return collections from this group
try {
    val result : kotlin.collections.List<Project> = apiInstance.projectsList(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, group)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#projectsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#projectsList")
    e.printStackTrace()
}
```

### Parameters
| **xCursor** | **java.util.UUID**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **page** | **kotlin.Long**| Page number. Used for pagination with page_size | [optional] |
| **pageSize** | **kotlin.Long**| The number of results included on a page. Used for pagination with page | [optional] [default to 10L] |
| **limit** | **kotlin.Long**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **kotlin.Long**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **kotlin.String**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date] [enum: published_date, modified_date, views] |
| **orderDirection** | **kotlin.String**|  | [optional] [default to desc] [enum: asc, desc] |
| **institution** | **kotlin.Long**| only return collections from this institution | [optional] |
| **publishedSince** | **kotlin.String**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **group** | **kotlin.Long**| only return collections from this group | [optional] |

### Return type

[**kotlin.collections.List&lt;Project&gt;**](Project.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a id="projectsSearch"></a>
# **projectsSearch**
> kotlin.collections.List&lt;Project&gt; projectsSearch(xCursor, search)

Public Projects Search

Returns a list of public articles

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = ProjectsApi()
val xCursor : java.util.UUID = 38400000-8cf0-11bd-b23e-10b96e4ef00d // java.util.UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
val search : ProjectsSearch =  // ProjectsSearch | Search Parameters
try {
    val result : kotlin.collections.List<Project> = apiInstance.projectsSearch(xCursor, search)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ProjectsApi#projectsSearch")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ProjectsApi#projectsSearch")
    e.printStackTrace()
}
```

### Parameters
| **xCursor** | **java.util.UUID**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**ProjectsSearch**](ProjectsSearch.md)| Search Parameters | [optional] |

### Return type

[**kotlin.collections.List&lt;Project&gt;**](Project.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

