
# ShortCustomField

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Long** | Custom field id |  |
| **name** | **kotlin.String** | Custom field name |  |
| **fieldType** | [**inline**](#FieldType) | Custom field type |  |
| **settings** | [**kotlin.Any**](.md) | Settings for the custom field |  [optional] |
| **order** | **kotlin.Long** | Order of the field in the group |  [optional] |
| **isMandatory** | **kotlin.Boolean** | Whether the field is mandatory or not |  [optional] |


<a id="FieldType"></a>
## Enum: field_type
| Name | Value |
| ---- | ----- |
| fieldType | text, textarea, dropdown, url, email, date, dropdown_large_list |



