
# CollectionHandle

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **handle** | **kotlin.String** | Reserved Handle |  |



