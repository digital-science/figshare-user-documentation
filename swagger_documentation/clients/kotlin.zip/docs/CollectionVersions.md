
# CollectionVersions

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **version** | **kotlin.Int** | Version number |  |
| **url** | **kotlin.String** | Api endpoint for the collection version |  |
| **funding** | [**kotlin.collections.List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Collection funding information |  |



