
# ArticleDOI

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **doi** | **kotlin.String** | Reserved DOI |  |



