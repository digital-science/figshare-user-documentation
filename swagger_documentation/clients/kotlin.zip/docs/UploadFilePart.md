
# UploadFilePart

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **partNo** | **kotlin.Long** | File part id |  [optional] |
| **startOffset** | **kotlin.Long** | Indexes on byte range. zero-based and inclusive |  [optional] |
| **endOffset** | **kotlin.Long** | Indexes on byte range. zero-based and inclusive |  [optional] |
| **status** | [**inline**](#Status) | part status |  [optional] |
| **locked** | **kotlin.Boolean** | When a part is being uploaded it is being locked, by setting the locked flag to true. No changes/uploads can happen on this part from other requests. |  [optional] |


<a id="Status"></a>
## Enum: status
| Name | Value |
| ---- | ----- |
| status | PENDING, COMPLETE |



