# OauthApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**createToken**](OauthApi.md#createToken) | **POST** /token | Create OAuth token |
| [**getTokenInfo**](OauthApi.md#getTokenInfo) | **GET** /token | Get OAuth token information |


<a id="createToken"></a>
# **createToken**
> OAuthToken createToken(body)

Create OAuth token

Creates OAuth token using various grant types

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = OauthApi()
val body : CreateOAuthToken =  // CreateOAuthToken | Create OAuth Token Parameters
try {
    val result : OAuthToken = apiInstance.createToken(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling OauthApi#createToken")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling OauthApi#createToken")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **body** | [**CreateOAuthToken**](CreateOAuthToken.md)| Create OAuth Token Parameters | [optional] |

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a id="getTokenInfo"></a>
# **getTokenInfo**
> OAuthToken getTokenInfo(accessToken)

Get OAuth token information

Returns information about the current OAuth token

### Example
```kotlin
// Import classes:
//import org.openapitools.client.infrastructure.*
//import org.openapitools.client.models.*

val apiInstance = OauthApi()
val accessToken : kotlin.String = accessToken_example // kotlin.String | OAuth access token
try {
    val result : OAuthToken = apiInstance.getTokenInfo(accessToken)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling OauthApi#getTokenInfo")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling OauthApi#getTokenInfo")
    e.printStackTrace()
}
```

### Parameters
| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **accessToken** | **kotlin.String**| OAuth access token | [optional] |

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

