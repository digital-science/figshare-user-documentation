
# ArticleConfidentiality

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **isConfidential** | **kotlin.Boolean** | True if article is confidential |  |
| **reason** | **kotlin.String** | Reason for confidentiality |  |



