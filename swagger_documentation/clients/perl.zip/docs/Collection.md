# WWW::OpenAPIClient::Object::Collection

## Load the model package
```perl
use WWW::OpenAPIClient::Object::Collection;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Collection id | 
**title** | **string** | Collection title | 
**doi** | **string** | Collection DOI | 
**handle** | **string** | Collection Handle | 
**url** | **string** | Api endpoint | 
**timeline** | [**Timeline**](Timeline.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


