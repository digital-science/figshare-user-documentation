# WWW::OpenAPIClient::Object::CurationCommentCreate

## Load the model package
```perl
use WWW::OpenAPIClient::Object::CurationCommentCreate;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **string** | The contents/value of the comment | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


