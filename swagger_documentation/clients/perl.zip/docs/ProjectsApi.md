# WWW::SwaggerClient::ProjectsApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ProjectsApi;
```

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**private_project_article_delete**](ProjectsApi.md#private_project_article_delete) | **DELETE** /account/projects/{project_id}/articles/{article_id} | Delete project article
[**private_project_article_details**](ProjectsApi.md#private_project_article_details) | **GET** /account/projects/{project_id}/articles/{article_id} | Project article details
[**private_project_article_file**](ProjectsApi.md#private_project_article_file) | **GET** /account/projects/{project_id}/articles/{article_id}/files/{file_id} | Project article file details
[**private_project_article_files**](ProjectsApi.md#private_project_article_files) | **GET** /account/projects/{project_id}/articles/{article_id}/files | Project article list files
[**private_project_articles_create**](ProjectsApi.md#private_project_articles_create) | **POST** /account/projects/{project_id}/articles | Create project article
[**private_project_articles_list**](ProjectsApi.md#private_project_articles_list) | **GET** /account/projects/{project_id}/articles | List project articles
[**private_project_collaborator_delete**](ProjectsApi.md#private_project_collaborator_delete) | **DELETE** /account/projects/{project_id}/collaborators/{user_id} | Remove project collaborator
[**private_project_collaborators_invite**](ProjectsApi.md#private_project_collaborators_invite) | **POST** /account/projects/{project_id}/collaborators | Invite project collaborators
[**private_project_collaborators_list**](ProjectsApi.md#private_project_collaborators_list) | **GET** /account/projects/{project_id}/collaborators | List project collaborators
[**private_project_create**](ProjectsApi.md#private_project_create) | **POST** /account/projects | Create project
[**private_project_delete**](ProjectsApi.md#private_project_delete) | **DELETE** /account/projects/{project_id} | Delete project
[**private_project_details**](ProjectsApi.md#private_project_details) | **GET** /account/projects/{project_id} | View project details
[**private_project_leave**](ProjectsApi.md#private_project_leave) | **POST** /account/projects/{project_id}/leave | Private Project Leave
[**private_project_note**](ProjectsApi.md#private_project_note) | **GET** /account/projects/{project_id}/notes/{note_id} | Project note details
[**private_project_note_delete**](ProjectsApi.md#private_project_note_delete) | **DELETE** /account/projects/{project_id}/notes/{note_id} | Delete project note
[**private_project_note_update**](ProjectsApi.md#private_project_note_update) | **PUT** /account/projects/{project_id}/notes/{note_id} | Update project note
[**private_project_notes_create**](ProjectsApi.md#private_project_notes_create) | **POST** /account/projects/{project_id}/notes | Create project note
[**private_project_notes_list**](ProjectsApi.md#private_project_notes_list) | **GET** /account/projects/{project_id}/notes | List project notes
[**private_project_partial_update**](ProjectsApi.md#private_project_partial_update) | **PATCH** /account/projects/{project_id} | Partially update project
[**private_project_publish**](ProjectsApi.md#private_project_publish) | **POST** /account/projects/{project_id}/publish | Private Project Publish
[**private_project_update**](ProjectsApi.md#private_project_update) | **PUT** /account/projects/{project_id} | Update project
[**private_projects_list**](ProjectsApi.md#private_projects_list) | **GET** /account/projects | Private Projects
[**private_projects_search**](ProjectsApi.md#private_projects_search) | **POST** /account/projects/search | Private Projects search
[**project_articles**](ProjectsApi.md#project_articles) | **GET** /projects/{project_id}/articles | Public Project Articles
[**project_details**](ProjectsApi.md#project_details) | **GET** /projects/{project_id} | Public Project
[**projects_list**](ProjectsApi.md#projects_list) | **GET** /projects | Public Projects
[**projects_search**](ProjectsApi.md#projects_search) | **POST** /projects/search | Public Projects Search


# **private_project_article_delete**
> private_project_article_delete(project_id => $project_id, article_id => $article_id)

Delete project article

Delete project article

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $article_id = 789; # int | Project Article unique identifier

eval { 
    $api_instance->private_project_article_delete(project_id => $project_id, article_id => $article_id);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_article_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **article_id** | **int**| Project Article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_article_details**
> ArticleCompletePrivate private_project_article_details(project_id => $project_id, article_id => $article_id)

Project article details

Project article details

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $article_id = 789; # int | Project Article unique identifier

eval { 
    my $result = $api_instance->private_project_article_details(project_id => $project_id, article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_article_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **article_id** | **int**| Project Article unique identifier | 

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_article_file**
> PrivateFile private_project_article_file(project_id => $project_id, article_id => $article_id, file_id => $file_id)

Project article file details

Project article file details

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $article_id = 789; # int | Project Article unique identifier
my $file_id = 789; # int | File unique identifier

eval { 
    my $result = $api_instance->private_project_article_file(project_id => $project_id, article_id => $article_id, file_id => $file_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_article_file: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **article_id** | **int**| Project Article unique identifier | 
 **file_id** | **int**| File unique identifier | 

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_article_files**
> ARRAY[PrivateFile] private_project_article_files(project_id => $project_id, article_id => $article_id)

Project article list files

List article files

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $article_id = 789; # int | Project Article unique identifier

eval { 
    my $result = $api_instance->private_project_article_files(project_id => $project_id, article_id => $article_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_article_files: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **article_id** | **int**| Project Article unique identifier | 

### Return type

[**ARRAY[PrivateFile]**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_articles_create**
> Location private_project_articles_create(project_id => $project_id, article => $article)

Create project article

Create a new Article and associate it with this project

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $article = WWW::SwaggerClient::Object::ArticleProjectCreate->new(); # ArticleProjectCreate | Article description

eval { 
    my $result = $api_instance->private_project_articles_create(project_id => $project_id, article => $article);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_articles_create: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **article** | [**ArticleProjectCreate**](ArticleProjectCreate.md)| Article description | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_articles_list**
> ARRAY[Article] private_project_articles_list(project_id => $project_id)

List project articles

List project articles

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier

eval { 
    my $result = $api_instance->private_project_articles_list(project_id => $project_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_articles_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 

### Return type

[**ARRAY[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_collaborator_delete**
> private_project_collaborator_delete(project_id => $project_id, user_id => $user_id)

Remove project collaborator

Remove project collaborator

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $user_id = 789; # int | User unique identifier

eval { 
    $api_instance->private_project_collaborator_delete(project_id => $project_id, user_id => $user_id);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_collaborator_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **user_id** | **int**| User unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_collaborators_invite**
> ResponseMessage private_project_collaborators_invite(project_id => $project_id, collaborator => $collaborator)

Invite project collaborators

Invite users to collaborate on project or view the project

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $collaborator = WWW::SwaggerClient::Object::ProjectCollaboratorInvite->new(); # ProjectCollaboratorInvite | viewer or collaborator role. User user_id or email of user

eval { 
    my $result = $api_instance->private_project_collaborators_invite(project_id => $project_id, collaborator => $collaborator);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_collaborators_invite: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **collaborator** | [**ProjectCollaboratorInvite**](ProjectCollaboratorInvite.md)| viewer or collaborator role. User user_id or email of user | 

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_collaborators_list**
> ARRAY[ProjectCollaborator] private_project_collaborators_list(project_id => $project_id)

List project collaborators

List Project collaborators and invited users

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier

eval { 
    my $result = $api_instance->private_project_collaborators_list(project_id => $project_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_collaborators_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 

### Return type

[**ARRAY[ProjectCollaborator]**](ProjectCollaborator.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_create**
> CreateProjectResponse private_project_create(project => $project)

Create project

Create a new project

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project = WWW::SwaggerClient::Object::ProjectCreate->new(); # ProjectCreate | Project  description

eval { 
    my $result = $api_instance->private_project_create(project => $project);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_create: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project** | [**ProjectCreate**](ProjectCreate.md)| Project  description | 

### Return type

[**CreateProjectResponse**](CreateProjectResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_delete**
> private_project_delete(project_id => $project_id)

Delete project

A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project. 

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier

eval { 
    $api_instance->private_project_delete(project_id => $project_id);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_details**
> ProjectCompletePrivate private_project_details(project_id => $project_id)

View project details

View a private project

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier

eval { 
    my $result = $api_instance->private_project_details(project_id => $project_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 

### Return type

[**ProjectCompletePrivate**](ProjectCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_leave**
> private_project_leave(project_id => $project_id)

Private Project Leave

Please note: project's owner cannot leave the project.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier

eval { 
    $api_instance->private_project_leave(project_id => $project_id);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_leave: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_note**
> ProjectNotePrivate private_project_note(project_id => $project_id, note_id => $note_id)

Project note details

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $note_id = 789; # int | Note unique identifier

eval { 
    my $result = $api_instance->private_project_note(project_id => $project_id, note_id => $note_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_note: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **note_id** | **int**| Note unique identifier | 

### Return type

[**ProjectNotePrivate**](ProjectNotePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_note_delete**
> private_project_note_delete(project_id => $project_id, note_id => $note_id)

Delete project note

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $note_id = 789; # int | Note unique identifier

eval { 
    $api_instance->private_project_note_delete(project_id => $project_id, note_id => $note_id);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_note_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **note_id** | **int**| Note unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_note_update**
> private_project_note_update(project_id => $project_id, note_id => $note_id, note => $note)

Update project note

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $note_id = 789; # int | Note unique identifier
my $note = WWW::SwaggerClient::Object::ProjectNoteCreate->new(); # ProjectNoteCreate | Note message

eval { 
    $api_instance->private_project_note_update(project_id => $project_id, note_id => $note_id, note => $note);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_note_update: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **note_id** | **int**| Note unique identifier | 
 **note** | [**ProjectNoteCreate**](ProjectNoteCreate.md)| Note message | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_notes_create**
> Location private_project_notes_create(project_id => $project_id, note => $note)

Create project note

Create a new project note

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $note = WWW::SwaggerClient::Object::ProjectNoteCreate->new(); # ProjectNoteCreate | Note message

eval { 
    my $result = $api_instance->private_project_notes_create(project_id => $project_id, note => $note);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_notes_create: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **note** | [**ProjectNoteCreate**](ProjectNoteCreate.md)| Note message | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_notes_list**
> ARRAY[ProjectNote] private_project_notes_list(project_id => $project_id, page => $page, page_size => $page_size, limit => $limit, offset => $offset)

List project notes

List project notes

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $page = 789; # int | Page number. Used for pagination with page_size
my $page_size = 789; # int | The number of results included on a page. Used for pagination with page
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing (the offset of the first result). Used for pagination with limit

eval { 
    my $result = $api_instance->private_project_notes_list(project_id => $project_id, page => $page, page_size => $page_size, limit => $limit, offset => $offset);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_notes_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**ARRAY[ProjectNote]**](ProjectNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_partial_update**
> private_project_partial_update(project_id => $project_id, project => $project)

Partially update project

Partially update a project; only provided fields will be changed.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $project = WWW::SwaggerClient::Object::ProjectUpdate->new(); # ProjectUpdate | Fields to update

eval { 
    $api_instance->private_project_partial_update(project_id => $project_id, project => $project);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_partial_update: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **project** | [**ProjectUpdate**](ProjectUpdate.md)| Fields to update | [optional] 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_publish**
> ResponseMessage private_project_publish(project_id => $project_id)

Private Project Publish

Publish a project. Possible after all items inside it are public

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier

eval { 
    my $result = $api_instance->private_project_publish(project_id => $project_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_publish: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_project_update**
> private_project_update(project_id => $project_id, project => $project)

Update project

Updating an project by passing body parameters.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $project_id = 789; # int | Project unique identifier
my $project = WWW::SwaggerClient::Object::ProjectUpdate->new(); # ProjectUpdate | Project description

eval { 
    $api_instance->private_project_update(project_id => $project_id, project => $project);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_project_update: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project unique identifier | 
 **project** | [**ProjectUpdate**](ProjectUpdate.md)| Project description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_projects_list**
> ARRAY[ProjectPrivate] private_projects_list(page => $page, page_size => $page_size, limit => $limit, offset => $offset, order => $order, order_direction => $order_direction, storage => $storage, roles => $roles)

Private Projects

List private projects

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $page = 789; # int | Page number. Used for pagination with page_size
my $page_size = 789; # int | The number of results included on a page. Used for pagination with page
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing (the offset of the first result). Used for pagination with limit
my $order = 'order_example'; # string | The field by which to order.
my $order_direction = 'order_direction_example'; # string | 
my $storage = 'storage_example'; # string | only return collections from this institution
my $roles = 'roles_example'; # string | Any combination of owner, collaborator, viewer separated by comma. Examples: \"owner\" or \"owner,collaborator\".

eval { 
    my $result = $api_instance->private_projects_list(page => $page, page_size => $page_size, limit => $limit, offset => $offset, order => $order, order_direction => $order_direction, storage => $storage, roles => $roles);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_projects_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **string**| The field by which to order. | [optional] [default to published_date]
 **order_direction** | **string**|  | [optional] [default to desc]
 **storage** | **string**| only return collections from this institution | [optional] 
 **roles** | **string**| Any combination of owner, collaborator, viewer separated by comma. Examples: \&quot;owner\&quot; or \&quot;owner,collaborator\&quot;. | [optional] 

### Return type

[**ARRAY[ProjectPrivate]**](ProjectPrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_projects_search**
> ARRAY[ProjectPrivate] private_projects_search(search => $search)

Private Projects search

Search inside the private projects

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(
);

my $search = WWW::SwaggerClient::Object::ProjectsSearch->new(); # ProjectsSearch | Search Parameters

eval { 
    my $result = $api_instance->private_projects_search(search => $search);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->private_projects_search: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**ProjectsSearch**](ProjectsSearch.md)| Search Parameters | [optional] 

### Return type

[**ARRAY[ProjectPrivate]**](ProjectPrivate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **project_articles**
> ARRAY[Article] project_articles(project_id => $project_id, page => $page, page_size => $page_size, limit => $limit, offset => $offset)

Public Project Articles

List articles in project

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(
);

my $project_id = 789; # int | Project Unique identifier
my $page = 789; # int | Page number. Used for pagination with page_size
my $page_size = 789; # int | The number of results included on a page. Used for pagination with page
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing (the offset of the first result). Used for pagination with limit

eval { 
    my $result = $api_instance->project_articles(project_id => $project_id, page => $page, page_size => $page_size, limit => $limit, offset => $offset);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->project_articles: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project Unique identifier | 
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**ARRAY[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **project_details**
> ProjectComplete project_details(project_id => $project_id)

Public Project

View a project

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(
);

my $project_id = 789; # int | Project Unique identifier

eval { 
    my $result = $api_instance->project_details(project_id => $project_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->project_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **int**| Project Unique identifier | 

### Return type

[**ProjectComplete**](ProjectComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **projects_list**
> ARRAY[Project] projects_list(x_cursor => $x_cursor, page => $page, page_size => $page_size, limit => $limit, offset => $offset, order => $order, order_direction => $order_direction, institution => $institution, published_since => $published_since, group => $group)

Public Projects

Returns a list of public projects

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(
);

my $x_cursor = ; # UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
my $page = 789; # int | Page number. Used for pagination with page_size
my $page_size = 789; # int | The number of results included on a page. Used for pagination with page
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing (the offset of the first result). Used for pagination with limit
my $order = 'order_example'; # string | The field by which to order. Default varies by endpoint/resource.
my $order_direction = 'order_direction_example'; # string | 
my $institution = 789; # int | only return collections from this institution
my $published_since = 'published_since_example'; # string | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
my $group = 789; # int | only return collections from this group

eval { 
    my $result = $api_instance->projects_list(x_cursor => $x_cursor, page => $page, page_size => $page_size, limit => $limit, offset => $offset, order => $order, order_direction => $order_direction, institution => $institution, published_since => $published_since, group => $group);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->projects_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **x_cursor** | [**UUID**](.md)| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **order_direction** | **string**|  | [optional] [default to desc]
 **institution** | **int**| only return collections from this institution | [optional] 
 **published_since** | **string**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **group** | **int**| only return collections from this group | [optional] 

### Return type

[**ARRAY[Project]**](Project.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **projects_search**
> ARRAY[Project] projects_search(x_cursor => $x_cursor, search => $search)

Public Projects Search

Returns a list of public articles

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProjectsApi;
my $api_instance = WWW::SwaggerClient::ProjectsApi->new(
);

my $x_cursor = ; # UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
my $search = WWW::SwaggerClient::Object::ProjectsSearch->new(); # ProjectsSearch | Search Parameters

eval { 
    my $result = $api_instance->projects_search(x_cursor => $x_cursor, search => $search);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProjectsApi->projects_search: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **x_cursor** | [**UUID**](.md)| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **search** | [**ProjectsSearch**](ProjectsSearch.md)| Search Parameters | [optional] 

### Return type

[**ARRAY[Project]**](Project.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

