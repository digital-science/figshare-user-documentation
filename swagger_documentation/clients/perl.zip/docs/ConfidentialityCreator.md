# WWW::OpenAPIClient::Object::ConfidentialityCreator

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ConfidentialityCreator;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason** | **string** | Reason for confidentiality | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


