# WWW::SwaggerClient::Object::ProjectNoteCreate

## Load the model package
```perl
use WWW::SwaggerClient::Object::ProjectNoteCreate;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **string** | Text of the note | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


