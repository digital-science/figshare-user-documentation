# WWW::OpenAPIClient::Object::CollectionDOI

## Load the model package
```perl
use WWW::OpenAPIClient::Object::CollectionDOI;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**doi** | **string** | Reserved DOI | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


