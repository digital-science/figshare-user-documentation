# WWW::OpenAPIClient::Object::AccountReport

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AccountReport;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | A unique ID for the AccountRecord | 
**account_id** | **int** | The ID of the account which generated this report. | 
**created_date** | **string** | Date when the AccountReport was requested | 
**status** | **string** | Status of the report | 
**download_url** | **string** | The download link for the generated XLSX | 
**group_id** | **int** | The group ID that was used to filter the report, if any. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


