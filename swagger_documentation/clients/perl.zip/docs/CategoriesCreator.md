# WWW::SwaggerClient::Object::CategoriesCreator

## Load the model package
```perl
use WWW::SwaggerClient::Object::CategoriesCreator;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categories** | **ARRAY[int]** | List of category ids | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


