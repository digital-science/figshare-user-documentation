# WWW::OpenAPIClient::Object::LocationWarningsUpdate

## Load the model package
```perl
use WWW::OpenAPIClient::Object::LocationWarningsUpdate;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **string** | Url for entity | 
**warnings** | **ARRAY[string]** | Issues encountered during the operation | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


