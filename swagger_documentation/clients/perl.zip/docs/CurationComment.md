# WWW::OpenAPIClient::Object::CurationComment

## Load the model package
```perl
use WWW::OpenAPIClient::Object::CurationComment;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The ID of the comment. | 
**account_id** | **int** | The ID of the account which generated this comment. | 
**type** | **string** | The ID of the account which generated this comment. | 
**text** | **string** | The value/content of the comment. | 
**created_date** | **string** | The creation date of the comment. | 
**modified_date** | **string** | The date the comment has been modified. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


