# WWW::OpenAPIClient::Object::FundingCreate

## Load the model package
```perl
use WWW::OpenAPIClient::Object::FundingCreate;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | A funding ID as returned by the Funding Search endpoint | [optional] 
**title** | **string** | The title of the new user created funding | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


