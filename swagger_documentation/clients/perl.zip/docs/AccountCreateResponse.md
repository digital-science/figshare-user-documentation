# WWW::OpenAPIClient::Object::AccountCreateResponse

## Load the model package
```perl
use WWW::OpenAPIClient::Object::AccountCreateResponse;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account_id** | **int** | ID of created account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


