# WWW::OpenAPIClient::Object::GroupEmbargoOptions

## Load the model package
```perl
use WWW::OpenAPIClient::Object::GroupEmbargoOptions;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Embargo option id | 
**type** | **string** | Embargo permission type | 
**ip_name** | **string** | IP range name; value appears if type is ip_range | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


