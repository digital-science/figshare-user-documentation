# WWW::SwaggerClient::Object::Timeline

## Load the model package
```perl
use WWW::SwaggerClient::Object::Timeline;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_online** | **string** | Online posted date | [optional] 
**publisher_publication** | **string** | Publish date | [optional] 
**publisher_acceptance** | **string** | Date when the item was accepted for publication | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


