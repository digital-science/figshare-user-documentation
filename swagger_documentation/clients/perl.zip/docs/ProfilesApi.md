# WWW::SwaggerClient::ProfilesApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ProfilesApi;
```

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**update_user_profile**](ProfilesApi.md#update_user_profile) | **PUT** /account/profile | Update public profile
[**update_user_profile_picture**](ProfilesApi.md#update_user_profile_picture) | **POST** /account/profile/{user_id}/picture | Update public profile picture


# **update_user_profile**
> object update_user_profile(user_profile_data => $user_profile_data, user_id => $user_id, institution_user_id => $institution_user_id)

Update public profile

Updates the fields of the user's public profile.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProfilesApi;
my $api_instance = WWW::SwaggerClient::ProfilesApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $user_profile_data = WWW::SwaggerClient::Object::ProfileUpdateData->new(); # ProfileUpdateData | 
my $user_id = 789; # int | User ID
my $institution_user_id = 'institution_user_id_example'; # string | Institutional user ID

eval { 
    my $result = $api_instance->update_user_profile(user_profile_data => $user_profile_data, user_id => $user_id, institution_user_id => $institution_user_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProfilesApi->update_user_profile: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_profile_data** | [**ProfileUpdateData**](ProfileUpdateData.md)|  | 
 **user_id** | **int**| User ID | [optional] 
 **institution_user_id** | **string**| Institutional user ID | [optional] 

### Return type

**object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_user_profile_picture**
> object update_user_profile_picture(user_id => $user_id, profile_picture => $profile_picture)

Update public profile picture

Updates the profile picture of the user's public profile.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProfilesApi;
my $api_instance = WWW::SwaggerClient::ProfilesApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $user_id = 789; # int | User ID
my $profile_picture = '/path/to/file.txt'; # File | User profile picture

eval { 
    my $result = $api_instance->update_user_profile_picture(user_id => $user_id, profile_picture => $profile_picture);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProfilesApi->update_user_profile_picture: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **int**| User ID | 
 **profile_picture** | **File**| User profile picture | 

### Return type

**object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

