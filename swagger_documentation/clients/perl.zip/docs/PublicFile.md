# WWW::OpenAPIClient::Object::PublicFile

## Load the model package
```perl
use WWW::OpenAPIClient::Object::PublicFile;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | File id | 
**name** | **string** | File name | 
**size** | **int** | File size | 
**is_link_only** | **boolean** | True if file is hosted somewhere else | 
**download_url** | **string** | Url for file download | 
**supplied_md5** | **string** | File supplied md5 | 
**computed_md5** | **string** | File computed md5 | 
**mimetype** | **string** | MIME Type of the file, it defaults to an empty string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


