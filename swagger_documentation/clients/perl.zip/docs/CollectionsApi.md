# WWW::OpenAPIClient::CollectionsApi

## Load the API package
```perl
use WWW::OpenAPIClient::Object::CollectionsApi;
```

All URIs are relative to *https://api.figinternal.dev*

Method | HTTP request | Description
------------- | ------------- | -------------
[**collection_articles**](CollectionsApi.md#collection_articles) | **GET** /collections/{collection_id}/articles | Public Collection Articles
[**collection_details**](CollectionsApi.md#collection_details) | **GET** /collections/{collection_id} | Collection details
[**collection_version_details**](CollectionsApi.md#collection_version_details) | **GET** /collections/{collection_id}/versions/{version_id} | Collection Version details
[**collection_versions**](CollectionsApi.md#collection_versions) | **GET** /collections/{collection_id}/versions | Collection Versions list
[**collections_list**](CollectionsApi.md#collections_list) | **GET** /collections | Public Collections
[**collections_search**](CollectionsApi.md#collections_search) | **POST** /collections/search | Public Collections Search
[**private_collection_article_delete**](CollectionsApi.md#private_collection_article_delete) | **DELETE** /account/collections/{collection_id}/articles/{article_id} | Delete collection article
[**private_collection_articles_add**](CollectionsApi.md#private_collection_articles_add) | **POST** /account/collections/{collection_id}/articles | Add collection articles
[**private_collection_articles_list**](CollectionsApi.md#private_collection_articles_list) | **GET** /account/collections/{collection_id}/articles | List collection articles
[**private_collection_articles_replace**](CollectionsApi.md#private_collection_articles_replace) | **PUT** /account/collections/{collection_id}/articles | Replace collection articles
[**private_collection_author_delete**](CollectionsApi.md#private_collection_author_delete) | **DELETE** /account/collections/{collection_id}/authors/{author_id} | Delete collection author
[**private_collection_authors_add**](CollectionsApi.md#private_collection_authors_add) | **POST** /account/collections/{collection_id}/authors | Add collection authors
[**private_collection_authors_list**](CollectionsApi.md#private_collection_authors_list) | **GET** /account/collections/{collection_id}/authors | List collection authors
[**private_collection_authors_replace**](CollectionsApi.md#private_collection_authors_replace) | **PUT** /account/collections/{collection_id}/authors | Replace collection authors
[**private_collection_categories_add**](CollectionsApi.md#private_collection_categories_add) | **POST** /account/collections/{collection_id}/categories | Add collection categories
[**private_collection_categories_list**](CollectionsApi.md#private_collection_categories_list) | **GET** /account/collections/{collection_id}/categories | List collection categories
[**private_collection_categories_replace**](CollectionsApi.md#private_collection_categories_replace) | **PUT** /account/collections/{collection_id}/categories | Replace collection categories
[**private_collection_category_delete**](CollectionsApi.md#private_collection_category_delete) | **DELETE** /account/collections/{collection_id}/categories/{category_id} | Delete collection category
[**private_collection_create**](CollectionsApi.md#private_collection_create) | **POST** /account/collections | Create collection
[**private_collection_delete**](CollectionsApi.md#private_collection_delete) | **DELETE** /account/collections/{collection_id} | Delete collection
[**private_collection_details**](CollectionsApi.md#private_collection_details) | **GET** /account/collections/{collection_id} | Collection details
[**private_collection_patch**](CollectionsApi.md#private_collection_patch) | **PATCH** /account/collections/{collection_id} | Partially update collection
[**private_collection_private_link_create**](CollectionsApi.md#private_collection_private_link_create) | **POST** /account/collections/{collection_id}/private_links | Create collection private link
[**private_collection_private_link_delete**](CollectionsApi.md#private_collection_private_link_delete) | **DELETE** /account/collections/{collection_id}/private_links/{link_id} | Disable private link
[**private_collection_private_link_details**](CollectionsApi.md#private_collection_private_link_details) | **GET** /account/collections/{collection_id}/private_links/{link_id} | View collection private link
[**private_collection_private_link_update**](CollectionsApi.md#private_collection_private_link_update) | **PUT** /account/collections/{collection_id}/private_links/{link_id} | Update collection private link
[**private_collection_private_links_list**](CollectionsApi.md#private_collection_private_links_list) | **GET** /account/collections/{collection_id}/private_links | List collection private links
[**private_collection_publish**](CollectionsApi.md#private_collection_publish) | **POST** /account/collections/{collection_id}/publish | Private Collection Publish
[**private_collection_reserve_doi**](CollectionsApi.md#private_collection_reserve_doi) | **POST** /account/collections/{collection_id}/reserve_doi | Private Collection Reserve DOI
[**private_collection_reserve_handle**](CollectionsApi.md#private_collection_reserve_handle) | **POST** /account/collections/{collection_id}/reserve_handle | Private Collection Reserve Handle
[**private_collection_resource**](CollectionsApi.md#private_collection_resource) | **POST** /account/collections/{collection_id}/resource | Private Collection Resource
[**private_collection_update**](CollectionsApi.md#private_collection_update) | **PUT** /account/collections/{collection_id} | Update collection
[**private_collections_list**](CollectionsApi.md#private_collections_list) | **GET** /account/collections | Private Collections List
[**private_collections_search**](CollectionsApi.md#private_collections_search) | **POST** /account/collections/search | Private Collections Search


# **collection_articles**
> ARRAY[Article] collection_articles(collection_id => $collection_id, page => $page, page_size => $page_size, limit => $limit, offset => $offset)

Public Collection Articles

Returns a list of public collection articles

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(
);

my $collection_id = 789; # int | Collection Unique identifier
my $page = 789; # int | Page number. Used for pagination with page_size
my $page_size = 10; # int | The number of results included on a page. Used for pagination with page
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing (the offset of the first result). Used for pagination with limit

eval {
    my $result = $api_instance->collection_articles(collection_id => $collection_id, page => $page, page_size => $page_size, limit => $limit, offset => $offset);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->collection_articles: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier | 
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**ARRAY[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **collection_details**
> CollectionComplete collection_details(collection_id => $collection_id)

Collection details

View a collection

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(
);

my $collection_id = 789; # int | Collection Unique identifier

eval {
    my $result = $api_instance->collection_details(collection_id => $collection_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->collection_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier | 

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **collection_version_details**
> CollectionComplete collection_version_details(collection_id => $collection_id, version_id => $version_id)

Collection Version details

View details for a certain version of a collection

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(
);

my $collection_id = 789; # int | Collection Unique identifier
my $version_id = 789; # int | Version Number

eval {
    my $result = $api_instance->collection_version_details(collection_id => $collection_id, version_id => $version_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->collection_version_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier | 
 **version_id** | **int**| Version Number | 

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **collection_versions**
> ARRAY[CollectionVersions] collection_versions(collection_id => $collection_id)

Collection Versions list

Returns a list of public collection Versions

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(
);

my $collection_id = 789; # int | Collection Unique identifier

eval {
    my $result = $api_instance->collection_versions(collection_id => $collection_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->collection_versions: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier | 

### Return type

[**ARRAY[CollectionVersions]**](CollectionVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **collections_list**
> ARRAY[Collection] collections_list(x_cursor => $x_cursor, page => $page, page_size => $page_size, limit => $limit, offset => $offset, order => $order, order_direction => $order_direction, institution => $institution, published_since => $published_since, modified_since => $modified_since, group => $group, resource_doi => $resource_doi, doi => $doi, handle => $handle)

Public Collections

Returns a list of public collections

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(
);

my $x_cursor = "x_cursor_example"; # string | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
my $page = 789; # int | Page number. Used for pagination with page_size
my $page_size = 10; # int | The number of results included on a page. Used for pagination with page
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing (the offset of the first result). Used for pagination with limit
my $order = 'published_date'; # string | The field by which to order. Default varies by endpoint/resource.
my $order_direction = 'desc'; # string | 
my $institution = 789; # int | only return collections from this institution
my $published_since = "published_since_example"; # string | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD
my $modified_since = "modified_since_example"; # string | Filter by collection modified date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD
my $group = 789; # int | only return collections from this group
my $resource_doi = "resource_doi_example"; # string | only return collections with this resource_doi
my $doi = "doi_example"; # string | only return collections with this doi
my $handle = "handle_example"; # string | only return collections with this handle

eval {
    my $result = $api_instance->collections_list(x_cursor => $x_cursor, page => $page, page_size => $page_size, limit => $limit, offset => $offset, order => $order, order_direction => $order_direction, institution => $institution, published_since => $published_since, modified_since => $modified_since, group => $group, resource_doi => $resource_doi, doi => $doi, handle => $handle);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->collections_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **x_cursor** | **string**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to &#39;published_date&#39;]
 **order_direction** | **string**|  | [optional] [default to &#39;desc&#39;]
 **institution** | **int**| only return collections from this institution | [optional] 
 **published_since** | **string**| Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **modified_since** | **string**| Filter by collection modified date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **group** | **int**| only return collections from this group | [optional] 
 **resource_doi** | **string**| only return collections with this resource_doi | [optional] 
 **doi** | **string**| only return collections with this doi | [optional] 
 **handle** | **string**| only return collections with this handle | [optional] 

### Return type

[**ARRAY[Collection]**](Collection.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **collections_search**
> ARRAY[Collection] collections_search(x_cursor => $x_cursor, search => $search)

Public Collections Search

Returns a list of public collections

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(
);

my $x_cursor = "x_cursor_example"; # string | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
my $search = WWW::OpenAPIClient::Object::CollectionSearch->new(); # CollectionSearch | Search Parameters

eval {
    my $result = $api_instance->collections_search(x_cursor => $x_cursor, search => $search);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->collections_search: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **x_cursor** | **string**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **search** | [**CollectionSearch**](CollectionSearch.md)| Search Parameters | [optional] 

### Return type

[**ARRAY[Collection]**](Collection.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_article_delete**
> private_collection_article_delete(collection_id => $collection_id, article_id => $article_id)

Delete collection article

De-associate article from collection

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $article_id = 789; # int | Collection article unique identifier

eval {
    $api_instance->private_collection_article_delete(collection_id => $collection_id, article_id => $article_id);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_article_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **article_id** | **int**| Collection article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_articles_add**
> Location private_collection_articles_add(collection_id => $collection_id, articles => $articles)

Add collection articles

Associate new articles with the collection. This will add new articles to the list of already associated articles

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $articles = WWW::OpenAPIClient::Object::ArticlesCreator->new(); # ArticlesCreator | Articles list

eval {
    my $result = $api_instance->private_collection_articles_add(collection_id => $collection_id, articles => $articles);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_articles_add: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **articles** | [**ArticlesCreator**](ArticlesCreator.md)| Articles list | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_articles_list**
> ARRAY[Article] private_collection_articles_list(collection_id => $collection_id, page => $page, page_size => $page_size, limit => $limit, offset => $offset)

List collection articles

List collection articles

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $page = 789; # int | Page number. Used for pagination with page_size
my $page_size = 10; # int | The number of results included on a page. Used for pagination with page
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing (the offset of the first result). Used for pagination with limit

eval {
    my $result = $api_instance->private_collection_articles_list(collection_id => $collection_id, page => $page, page_size => $page_size, limit => $limit, offset => $offset);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_articles_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**ARRAY[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_articles_replace**
> private_collection_articles_replace(collection_id => $collection_id, articles => $articles)

Replace collection articles

Associate new articles with the collection. This will remove all already associated articles and add these new ones

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $articles = WWW::OpenAPIClient::Object::ArticlesCreator->new(); # ArticlesCreator | Articles List

eval {
    $api_instance->private_collection_articles_replace(collection_id => $collection_id, articles => $articles);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_articles_replace: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **articles** | [**ArticlesCreator**](ArticlesCreator.md)| Articles List | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_author_delete**
> private_collection_author_delete(collection_id => $collection_id, author_id => $author_id)

Delete collection author

Delete collection author

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $author_id = 789; # int | Collection Author unique identifier

eval {
    $api_instance->private_collection_author_delete(collection_id => $collection_id, author_id => $author_id);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_author_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **author_id** | **int**| Collection Author unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_authors_add**
> Location private_collection_authors_add(collection_id => $collection_id, authors => $authors)

Add collection authors

Associate new authors with the collection. This will add new authors to the list of already associated authors

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $authors = WWW::OpenAPIClient::Object::AuthorsCreator->new(); # AuthorsCreator | List of authors

eval {
    my $result = $api_instance->private_collection_authors_add(collection_id => $collection_id, authors => $authors);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_authors_add: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| List of authors | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_authors_list**
> ARRAY[Author] private_collection_authors_list(collection_id => $collection_id)

List collection authors

List collection authors

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier

eval {
    my $result = $api_instance->private_collection_authors_list(collection_id => $collection_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_authors_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 

### Return type

[**ARRAY[Author]**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_authors_replace**
> private_collection_authors_replace(collection_id => $collection_id, authors => $authors)

Replace collection authors

Associate new authors with the collection. This will remove all already associated authors and add these new ones

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $authors = WWW::OpenAPIClient::Object::AuthorsCreator->new(); # AuthorsCreator | List of authors

eval {
    $api_instance->private_collection_authors_replace(collection_id => $collection_id, authors => $authors);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_authors_replace: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| List of authors | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_categories_add**
> Location private_collection_categories_add(collection_id => $collection_id, categories => $categories)

Add collection categories

Associate new categories with the collection. This will add new categories to the list of already associated categories

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $categories = WWW::OpenAPIClient::Object::CategoriesCreator->new(); # CategoriesCreator | Categories list

eval {
    my $result = $api_instance->private_collection_categories_add(collection_id => $collection_id, categories => $categories);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_categories_add: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)| Categories list | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_categories_list**
> ARRAY[Category] private_collection_categories_list(collection_id => $collection_id)

List collection categories

List collection categories

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier

eval {
    my $result = $api_instance->private_collection_categories_list(collection_id => $collection_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_categories_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 

### Return type

[**ARRAY[Category]**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_categories_replace**
> private_collection_categories_replace(collection_id => $collection_id, categories => $categories)

Replace collection categories

Associate new categories with the collection. This will remove all already associated categories and add these new ones

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $categories = WWW::OpenAPIClient::Object::CategoriesCreator->new(); # CategoriesCreator | Categories list

eval {
    $api_instance->private_collection_categories_replace(collection_id => $collection_id, categories => $categories);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_categories_replace: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)| Categories list | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_category_delete**
> private_collection_category_delete(collection_id => $collection_id, category_id => $category_id)

Delete collection category

De-associate category from collection

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $category_id = 789; # int | Collection category unique identifier

eval {
    $api_instance->private_collection_category_delete(collection_id => $collection_id, category_id => $category_id);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_category_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **category_id** | **int**| Collection category unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_create**
> LocationWarnings private_collection_create(collection => $collection)

Create collection

Create a new Collection by sending collection information

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection = WWW::OpenAPIClient::Object::CollectionCreate->new(); # CollectionCreate | Collection description

eval {
    my $result = $api_instance->private_collection_create(collection => $collection);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_create: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection** | [**CollectionCreate**](CollectionCreate.md)| Collection description | 

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_delete**
> private_collection_delete(collection_id => $collection_id)

Delete collection

Delete n collection

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection Unique identifier

eval {
    $api_instance->private_collection_delete(collection_id => $collection_id);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_details**
> CollectionCompletePrivate private_collection_details(collection_id => $collection_id)

Collection details

View a collection

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection Unique identifier

eval {
    my $result = $api_instance->private_collection_details(collection_id => $collection_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier | 

### Return type

[**CollectionCompletePrivate**](CollectionCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_patch**
> LocationWarningsUpdate private_collection_patch(collection_id => $collection_id, collection => $collection)

Partially update collection

Partially update a collection by sending only the fields to change.

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection Unique identifier
my $collection = WWW::OpenAPIClient::Object::CollectionUpdate->new(); # CollectionUpdate | Subset of collection fields to update

eval {
    my $result = $api_instance->private_collection_patch(collection_id => $collection_id, collection => $collection);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_patch: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier | 
 **collection** | [**CollectionUpdate**](CollectionUpdate.md)| Subset of collection fields to update | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_private_link_create**
> PrivateLinkResponse private_collection_private_link_create(collection_id => $collection_id, private_link => $private_link)

Create collection private link

Create new private link

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $private_link = WWW::OpenAPIClient::Object::CollectionPrivateLinkCreator->new(); # CollectionPrivateLinkCreator | 

eval {
    my $result = $api_instance->private_collection_private_link_create(collection_id => $collection_id, private_link => $private_link);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_private_link_create: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **private_link** | [**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md)|  | [optional] 

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_private_link_delete**
> private_collection_private_link_delete(collection_id => $collection_id, link_id => $link_id)

Disable private link

Disable/delete private link for this collection

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $link_id = "link_id_example"; # string | Private link token

eval {
    $api_instance->private_collection_private_link_delete(collection_id => $collection_id, link_id => $link_id);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_private_link_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **link_id** | **string**| Private link token | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_private_link_details**
> PrivateLink private_collection_private_link_details(collection_id => $collection_id, link_id => $link_id)

View collection private link

View existing private link for this collection

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $link_id = "link_id_example"; # string | Private link token

eval {
    my $result = $api_instance->private_collection_private_link_details(collection_id => $collection_id, link_id => $link_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_private_link_details: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **link_id** | **string**| Private link token | 

### Return type

[**PrivateLink**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_private_link_update**
> private_collection_private_link_update(collection_id => $collection_id, link_id => $link_id, private_link => $private_link)

Update collection private link

Update existing private link for this collection

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $link_id = "link_id_example"; # string | Private link token
my $private_link = WWW::OpenAPIClient::Object::CollectionPrivateLinkCreator->new(); # CollectionPrivateLinkCreator | 

eval {
    $api_instance->private_collection_private_link_update(collection_id => $collection_id, link_id => $link_id, private_link => $private_link);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_private_link_update: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **link_id** | **string**| Private link token | 
 **private_link** | [**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_private_links_list**
> ARRAY[PrivateLink] private_collection_private_links_list(collection_id => $collection_id)

List collection private links

List article private links

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier

eval {
    my $result = $api_instance->private_collection_private_links_list(collection_id => $collection_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_private_links_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 

### Return type

[**ARRAY[PrivateLink]**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_publish**
> Location private_collection_publish(collection_id => $collection_id)

Private Collection Publish

When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection Unique identifier

eval {
    my $result = $api_instance->private_collection_publish(collection_id => $collection_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_publish: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_reserve_doi**
> CollectionDOI private_collection_reserve_doi(collection_id => $collection_id)

Private Collection Reserve DOI

Reserve DOI for collection

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection Unique identifier

eval {
    my $result = $api_instance->private_collection_reserve_doi(collection_id => $collection_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_reserve_doi: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier | 

### Return type

[**CollectionDOI**](CollectionDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_reserve_handle**
> CollectionHandle private_collection_reserve_handle(collection_id => $collection_id)

Private Collection Reserve Handle

Reserve Handle for collection

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection Unique identifier

eval {
    my $result = $api_instance->private_collection_reserve_handle(collection_id => $collection_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_reserve_handle: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier | 

### Return type

[**CollectionHandle**](CollectionHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_resource**
> Location private_collection_resource(collection_id => $collection_id, resource => $resource)

Private Collection Resource

Edit collection resource data.

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection unique identifier
my $resource = WWW::OpenAPIClient::Object::Resource->new(); # Resource | Resource data

eval {
    my $result = $api_instance->private_collection_resource(collection_id => $collection_id, resource => $resource);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_resource: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection unique identifier | 
 **resource** | [**Resource**](Resource.md)| Resource data | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collection_update**
> LocationWarningsUpdate private_collection_update(collection_id => $collection_id, collection => $collection)

Update collection

Update a collection by passing full body parameters.

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $collection_id = 789; # int | Collection Unique identifier
my $collection = WWW::OpenAPIClient::Object::CollectionUpdate->new(); # CollectionUpdate | Collection description

eval {
    my $result = $api_instance->private_collection_update(collection_id => $collection_id, collection => $collection);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collection_update: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_id** | **int**| Collection Unique identifier | 
 **collection** | [**CollectionUpdate**](CollectionUpdate.md)| Collection description | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collections_list**
> ARRAY[Collection] private_collections_list(page => $page, page_size => $page_size, limit => $limit, offset => $offset, order => $order, order_direction => $order_direction)

Private Collections List

List private collections

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $page = 789; # int | Page number. Used for pagination with page_size
my $page_size = 10; # int | The number of results included on a page. Used for pagination with page
my $limit = 789; # int | Number of results included on a page. Used for pagination with query
my $offset = 789; # int | Where to start the listing (the offset of the first result). Used for pagination with limit
my $order = 'published_date'; # string | The field by which to order. Default varies by endpoint/resource.
my $order_direction = 'desc'; # string | 

eval {
    my $result = $api_instance->private_collections_list(page => $page, page_size => $page_size, limit => $limit, offset => $offset, order => $order, order_direction => $order_direction);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collections_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to &#39;published_date&#39;]
 **order_direction** | **string**|  | [optional] [default to &#39;desc&#39;]

### Return type

[**ARRAY[Collection]**](Collection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_collections_search**
> ARRAY[Collection] private_collections_search(search => $search)

Private Collections Search

Returns a list of private Collections

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::CollectionsApi;
my $api_instance = WWW::OpenAPIClient::CollectionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $search = WWW::OpenAPIClient::Object::PrivateCollectionSearch->new(); # PrivateCollectionSearch | Search Parameters

eval {
    my $result = $api_instance->private_collections_search(search => $search);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CollectionsApi->private_collections_search: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateCollectionSearch**](PrivateCollectionSearch.md)| Search Parameters | 

### Return type

[**ARRAY[Collection]**](Collection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

