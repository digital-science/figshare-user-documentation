# WWW::OpenAPIClient::Object::PrivateProjectArticle

## Load the model package
```perl
use WWW::OpenAPIClient::Object::PrivateProjectArticle;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**files** | [**ARRAY[PublicFile]**](PublicFile.md) | List of up to 10 article files. | 
**embargo_options** | [**ARRAY[GroupEmbargoOptions]**](GroupEmbargoOptions.md) | List of embargo options | 
**custom_fields** | [**ARRAY[CustomArticleField]**](CustomArticleField.md) | List of custom fields values | 
**account_id** | **int** | ID of the account owning the article | 
**download_disabled** | **boolean** | If true, downloading of files for this article is disabled | 
**authors** | [**ARRAY[Author]**](Author.md) | List of authors | 
**figshare_url** | **string** | Article public url | 
**curation_status** | **string** | Curation status of the article | 
**citation** | **string** | Article citation | 
**confidential_reason** | **string** | Confidentiality reason | 
**is_confidential** | **boolean** | Article Confidentiality | 
**size** | **int** | Article size | 
**funding** | **string** | Article funding | 
**funding_list** | [**ARRAY[FundingInformation]**](FundingInformation.md) | Full Article funding information | 
**tags** | **ARRAY[string]** | List of article tags. Keywords can be used instead | 
**keywords** | **ARRAY[string]** | List of article keywords. Tags can be used instead | 
**version** | **int** | Article version | 
**is_metadata_record** | **boolean** | True if article has no files | 
**metadata_reason** | **string** | Article metadata reason | 
**status** | **string** | Article status | 
**description** | **string** | Article description | 
**is_embargoed** | **boolean** | True if article is embargoed | 
**is_public** | **boolean** | True if article is published | 
**created_date** | **string** | Date when article was created | 
**has_linked_file** | **boolean** | True if any files are linked to the article | 
**categories** | [**ARRAY[Category]**](Category.md) | List of categories selected for the article | 
**license** | [**License**](License.md) |  | 
**embargo_title** | **string** | Title for embargo | 
**embargo_reason** | **string** | Reason for embargo | 
**references** | **ARRAY[string]** | List of references | 
**related_materials** | [**ARRAY[RelatedMaterial]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 
**id** | **int** | Unique identifier for article | 
**title** | **string** | Title of article | 
**doi** | **string** | DOI | 
**handle** | **string** | Handle | 
**url** | **string** | Api endpoint for article | 
**url_public_html** | **string** | Public site endpoint for article | 
**url_public_api** | **string** | Public Api endpoint for article | 
**url_private_html** | **string** | Private site endpoint for article | 
**url_private_api** | **string** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) |  | 
**thumb** | **string** | Thumbnail image | 
**defined_type** | **int** | Type of article identifier | 
**defined_type_name** | **string** | Name of the article type identifier | 
**resource_doi** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to &#39;&#39;]
**resource_title** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to &#39;&#39;]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


