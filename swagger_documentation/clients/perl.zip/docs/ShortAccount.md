# WWW::OpenAPIClient::Object::ShortAccount

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ShortAccount;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Account id | 
**first_name** | **string** | First Name | 
**last_name** | **string** | Last Name | 
**institution_id** | **int** | Account institution | 
**email** | **string** | User email | 
**active** | **int** | Account activity status | 
**institution_user_id** | **string** | Account institution user id | 
**quota** | **int** | Total storage available to account, in bytes | 
**used_quota** | **int** | Storage used by the account, in bytes | 
**user_id** | **int** | User id associated with account, useful for example for adding the account as an author to an item | 
**orcid_id** | **string** | ORCID iD associated to account | 
**symplectic_user_id** | **string** | Symplectic ID associated to account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


