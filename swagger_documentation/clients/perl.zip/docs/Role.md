# WWW::OpenAPIClient::Object::Role

## Load the model package
```perl
use WWW::OpenAPIClient::Object::Role;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Role id | 
**name** | **string** | Role name | 
**category** | **string** | Role category | 
**description** | **string** | Role description | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


