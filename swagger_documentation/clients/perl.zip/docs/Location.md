# WWW::OpenAPIClient::Object::Location

## Load the model package
```perl
use WWW::OpenAPIClient::Object::Location;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **string** | Url for item | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


