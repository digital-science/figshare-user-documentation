# WWW::OpenAPIClient::Object::InstitutionAccountsSearch

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InstitutionAccountsSearch;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_for** | **string** | Search term | [optional] 
**is_active** | **int** | Filter by active status | [optional] 
**page** | **int** | Page number. Used for pagination with page_size | [optional] 
**page_size** | **int** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **int** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **int** | Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
**institution_user_id** | **string** | filter by institution_user_id | [optional] 
**email** | **string** | filter by email | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


