# WWW::OpenAPIClient::Object::FundingSearch

## Load the model package
```perl
use WWW::OpenAPIClient::Object::FundingSearch;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_for** | **string** | Search term | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


