# WWW::SwaggerClient::Object::AccountCreate

## Load the model package
```perl
use WWW::SwaggerClient::Object::AccountCreate;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **string** | Email of account | 
**first_name** | **string** | First Name | [optional] [default to &#39;&#39;]
**last_name** | **string** | Last Name | [default to &#39;&#39;]
**group_id** | **int** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] 
**institution_user_id** | **string** | Institution user id | [optional] [default to &#39;&#39;]
**symplectic_user_id** | **string** | Symplectic user id | [optional] [default to &#39;&#39;]
**quota** | **int** | Account quota | [optional] 
**is_active** | **boolean** | Is account active | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


