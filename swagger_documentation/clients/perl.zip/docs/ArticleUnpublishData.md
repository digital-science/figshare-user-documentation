# WWW::OpenAPIClient::Object::ArticleUnpublishData

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ArticleUnpublishData;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason** | **string** | Reason of article unpublishing | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


