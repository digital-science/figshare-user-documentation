# WWW::OpenAPIClient::Object::PrivateAuthorsSearch

## Load the model package
```perl
use WWW::OpenAPIClient::Object::PrivateAuthorsSearch;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_for** | **string** | Search term | [optional] 
**page** | **int** | Page number. Used for pagination with page_size | [optional] 
**page_size** | **int** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **int** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **int** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
**institution_id** | **int** | Return only authors associated to this institution | [optional] 
**orcid** | **string** | Orcid of author | [optional] 
**group_id** | **int** | Return only authors in this group or subgroups of the group | [optional] 
**is_active** | **boolean** | Return only active authors if True | [optional] 
**is_public** | **boolean** | Return only authors that have published items if True | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


