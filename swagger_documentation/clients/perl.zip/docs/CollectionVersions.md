# WWW::SwaggerClient::Object::CollectionVersions

## Load the model package
```perl
use WWW::SwaggerClient::Object::CollectionVersions;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Version number | 
**url** | **string** | Api endpoint for the collection version | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


