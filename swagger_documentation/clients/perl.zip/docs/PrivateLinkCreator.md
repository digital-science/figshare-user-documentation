# WWW::SwaggerClient::Object::PrivateLinkCreator

## Load the model package
```perl
use WWW::SwaggerClient::Object::PrivateLinkCreator;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expires_date** | **string** | Date when this private link should expire - optional. By default private links expire in 365 days. | [optional] 
**read_only** | **boolean** | Optional, default true. Set to false to give private link users editing rights for this collection. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


