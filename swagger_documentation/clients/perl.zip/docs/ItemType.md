# WWW::OpenAPIClient::Object::ItemType

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ItemType;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The ID of the item type. | 
**name** | **string** | The name of the item type | 
**string_id** | **string** | The string identifier of the item type. | 
**icon** | **string** | The string identifying the icon of the item type. | 
**public_description** | **string** | The description of the item type. | 
**is_selectable** | **boolean** | The selectable status | 
**url_name** | **string** | The URL name of the item type. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


