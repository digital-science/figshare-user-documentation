# WWW::OpenAPIClient::Object::Author

## Load the model package
```perl
use WWW::OpenAPIClient::Object::Author;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Author id | 
**full_name** | **string** | Author full name | 
**first_name** | **string** | Author first name | 
**last_name** | **string** | Author last name | 
**is_active** | **boolean** | True if author has published items | 
**url_name** | **string** | Author url name | 
**orcid_id** | **string** | Author Orcid | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


