# WWW::SwaggerClient::Object::CategoryList

## Load the model package
```perl
use WWW::SwaggerClient::Object::CategoryList;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent_id** | **int** | Parent category | 
**id** | **int** | Category id | 
**title** | **string** | Category title | 
**path** | **string** | Path to all ancestor ids | 
**source_id** | **string** | ID in original standard taxonomy | 
**taxonomy_id** | **int** | Internal id of taxonomy the category is part of | 
**is_selectable** | **boolean** | The selectable status | 
**has_children** | **boolean** | True if category has children | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


