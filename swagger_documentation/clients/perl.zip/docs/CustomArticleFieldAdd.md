# WWW::OpenAPIClient::Object::CustomArticleFieldAdd

## Load the model package
```perl
use WWW::OpenAPIClient::Object::CustomArticleFieldAdd;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Custom  metadata name | 
**value** | **object** | Custom metadata value (can be either a string or an array of strings) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


