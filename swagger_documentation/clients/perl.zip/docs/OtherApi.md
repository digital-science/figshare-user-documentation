# WWW::OpenAPIClient::OtherApi

## Load the API package
```perl
use WWW::OpenAPIClient::Object::OtherApi;
```

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categories_list**](OtherApi.md#categories_list) | **GET** /categories | Public Categories
[**file_download**](OtherApi.md#file_download) | **GET** /file/download/{file_id} | Public File Download
[**item_types_list**](OtherApi.md#item_types_list) | **GET** /item_types | Item Types
[**licenses_list**](OtherApi.md#licenses_list) | **GET** /licenses | Public Licenses
[**private_account**](OtherApi.md#private_account) | **GET** /account | Private Account information
[**private_funding_search**](OtherApi.md#private_funding_search) | **POST** /account/funding/search | Search Funding
[**private_licenses_list**](OtherApi.md#private_licenses_list) | **GET** /account/licenses | Private Account Licenses


# **categories_list**
> ARRAY[CategoryList] categories_list()

Public Categories

Returns a list of public categories

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::OtherApi;
my $api_instance = WWW::OpenAPIClient::OtherApi->new(
);


eval {
    my $result = $api_instance->categories_list();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OtherApi->categories_list: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ARRAY[CategoryList]**](CategoryList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **file_download**
> file_download(file_id => $file_id)

Public File Download

Starts the download of a file

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::OtherApi;
my $api_instance = WWW::OpenAPIClient::OtherApi->new(
);

my $file_id = 56; # int | 

eval {
    $api_instance->file_download(file_id => $file_id);
};
if ($@) {
    warn "Exception when calling OtherApi->file_download: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **file_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **item_types_list**
> ARRAY[ItemType] item_types_list(group_id => $group_id)

Item Types

Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare.

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::OtherApi;
my $api_instance = WWW::OpenAPIClient::OtherApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $group_id = 0; # int | Identifier of the group for which the item types are requested

eval {
    my $result = $api_instance->item_types_list(group_id => $group_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OtherApi->item_types_list: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| Identifier of the group for which the item types are requested | [optional] [default to 0]

### Return type

[**ARRAY[ItemType]**](ItemType.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **licenses_list**
> ARRAY[License] licenses_list()

Public Licenses

Returns a list of public licenses

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::OtherApi;
my $api_instance = WWW::OpenAPIClient::OtherApi->new(
);


eval {
    my $result = $api_instance->licenses_list();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OtherApi->licenses_list: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ARRAY[License]**](License.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_account**
> Account private_account()

Private Account information

Account information for token/personal token

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::OtherApi;
my $api_instance = WWW::OpenAPIClient::OtherApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);


eval {
    my $result = $api_instance->private_account();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OtherApi->private_account: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_funding_search**
> ARRAY[FundingInformation] private_funding_search(search => $search)

Search Funding

Search for fundings

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::OtherApi;
my $api_instance = WWW::OpenAPIClient::OtherApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $search = WWW::OpenAPIClient::Object::FundingSearch->new(); # FundingSearch | Search Parameters

eval {
    my $result = $api_instance->private_funding_search(search => $search);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OtherApi->private_funding_search: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**FundingSearch**](FundingSearch.md)| Search Parameters | [optional] 

### Return type

[**ARRAY[FundingInformation]**](FundingInformation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_licenses_list**
> ARRAY[License] private_licenses_list()

Private Account Licenses

This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution.

### Example
```perl
use Data::Dumper;
use WWW::OpenAPIClient::OtherApi;
my $api_instance = WWW::OpenAPIClient::OtherApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);


eval {
    my $result = $api_instance->private_licenses_list();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OtherApi->private_licenses_list: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ARRAY[License]**](License.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

