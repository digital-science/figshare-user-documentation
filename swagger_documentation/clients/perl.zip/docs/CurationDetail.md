# WWW::OpenAPIClient::Object::CurationDetail

## Load the model package
```perl
use WWW::OpenAPIClient::Object::CurationDetail;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**item** | [**ArticleComplete**](ArticleComplete.md) |  | 
**id** | **int** | The review id | 
**group_id** | **int** | The group in which the article is present. | 
**account_id** | **int** | The ID of the account of the owner of the article of this review. | 
**assigned_to** | **int** | The ID of the account to which this review is assigned. | 
**article_id** | **int** | The ID of the article of this review. | 
**version** | **int** | The Version number of the article in review. | 
**comments_count** | **int** | The number of comments in the review. | 
**status** | **string** | The status of the review. | 
**created_date** | **string** | The creation date of the review. | 
**modified_date** | **string** | The date the review has been modified. | 
**request_number** | **int** | The request number of the review. | 
**resolution_comment** | **string** | The resolution comment of the review. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


