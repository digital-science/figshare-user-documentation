# WWW::OpenAPIClient::Object::ProjectPrivate

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ProjectPrivate;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | **string** | Role inside this project | 
**storage** | **string** | Project storage type | 
**url** | **string** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **string** | Project title | 
**created_date** | **string** | Date when project was created | 
**modified_date** | **string** | Date when project was last modified | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


