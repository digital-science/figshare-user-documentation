# WWW::OpenAPIClient::Object::License

## Load the model package
```perl
use WWW::OpenAPIClient::Object::License;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **int** | License value | 
**name** | **string** | License name | 
**url** | **string** | License url | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


