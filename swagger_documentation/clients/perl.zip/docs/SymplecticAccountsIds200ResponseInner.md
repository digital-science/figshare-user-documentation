# WWW::OpenAPIClient::Object::SymplecticAccountsIds200ResponseInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SymplecticAccountsIds200ResponseInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**institution_user_id** | **string** |  | [optional] 
**modified_date** | **DATE_TIME** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


