# WWW::OpenAPIClient::Object::ArticleVersions

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ArticleVersions;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **int** | Version number | 
**url** | **string** | Api endpoint for the item version | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


