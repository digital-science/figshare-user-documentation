# FigshareApi.FileId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fileId** | **Number** | File ID | [optional] 


