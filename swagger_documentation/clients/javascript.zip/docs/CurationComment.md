# FigshareApi.CurationComment

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | The ID of the comment. | 
**accountId** | **Number** | The ID of the account which generated this comment. | 
**type** | **String** | The ID of the account which generated this comment. | 
**text** | **String** | The value/content of the comment. | 
**createdDate** | **String** | The creation date of the comment. | 
**modifiedDate** | **String** | The date the comment has been modified. | 



## Enum: TypeEnum


* `comment` (value: `"comment"`)

* `approved` (value: `"approved"`)

* `rejected` (value: `"rejected"`)

* `closed` (value: `"closed"`)




