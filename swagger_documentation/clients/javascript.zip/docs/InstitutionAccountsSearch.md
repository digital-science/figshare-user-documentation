# FigshareApi.InstitutionAccountsSearch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**searchFor** | **String** | Search term | [optional] 
**isActive** | **Number** | Filter by active status | [optional] 
**page** | **Number** | Page number. Used for pagination with page_size | [optional] 
**pageSize** | **Number** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **Number** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **Number** | Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
**institutionUserId** | **String** | filter by institution_user_id | [optional] 
**email** | **String** | filter by email | [optional] 


