# FigshareApi.UploadInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **String** | token received after initializing a file upload | [optional] 
**md5** | **String** | md5 provided on upload initialization | [optional] 
**size** | **Number** | size of file in bytes | [optional] 
**name** | **String** | name of file on upload server | [optional] 
**status** | **String** | Upload status | [optional] 
**parts** | [**[UploadFilePart]**](UploadFilePart.md) | Uploads parts | [optional] 



## Enum: StatusEnum


* `PENDING` (value: `"PENDING"`)

* `COMPLETED` (value: `"COMPLETED"`)

* `ABORTED` (value: `"ABORTED"`)




