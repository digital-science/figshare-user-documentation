# FigshareApi.PrivateLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Private link id | 
**isActive** | **Boolean** | True if private link is active | 
**expiresDate** | **String** | Date when link will expire | 
**htmlLocation** | **String** | HTML url for private link | 


