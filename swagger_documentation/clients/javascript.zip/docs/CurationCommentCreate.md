# FigshareApi.CurationCommentCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** | The contents/value of the comment | 


