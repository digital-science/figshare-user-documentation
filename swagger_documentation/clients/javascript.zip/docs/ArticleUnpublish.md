# FigshareApi.ArticleUnpublish

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason** | **String** | Reason of article unpublishing | [optional] 


