# FigshareApi.CollectionSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resourceDoi** | **String** | Only return collections with this resource_doi | [optional] 
**doi** | **String** | Only return collections with this doi | [optional] 
**handle** | **String** | Only return collections with this handle | [optional] 
**order** | **String** | The field by which to order. | [optional] [default to 'created_date']


<a name="OrderEnum"></a>
## Enum: OrderEnum


* `createdDate` (value: `"created_date"`)

* `publishedDate` (value: `"published_date"`)

* `modifiedDate` (value: `"modified_date"`)

* `views` (value: `"views"`)

* `shares` (value: `"shares"`)

* `cites` (value: `"cites"`)




