# FigshareApi.AccountUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupId** | **Number** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | 
**isActive** | **Boolean** | Is account active | 


