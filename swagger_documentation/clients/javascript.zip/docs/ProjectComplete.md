# FigshareApi.ProjectComplete

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **String** | Project funding | 
**fundingList** | [**[FundingInformation]**](FundingInformation.md) | Full Project funding information | 
**description** | **String** | Project description | 
**collaborators** | [**[Collaborator]**](Collaborator.md) | List of project collaborators | 
**customFields** | [**[CustomArticleField]**](CustomArticleField.md) | Project custom fields | 
**modifiedDate** | **String** | Date when project was last modified | 
**createdDate** | **String** | Date when project was created | 
**url** | **String** | Api endpoint | 
**id** | **Number** | Project id | 
**title** | **String** | Project title | 


