# FigshareApi.AccountReport

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | A unique ID for the AccountRecord | 
**accountId** | **Number** | The ID of the account which generated this report. | 
**createdDate** | **String** | Date when the AccountReport was requested | 
**status** | **String** | Status of the report | 
**downloadUrl** | **String** | The download link for the generated XLSX | 
**groupId** | **Number** | The group ID that was used to filter the report, if any. | 



## Enum: StatusEnum


* `missing` (value: `"missing"`)

* `pending` (value: `"pending"`)

* `done` (value: `"done"`)




