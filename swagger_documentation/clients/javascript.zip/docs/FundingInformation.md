# FigshareApi.FundingInformation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Funding id | 
**title** | **String** | The funding name | 
**grantCode** | **String** | The grant code | 
**funderName** | **String** | Funder&#39;s name | 
**isUserDefined** | **Number** | Return 1 whether the grant has been introduced manually, 0 otherwise | 
**url** | **String** | The grant url | 


