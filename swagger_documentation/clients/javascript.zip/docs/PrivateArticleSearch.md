# FigshareApi.PrivateArticleSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resourceId** | **String** | only return collections with this resource_id | [optional] 


