# FigshareApi.TimelineUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**firstOnline** | **String** | Online posted date | [optional] 
**publisherPublication** | **String** | Publish date | [optional] 
**publisherAcceptance** | **String** | Date when the item was accepted for publication | [optional] 


