# FigshareApi.CollectionVersions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **Number** | Version number | 
**url** | **String** | Api endpoint for the collection version | 
**funding** | [**[FundingInformation]**](FundingInformation.md) | Full Collection funding information | 


