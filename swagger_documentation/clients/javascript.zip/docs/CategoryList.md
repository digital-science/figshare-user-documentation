# FigshareApi.CategoryList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isSelectable** | **Boolean** | The selectable status | 
**hasChildren** | **Boolean** | True if category has children | 


