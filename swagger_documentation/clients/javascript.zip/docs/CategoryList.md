# FigshareApi.CategoryList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isSelectable** | **Boolean** | The selectable status | 
**hasChildren** | **Boolean** | True if category has children | 
**parentId** | **Number** | Parent category | 
**id** | **Number** | Category id | 
**title** | **String** | Category title | 
**path** | **String** | Path to all ancestor ids | 
**sourceId** | **String** | ID in original standard taxonomy | 
**taxonomyId** | **Number** | Internal id of taxonomy the category is part of | 


