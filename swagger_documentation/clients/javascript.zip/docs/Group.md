# FigshareApi.Group

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Group id | 
**name** | **String** | Group name | 
**resourceId** | **String** | Group resource id | 
**parentId** | **Number** | Parent group if any | 
**associationCriteria** | **String** | HR code associated with group, if code exists | 


