# FigshareApi.ProfilesApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateUserProfile**](ProfilesApi.md#updateUserProfile) | **PUT** /account/profile | Update public profile
[**updateUserProfilePicture**](ProfilesApi.md#updateUserProfilePicture) | **POST** /account/profile/{user_id}/picture | Update public profile picture



## updateUserProfile

> Object updateUserProfile(userProfileData, opts)

Update public profile

Updates the fields of the user&#39;s public profile.

### Example

```javascript
import FigshareApi from 'figshare_api';
let defaultClient = FigshareApi.ApiClient.instance;
// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new FigshareApi.ProfilesApi();
let userProfileData = new FigshareApi.ProfileUpdateData(); // ProfileUpdateData | 
let opts = {
  'userId': 789, // Number | User ID
  'institutionUserId': "institutionUserId_example" // String | Institutional user ID
};
apiInstance.updateUserProfile(userProfileData, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userProfileData** | [**ProfileUpdateData**](ProfileUpdateData.md)|  | 
 **userId** | **Number**| User ID | [optional] 
 **institutionUserId** | **String**| Institutional user ID | [optional] 

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## updateUserProfilePicture

> Object updateUserProfilePicture(userId, profilePicture)

Update public profile picture

Updates the profile picture of the user&#39;s public profile.

### Example

```javascript
import FigshareApi from 'figshare_api';
let defaultClient = FigshareApi.ApiClient.instance;
// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new FigshareApi.ProfilesApi();
let userId = 789; // Number | User ID
let profilePicture = "/path/to/file"; // File | User profile picture
apiInstance.updateUserProfilePicture(userId, profilePicture, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **Number**| User ID | 
 **profilePicture** | **File**| User profile picture | 

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: multipart/form-data
- **Accept**: application/json

