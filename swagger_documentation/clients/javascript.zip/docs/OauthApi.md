# FigshareApi.OauthApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createToken**](OauthApi.md#createToken) | **POST** /token | Create OAuth token
[**getTokenInfo**](OauthApi.md#getTokenInfo) | **GET** /token | Get OAuth token information



## createToken

> OAuthToken createToken(opts)

Create OAuth token

Creates OAuth token using various grant types

### Example

```javascript
import FigshareApi from 'figshare_api';

let apiInstance = new FigshareApi.OauthApi();
let opts = {
  'body': new FigshareApi.CreateOAuthToken() // CreateOAuthToken | Create OAuth Token Parameters
};
apiInstance.createToken(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateOAuthToken**](CreateOAuthToken.md)| Create OAuth Token Parameters | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## getTokenInfo

> OAuthToken getTokenInfo(opts)

Get OAuth token information

Returns information about the current OAuth token

### Example

```javascript
import FigshareApi from 'figshare_api';

let apiInstance = new FigshareApi.OauthApi();
let opts = {
  'accessToken': "accessToken_example" // String | OAuth access token
};
apiInstance.getTokenInfo(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accessToken** | **String**| OAuth access token | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

