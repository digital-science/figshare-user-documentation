# FigshareApi.AltmetricApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**altmetricInstitutionsList**](AltmetricApi.md#altmetricInstitutionsList) | **GET** /altmetric/institutions | List Altmetric Institutions



## altmetricInstitutionsList

> [AltmetricInstitution] altmetricInstitutionsList(opts)

List Altmetric Institutions

Returns a list of institutions available for Altmetric reporting

### Example

```javascript
import FigshareApi from 'figshare_api';

let apiInstance = new FigshareApi.AltmetricApi();
let opts = {
  'offset': 0 // Number | Where to start the listing. The offset of the first item.
};
apiInstance.altmetricInstitutionsList(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **Number**| Where to start the listing. The offset of the first item. | [optional] [default to 0]

### Return type

[**[AltmetricInstitution]**](AltmetricInstitution.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

