# FigshareApi.CollectionCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountId** | **Number** | ID of the account owning the collection | 
**funding** | [**[FundingInformation]**](FundingInformation.md) | Full Collection funding information | 
**resourceId** | **String** | Collection resource id | 
**resourceDoi** | **String** | Collection resource doi | 
**resourceTitle** | **String** | Collection resource title | 
**resourceLink** | **String** | Collection resource link | 
**resourceVersion** | **Number** | Collection resource version | 
**version** | **Number** | Collection version | 
**description** | **String** | Collection description | 
**categories** | [**[Category]**](Category.md) | List of collection categories | 
**references** | **[String]** | List of collection references | 
**tags** | **[String]** | List of collection tags | 
**authors** | [**[Author]**](Author.md) | List of collection authors | 
**institutionId** | **Number** | Collection institution | 
**groupId** | **Number** | Collection group | 
**articlesCount** | **Number** | Number of articles in collection | 
**_public** | **Boolean** | True if collection is published | 
**citation** | **String** | Collection citation | 
**customFields** | [**[CustomArticleField]**](CustomArticleField.md) | Collection custom fields | 
**modifiedDate** | **String** | Date when collection was last modified | 
**createdDate** | **String** | Date when collection was created | 
**timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 


