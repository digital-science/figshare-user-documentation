# FigshareApi.ProjectPrivate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | **String** | Role inside this project | 
**storage** | **String** | Project storage type | 
**url** | **String** | Api endpoint | 
**id** | **Number** | Project id | 
**title** | **String** | Project title | 
**createdDate** | **String** | Date when project was created | 
**modifiedDate** | **String** | Date when project was last modified | 



## Enum: RoleEnum


* `Owner` (value: `"Owner"`)

* `Collaborator` (value: `"Collaborator"`)

* `Viewer` (value: `"Viewer"`)





## Enum: StorageEnum


* `individual` (value: `"individual"`)

* `group` (value: `"group"`)




