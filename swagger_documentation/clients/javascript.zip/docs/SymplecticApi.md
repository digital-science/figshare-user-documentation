# FigshareApi.SymplecticApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**symplecticAccountArticles**](SymplecticApi.md#symplecticAccountArticles) | **GET** /symplectic/accounts/{external_user_id}/articles | Get articles for a specific account
[**symplecticAccountsIds**](SymplecticApi.md#symplecticAccountsIds) | **GET** /symplectic/accounts | Get changed accounts for Symplectic Elements
[**symplecticArticle**](SymplecticApi.md#symplecticArticle) | **GET** /symplectic/articles/{article_id} | Get article details for Symplectic Elements
[**symplecticChangedArticles**](SymplecticApi.md#symplecticChangedArticles) | **GET** /symplectic/articles | Get changed articles for Symplectic Elements
[**symplecticUserId**](SymplecticApi.md#symplecticUserId) | **GET** /symplectic/users/{user_id} | Get institutional user ID for a user



## symplecticAccountArticles

> [Object] symplecticAccountArticles(externalUserId, opts)

Get articles for a specific account

Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id).

### Example

```javascript
import FigshareApi from 'figshare_api';
let defaultClient = FigshareApi.ApiClient.instance;
// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new FigshareApi.SymplecticApi();
let externalUserId = "externalUserId_example"; // String | External user ID (symplectic_user_id or institution_user_id)
let opts = {
  'offset': 0, // Number | Number of results to skip for pagination
  'limit': 10, // Number | Maximum number of results to return
  'status': "status_example", // String | Filter by article status
  'isEmbargoed': "isEmbargoed_example" // String | Filter by embargo status
};
apiInstance.symplecticAccountArticles(externalUserId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **externalUserId** | **String**| External user ID (symplectic_user_id or institution_user_id) | 
 **offset** | **Number**| Number of results to skip for pagination | [optional] [default to 0]
 **limit** | **Number**| Maximum number of results to return | [optional] [default to 10]
 **status** | **String**| Filter by article status | [optional] 
 **isEmbargoed** | **String**| Filter by embargo status | [optional] 

### Return type

**[Object]**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## symplecticAccountsIds

> [SymplecticAccountsIds200ResponseInner] symplecticAccountsIds(since)

Get changed accounts for Symplectic Elements

Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration.

### Example

```javascript
import FigshareApi from 'figshare_api';
let defaultClient = FigshareApi.ApiClient.instance;
// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new FigshareApi.SymplecticApi();
let since = "2015-01-01 00:00:00"; // String | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
apiInstance.symplecticAccountsIds(since, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **since** | **String**| ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | 

### Return type

[**[SymplecticAccountsIds200ResponseInner]**](SymplecticAccountsIds200ResponseInner.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## symplecticArticle

> Object symplecticArticle(articleId)

Get article details for Symplectic Elements

Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information.

### Example

```javascript
import FigshareApi from 'figshare_api';
let defaultClient = FigshareApi.ApiClient.instance;
// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new FigshareApi.SymplecticApi();
let articleId = 56; // Number | Article ID
apiInstance.symplecticArticle(articleId, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Number**| Article ID | 

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## symplecticChangedArticles

> [Object] symplecticChangedArticles(since, opts)

Get changed articles for Symplectic Elements

Returns a list of articles for Symplectic Elements integration to synchronize article data.

### Example

```javascript
import FigshareApi from 'figshare_api';
let defaultClient = FigshareApi.ApiClient.instance;
// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new FigshareApi.SymplecticApi();
let since = "2015-01-01 00:00:00"; // String | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
let opts = {
  'offset': 0, // Number | Number of results to skip for pagination
  'limit': 10, // Number | Maximum number of results to return
  'status': "status_example", // String | Filter by article status
  'isEmbargoed': "isEmbargoed_example" // String | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type
};
apiInstance.symplecticChangedArticles(since, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **since** | **String**| ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | 
 **offset** | **Number**| Number of results to skip for pagination | [optional] [default to 0]
 **limit** | **Number**| Maximum number of results to return | [optional] [default to 10]
 **status** | **String**| Filter by article status | [optional] 
 **isEmbargoed** | **String**| Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type | [optional] 

### Return type

**[Object]**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## symplecticUserId

> SymplecticUserId200Response symplecticUserId(userId)

Get institutional user ID for a user

Returns the institution user ID for a given user within the authenticated account&#39;s institution.

### Example

```javascript
import FigshareApi from 'figshare_api';
let defaultClient = FigshareApi.ApiClient.instance;
// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new FigshareApi.SymplecticApi();
let userId = 56; // Number | User ID
apiInstance.symplecticUserId(userId, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **Number**| User ID | 

### Return type

[**SymplecticUserId200Response**](SymplecticUserId200Response.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

