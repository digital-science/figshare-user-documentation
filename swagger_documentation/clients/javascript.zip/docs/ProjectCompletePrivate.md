# FigshareApi.ProjectCompletePrivate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **String** | Project funding | 
**fundingList** | [**[FundingInformation]**](FundingInformation.md) | Full Project funding information | 
**description** | **String** | Project description | 
**collaborators** | [**[Collaborator]**](Collaborator.md) | List of project collaborators | 
**quota** | **Number** | Project quota | 
**usedQuota** | **Number** | Project used quota | 
**createdDate** | **String** | Date when project was created | 
**modifiedDate** | **String** | Date when project was last modified | 
**usedQuotaPrivate** | **Number** | Project private quota used | 
**usedQuotaPublic** | **Number** | Project public quota used | 
**groupId** | **Number** | Group of project if any | 
**accountId** | **Number** | ID of the account owning the project | 
**customFields** | [**[ShortCustomField]**](ShortCustomField.md) | Collection custom fields | 
**role** | **String** | Role inside this project | 
**storage** | **String** | Project storage type | 
**url** | **String** | Api endpoint | 
**id** | **Number** | Project id | 
**title** | **String** | Project title | 



## Enum: RoleEnum


* `Owner` (value: `"Owner"`)

* `Collaborator` (value: `"Collaborator"`)

* `Viewer` (value: `"Viewer"`)





## Enum: StorageEnum


* `individual` (value: `"individual"`)

* `group` (value: `"group"`)




