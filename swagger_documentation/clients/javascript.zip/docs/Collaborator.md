# FigshareApi.Collaborator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**roleName** | **String** | Collaborator role | 
**userId** | **Number** | Collaborator id | 
**name** | **String** | Collaborator name | 


