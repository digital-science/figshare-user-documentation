# FigshareApi.ArticlesCreator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | **[Number]** | List of article ids | 


