# FigshareApi.AuthorComplete

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**institutionId** | **Number** | Institution id | 
**groupId** | **Number** | Group id | 
**firstName** | **String** | First Name | 
**lastName** | **String** | Last Name | 
**isPublic** | **Number** | if 1 then the author has published items | 
**jobTitle** | **String** | Job title | 
**id** | **Number** | Author id | 
**fullName** | **String** | Author full name | 
**isActive** | **Boolean** | True if author has published items | 
**urlName** | **String** | Author url name | 
**orcidId** | **String** | Author Orcid | 


