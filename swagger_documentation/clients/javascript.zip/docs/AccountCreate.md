# FigshareApi.AccountCreate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** | Email of account | 
**firstName** | **String** | First Name | [optional] [default to &#39;&#39;]
**lastName** | **String** | Last Name | [default to &#39;&#39;]
**groupId** | **Number** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] 
**institutionUserId** | **String** | Institution user id | [optional] [default to &#39;&#39;]
**symplecticUserId** | **String** | Symplectic user id | [optional] [default to &#39;&#39;]
**quota** | **Number** | Account quota | [optional] 
**isActive** | **Boolean** | Is account active | [optional] 


