# FigshareApi.GroupEmbargoOptions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Embargo option id | 
**type** | **String** | Embargo permission type | 
**ipName** | **String** | IP range name; value appears if type is ip_range | 



## Enum: TypeEnum


* `logged_in` (value: `"logged_in"`)

* `ip_range` (value: `"ip_range"`)

* `administrator` (value: `"administrator"`)




