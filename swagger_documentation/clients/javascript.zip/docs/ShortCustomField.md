# FigshareApi.ShortCustomField

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Custom field id | 
**name** | **String** | Custom field name | 
**fieldType** | **String** | Custom field type | 
**settings** | **Object** | Settings for the custom field | [optional] 
**order** | **Number** | Order of the field in the group | [optional] 
**isMandatory** | **Boolean** | Whether the field is mandatory or not | [optional] 



## Enum: FieldTypeEnum


* `text` (value: `"text"`)

* `textarea` (value: `"textarea"`)

* `dropdown` (value: `"dropdown"`)

* `url` (value: `"url"`)

* `email` (value: `"email"`)

* `date` (value: `"date"`)

* `dropdown_large_list` (value: `"dropdown_large_list"`)




