# FigshareApi.AccountCreateResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountId** | **Number** | ID of created account | 


