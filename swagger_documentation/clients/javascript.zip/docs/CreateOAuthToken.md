# FigshareApi.CreateOAuthToken

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clientId** | **String** |  | 
**clientSecret** | **String** |  | 
**grantType** | **String** |  | 
**code** | **String** | Required if grant_type is &#39;authorization_code&#39; | [optional] 
**refreshToken** | **String** | Required if grant_type is &#39;refresh_token&#39; | [optional] 
**username** | **String** | Required if grant_type is &#39;password&#39; | [optional] 
**password** | **String** | Required if grant_type is &#39;password&#39; | [optional] 



## Enum: GrantTypeEnum


* `authorization_code` (value: `"authorization_code"`)

* `refresh_token` (value: `"refresh_token"`)

* `password` (value: `"password"`)

* `client_credentials` (value: `"client_credentials"`)




