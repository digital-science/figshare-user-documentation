# FigshareApi.ProjectArticle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**citation** | **String** | Article citation | 
**confidentialReason** | **String** | Confidentiality reason | 
**isConfidential** | **Boolean** | Article Confidentiality | 
**size** | **Number** | Article size | 
**funding** | **String** | Article funding | 
**fundingList** | [**[FundingInformation]**](FundingInformation.md) | Full Article funding information | 
**tags** | **[String]** | List of article tags | 
**version** | **Number** | Article version | 
**isActive** | **Boolean** | True if article is active | 
**isMetadataRecord** | **Boolean** | True if article has no files | 
**metadataReason** | **String** | Article metadata reason | 
**status** | **String** | Article status | 
**description** | **String** | Article description | 
**isEmbargoed** | **Boolean** | True if article is embargoed | 
**isPublic** | **Boolean** | True if article is published | 
**createdDate** | **String** | Date when article was created | 
**hasLinkedFile** | **Boolean** | True if any files are linked to the article | 
**categories** | [**[Category]**](Category.md) | List of categories selected for the article | 
**license** | [**License**](License.md) | Article selected license | 
**embargoTitle** | **String** | Title for embargo | 
**embargoReason** | **String** | Reason for embargo | 
**references** | **[String]** | List of references | 
**relatedMaterials** | [**[RelatedMaterial]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 


