# FigshareApi.ArticleWithProject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**projectId** | **Number** | Project id for this article. | [default to 0]


