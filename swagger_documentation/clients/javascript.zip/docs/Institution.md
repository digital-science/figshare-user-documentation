# FigshareApi.Institution

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Institution id | 
**name** | **String** | Institution name | 


