# FigshareApi.LocationWarningsUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **String** | Url for entity | 
**warnings** | **[String]** | Issues encountered during the operation | 


