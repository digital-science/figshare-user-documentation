# FigshareApi.Category

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parentId** | **Number** | Parent category | 
**id** | **Number** | Category id | 
**title** | **String** | Category title | 
**path** | **String** | Path to all ancestor ids | 
**sourceId** | **String** | ID in original standard taxonomy | 
**taxonomyId** | **Number** | Internal id of taxonomy the category is part of | 


