# FigshareApi.CreateProjectResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entityId** | **Number** | Figshare ID of the entity | 
**location** | **String** | Url for entity | 


