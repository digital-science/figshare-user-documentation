# FigshareApi.ProjectCollaboratorInvite

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**roleName** | **String** | Role of the the collaborator inside the project | 
**userId** | **Number** | User id of the collaborator | [optional] 
**email** | **String** | Collaborator email | [optional] 
**comment** | **String** | Text sent when inviting the user to the project | [optional] 



## Enum: RoleNameEnum


* `viewer` (value: `"viewer"`)

* `collaborator` (value: `"collaborator"`)




