# CurationDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**item** | [**ArticleComplete**](ArticleComplete.md) |  | 
**id** | **Int** | The review id | 
**groupId** | **Int** | The group in which the article is present. | 
**accountId** | **Int** | The ID of the account of the owner of the article of this review. | 
**assignedTo** | **Int** | The ID of the account to which this review is assigned. | 
**articleId** | **Int** | The ID of the article of this review. | 
**version** | **Int** | The Version number of the article in review. | 
**commentsCount** | **Int** | The number of comments in the review. | 
**status** | **String** | The status of the review. | 
**createdDate** | **String** | The creation date of the review. | 
**modifiedDate** | **String** | The date the review has been modified. | 
**requestNumber** | **Int** | The request number of the review. | 
**resolutionComment** | **String** | The resolution comment of the review. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


