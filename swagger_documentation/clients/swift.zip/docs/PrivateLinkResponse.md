# PrivateLinkResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **String** | Url for private link | 
**htmlLocation** | **String** | HTML url for private link | 
**token** | **String** | Token for private link | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


