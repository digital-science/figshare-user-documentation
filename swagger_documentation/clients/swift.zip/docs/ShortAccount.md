# ShortAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int64** | Account id | 
**firstName** | **String** | First Name | 
**lastName** | **String** | Last Name | 
**institutionId** | **Int64** | Account institution | 
**email** | **String** | User email | 
**active** | **Int64** | Account activity status | 
**institutionUserId** | **String** | Account institution user id | 
**quota** | **Int64** | Total storage available to account, in bytes | 
**usedQuota** | **Int64** | Storage used by the account, in bytes | 
**userId** | **Int64** | User id associated with account, useful for example for adding the account as an author to an item | 
**orcidId** | **String** | ORCID iD associated to account | 
**symplecticUserId** | **String** | Symplectic ID associated to account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


