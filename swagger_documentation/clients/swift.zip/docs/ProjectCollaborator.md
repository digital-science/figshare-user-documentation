# ProjectCollaborator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | Status of collaborator invitation | 
**roleName** | **String** | Collaborator role | 
**userId** | **Int** | Collaborator id | 
**name** | **String** | Collaborator name | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


