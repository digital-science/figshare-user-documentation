# License

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Int64** | License value | 
**name** | **String** | License name | 
**url** | **String** | License url | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


