# ProjectsAPI

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**privateProjectArticleDelete**](ProjectsAPI.md#privateprojectarticledelete) | **DELETE** /account/projects/{project_id}/articles/{article_id} | Delete project article
[**privateProjectArticleDetails**](ProjectsAPI.md#privateprojectarticledetails) | **GET** /account/projects/{project_id}/articles/{article_id} | Project article details
[**privateProjectArticleFile**](ProjectsAPI.md#privateprojectarticlefile) | **GET** /account/projects/{project_id}/articles/{article_id}/files/{file_id} | Project article file details
[**privateProjectArticleFiles**](ProjectsAPI.md#privateprojectarticlefiles) | **GET** /account/projects/{project_id}/articles/{article_id}/files | Project article list files
[**privateProjectArticlesCreate**](ProjectsAPI.md#privateprojectarticlescreate) | **POST** /account/projects/{project_id}/articles | Create project article
[**privateProjectArticlesList**](ProjectsAPI.md#privateprojectarticleslist) | **GET** /account/projects/{project_id}/articles | List project articles
[**privateProjectCollaboratorDelete**](ProjectsAPI.md#privateprojectcollaboratordelete) | **DELETE** /account/projects/{project_id}/collaborators/{user_id} | Remove project collaborator
[**privateProjectCollaboratorsInvite**](ProjectsAPI.md#privateprojectcollaboratorsinvite) | **POST** /account/projects/{project_id}/collaborators | Invite project collaborators
[**privateProjectCollaboratorsList**](ProjectsAPI.md#privateprojectcollaboratorslist) | **GET** /account/projects/{project_id}/collaborators | List project collaborators
[**privateProjectCreate**](ProjectsAPI.md#privateprojectcreate) | **POST** /account/projects | Create project
[**privateProjectDelete**](ProjectsAPI.md#privateprojectdelete) | **DELETE** /account/projects/{project_id} | Delete project
[**privateProjectDetails**](ProjectsAPI.md#privateprojectdetails) | **GET** /account/projects/{project_id} | View project details
[**privateProjectLeave**](ProjectsAPI.md#privateprojectleave) | **POST** /account/projects/{project_id}/leave | Private Project Leave
[**privateProjectNote**](ProjectsAPI.md#privateprojectnote) | **GET** /account/projects/{project_id}/notes/{note_id} | Project note details
[**privateProjectNoteDelete**](ProjectsAPI.md#privateprojectnotedelete) | **DELETE** /account/projects/{project_id}/notes/{note_id} | Delete project note
[**privateProjectNoteUpdate**](ProjectsAPI.md#privateprojectnoteupdate) | **PUT** /account/projects/{project_id}/notes/{note_id} | Update project note
[**privateProjectNotesCreate**](ProjectsAPI.md#privateprojectnotescreate) | **POST** /account/projects/{project_id}/notes | Create project note
[**privateProjectNotesList**](ProjectsAPI.md#privateprojectnoteslist) | **GET** /account/projects/{project_id}/notes | List project notes
[**privateProjectPartialUpdate**](ProjectsAPI.md#privateprojectpartialupdate) | **PATCH** /account/projects/{project_id} | Partially update project
[**privateProjectPublish**](ProjectsAPI.md#privateprojectpublish) | **POST** /account/projects/{project_id}/publish | Private Project Publish
[**privateProjectUpdate**](ProjectsAPI.md#privateprojectupdate) | **PUT** /account/projects/{project_id} | Update project
[**privateProjectsList**](ProjectsAPI.md#privateprojectslist) | **GET** /account/projects | Private Projects
[**privateProjectsSearch**](ProjectsAPI.md#privateprojectssearch) | **POST** /account/projects/search | Private Projects search
[**projectArticles**](ProjectsAPI.md#projectarticles) | **GET** /projects/{project_id}/articles | Public Project Articles
[**projectDetails**](ProjectsAPI.md#projectdetails) | **GET** /projects/{project_id} | Public Project
[**projectsList**](ProjectsAPI.md#projectslist) | **GET** /projects | Public Projects
[**projectsSearch**](ProjectsAPI.md#projectssearch) | **POST** /projects/search | Public Projects Search


# **privateProjectArticleDelete**
```swift
    open class func privateProjectArticleDelete(projectId: Int64, articleId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete project article

Delete project article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let articleId = 987 // Int64 | Project Article unique identifier

// Delete project article
ProjectsAPI.privateProjectArticleDelete(projectId: projectId, articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **articleId** | **Int64** | Project Article unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectArticleDetails**
```swift
    open class func privateProjectArticleDetails(projectId: Int64, articleId: Int64, completion: @escaping (_ data: ArticleCompletePrivate?, _ error: Error?) -> Void)
```

Project article details

Project article details

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let articleId = 987 // Int64 | Project Article unique identifier

// Project article details
ProjectsAPI.privateProjectArticleDetails(projectId: projectId, articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **articleId** | **Int64** | Project Article unique identifier | 

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectArticleFile**
```swift
    open class func privateProjectArticleFile(projectId: Int64, articleId: Int64, fileId: Int64, completion: @escaping (_ data: PrivateFile?, _ error: Error?) -> Void)
```

Project article file details

Project article file details

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let articleId = 987 // Int64 | Project Article unique identifier
let fileId = 987 // Int64 | File unique identifier

// Project article file details
ProjectsAPI.privateProjectArticleFile(projectId: projectId, articleId: articleId, fileId: fileId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **articleId** | **Int64** | Project Article unique identifier | 
 **fileId** | **Int64** | File unique identifier | 

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectArticleFiles**
```swift
    open class func privateProjectArticleFiles(projectId: Int64, articleId: Int64, completion: @escaping (_ data: [PrivateFile]?, _ error: Error?) -> Void)
```

Project article list files

List article files

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let articleId = 987 // Int64 | Project Article unique identifier

// Project article list files
ProjectsAPI.privateProjectArticleFiles(projectId: projectId, articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **articleId** | **Int64** | Project Article unique identifier | 

### Return type

[**[PrivateFile]**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectArticlesCreate**
```swift
    open class func privateProjectArticlesCreate(projectId: Int64, article: ArticleProjectCreate, completion: @escaping (_ data: Location?, _ error: Error?) -> Void)
```

Create project article

Create a new Article and associate it with this project

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let article = ArticleProjectCreate(title: "title_example", description: "description_example", tags: ["tags_example"], keywords: ["keywords_example"], references: ["references_example"], relatedMaterials: [RelatedMaterial(id: 123, identifier: "identifier_example", title: "title_example", relation: "relation_example", identifierType: "identifierType_example", isLinkout: true, link: "link_example")], categories: [123], categoriesBySourceId: ["categoriesBySourceId_example"], authors: [123], customFields: 123, customFieldsList: [CustomArticleFieldAdd(name: "name_example", value: 123)], definedType: "definedType_example", funding: "funding_example", fundingList: [FundingCreate(id: 123, title: "title_example")], license: 123, doi: "doi_example", handle: "handle_example", resourceDoi: "resourceDoi_example", resourceTitle: "resourceTitle_example", timeline: TimelineUpdate(firstOnline: "firstOnline_example", publisherPublication: "publisherPublication_example", publisherAcceptance: "publisherAcceptance_example")) // ArticleProjectCreate | Article description

// Create project article
ProjectsAPI.privateProjectArticlesCreate(projectId: projectId, article: article) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **article** | [**ArticleProjectCreate**](ArticleProjectCreate.md) | Article description | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectArticlesList**
```swift
    open class func privateProjectArticlesList(projectId: Int64, completion: @escaping (_ data: [Article]?, _ error: Error?) -> Void)
```

List project articles

List project articles

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier

// List project articles
ProjectsAPI.privateProjectArticlesList(projectId: projectId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 

### Return type

[**[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectCollaboratorDelete**
```swift
    open class func privateProjectCollaboratorDelete(projectId: Int64, userId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Remove project collaborator

Remove project collaborator

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let userId = 987 // Int64 | User unique identifier

// Remove project collaborator
ProjectsAPI.privateProjectCollaboratorDelete(projectId: projectId, userId: userId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **userId** | **Int64** | User unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectCollaboratorsInvite**
```swift
    open class func privateProjectCollaboratorsInvite(projectId: Int64, collaborator: ProjectCollaboratorInvite, completion: @escaping (_ data: ResponseMessage?, _ error: Error?) -> Void)
```

Invite project collaborators

Invite users to collaborate on project or view the project

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let collaborator = ProjectCollaboratorInvite(roleName: "roleName_example", userId: 123, email: "email_example", comment: "comment_example") // ProjectCollaboratorInvite | viewer or collaborator role. User user_id or email of user

// Invite project collaborators
ProjectsAPI.privateProjectCollaboratorsInvite(projectId: projectId, collaborator: collaborator) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **collaborator** | [**ProjectCollaboratorInvite**](ProjectCollaboratorInvite.md) | viewer or collaborator role. User user_id or email of user | 

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectCollaboratorsList**
```swift
    open class func privateProjectCollaboratorsList(projectId: Int64, completion: @escaping (_ data: [ProjectCollaborator]?, _ error: Error?) -> Void)
```

List project collaborators

List Project collaborators and invited users

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier

// List project collaborators
ProjectsAPI.privateProjectCollaboratorsList(projectId: projectId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 

### Return type

[**[ProjectCollaborator]**](ProjectCollaborator.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectCreate**
```swift
    open class func privateProjectCreate(project: ProjectCreate, completion: @escaping (_ data: CreateProjectResponse?, _ error: Error?) -> Void)
```

Create project

Create a new project

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let project = ProjectCreate(title: "title_example", description: "description_example", funding: "", fundingList: [FundingCreate(id: 123, title: "title_example")], groupId: 123, customFields: 123, customFieldsList: [CustomArticleFieldAdd(name: "name_example", value: 123)]) // ProjectCreate | Project  description

// Create project
ProjectsAPI.privateProjectCreate(project: project) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project** | [**ProjectCreate**](ProjectCreate.md) | Project  description | 

### Return type

[**CreateProjectResponse**](CreateProjectResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectDelete**
```swift
    open class func privateProjectDelete(projectId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete project

A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project. 

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier

// Delete project
ProjectsAPI.privateProjectDelete(projectId: projectId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectDetails**
```swift
    open class func privateProjectDetails(projectId: Int64, completion: @escaping (_ data: ProjectCompletePrivate?, _ error: Error?) -> Void)
```

View project details

View a private project

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier

// View project details
ProjectsAPI.privateProjectDetails(projectId: projectId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 

### Return type

[**ProjectCompletePrivate**](ProjectCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectLeave**
```swift
    open class func privateProjectLeave(projectId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Private Project Leave

Please note: project's owner cannot leave the project.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier

// Private Project Leave
ProjectsAPI.privateProjectLeave(projectId: projectId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectNote**
```swift
    open class func privateProjectNote(projectId: Int64, noteId: Int64, completion: @escaping (_ data: ProjectNotePrivate?, _ error: Error?) -> Void)
```

Project note details

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let noteId = 987 // Int64 | Note unique identifier

// Project note details
ProjectsAPI.privateProjectNote(projectId: projectId, noteId: noteId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **noteId** | **Int64** | Note unique identifier | 

### Return type

[**ProjectNotePrivate**](ProjectNotePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectNoteDelete**
```swift
    open class func privateProjectNoteDelete(projectId: Int64, noteId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete project note

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let noteId = 987 // Int64 | Note unique identifier

// Delete project note
ProjectsAPI.privateProjectNoteDelete(projectId: projectId, noteId: noteId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **noteId** | **Int64** | Note unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectNoteUpdate**
```swift
    open class func privateProjectNoteUpdate(projectId: Int64, noteId: Int64, note: ProjectNoteCreate, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Update project note

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let noteId = 987 // Int64 | Note unique identifier
let note = ProjectNoteCreate(text: "text_example") // ProjectNoteCreate | Note message

// Update project note
ProjectsAPI.privateProjectNoteUpdate(projectId: projectId, noteId: noteId, note: note) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **noteId** | **Int64** | Note unique identifier | 
 **note** | [**ProjectNoteCreate**](ProjectNoteCreate.md) | Note message | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectNotesCreate**
```swift
    open class func privateProjectNotesCreate(projectId: Int64, note: ProjectNoteCreate, completion: @escaping (_ data: Location?, _ error: Error?) -> Void)
```

Create project note

Create a new project note

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let note = ProjectNoteCreate(text: "text_example") // ProjectNoteCreate | Note message

// Create project note
ProjectsAPI.privateProjectNotesCreate(projectId: projectId, note: note) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **note** | [**ProjectNoteCreate**](ProjectNoteCreate.md) | Note message | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectNotesList**
```swift
    open class func privateProjectNotesList(projectId: Int64, page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, completion: @escaping (_ data: [ProjectNote]?, _ error: Error?) -> Void)
```

List project notes

List project notes

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

// List project notes
ProjectsAPI.privateProjectNotesList(projectId: projectId, page: page, pageSize: pageSize, limit: limit, offset: offset) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[ProjectNote]**](ProjectNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectPartialUpdate**
```swift
    open class func privateProjectPartialUpdate(projectId: Int64, project: ProjectUpdate? = nil, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Partially update project

Partially update a project; only provided fields will be changed.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let project = ProjectUpdate(title: "title_example", description: "description_example", funding: "", fundingList: [FundingCreate(id: 123, title: "title_example")], customFields: 123, customFieldsList: [CustomArticleFieldAdd(name: "name_example", value: 123)]) // ProjectUpdate | Fields to update (optional)

// Partially update project
ProjectsAPI.privateProjectPartialUpdate(projectId: projectId, project: project) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **project** | [**ProjectUpdate**](ProjectUpdate.md) | Fields to update | [optional] 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectPublish**
```swift
    open class func privateProjectPublish(projectId: Int64, completion: @escaping (_ data: ResponseMessage?, _ error: Error?) -> Void)
```

Private Project Publish

Publish a project. Possible after all items inside it are public

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier

// Private Project Publish
ProjectsAPI.privateProjectPublish(projectId: projectId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectUpdate**
```swift
    open class func privateProjectUpdate(projectId: Int64, project: ProjectUpdate, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Update project

Updating an project by passing body parameters.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project unique identifier
let project = ProjectUpdate(title: "title_example", description: "description_example", funding: "", fundingList: [FundingCreate(id: 123, title: "title_example")], customFields: 123, customFieldsList: [CustomArticleFieldAdd(name: "name_example", value: 123)]) // ProjectUpdate | Project description

// Update project
ProjectsAPI.privateProjectUpdate(projectId: projectId, project: project) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project unique identifier | 
 **project** | [**ProjectUpdate**](ProjectUpdate.md) | Project description | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectsList**
```swift
    open class func privateProjectsList(page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, order: Order_privateProjectsList? = nil, orderDirection: OrderDirection_privateProjectsList? = nil, storage: Storage_privateProjectsList? = nil, roles: String? = nil, completion: @escaping (_ data: [ProjectPrivate]?, _ error: Error?) -> Void)
```

Private Projects

List private projects

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
let order = "order_example" // String | The field by which to order. (optional) (default to .publishedDate)
let orderDirection = "orderDirection_example" // String |  (optional) (default to .desc)
let storage = "storage_example" // String | only return collections from this institution (optional)
let roles = "roles_example" // String | Any combination of owner, collaborator, viewer separated by comma. Examples: \"owner\" or \"owner,collaborator\". (optional)

// Private Projects
ProjectsAPI.privateProjectsList(page: page, pageSize: pageSize, limit: limit, offset: offset, order: order, orderDirection: orderDirection, storage: storage, roles: roles) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **String** | The field by which to order. | [optional] [default to .publishedDate]
 **orderDirection** | **String** |  | [optional] [default to .desc]
 **storage** | **String** | only return collections from this institution | [optional] 
 **roles** | **String** | Any combination of owner, collaborator, viewer separated by comma. Examples: \&quot;owner\&quot; or \&quot;owner,collaborator\&quot;. | [optional] 

### Return type

[**[ProjectPrivate]**](ProjectPrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateProjectsSearch**
```swift
    open class func privateProjectsSearch(search: ProjectsSearch? = nil, completion: @escaping (_ data: [ProjectPrivate]?, _ error: Error?) -> Void)
```

Private Projects search

Search inside the private projects

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let search = ProjectsSearch(order: "order_example", searchFor: "searchFor_example", page: 123, pageSize: 123, limit: 123, offset: 123, orderDirection: "orderDirection_example", institution: 123, publishedSince: "publishedSince_example", modifiedSince: "modifiedSince_example", group: 123) // ProjectsSearch | Search Parameters (optional)

// Private Projects search
ProjectsAPI.privateProjectsSearch(search: search) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**ProjectsSearch**](ProjectsSearch.md) | Search Parameters | [optional] 

### Return type

[**[ProjectPrivate]**](ProjectPrivate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **projectArticles**
```swift
    open class func projectArticles(projectId: Int64, page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, completion: @escaping (_ data: [Article]?, _ error: Error?) -> Void)
```

Public Project Articles

List articles in project

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project Unique identifier
let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

// Public Project Articles
ProjectsAPI.projectArticles(projectId: projectId, page: page, pageSize: pageSize, limit: limit, offset: offset) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project Unique identifier | 
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **projectDetails**
```swift
    open class func projectDetails(projectId: Int64, completion: @escaping (_ data: ProjectComplete?, _ error: Error?) -> Void)
```

Public Project

View a project

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let projectId = 987 // Int64 | Project Unique identifier

// Public Project
ProjectsAPI.projectDetails(projectId: projectId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **projectId** | **Int64** | Project Unique identifier | 

### Return type

[**ProjectComplete**](ProjectComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **projectsList**
```swift
    open class func projectsList(xCursor: UUID? = nil, page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, order: Order_projectsList? = nil, orderDirection: OrderDirection_projectsList? = nil, institution: Int64? = nil, publishedSince: String? = nil, group: Int64? = nil, completion: @escaping (_ data: [Project]?, _ error: Error?) -> Void)
```

Public Projects

Returns a list of public projects

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let xCursor = 987 // UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
let order = "order_example" // String | The field by which to order. Default varies by endpoint/resource. (optional) (default to .publishedDate)
let orderDirection = "orderDirection_example" // String |  (optional) (default to .desc)
let institution = 987 // Int64 | only return collections from this institution (optional)
let publishedSince = "publishedSince_example" // String | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
let group = 987 // Int64 | only return collections from this group (optional)

// Public Projects
ProjectsAPI.projectsList(xCursor: xCursor, page: page, pageSize: pageSize, limit: limit, offset: offset, order: order, orderDirection: orderDirection, institution: institution, publishedSince: publishedSince, group: group) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | **UUID** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **String** | The field by which to order. Default varies by endpoint/resource. | [optional] [default to .publishedDate]
 **orderDirection** | **String** |  | [optional] [default to .desc]
 **institution** | **Int64** | only return collections from this institution | [optional] 
 **publishedSince** | **String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **group** | **Int64** | only return collections from this group | [optional] 

### Return type

[**[Project]**](Project.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **projectsSearch**
```swift
    open class func projectsSearch(xCursor: UUID? = nil, search: ProjectsSearch? = nil, completion: @escaping (_ data: [Project]?, _ error: Error?) -> Void)
```

Public Projects Search

Returns a list of public articles

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let xCursor = 987 // UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
let search = ProjectsSearch(order: "order_example", searchFor: "searchFor_example", page: 123, pageSize: 123, limit: 123, offset: 123, orderDirection: "orderDirection_example", institution: 123, publishedSince: "publishedSince_example", modifiedSince: "modifiedSince_example", group: 123) // ProjectsSearch | Search Parameters (optional)

// Public Projects Search
ProjectsAPI.projectsSearch(xCursor: xCursor, search: search) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | **UUID** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **search** | [**ProjectsSearch**](ProjectsSearch.md) | Search Parameters | [optional] 

### Return type

[**[Project]**](Project.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

