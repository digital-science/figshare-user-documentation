# InstitutionAccountsSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**searchFor** | **String** | Search term | [optional] 
**isActive** | **Int64** | Filter by active status | [optional] 
**page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
**pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
**institutionUserId** | **String** | filter by institution_user_id | [optional] 
**email** | **String** | filter by email | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


