# ProjectsSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order** | **String** | The field by which to order. | [optional] [default to .publishedDate]
**searchFor** | **String** | Search term | [optional] 
**page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
**pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
**orderDirection** | **String** | Direction of ordering | [optional] [default to .desc]
**institution** | **Int** | only return collections from this institution | [optional] 
**publishedSince** | **String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
**modifiedSince** | **String** | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
**group** | **Int** | only return collections from this group | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


