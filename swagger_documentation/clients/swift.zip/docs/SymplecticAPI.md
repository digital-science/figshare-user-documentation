# SymplecticAPI

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**symplecticAccountArticles**](SymplecticAPI.md#symplecticaccountarticles) | **GET** /symplectic/accounts/{external_user_id}/articles | Get articles for a specific account
[**symplecticAccountsIds**](SymplecticAPI.md#symplecticaccountsids) | **GET** /symplectic/accounts | Get changed accounts for Symplectic Elements
[**symplecticArticle**](SymplecticAPI.md#symplecticarticle) | **GET** /symplectic/articles/{article_id} | Get article details for Symplectic Elements
[**symplecticChangedArticles**](SymplecticAPI.md#symplecticchangedarticles) | **GET** /symplectic/articles | Get changed articles for Symplectic Elements
[**symplecticUserId**](SymplecticAPI.md#symplecticuserid) | **GET** /symplectic/users/{user_id} | Get institutional user ID for a user


# **symplecticAccountArticles**
```swift
    open class func symplecticAccountArticles(externalUserId: String, offset: Int? = nil, limit: Int? = nil, status: Status_symplecticAccountArticles? = nil, isEmbargoed: IsEmbargoed_symplecticAccountArticles? = nil, completion: @escaping (_ data: [AnyCodable]?, _ error: Error?) -> Void)
```

Get articles for a specific account

Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id).

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let externalUserId = "externalUserId_example" // String | External user ID (symplectic_user_id or institution_user_id)
let offset = 987 // Int | Number of results to skip for pagination (optional) (default to 0)
let limit = 987 // Int | Maximum number of results to return (optional) (default to 10)
let status = "status_example" // String | Filter by article status (optional)
let isEmbargoed = "isEmbargoed_example" // String | Filter by embargo status (optional)

// Get articles for a specific account
SymplecticAPI.symplecticAccountArticles(externalUserId: externalUserId, offset: offset, limit: limit, status: status, isEmbargoed: isEmbargoed) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **externalUserId** | **String** | External user ID (symplectic_user_id or institution_user_id) | 
 **offset** | **Int** | Number of results to skip for pagination | [optional] [default to 0]
 **limit** | **Int** | Maximum number of results to return | [optional] [default to 10]
 **status** | **String** | Filter by article status | [optional] 
 **isEmbargoed** | **String** | Filter by embargo status | [optional] 

### Return type

**[AnyCodable]**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **symplecticAccountsIds**
```swift
    open class func symplecticAccountsIds(since: String, completion: @escaping (_ data: [SymplecticAccountsIds200ResponseInner]?, _ error: Error?) -> Void)
```

Get changed accounts for Symplectic Elements

Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let since = "since_example" // String | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)

// Get changed accounts for Symplectic Elements
SymplecticAPI.symplecticAccountsIds(since: since) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **since** | **String** | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | 

### Return type

[**[SymplecticAccountsIds200ResponseInner]**](SymplecticAccountsIds200ResponseInner.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **symplecticArticle**
```swift
    open class func symplecticArticle(articleId: Int, completion: @escaping (_ data: AnyCodable?, _ error: Error?) -> Void)
```

Get article details for Symplectic Elements

Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int | Article ID

// Get article details for Symplectic Elements
SymplecticAPI.symplecticArticle(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int** | Article ID | 

### Return type

**AnyCodable**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **symplecticChangedArticles**
```swift
    open class func symplecticChangedArticles(since: String, offset: Int? = nil, limit: Int? = nil, status: Status_symplecticChangedArticles? = nil, isEmbargoed: IsEmbargoed_symplecticChangedArticles? = nil, completion: @escaping (_ data: [AnyCodable]?, _ error: Error?) -> Void)
```

Get changed articles for Symplectic Elements

Returns a list of articles for Symplectic Elements integration to synchronize article data.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let since = "since_example" // String | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
let offset = 987 // Int | Number of results to skip for pagination (optional) (default to 0)
let limit = 987 // Int | Maximum number of results to return (optional) (default to 10)
let status = "status_example" // String | Filter by article status (optional)
let isEmbargoed = "isEmbargoed_example" // String | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type (optional)

// Get changed articles for Symplectic Elements
SymplecticAPI.symplecticChangedArticles(since: since, offset: offset, limit: limit, status: status, isEmbargoed: isEmbargoed) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **since** | **String** | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | 
 **offset** | **Int** | Number of results to skip for pagination | [optional] [default to 0]
 **limit** | **Int** | Maximum number of results to return | [optional] [default to 10]
 **status** | **String** | Filter by article status | [optional] 
 **isEmbargoed** | **String** | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type | [optional] 

### Return type

**[AnyCodable]**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **symplecticUserId**
```swift
    open class func symplecticUserId(userId: Int, completion: @escaping (_ data: SymplecticUserId200Response?, _ error: Error?) -> Void)
```

Get institutional user ID for a user

Returns the institution user ID for a given user within the authenticated account's institution.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let userId = 987 // Int | User ID

// Get institutional user ID for a user
SymplecticAPI.symplecticUserId(userId: userId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **Int** | User ID | 

### Return type

[**SymplecticUserId200Response**](SymplecticUserId200Response.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

