# FileId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fileId** | **Int64** | File ID | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


