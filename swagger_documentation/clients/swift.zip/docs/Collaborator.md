# Collaborator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**roleName** | **String** | Collaborator role | 
**userId** | **Int** | Collaborator id | 
**name** | **String** | Collaborator name | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


