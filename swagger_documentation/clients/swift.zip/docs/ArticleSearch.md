# ArticleSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resourceDoi** | **String** | Only return articles with this resource_doi | [optional] 
**itemType** | **Int64** | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
**doi** | **String** | Only return articles with this doi | [optional] 
**handle** | **String** | Only return articles with this handle | [optional] 
**projectId** | **Int64** | Only return articles in this project | [optional] 
**order** | **String** | The field by which to order | [optional] [default to .createdDate]
**searchFor** | **String** | Search term | [optional] 
**page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
**pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **Int64** | Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
**orderDirection** | **String** | Direction of ordering | [optional] [default to .desc]
**institution** | **Int** | only return collections from this institution | [optional] 
**publishedSince** | **String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
**modifiedSince** | **String** | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
**group** | **Int** | only return collections from this group | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


