# ProjectCollaboratorInvite

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**roleName** | **String** | Role of the the collaborator inside the project | 
**userId** | **Int64** | User id of the collaborator | [optional] 
**email** | **String** | Collaborator email | [optional] 
**comment** | **String** | Text sent when inviting the user to the project | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


