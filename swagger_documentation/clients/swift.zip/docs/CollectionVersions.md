# CollectionVersions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **Int** | Version number | 
**url** | **String** | Api endpoint for the collection version | 
**funding** | [FundingInformation] | Full Collection funding information | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


