# ProfileUpdateData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**firstName** | **String** | First name | [optional] 
**lastName** | **String** | Last Name | [optional] 
**orcid** | **String** | User ORCID | [optional] 
**jobTitle** | **String** | User job title | [optional] 
**fieldsOfInterest** | **[Int64]** | User fields of interest (category ids) | [optional] 
**fieldsOfInterestBySourceId** | **[String]** | User fields of interest (category source IDs), supersedes the fields_of_interest property | [optional] 
**location** | **String** | User location | [optional] 
**facebook** | **String** | User facebook URL | [optional] 
**x** | **String** | User X (twitter) URL | [optional] 
**linkedin** | **String** | User linkedin URL | [optional] 
**bio** | **String** | User biographical information | [optional] 
**personalProfiles** | [ProfileUpdateDataPersonalProfilesInner] | Add up to 10 additional personal profile links | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


