# Group

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int64** | Group id | 
**name** | **String** | Group name | 
**resourceId** | **String** | Group resource id | 
**parentId** | **Int64** | Parent group if any | 
**associationCriteria** | **String** | HR code associated with group, if code exists | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


