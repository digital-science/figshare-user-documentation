# ArticlesAPI

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**accountArticlePublish**](ArticlesAPI.md#accountarticlepublish) | **POST** /account/articles/{article_id}/publish | Private Article Publish
[**accountArticleReport**](ArticlesAPI.md#accountarticlereport) | **GET** /account/articles/export | Account Article Report
[**accountArticleReportGenerate**](ArticlesAPI.md#accountarticlereportgenerate) | **POST** /account/articles/export | Initiate a new Report
[**accountArticleUnpublish**](ArticlesAPI.md#accountarticleunpublish) | **POST** /account/articles/{article_id}/unpublish | Public Article Unpublish
[**articleDetails**](ArticlesAPI.md#articledetails) | **GET** /articles/{article_id} | View article details
[**articleFileDetails**](ArticlesAPI.md#articlefiledetails) | **GET** /articles/{article_id}/files/{file_id} | Article file details
[**articleFiles**](ArticlesAPI.md#articlefiles) | **GET** /articles/{article_id}/files | List article files
[**articleVersionConfidentiality**](ArticlesAPI.md#articleversionconfidentiality) | **GET** /articles/{article_id}/versions/{version_id}/confidentiality | Public Article Confidentiality for article version
[**articleVersionDetails**](ArticlesAPI.md#articleversiondetails) | **GET** /articles/{article_id}/versions/{version_id} | Article details for version
[**articleVersionEmbargo**](ArticlesAPI.md#articleversionembargo) | **GET** /articles/{article_id}/versions/{version_id}/embargo | Public Article Embargo for article version
[**articleVersionFiles**](ArticlesAPI.md#articleversionfiles) | **GET** /articles/{article_id}/versions/{version_id}/files | Public Article version files
[**articleVersionPartialUpdate**](ArticlesAPI.md#articleversionpartialupdate) | **PATCH** /account/articles/{article_id}/versions/{version_id} | Partially update article version
[**articleVersionUpdate**](ArticlesAPI.md#articleversionupdate) | **PUT** /account/articles/{article_id}/versions/{version_id} | Update article version
[**articleVersionUpdateThumb**](ArticlesAPI.md#articleversionupdatethumb) | **PUT** /account/articles/{article_id}/versions/{version_id}/update_thumb | Update article version thumbnail
[**articleVersions**](ArticlesAPI.md#articleversions) | **GET** /articles/{article_id}/versions | List article versions
[**articlesList**](ArticlesAPI.md#articleslist) | **GET** /articles | Public Articles
[**articlesSearch**](ArticlesAPI.md#articlessearch) | **POST** /articles/search | Public Articles Search
[**privateArticleAuthorDelete**](ArticlesAPI.md#privatearticleauthordelete) | **DELETE** /account/articles/{article_id}/authors/{author_id} | Delete article author
[**privateArticleAuthorsAdd**](ArticlesAPI.md#privatearticleauthorsadd) | **POST** /account/articles/{article_id}/authors | Add article authors
[**privateArticleAuthorsList**](ArticlesAPI.md#privatearticleauthorslist) | **GET** /account/articles/{article_id}/authors | List article authors
[**privateArticleAuthorsReplace**](ArticlesAPI.md#privatearticleauthorsreplace) | **PUT** /account/articles/{article_id}/authors | Replace article authors
[**privateArticleCategoriesAdd**](ArticlesAPI.md#privatearticlecategoriesadd) | **POST** /account/articles/{article_id}/categories | Add article categories
[**privateArticleCategoriesList**](ArticlesAPI.md#privatearticlecategorieslist) | **GET** /account/articles/{article_id}/categories | List article categories
[**privateArticleCategoriesReplace**](ArticlesAPI.md#privatearticlecategoriesreplace) | **PUT** /account/articles/{article_id}/categories | Replace article categories
[**privateArticleCategoryDelete**](ArticlesAPI.md#privatearticlecategorydelete) | **DELETE** /account/articles/{article_id}/categories/{category_id} | Delete article category
[**privateArticleConfidentialityDelete**](ArticlesAPI.md#privatearticleconfidentialitydelete) | **DELETE** /account/articles/{article_id}/confidentiality | Delete article confidentiality
[**privateArticleConfidentialityDetails**](ArticlesAPI.md#privatearticleconfidentialitydetails) | **GET** /account/articles/{article_id}/confidentiality | Article confidentiality details
[**privateArticleConfidentialityUpdate**](ArticlesAPI.md#privatearticleconfidentialityupdate) | **PUT** /account/articles/{article_id}/confidentiality | Update article confidentiality
[**privateArticleCreate**](ArticlesAPI.md#privatearticlecreate) | **POST** /account/articles | Create new Article
[**privateArticleDelete**](ArticlesAPI.md#privatearticledelete) | **DELETE** /account/articles/{article_id} | Delete article
[**privateArticleDetails**](ArticlesAPI.md#privatearticledetails) | **GET** /account/articles/{article_id} | Article details
[**privateArticleDownload**](ArticlesAPI.md#privatearticledownload) | **GET** /account/articles/{article_id}/download | Private Article Download
[**privateArticleEmbargoDelete**](ArticlesAPI.md#privatearticleembargodelete) | **DELETE** /account/articles/{article_id}/embargo | Delete Article Embargo
[**privateArticleEmbargoDetails**](ArticlesAPI.md#privatearticleembargodetails) | **GET** /account/articles/{article_id}/embargo | Article Embargo Details
[**privateArticleEmbargoUpdate**](ArticlesAPI.md#privatearticleembargoupdate) | **PUT** /account/articles/{article_id}/embargo | Update Article Embargo
[**privateArticleFile**](ArticlesAPI.md#privatearticlefile) | **GET** /account/articles/{article_id}/files/{file_id} | Single File
[**privateArticleFileDelete**](ArticlesAPI.md#privatearticlefiledelete) | **DELETE** /account/articles/{article_id}/files/{file_id} | File Delete
[**privateArticleFilesList**](ArticlesAPI.md#privatearticlefileslist) | **GET** /account/articles/{article_id}/files | List article files
[**privateArticlePartialUpdate**](ArticlesAPI.md#privatearticlepartialupdate) | **PATCH** /account/articles/{article_id} | Partially update article
[**privateArticlePrivateLink**](ArticlesAPI.md#privatearticleprivatelink) | **GET** /account/articles/{article_id}/private_links | List private links
[**privateArticlePrivateLinkCreate**](ArticlesAPI.md#privatearticleprivatelinkcreate) | **POST** /account/articles/{article_id}/private_links | Create private link
[**privateArticlePrivateLinkDelete**](ArticlesAPI.md#privatearticleprivatelinkdelete) | **DELETE** /account/articles/{article_id}/private_links/{link_id} | Disable private link
[**privateArticlePrivateLinkUpdate**](ArticlesAPI.md#privatearticleprivatelinkupdate) | **PUT** /account/articles/{article_id}/private_links/{link_id} | Update private link
[**privateArticleReserveDoi**](ArticlesAPI.md#privatearticlereservedoi) | **POST** /account/articles/{article_id}/reserve_doi | Private Article Reserve DOI
[**privateArticleReserveHandle**](ArticlesAPI.md#privatearticlereservehandle) | **POST** /account/articles/{article_id}/reserve_handle | Private Article Reserve Handle
[**privateArticleResource**](ArticlesAPI.md#privatearticleresource) | **POST** /account/articles/{article_id}/resource | Private Article Resource
[**privateArticleUpdate**](ArticlesAPI.md#privatearticleupdate) | **PUT** /account/articles/{article_id} | Update article
[**privateArticleUploadComplete**](ArticlesAPI.md#privatearticleuploadcomplete) | **POST** /account/articles/{article_id}/files/{file_id} | Complete Upload
[**privateArticleUploadInitiate**](ArticlesAPI.md#privatearticleuploadinitiate) | **POST** /account/articles/{article_id}/files | Initiate Upload
[**privateArticlesList**](ArticlesAPI.md#privatearticleslist) | **GET** /account/articles | Private Articles
[**privateArticlesSearch**](ArticlesAPI.md#privatearticlessearch) | **POST** /account/articles/search | Private Articles search
[**publicArticleDownload**](ArticlesAPI.md#publicarticledownload) | **GET** /articles/{article_id}/download | Public Article Download
[**publicArticleVersionDownload**](ArticlesAPI.md#publicarticleversiondownload) | **GET** /articles/{article_id}/versions/{version_id}/download | Public Article Version Download


# **accountArticlePublish**
```swift
    open class func accountArticlePublish(articleId: Int64, completion: @escaping (_ data: Location?, _ error: Error?) -> Void)
```

Private Article Publish

- If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier

// Private Article Publish
ArticlesAPI.accountArticlePublish(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **accountArticleReport**
```swift
    open class func accountArticleReport(groupId: Int64? = nil, completion: @escaping (_ data: [AccountReport]?, _ error: Error?) -> Void)
```

Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let groupId = 987 // Int64 | A group ID to filter by (optional)

// Account Article Report
ArticlesAPI.accountArticleReport(groupId: groupId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **Int64** | A group ID to filter by | [optional] 

### Return type

[**[AccountReport]**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **accountArticleReportGenerate**
```swift
    open class func accountArticleReportGenerate(completion: @escaping (_ data: AccountReport?, _ error: Error?) -> Void)
```

Initiate a new Report

Initiate a new Article Report for this Account. There is a limit of 1 report per day.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient


// Initiate a new Report
ArticlesAPI.accountArticleReportGenerate() { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **accountArticleUnpublish**
```swift
    open class func accountArticleUnpublish(articleId: Int64, reason: ArticleUnpublishData, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Public Article Unpublish

Allows authorized users to unpublish an article.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let reason = ArticleUnpublishData(reason: "reason_example") // ArticleUnpublishData | Article unpublish data

// Public Article Unpublish
ArticlesAPI.accountArticleUnpublish(articleId: articleId, reason: reason) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **reason** | [**ArticleUnpublishData**](ArticleUnpublishData.md) | Article unpublish data | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articleDetails**
```swift
    open class func articleDetails(articleId: Int64, completion: @escaping (_ data: ArticleComplete?, _ error: Error?) -> Void)
```

View article details

View an article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article Unique identifier

// View article details
ArticlesAPI.articleDetails(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article Unique identifier | 

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articleFileDetails**
```swift
    open class func articleFileDetails(articleId: Int64, fileId: Int64, completion: @escaping (_ data: PublicFile?, _ error: Error?) -> Void)
```

Article file details

File by id

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article Unique identifier
let fileId = 987 // Int64 | File Unique identifier

// Article file details
ArticlesAPI.articleFileDetails(articleId: articleId, fileId: fileId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article Unique identifier | 
 **fileId** | **Int64** | File Unique identifier | 

### Return type

[**PublicFile**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articleFiles**
```swift
    open class func articleFiles(articleId: Int64, page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, completion: @escaping (_ data: [PublicFile]?, _ error: Error?) -> Void)
```

List article files

Files list for article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article Unique identifier
let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

// List article files
ArticlesAPI.articleFiles(articleId: articleId, page: page, pageSize: pageSize, limit: limit, offset: offset) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article Unique identifier | 
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[PublicFile]**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articleVersionConfidentiality**
```swift
    open class func articleVersionConfidentiality(articleId: Int64, versionId: Int64, completion: @escaping (_ data: ArticleConfidentiality?, _ error: Error?) -> Void)
```

Public Article Confidentiality for article version

Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article Unique identifier
let versionId = 987 // Int64 | Version Number

// Public Article Confidentiality for article version
ArticlesAPI.articleVersionConfidentiality(articleId: articleId, versionId: versionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article Unique identifier | 
 **versionId** | **Int64** | Version Number | 

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articleVersionDetails**
```swift
    open class func articleVersionDetails(articleId: Int64, versionId: Int64, completion: @escaping (_ data: ArticleComplete?, _ error: Error?) -> Void)
```

Article details for version

Article with specified version

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article Unique identifier
let versionId = 987 // Int64 | Article Version Number

// Article details for version
ArticlesAPI.articleVersionDetails(articleId: articleId, versionId: versionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article Unique identifier | 
 **versionId** | **Int64** | Article Version Number | 

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articleVersionEmbargo**
```swift
    open class func articleVersionEmbargo(articleId: Int64, versionId: Int64, completion: @escaping (_ data: ArticleEmbargo?, _ error: Error?) -> Void)
```

Public Article Embargo for article version

Embargo for article version

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article Unique identifier
let versionId = 987 // Int64 | Version Number

// Public Article Embargo for article version
ArticlesAPI.articleVersionEmbargo(articleId: articleId, versionId: versionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article Unique identifier | 
 **versionId** | **Int64** | Version Number | 

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articleVersionFiles**
```swift
    open class func articleVersionFiles(articleId: Int64, versionId: Int64, page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, completion: @escaping (_ data: [PublicFile]?, _ error: Error?) -> Void)
```

Public Article version files

Article version file details

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article Unique identifier
let versionId = 987 // Int64 | Article Version Unique identifier
let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

// Public Article version files
ArticlesAPI.articleVersionFiles(articleId: articleId, versionId: versionId, page: page, pageSize: pageSize, limit: limit, offset: offset) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article Unique identifier | 
 **versionId** | **Int64** | Article Version Unique identifier | 
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[PublicFile]**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articleVersionPartialUpdate**
```swift
    open class func articleVersionPartialUpdate(articleId: Int64, versionId: Int64, article: ArticleVersionUpdate, completion: @escaping (_ data: LocationWarningsUpdate?, _ error: Error?) -> Void)
```

Partially update article version

Partially updating an article version by passing only the fields to change.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let versionId = 987 // Int64 | Article version identifier
let article = ArticleVersionUpdate(supplementaryFields: [123], internalMetadata: 123) // ArticleVersionUpdate | Subset of article version fields to update

// Partially update article version
ArticlesAPI.articleVersionPartialUpdate(articleId: articleId, versionId: versionId, article: article) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **versionId** | **Int64** | Article version identifier | 
 **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md) | Subset of article version fields to update | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articleVersionUpdate**
```swift
    open class func articleVersionUpdate(articleId: Int64, versionId: Int64, article: ArticleVersionUpdate, completion: @escaping (_ data: LocationWarningsUpdate?, _ error: Error?) -> Void)
```

Update article version

Updating an article version by passing body parameters.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let versionId = 987 // Int64 | Article version identifier
let article = ArticleVersionUpdate(supplementaryFields: [123], internalMetadata: 123) // ArticleVersionUpdate | Article description

// Update article version
ArticlesAPI.articleVersionUpdate(articleId: articleId, versionId: versionId, article: article) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **versionId** | **Int64** | Article version identifier | 
 **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md) | Article description | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articleVersionUpdateThumb**
```swift
    open class func articleVersionUpdateThumb(articleId: Int64, versionId: Int64, fileId: FileId, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Update article version thumbnail

For a given public article version update the article thumbnail by choosing one of the associated files

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let versionId = 987 // Int64 | Article version identifier
let fileId = FileId(fileId: 123) // FileId | File ID

// Update article version thumbnail
ArticlesAPI.articleVersionUpdateThumb(articleId: articleId, versionId: versionId, fileId: fileId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **versionId** | **Int64** | Article version identifier | 
 **fileId** | [**FileId**](FileId.md) | File ID | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articleVersions**
```swift
    open class func articleVersions(articleId: Int64, completion: @escaping (_ data: [ArticleVersions]?, _ error: Error?) -> Void)
```

List article versions

List public article versions

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article Unique identifier

// List article versions
ArticlesAPI.articleVersions(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article Unique identifier | 

### Return type

[**[ArticleVersions]**](ArticleVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articlesList**
```swift
    open class func articlesList(xCursor: UUID? = nil, page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, order: Order_articlesList? = nil, orderDirection: OrderDirection_articlesList? = nil, institution: Int64? = nil, publishedSince: String? = nil, modifiedSince: String? = nil, group: Int64? = nil, resourceDoi: String? = nil, itemType: Int64? = nil, doi: String? = nil, handle: String? = nil, completion: @escaping (_ data: [Article]?, _ error: Error?) -> Void)
```

Public Articles

Returns a list of public articles

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let xCursor = 987 // UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
let order = "order_example" // String | The field by which to order. Default varies by endpoint/resource. (optional) (default to .publishedDate)
let orderDirection = "orderDirection_example" // String |  (optional) (default to .desc)
let institution = 987 // Int64 | only return articles from this institution (optional)
let publishedSince = "publishedSince_example" // String | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
let modifiedSince = "modifiedSince_example" // String | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
let group = 987 // Int64 | only return articles from this group (optional)
let resourceDoi = "resourceDoi_example" // String | Deprecated by related materials. Only return articles with this resource_doi (optional)
let itemType = 987 // Int64 | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional)
let doi = "doi_example" // String | only return articles with this doi (optional)
let handle = "handle_example" // String | only return articles with this handle (optional)

// Public Articles
ArticlesAPI.articlesList(xCursor: xCursor, page: page, pageSize: pageSize, limit: limit, offset: offset, order: order, orderDirection: orderDirection, institution: institution, publishedSince: publishedSince, modifiedSince: modifiedSince, group: group, resourceDoi: resourceDoi, itemType: itemType, doi: doi, handle: handle) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | **UUID** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **String** | The field by which to order. Default varies by endpoint/resource. | [optional] [default to .publishedDate]
 **orderDirection** | **String** |  | [optional] [default to .desc]
 **institution** | **Int64** | only return articles from this institution | [optional] 
 **publishedSince** | **String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **modifiedSince** | **String** | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **group** | **Int64** | only return articles from this group | [optional] 
 **resourceDoi** | **String** | Deprecated by related materials. Only return articles with this resource_doi | [optional] 
 **itemType** | **Int64** | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
 **doi** | **String** | only return articles with this doi | [optional] 
 **handle** | **String** | only return articles with this handle | [optional] 

### Return type

[**[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articlesSearch**
```swift
    open class func articlesSearch(xCursor: UUID? = nil, search: ArticleSearch? = nil, completion: @escaping (_ data: [ArticleWithProject]?, _ error: Error?) -> Void)
```

Public Articles Search

Returns a list of public articles, filtered by the search parameters

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let xCursor = 987 // UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
let search = ArticleSearch(resourceDoi: "resourceDoi_example", itemType: 123, doi: "doi_example", handle: "handle_example", projectId: 123, order: "order_example", searchFor: "searchFor_example", page: 123, pageSize: 123, limit: 123, offset: 123, orderDirection: "orderDirection_example", institution: 123, publishedSince: "publishedSince_example", modifiedSince: "modifiedSince_example", group: 123) // ArticleSearch | Search Parameters (optional)

// Public Articles Search
ArticlesAPI.articlesSearch(xCursor: xCursor, search: search) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | **UUID** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **search** | [**ArticleSearch**](ArticleSearch.md) | Search Parameters | [optional] 

### Return type

[**[ArticleWithProject]**](ArticleWithProject.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleAuthorDelete**
```swift
    open class func privateArticleAuthorDelete(articleId: Int64, authorId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete article author

De-associate author from article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let authorId = 987 // Int64 | Article Author unique identifier

// Delete article author
ArticlesAPI.privateArticleAuthorDelete(articleId: articleId, authorId: authorId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **authorId** | **Int64** | Article Author unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleAuthorsAdd**
```swift
    open class func privateArticleAuthorsAdd(articleId: Int64, authors: AuthorsCreator, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Add article authors

Associate new authors with the article. This will add new authors to the list of already associated authors

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let authors = AuthorsCreator(authors: [123]) // AuthorsCreator | Authors description

// Add article authors
ArticlesAPI.privateArticleAuthorsAdd(articleId: articleId, authors: authors) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md) | Authors description | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleAuthorsList**
```swift
    open class func privateArticleAuthorsList(articleId: Int64, completion: @escaping (_ data: [Author]?, _ error: Error?) -> Void)
```

List article authors

List article authors

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier

// List article authors
ArticlesAPI.privateArticleAuthorsList(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 

### Return type

[**[Author]**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleAuthorsReplace**
```swift
    open class func privateArticleAuthorsReplace(articleId: Int64, authors: AuthorsCreator, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Replace article authors

Associate new authors with the article. This will remove all already associated authors and add these new ones

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let authors = AuthorsCreator(authors: [123]) // AuthorsCreator | Authors description

// Replace article authors
ArticlesAPI.privateArticleAuthorsReplace(articleId: articleId, authors: authors) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md) | Authors description | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleCategoriesAdd**
```swift
    open class func privateArticleCategoriesAdd(articleId: Int64, categories: CategoriesCreator, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Add article categories

Associate new categories with the article. This will add new categories to the list of already associated categories

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let categories = CategoriesCreator(categories: [123]) // CategoriesCreator | 

// Add article categories
ArticlesAPI.privateArticleCategoriesAdd(articleId: articleId, categories: categories) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md) |  | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleCategoriesList**
```swift
    open class func privateArticleCategoriesList(articleId: Int64, completion: @escaping (_ data: [Category]?, _ error: Error?) -> Void)
```

List article categories

List article categories

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier

// List article categories
ArticlesAPI.privateArticleCategoriesList(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 

### Return type

[**[Category]**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleCategoriesReplace**
```swift
    open class func privateArticleCategoriesReplace(articleId: Int64, categories: CategoriesCreator, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Replace article categories

Associate new categories with the article. This will remove all already associated categories and add these new ones

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let categories = CategoriesCreator(categories: [123]) // CategoriesCreator | 

// Replace article categories
ArticlesAPI.privateArticleCategoriesReplace(articleId: articleId, categories: categories) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md) |  | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleCategoryDelete**
```swift
    open class func privateArticleCategoryDelete(articleId: Int64, categoryId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete article category

De-associate category from article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let categoryId = 987 // Int64 | Category unique identifier

// Delete article category
ArticlesAPI.privateArticleCategoryDelete(articleId: articleId, categoryId: categoryId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **categoryId** | **Int64** | Category unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleConfidentialityDelete**
```swift
    open class func privateArticleConfidentialityDelete(articleId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete article confidentiality

Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier

// Delete article confidentiality
ArticlesAPI.privateArticleConfidentialityDelete(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleConfidentialityDetails**
```swift
    open class func privateArticleConfidentialityDetails(articleId: Int64, completion: @escaping (_ data: ArticleConfidentiality?, _ error: Error?) -> Void)
```

Article confidentiality details

View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier

// Article confidentiality details
ArticlesAPI.privateArticleConfidentialityDetails(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleConfidentialityUpdate**
```swift
    open class func privateArticleConfidentialityUpdate(articleId: Int64, reason: ConfidentialityCreator, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Update article confidentiality

Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let reason = ConfidentialityCreator(reason: "reason_example") // ConfidentialityCreator | 

// Update article confidentiality
ArticlesAPI.privateArticleConfidentialityUpdate(articleId: articleId, reason: reason) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **reason** | [**ConfidentialityCreator**](ConfidentialityCreator.md) |  | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleCreate**
```swift
    open class func privateArticleCreate(article: ArticleCreate, completion: @escaping (_ data: LocationWarnings?, _ error: Error?) -> Void)
```

Create new Article

Create a new Article by sending article information

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let article = ArticleCreate(title: "title_example", description: "description_example", isMetadataRecord: true, metadataReason: "metadataReason_example", tags: ["tags_example"], keywords: ["keywords_example"], references: ["references_example"], relatedMaterials: [RelatedMaterial(id: 123, identifier: "identifier_example", title: "title_example", relation: "relation_example", identifierType: "identifierType_example", isLinkout: true, link: "link_example")], categories: [123], categoriesBySourceId: ["categoriesBySourceId_example"], authors: [123], customFields: 123, customFieldsList: [CustomArticleFieldAdd(name: "name_example", value: 123)], definedType: "definedType_example", funding: "funding_example", fundingList: [FundingCreate(id: 123, title: "title_example")], license: 123, doi: "doi_example", handle: "handle_example", resourceDoi: "resourceDoi_example", resourceTitle: "resourceTitle_example", timeline: TimelineUpdate(firstOnline: "firstOnline_example", publisherPublication: "publisherPublication_example", publisherAcceptance: "publisherAcceptance_example"), groupId: 123) // ArticleCreate | Article description

// Create new Article
ArticlesAPI.privateArticleCreate(article: article) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article** | [**ArticleCreate**](ArticleCreate.md) | Article description | 

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleDelete**
```swift
    open class func privateArticleDelete(articleId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete article

Delete an article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier

// Delete article
ArticlesAPI.privateArticleDelete(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleDetails**
```swift
    open class func privateArticleDetails(articleId: Int64, completion: @escaping (_ data: ArticleCompletePrivate?, _ error: Error?) -> Void)
```

Article details

View a private article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier

// Article details
ArticlesAPI.privateArticleDetails(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleDownload**
```swift
    open class func privateArticleDownload(articleId: Int64, folderPath: String? = nil, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Private Article Download

Download files from a private article preserving the folder structure

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let folderPath = "folderPath_example" // String | Folder path to download. If not provided, all files from the article will be downloaded (optional)

// Private Article Download
ArticlesAPI.privateArticleDownload(articleId: articleId, folderPath: folderPath) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **folderPath** | **String** | Folder path to download. If not provided, all files from the article will be downloaded | [optional] 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleEmbargoDelete**
```swift
    open class func privateArticleEmbargoDelete(articleId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete Article Embargo

Will lift the embargo for the specified article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier

// Delete Article Embargo
ArticlesAPI.privateArticleEmbargoDelete(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleEmbargoDetails**
```swift
    open class func privateArticleEmbargoDetails(articleId: Int64, completion: @escaping (_ data: ArticleEmbargo?, _ error: Error?) -> Void)
```

Article Embargo Details

View a private article embargo details

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier

// Article Embargo Details
ArticlesAPI.privateArticleEmbargoDetails(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleEmbargoUpdate**
```swift
    open class func privateArticleEmbargoUpdate(articleId: Int64, embargo: ArticleEmbargoUpdater, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Update Article Embargo

Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let embargo = ArticleEmbargoUpdater(isEmbargoed: true, embargoDate: "embargoDate_example", embargoType: "embargoType_example", embargoTitle: "embargoTitle_example", embargoReason: "", embargoOptions: [123]) // ArticleEmbargoUpdater | Embargo description

// Update Article Embargo
ArticlesAPI.privateArticleEmbargoUpdate(articleId: articleId, embargo: embargo) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **embargo** | [**ArticleEmbargoUpdater**](ArticleEmbargoUpdater.md) | Embargo description | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleFile**
```swift
    open class func privateArticleFile(articleId: Int64, fileId: Int64, completion: @escaping (_ data: PrivateFile?, _ error: Error?) -> Void)
```

Single File

View details of file for specified article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let fileId = 987 // Int64 | File unique identifier

// Single File
ArticlesAPI.privateArticleFile(articleId: articleId, fileId: fileId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **fileId** | **Int64** | File unique identifier | 

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleFileDelete**
```swift
    open class func privateArticleFileDelete(articleId: Int64, fileId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

File Delete

Complete file upload

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let fileId = 987 // Int64 | File unique identifier

// File Delete
ArticlesAPI.privateArticleFileDelete(articleId: articleId, fileId: fileId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **fileId** | **Int64** | File unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleFilesList**
```swift
    open class func privateArticleFilesList(articleId: Int64, page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, completion: @escaping (_ data: [PrivateFile]?, _ error: Error?) -> Void)
```

List article files

List private files

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

// List article files
ArticlesAPI.privateArticleFilesList(articleId: articleId, page: page, pageSize: pageSize, limit: limit, offset: offset) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[PrivateFile]**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticlePartialUpdate**
```swift
    open class func privateArticlePartialUpdate(articleId: Int64, article: ArticleUpdate, completion: @escaping (_ data: LocationWarningsUpdate?, _ error: Error?) -> Void)
```

Partially update article

Partially update an article by sending only the fields to change.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let article = ArticleUpdate(title: "title_example", description: "description_example", isMetadataRecord: true, metadataReason: "metadataReason_example", tags: ["tags_example"], keywords: ["keywords_example"], references: ["references_example"], relatedMaterials: [RelatedMaterial(id: 123, identifier: "identifier_example", title: "title_example", relation: "relation_example", identifierType: "identifierType_example", isLinkout: true, link: "link_example")], categories: [123], categoriesBySourceId: ["categoriesBySourceId_example"], authors: [123], customFields: 123, customFieldsList: [CustomArticleFieldAdd(name: "name_example", value: 123)], definedType: "definedType_example", funding: "funding_example", fundingList: [FundingCreate(id: 123, title: "title_example")], license: 123, doi: "doi_example", handle: "handle_example", resourceDoi: "resourceDoi_example", resourceTitle: "resourceTitle_example", timeline: TimelineUpdate(firstOnline: "firstOnline_example", publisherPublication: "publisherPublication_example", publisherAcceptance: "publisherAcceptance_example"), downloadDisabled: false, groupId: 123) // ArticleUpdate | Subset of article fields to update

// Partially update article
ArticlesAPI.privateArticlePartialUpdate(articleId: articleId, article: article) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **article** | [**ArticleUpdate**](ArticleUpdate.md) | Subset of article fields to update | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticlePrivateLink**
```swift
    open class func privateArticlePrivateLink(articleId: Int64, completion: @escaping (_ data: [PrivateLink]?, _ error: Error?) -> Void)
```

List private links

List private links

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier

// List private links
ArticlesAPI.privateArticlePrivateLink(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 

### Return type

[**[PrivateLink]**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticlePrivateLinkCreate**
```swift
    open class func privateArticlePrivateLinkCreate(articleId: Int64, privateLink: PrivateLinkCreator? = nil, completion: @escaping (_ data: PrivateLinkResponse?, _ error: Error?) -> Void)
```

Create private link

Create new private link for this article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let privateLink = PrivateLinkCreator(expiresDate: "expiresDate_example") // PrivateLinkCreator |  (optional)

// Create private link
ArticlesAPI.privateArticlePrivateLinkCreate(articleId: articleId, privateLink: privateLink) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **privateLink** | [**PrivateLinkCreator**](PrivateLinkCreator.md) |  | [optional] 

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticlePrivateLinkDelete**
```swift
    open class func privateArticlePrivateLinkDelete(articleId: Int64, linkId: String, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Disable private link

Disable/delete private link for this article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let linkId = "linkId_example" // String | Private link token

// Disable private link
ArticlesAPI.privateArticlePrivateLinkDelete(articleId: articleId, linkId: linkId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **linkId** | **String** | Private link token | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticlePrivateLinkUpdate**
```swift
    open class func privateArticlePrivateLinkUpdate(articleId: Int64, linkId: String, privateLink: PrivateLinkCreator? = nil, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Update private link

Update existing private link for this article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let linkId = "linkId_example" // String | Private link token
let privateLink = PrivateLinkCreator(expiresDate: "expiresDate_example") // PrivateLinkCreator |  (optional)

// Update private link
ArticlesAPI.privateArticlePrivateLinkUpdate(articleId: articleId, linkId: linkId, privateLink: privateLink) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **linkId** | **String** | Private link token | 
 **privateLink** | [**PrivateLinkCreator**](PrivateLinkCreator.md) |  | [optional] 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleReserveDoi**
```swift
    open class func privateArticleReserveDoi(articleId: Int64, completion: @escaping (_ data: ArticleDOI?, _ error: Error?) -> Void)
```

Private Article Reserve DOI

Reserve DOI for article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier

// Private Article Reserve DOI
ArticlesAPI.privateArticleReserveDoi(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 

### Return type

[**ArticleDOI**](ArticleDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleReserveHandle**
```swift
    open class func privateArticleReserveHandle(articleId: Int64, completion: @escaping (_ data: ArticleHandle?, _ error: Error?) -> Void)
```

Private Article Reserve Handle

Reserve Handle for article

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier

// Private Article Reserve Handle
ArticlesAPI.privateArticleReserveHandle(articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 

### Return type

[**ArticleHandle**](ArticleHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleResource**
```swift
    open class func privateArticleResource(articleId: Int64, resource: Resource, completion: @escaping (_ data: Location?, _ error: Error?) -> Void)
```

Private Article Resource

Edit article resource data.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let resource = Resource(id: "id_example", title: "title_example", doi: "doi_example", link: "link_example", status: "status_example", version: 123) // Resource | Resource data

// Private Article Resource
ArticlesAPI.privateArticleResource(articleId: articleId, resource: resource) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **resource** | [**Resource**](Resource.md) | Resource data | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleUpdate**
```swift
    open class func privateArticleUpdate(articleId: Int64, article: ArticleUpdate, completion: @escaping (_ data: LocationWarningsUpdate?, _ error: Error?) -> Void)
```

Update article

Update an article by passing full body parameters.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let article = ArticleUpdate(title: "title_example", description: "description_example", isMetadataRecord: true, metadataReason: "metadataReason_example", tags: ["tags_example"], keywords: ["keywords_example"], references: ["references_example"], relatedMaterials: [RelatedMaterial(id: 123, identifier: "identifier_example", title: "title_example", relation: "relation_example", identifierType: "identifierType_example", isLinkout: true, link: "link_example")], categories: [123], categoriesBySourceId: ["categoriesBySourceId_example"], authors: [123], customFields: 123, customFieldsList: [CustomArticleFieldAdd(name: "name_example", value: 123)], definedType: "definedType_example", funding: "funding_example", fundingList: [FundingCreate(id: 123, title: "title_example")], license: 123, doi: "doi_example", handle: "handle_example", resourceDoi: "resourceDoi_example", resourceTitle: "resourceTitle_example", timeline: TimelineUpdate(firstOnline: "firstOnline_example", publisherPublication: "publisherPublication_example", publisherAcceptance: "publisherAcceptance_example"), downloadDisabled: false, groupId: 123) // ArticleUpdate | Full article representation

// Update article
ArticlesAPI.privateArticleUpdate(articleId: articleId, article: article) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **article** | [**ArticleUpdate**](ArticleUpdate.md) | Full article representation | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleUploadComplete**
```swift
    open class func privateArticleUploadComplete(articleId: Int64, fileId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Complete Upload

Complete file upload

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let fileId = 987 // Int64 | File unique identifier

// Complete Upload
ArticlesAPI.privateArticleUploadComplete(articleId: articleId, fileId: fileId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **fileId** | **Int64** | File unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticleUploadInitiate**
```swift
    open class func privateArticleUploadInitiate(articleId: Int64, file: FileCreator, page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, completion: @escaping (_ data: Location?, _ error: Error?) -> Void)
```

Initiate Upload

Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let file = FileCreator(link: "link_example", md5: "md5_example", name: "name_example", size: 123, folderPath: "folderPath_example") // FileCreator | 
let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

// Initiate Upload
ArticlesAPI.privateArticleUploadInitiate(articleId: articleId, file: file, page: page, pageSize: pageSize, limit: limit, offset: offset) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **file** | [**FileCreator**](FileCreator.md) |  | 
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticlesList**
```swift
    open class func privateArticlesList(page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, completion: @escaping (_ data: [Article]?, _ error: Error?) -> Void)
```

Private Articles

Get Own Articles

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

// Private Articles
ArticlesAPI.privateArticlesList(page: page, pageSize: pageSize, limit: limit, offset: offset) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateArticlesSearch**
```swift
    open class func privateArticlesSearch(search: PrivateArticleSearch, completion: @escaping (_ data: [ArticleWithProject]?, _ error: Error?) -> Void)
```

Private Articles search

Returns a list of private articles filtered by the search parameters

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let search = PrivateArticleSearch(resourceId: "resourceId_example", resourceDoi: "resourceDoi_example", itemType: 123, doi: "doi_example", handle: "handle_example", projectId: 123, order: "order_example", searchFor: "searchFor_example", page: 123, pageSize: 123, limit: 123, offset: 123, orderDirection: "orderDirection_example", institution: 123, publishedSince: "publishedSince_example", modifiedSince: "modifiedSince_example", group: 123) // PrivateArticleSearch | Search Parameters

// Private Articles search
ArticlesAPI.privateArticlesSearch(search: search) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateArticleSearch**](PrivateArticleSearch.md) | Search Parameters | 

### Return type

[**[ArticleWithProject]**](ArticleWithProject.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **publicArticleDownload**
```swift
    open class func publicArticleDownload(articleId: Int64, folderPath: String? = nil, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Public Article Download

Download files from a public article preserving the folder structure

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let folderPath = "folderPath_example" // String | Folder path to download. If not provided, all files from the article will be downloaded (optional)

// Public Article Download
ArticlesAPI.publicArticleDownload(articleId: articleId, folderPath: folderPath) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **folderPath** | **String** | Folder path to download. If not provided, all files from the article will be downloaded | [optional] 

### Return type

Void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **publicArticleVersionDownload**
```swift
    open class func publicArticleVersionDownload(articleId: Int64, versionId: Int64, folderPath: String? = nil, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Public Article Version Download

Download files from a certain version of an public article preserving the folder structure

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let articleId = 987 // Int64 | Article unique identifier
let versionId = 987 // Int64 | Version Number
let folderPath = "folderPath_example" // String | Folder path to download. If not provided, all files from the article will be downloaded (optional)

// Public Article Version Download
ArticlesAPI.publicArticleVersionDownload(articleId: articleId, versionId: versionId, folderPath: folderPath) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **articleId** | **Int64** | Article unique identifier | 
 **versionId** | **Int64** | Version Number | 
 **folderPath** | **String** | Folder path to download. If not provided, all files from the article will be downloaded | [optional] 

### Return type

Void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

