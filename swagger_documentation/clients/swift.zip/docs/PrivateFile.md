# PrivateFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**viewerType** | **String** | File viewer type | 
**previewState** | **String** | File preview state | 
**uploadUrl** | **String** | Upload url for file | 
**uploadToken** | **String** | Token for file upload | 
**isAttachedToPublicVersion** | **Bool** | True if the file is attached to a public item version | 
**id** | **Int64** | File id | 
**name** | **String** | File name | 
**size** | **Int64** | File size | 
**isLinkOnly** | **Bool** | True if file is hosted somewhere else | 
**downloadUrl** | **String** | Url for file download | 
**suppliedMd5** | **String** | File supplied md5 | 
**computedMd5** | **String** | File computed md5 | 
**mimetype** | **String** | MIME Type of the file, it defaults to an empty string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


