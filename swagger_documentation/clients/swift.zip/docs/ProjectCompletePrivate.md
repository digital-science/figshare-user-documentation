# ProjectCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **String** | Project funding | 
**fundingList** | [FundingInformation] | Full Project funding information | 
**description** | **String** | Project description | 
**collaborators** | [Collaborator] | List of project collaborators | 
**quota** | **Int64** | Project quota | 
**usedQuota** | **Int64** | Project used quota | 
**createdDate** | **String** | Date when project was created | 
**modifiedDate** | **String** | Date when project was last modified | 
**usedQuotaPrivate** | **Int64** | Project private quota used | 
**usedQuotaPublic** | **Int64** | Project public quota used | 
**groupId** | **Int64** | Group of project if any | 
**accountId** | **Int64** | ID of the account owning the project | 
**customFields** | [ShortCustomField] | Collection custom fields | 
**role** | **String** | Role inside this project | 
**storage** | **String** | Project storage type | 
**url** | **String** | Api endpoint | 
**id** | **Int64** | Project id | 
**title** | **String** | Project title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


