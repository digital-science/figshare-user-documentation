# PublicFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int64** | File id | 
**name** | **String** | File name | 
**size** | **Int64** | File size | 
**isLinkOnly** | **Bool** | True if file is hosted somewhere else | 
**downloadUrl** | **String** | Url for file download | 
**suppliedMd5** | **String** | File supplied md5 | 
**computedMd5** | **String** | File computed md5 | 
**mimetype** | **String** | MIME Type of the file, it defaults to an empty string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


