# Resource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | ID of resource item | [optional] [default to ""]
**title** | **String** | Title of resource item | [optional] [default to ""]
**doi** | **String** | DOI of resource item | [optional] [default to ""]
**link** | **String** | Link of resource item | [optional] [default to ""]
**status** | **String** | Status of resource item | [optional] [default to ""]
**version** | **Int64** | Version of resource item | [optional] [default to 0]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


