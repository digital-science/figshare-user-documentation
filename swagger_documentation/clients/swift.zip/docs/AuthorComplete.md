# AuthorComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**institutionId** | **Int64** | Institution id | 
**groupId** | **Int64** | Group id | 
**firstName** | **String** | First Name | 
**lastName** | **String** | Last Name | 
**isPublic** | **Int64** | if 1 then the author has published items | 
**jobTitle** | **String** | Job title | 
**id** | **Int64** | Author id | 
**fullName** | **String** | Author full name | 
**isActive** | **Bool** | True if author has published items | 
**urlName** | **String** | Author url name | 
**orcidId** | **String** | Author Orcid | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


