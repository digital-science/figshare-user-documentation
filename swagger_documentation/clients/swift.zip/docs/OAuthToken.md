# OAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessToken** | **String** | The OAuth access token | 
**token** | **String** | The OAuth access token | [optional] 
**tokenType** | **String** | The type of token issued | 
**expiresIn** | **Int64** | Token expiration time in seconds | 
**refreshToken** | **String** | The refresh token (only provided for certain grant types) | [optional] 
**scope** | **String** | The scope of the access token | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


