# ArticleWithProject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**projectId** | **Int64** | Project id for this article. | [default to 0]
**id** | **Int64** | Unique identifier for article | 
**title** | **String** | Title of article | 
**doi** | **String** | DOI | 
**handle** | **String** | Handle | 
**url** | **String** | Api endpoint for article | 
**urlPublicHtml** | **String** | Public site endpoint for article | 
**urlPublicApi** | **String** | Public Api endpoint for article | 
**urlPrivateHtml** | **String** | Private site endpoint for article | 
**urlPrivateApi** | **String** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) |  | 
**thumb** | **String** | Thumbnail image | 
**definedType** | **Int64** | Type of article identifier | 
**definedTypeName** | **String** | Name of the article type identifier | 
**resourceDoi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to ""]
**resourceTitle** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to ""]
**createdDate** | **String** | Date when article was created | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


