# Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int64** | Account id | 
**firstName** | **String** | First Name | 
**lastName** | **String** | Last Name | 
**usedQuotaPrivate** | **Int64** | Account used private quota | 
**modifiedDate** | **String** | Date of last account modification | 
**usedQuota** | **Int64** | Account total used quota | 
**createdDate** | **String** | Date when account was created | 
**quota** | **Int64** | Account quota | 
**groupId** | **Int64** | Account group id | 
**institutionUserId** | **String** | Account institution user id | 
**institutionId** | **Int64** | Account institution | 
**email** | **String** | User email | 
**usedQuotaPublic** | **Int64** | Account public used quota | 
**pendingQuotaRequest** | **Bool** | True if a quota request is pending | 
**active** | **Int64** | Account activity status | 
**maximumFileSize** | **Int64** | Maximum upload size for account | 
**userId** | **Int64** | User id associated with account, useful for example for adding the account as an author to an item | 
**orcidId** | **String** | ORCID iD associated to account | 
**symplecticUserId** | **String** | Symplectic ID associated to account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


