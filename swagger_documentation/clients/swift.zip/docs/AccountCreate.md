# AccountCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** | Email of account | 
**firstName** | **String** | First Name | [optional] [default to ""]
**lastName** | **String** | Last Name | [default to ""]
**groupId** | **Int64** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] 
**institutionUserId** | **String** | Institution user id | [optional] [default to ""]
**symplecticUserId** | **String** | Symplectic user id | [optional] [default to ""]
**quota** | **Int64** | Account quota | [optional] 
**isActive** | **Bool** | Is account active | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


