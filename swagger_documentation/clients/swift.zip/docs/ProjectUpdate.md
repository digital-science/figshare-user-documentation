# ProjectUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** | The title for this project - mandatory. 3 - 1000 characters. | [optional] 
**description** | **String** | Project description | [optional] 
**funding** | **String** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional] 
**fundingList** | [FundingCreate] | Funding creation / update items | [optional] 
**customFields** | **AnyCodable** | List of key, values pairs to be associated with the project | [optional] 
**customFieldsList** | [CustomArticleFieldAdd] | List of custom fields values, supersedes custom_fields parameter | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


