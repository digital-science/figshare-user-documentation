# PrivateLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Private link id | 
**isActive** | **Bool** | True if private link is active | 
**expiresDate** | **String** | Date when link will expire | 
**htmlLocation** | **String** | HTML url for private link | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


