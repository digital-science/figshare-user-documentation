# ProjectNote

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int64** | Project note id | 
**userId** | **Int64** | User who wrote the note | 
**abstract** | **String** | Note Abstract - short/truncated content | 
**userName** | **String** | Username of the one who wrote the note | 
**createdDate** | **String** | Date when note was created | 
**modifiedDate** | **String** | Date when note was last modified | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


