# CollectionCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountId** | **Int64** | ID of the account owning the collection | 
**funding** | [FundingInformation] | Full Collection funding information | 
**resourceId** | **String** | Collection resource id | 
**resourceDoi** | **String** | Collection resource doi | 
**resourceTitle** | **String** | Collection resource title | 
**resourceLink** | **String** | Collection resource link | 
**resourceVersion** | **Int64** | Collection resource version | 
**version** | **Int64** | Collection version | 
**description** | **String** | Collection description | 
**categories** | [Category] | List of collection categories | 
**references** | **[String]** | List of collection references | 
**relatedMaterials** | [RelatedMaterial] | List of related materials; supersedes references and resource DOI/title. | [optional] 
**tags** | **[String]** | List of collection tags. Keywords can be used instead | 
**keywords** | **[String]** | List of collection keywords. Tags can be used instead | 
**authors** | [Author] | List of collection authors | 
**institutionId** | **Int64** | Collection institution | 
**groupId** | **Int64** | Collection group | 
**articlesCount** | **Int64** | Number of articles in collection | 
**_public** | **Bool** | True if collection is published | 
**citation** | **String** | Collection citation | 
**customFields** | [CustomArticleField] | Collection custom fields | 
**modifiedDate** | **String** | Date when collection was last modified | 
**createdDate** | **String** | Date when collection was created | 
**timeline** | [**Timeline**](Timeline.md) |  | 
**id** | **Int64** | Collection id | 
**title** | **String** | Collection title | 
**doi** | **String** | Collection DOI | 
**handle** | **String** | Collection Handle | 
**url** | **String** | Api endpoint | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


