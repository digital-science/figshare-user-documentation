# LocationWarnings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entityId** | **Int** | Figshare ID of the entity | 
**location** | **String** | Url for entity | 
**warnings** | **[String]** | Issues encountered during the operation | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


