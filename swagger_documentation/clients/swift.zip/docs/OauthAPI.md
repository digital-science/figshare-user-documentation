# OauthAPI

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createToken**](OauthAPI.md#createtoken) | **POST** /token | Create OAuth token
[**getTokenInfo**](OauthAPI.md#gettokeninfo) | **GET** /token | Get OAuth token information


# **createToken**
```swift
    open class func createToken(body: CreateOAuthToken? = nil, completion: @escaping (_ data: OAuthToken?, _ error: Error?) -> Void)
```

Create OAuth token

Creates OAuth token using various grant types

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let body = CreateOAuthToken(clientId: "clientId_example", clientSecret: "clientSecret_example", grantType: "grantType_example", code: "code_example", refreshToken: "refreshToken_example", username: "username_example", password: "password_example") // CreateOAuthToken | Create OAuth Token Parameters (optional)

// Create OAuth token
OauthAPI.createToken(body: body) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateOAuthToken**](CreateOAuthToken.md) | Create OAuth Token Parameters | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **getTokenInfo**
```swift
    open class func getTokenInfo(accessToken: String? = nil, completion: @escaping (_ data: OAuthToken?, _ error: Error?) -> Void)
```

Get OAuth token information

Returns information about the current OAuth token

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let accessToken = "accessToken_example" // String | OAuth access token (optional)

// Get OAuth token information
OauthAPI.getTokenInfo(accessToken: accessToken) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accessToken** | **String** | OAuth access token | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

