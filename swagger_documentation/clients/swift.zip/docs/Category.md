# Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parentId** | **Int64** | Parent category | 
**id** | **Int64** | Category id | 
**title** | **String** | Category title | 
**path** | **String** | Path to all ancestor ids | 
**sourceId** | **String** | ID in original standard taxonomy | 
**taxonomyId** | **Int64** | Internal id of taxonomy the category is part of | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


