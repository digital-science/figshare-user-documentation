# CollectionSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resourceDoi** | **String** | Only return collections with this resource_doi | [optional] 
**doi** | **String** | Only return collections with this doi | [optional] 
**handle** | **String** | Only return collections with this handle | [optional] 
**order** | **String** | The field by which to order. | [optional] [default to .createdDate]
**searchFor** | **String** | Search term | [optional] 
**page** | **Int** | Page number. Used for pagination with page_size | [optional] 
**pageSize** | **Int** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **Int** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **Int** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
**orderDirection** | **String** | Direction of ordering | [optional] [default to .desc]
**institution** | **Int** | only return collections from this institution | [optional] 
**publishedSince** | **String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
**modifiedSince** | **String** | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
**group** | **Int** | only return collections from this group | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


