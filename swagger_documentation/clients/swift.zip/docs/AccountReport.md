# AccountReport

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int64** | A unique ID for the AccountRecord | 
**accountId** | **Int64** | The ID of the account which generated this report. | 
**createdDate** | **String** | Date when the AccountReport was requested | 
**status** | **String** | Status of the report | 
**downloadUrl** | **String** | The download link for the generated XLSX | 
**groupId** | **Int64** | The group ID that was used to filter the report, if any. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


