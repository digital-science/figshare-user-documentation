# CurationComment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int64** | The ID of the comment. | 
**accountId** | **Int64** | The ID of the account which generated this comment. | 
**type** | **String** | The ID of the account which generated this comment. | 
**text** | **String** | The value/content of the comment. | 
**createdDate** | **String** | The creation date of the comment. | 
**modifiedDate** | **String** | The date the comment has been modified. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


