# FundingInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int** | Funding id | 
**title** | **String** | The funding name | 
**grantCode** | **String** | The grant code | 
**funderName** | **String** | Funder&#39;s name | 
**isUserDefined** | **Int** | Return 1 whether the grant has been introduced manually, 0 otherwise | 
**url** | **String** | The grant url | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


