# AccountUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupId** | **Int64** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | 
**isActive** | **Bool** | Is account active | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


