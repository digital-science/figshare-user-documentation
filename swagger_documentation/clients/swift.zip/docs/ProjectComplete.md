# ProjectComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **String** | Project funding | 
**fundingList** | [FundingInformation] | Full Project funding information | 
**description** | **String** | Project description | 
**collaborators** | [Collaborator] | List of project collaborators | 
**customFields** | [CustomArticleField] | Project custom fields | 
**modifiedDate** | **String** | Date when project was last modified | 
**createdDate** | **String** | Date when project was created | 
**url** | **String** | Api endpoint | 
**id** | **Int64** | Project id | 
**title** | **String** | Project title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


