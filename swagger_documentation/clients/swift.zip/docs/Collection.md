# Collection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int64** | Collection id | 
**title** | **String** | Collection title | 
**doi** | **String** | Collection DOI | 
**handle** | **String** | Collection Handle | 
**url** | **String** | Api endpoint | 
**timeline** | [**Timeline**](Timeline.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


