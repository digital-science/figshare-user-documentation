# ShortCustomField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int64** | Custom field id | 
**name** | **String** | Custom field name | 
**fieldType** | **String** | Custom field type | 
**settings** | **AnyCodable** | Settings for the custom field | [optional] 
**order** | **Int64** | Order of the field in the group | [optional] 
**isMandatory** | **Bool** | Whether the field is mandatory or not | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


