# CollectionsAPI

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**collectionArticles**](CollectionsAPI.md#collectionarticles) | **GET** /collections/{collection_id}/articles | Public Collection Articles
[**collectionDetails**](CollectionsAPI.md#collectiondetails) | **GET** /collections/{collection_id} | Collection details
[**collectionVersionDetails**](CollectionsAPI.md#collectionversiondetails) | **GET** /collections/{collection_id}/versions/{version_id} | Collection Version details
[**collectionVersions**](CollectionsAPI.md#collectionversions) | **GET** /collections/{collection_id}/versions | Collection Versions list
[**collectionsList**](CollectionsAPI.md#collectionslist) | **GET** /collections | Public Collections
[**collectionsSearch**](CollectionsAPI.md#collectionssearch) | **POST** /collections/search | Public Collections Search
[**privateCollectionArticleDelete**](CollectionsAPI.md#privatecollectionarticledelete) | **DELETE** /account/collections/{collection_id}/articles/{article_id} | Delete collection article
[**privateCollectionArticlesAdd**](CollectionsAPI.md#privatecollectionarticlesadd) | **POST** /account/collections/{collection_id}/articles | Add collection articles
[**privateCollectionArticlesList**](CollectionsAPI.md#privatecollectionarticleslist) | **GET** /account/collections/{collection_id}/articles | List collection articles
[**privateCollectionArticlesReplace**](CollectionsAPI.md#privatecollectionarticlesreplace) | **PUT** /account/collections/{collection_id}/articles | Replace collection articles
[**privateCollectionAuthorDelete**](CollectionsAPI.md#privatecollectionauthordelete) | **DELETE** /account/collections/{collection_id}/authors/{author_id} | Delete collection author
[**privateCollectionAuthorsAdd**](CollectionsAPI.md#privatecollectionauthorsadd) | **POST** /account/collections/{collection_id}/authors | Add collection authors
[**privateCollectionAuthorsList**](CollectionsAPI.md#privatecollectionauthorslist) | **GET** /account/collections/{collection_id}/authors | List collection authors
[**privateCollectionAuthorsReplace**](CollectionsAPI.md#privatecollectionauthorsreplace) | **PUT** /account/collections/{collection_id}/authors | Replace collection authors
[**privateCollectionCategoriesAdd**](CollectionsAPI.md#privatecollectioncategoriesadd) | **POST** /account/collections/{collection_id}/categories | Add collection categories
[**privateCollectionCategoriesList**](CollectionsAPI.md#privatecollectioncategorieslist) | **GET** /account/collections/{collection_id}/categories | List collection categories
[**privateCollectionCategoriesReplace**](CollectionsAPI.md#privatecollectioncategoriesreplace) | **PUT** /account/collections/{collection_id}/categories | Replace collection categories
[**privateCollectionCategoryDelete**](CollectionsAPI.md#privatecollectioncategorydelete) | **DELETE** /account/collections/{collection_id}/categories/{category_id} | Delete collection category
[**privateCollectionCreate**](CollectionsAPI.md#privatecollectioncreate) | **POST** /account/collections | Create collection
[**privateCollectionDelete**](CollectionsAPI.md#privatecollectiondelete) | **DELETE** /account/collections/{collection_id} | Delete collection
[**privateCollectionDetails**](CollectionsAPI.md#privatecollectiondetails) | **GET** /account/collections/{collection_id} | Collection details
[**privateCollectionPatch**](CollectionsAPI.md#privatecollectionpatch) | **PATCH** /account/collections/{collection_id} | Partially update collection
[**privateCollectionPrivateLinkCreate**](CollectionsAPI.md#privatecollectionprivatelinkcreate) | **POST** /account/collections/{collection_id}/private_links | Create collection private link
[**privateCollectionPrivateLinkDelete**](CollectionsAPI.md#privatecollectionprivatelinkdelete) | **DELETE** /account/collections/{collection_id}/private_links/{link_id} | Disable private link
[**privateCollectionPrivateLinkDetails**](CollectionsAPI.md#privatecollectionprivatelinkdetails) | **GET** /account/collections/{collection_id}/private_links/{link_id} | View collection private link
[**privateCollectionPrivateLinkUpdate**](CollectionsAPI.md#privatecollectionprivatelinkupdate) | **PUT** /account/collections/{collection_id}/private_links/{link_id} | Update collection private link
[**privateCollectionPrivateLinksList**](CollectionsAPI.md#privatecollectionprivatelinkslist) | **GET** /account/collections/{collection_id}/private_links | List collection private links
[**privateCollectionPublish**](CollectionsAPI.md#privatecollectionpublish) | **POST** /account/collections/{collection_id}/publish | Private Collection Publish
[**privateCollectionReserveDoi**](CollectionsAPI.md#privatecollectionreservedoi) | **POST** /account/collections/{collection_id}/reserve_doi | Private Collection Reserve DOI
[**privateCollectionReserveHandle**](CollectionsAPI.md#privatecollectionreservehandle) | **POST** /account/collections/{collection_id}/reserve_handle | Private Collection Reserve Handle
[**privateCollectionResource**](CollectionsAPI.md#privatecollectionresource) | **POST** /account/collections/{collection_id}/resource | Private Collection Resource
[**privateCollectionUpdate**](CollectionsAPI.md#privatecollectionupdate) | **PUT** /account/collections/{collection_id} | Update collection
[**privateCollectionsList**](CollectionsAPI.md#privatecollectionslist) | **GET** /account/collections | Private Collections List
[**privateCollectionsSearch**](CollectionsAPI.md#privatecollectionssearch) | **POST** /account/collections/search | Private Collections Search


# **collectionArticles**
```swift
    open class func collectionArticles(collectionId: Int64, page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, completion: @escaping (_ data: [Article]?, _ error: Error?) -> Void)
```

Public Collection Articles

Returns a list of public collection articles

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection Unique identifier
let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

// Public Collection Articles
CollectionsAPI.collectionArticles(collectionId: collectionId, page: page, pageSize: pageSize, limit: limit, offset: offset) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection Unique identifier | 
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **collectionDetails**
```swift
    open class func collectionDetails(collectionId: Int64, completion: @escaping (_ data: CollectionComplete?, _ error: Error?) -> Void)
```

Collection details

View a collection

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection Unique identifier

// Collection details
CollectionsAPI.collectionDetails(collectionId: collectionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection Unique identifier | 

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **collectionVersionDetails**
```swift
    open class func collectionVersionDetails(collectionId: Int64, versionId: Int64, completion: @escaping (_ data: CollectionComplete?, _ error: Error?) -> Void)
```

Collection Version details

View details for a certain version of a collection

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection Unique identifier
let versionId = 987 // Int64 | Version Number

// Collection Version details
CollectionsAPI.collectionVersionDetails(collectionId: collectionId, versionId: versionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection Unique identifier | 
 **versionId** | **Int64** | Version Number | 

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **collectionVersions**
```swift
    open class func collectionVersions(collectionId: Int64, completion: @escaping (_ data: [CollectionVersions]?, _ error: Error?) -> Void)
```

Collection Versions list

Returns a list of public collection Versions

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection Unique identifier

// Collection Versions list
CollectionsAPI.collectionVersions(collectionId: collectionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection Unique identifier | 

### Return type

[**[CollectionVersions]**](CollectionVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **collectionsList**
```swift
    open class func collectionsList(xCursor: UUID? = nil, page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, order: Order_collectionsList? = nil, orderDirection: OrderDirection_collectionsList? = nil, institution: Int64? = nil, publishedSince: String? = nil, modifiedSince: String? = nil, group: Int64? = nil, resourceDoi: String? = nil, doi: String? = nil, handle: String? = nil, completion: @escaping (_ data: [Collection]?, _ error: Error?) -> Void)
```

Public Collections

Returns a list of public collections

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let xCursor = 987 // UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
let order = "order_example" // String | The field by which to order. Default varies by endpoint/resource. (optional) (default to .publishedDate)
let orderDirection = "orderDirection_example" // String |  (optional) (default to .desc)
let institution = 987 // Int64 | only return collections from this institution (optional)
let publishedSince = "publishedSince_example" // String | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD (optional)
let modifiedSince = "modifiedSince_example" // String | Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD (optional)
let group = 987 // Int64 | only return collections from this group (optional)
let resourceDoi = "resourceDoi_example" // String | only return collections with this resource_doi (optional)
let doi = "doi_example" // String | only return collections with this doi (optional)
let handle = "handle_example" // String | only return collections with this handle (optional)

// Public Collections
CollectionsAPI.collectionsList(xCursor: xCursor, page: page, pageSize: pageSize, limit: limit, offset: offset, order: order, orderDirection: orderDirection, institution: institution, publishedSince: publishedSince, modifiedSince: modifiedSince, group: group, resourceDoi: resourceDoi, doi: doi, handle: handle) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | **UUID** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **String** | The field by which to order. Default varies by endpoint/resource. | [optional] [default to .publishedDate]
 **orderDirection** | **String** |  | [optional] [default to .desc]
 **institution** | **Int64** | only return collections from this institution | [optional] 
 **publishedSince** | **String** | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **modifiedSince** | **String** | Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD | [optional] 
 **group** | **Int64** | only return collections from this group | [optional] 
 **resourceDoi** | **String** | only return collections with this resource_doi | [optional] 
 **doi** | **String** | only return collections with this doi | [optional] 
 **handle** | **String** | only return collections with this handle | [optional] 

### Return type

[**[Collection]**](Collection.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **collectionsSearch**
```swift
    open class func collectionsSearch(xCursor: UUID? = nil, search: CollectionSearch? = nil, completion: @escaping (_ data: [Collection]?, _ error: Error?) -> Void)
```

Public Collections Search

Returns a list of public collections

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let xCursor = 987 // UUID | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
let search = CollectionSearch(resourceDoi: "resourceDoi_example", doi: "doi_example", handle: "handle_example", order: "order_example", searchFor: "searchFor_example", page: 123, pageSize: 123, limit: 123, offset: 123, orderDirection: "orderDirection_example", institution: 123, publishedSince: "publishedSince_example", modifiedSince: "modifiedSince_example", group: 123) // CollectionSearch | Search Parameters (optional)

// Public Collections Search
CollectionsAPI.collectionsSearch(xCursor: xCursor, search: search) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xCursor** | **UUID** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **search** | [**CollectionSearch**](CollectionSearch.md) | Search Parameters | [optional] 

### Return type

[**[Collection]**](Collection.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionArticleDelete**
```swift
    open class func privateCollectionArticleDelete(collectionId: Int64, articleId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete collection article

De-associate article from collection

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let articleId = 987 // Int64 | Collection article unique identifier

// Delete collection article
CollectionsAPI.privateCollectionArticleDelete(collectionId: collectionId, articleId: articleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **articleId** | **Int64** | Collection article unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionArticlesAdd**
```swift
    open class func privateCollectionArticlesAdd(collectionId: Int64, articles: ArticlesCreator, completion: @escaping (_ data: Location?, _ error: Error?) -> Void)
```

Add collection articles

Associate new articles with the collection. This will add new articles to the list of already associated articles

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let articles = ArticlesCreator(articles: [123]) // ArticlesCreator | Articles list

// Add collection articles
CollectionsAPI.privateCollectionArticlesAdd(collectionId: collectionId, articles: articles) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **articles** | [**ArticlesCreator**](ArticlesCreator.md) | Articles list | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionArticlesList**
```swift
    open class func privateCollectionArticlesList(collectionId: Int64, page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, completion: @escaping (_ data: [Article]?, _ error: Error?) -> Void)
```

List collection articles

List collection articles

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

// List collection articles
CollectionsAPI.privateCollectionArticlesList(collectionId: collectionId, page: page, pageSize: pageSize, limit: limit, offset: offset) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionArticlesReplace**
```swift
    open class func privateCollectionArticlesReplace(collectionId: Int64, articles: ArticlesCreator, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Replace collection articles

Associate new articles with the collection. This will remove all already associated articles and add these new ones

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let articles = ArticlesCreator(articles: [123]) // ArticlesCreator | Articles List

// Replace collection articles
CollectionsAPI.privateCollectionArticlesReplace(collectionId: collectionId, articles: articles) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **articles** | [**ArticlesCreator**](ArticlesCreator.md) | Articles List | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionAuthorDelete**
```swift
    open class func privateCollectionAuthorDelete(collectionId: Int64, authorId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete collection author

Delete collection author

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let authorId = 987 // Int64 | Collection Author unique identifier

// Delete collection author
CollectionsAPI.privateCollectionAuthorDelete(collectionId: collectionId, authorId: authorId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **authorId** | **Int64** | Collection Author unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionAuthorsAdd**
```swift
    open class func privateCollectionAuthorsAdd(collectionId: Int64, authors: AuthorsCreator, completion: @escaping (_ data: Location?, _ error: Error?) -> Void)
```

Add collection authors

Associate new authors with the collection. This will add new authors to the list of already associated authors

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let authors = AuthorsCreator(authors: [123]) // AuthorsCreator | List of authors

// Add collection authors
CollectionsAPI.privateCollectionAuthorsAdd(collectionId: collectionId, authors: authors) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md) | List of authors | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionAuthorsList**
```swift
    open class func privateCollectionAuthorsList(collectionId: Int64, completion: @escaping (_ data: [Author]?, _ error: Error?) -> Void)
```

List collection authors

List collection authors

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier

// List collection authors
CollectionsAPI.privateCollectionAuthorsList(collectionId: collectionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 

### Return type

[**[Author]**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionAuthorsReplace**
```swift
    open class func privateCollectionAuthorsReplace(collectionId: Int64, authors: AuthorsCreator, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Replace collection authors

Associate new authors with the collection. This will remove all already associated authors and add these new ones

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let authors = AuthorsCreator(authors: [123]) // AuthorsCreator | List of authors

// Replace collection authors
CollectionsAPI.privateCollectionAuthorsReplace(collectionId: collectionId, authors: authors) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md) | List of authors | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionCategoriesAdd**
```swift
    open class func privateCollectionCategoriesAdd(collectionId: Int64, categories: CategoriesCreator, completion: @escaping (_ data: Location?, _ error: Error?) -> Void)
```

Add collection categories

Associate new categories with the collection. This will add new categories to the list of already associated categories

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let categories = CategoriesCreator(categories: [123]) // CategoriesCreator | Categories list

// Add collection categories
CollectionsAPI.privateCollectionCategoriesAdd(collectionId: collectionId, categories: categories) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md) | Categories list | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionCategoriesList**
```swift
    open class func privateCollectionCategoriesList(collectionId: Int64, completion: @escaping (_ data: [Category]?, _ error: Error?) -> Void)
```

List collection categories

List collection categories

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier

// List collection categories
CollectionsAPI.privateCollectionCategoriesList(collectionId: collectionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 

### Return type

[**[Category]**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionCategoriesReplace**
```swift
    open class func privateCollectionCategoriesReplace(collectionId: Int64, categories: CategoriesCreator, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Replace collection categories

Associate new categories with the collection. This will remove all already associated categories and add these new ones

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let categories = CategoriesCreator(categories: [123]) // CategoriesCreator | Categories list

// Replace collection categories
CollectionsAPI.privateCollectionCategoriesReplace(collectionId: collectionId, categories: categories) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md) | Categories list | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionCategoryDelete**
```swift
    open class func privateCollectionCategoryDelete(collectionId: Int64, categoryId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete collection category

De-associate category from collection

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let categoryId = 987 // Int64 | Collection category unique identifier

// Delete collection category
CollectionsAPI.privateCollectionCategoryDelete(collectionId: collectionId, categoryId: categoryId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **categoryId** | **Int64** | Collection category unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionCreate**
```swift
    open class func privateCollectionCreate(collection: CollectionCreate, completion: @escaping (_ data: LocationWarnings?, _ error: Error?) -> Void)
```

Create collection

Create a new Collection by sending collection information

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collection = CollectionCreate(funding: "funding_example", fundingList: [FundingCreate(id: 123, title: "title_example")], title: "title_example", description: "description_example", articles: [123], authors: [123], categories: [123], categoriesBySourceId: ["categoriesBySourceId_example"], tags: ["tags_example"], keywords: ["keywords_example"], references: ["references_example"], relatedMaterials: [RelatedMaterial(id: 123, identifier: "identifier_example", title: "title_example", relation: "relation_example", identifierType: "identifierType_example", isLinkout: true, link: "link_example")], customFields: 123, customFieldsList: [CustomArticleFieldAdd(name: "name_example", value: 123)], doi: "doi_example", handle: "handle_example", resourceId: "resourceId_example", resourceDoi: "resourceDoi_example", resourceLink: "resourceLink_example", resourceTitle: "resourceTitle_example", resourceVersion: 123, groupId: 123, timeline: TimelineUpdate(firstOnline: "firstOnline_example", publisherPublication: "publisherPublication_example", publisherAcceptance: "publisherAcceptance_example")) // CollectionCreate | Collection description

// Create collection
CollectionsAPI.privateCollectionCreate(collection: collection) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection** | [**CollectionCreate**](CollectionCreate.md) | Collection description | 

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionDelete**
```swift
    open class func privateCollectionDelete(collectionId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete collection

Delete n collection

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection Unique identifier

// Delete collection
CollectionsAPI.privateCollectionDelete(collectionId: collectionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection Unique identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionDetails**
```swift
    open class func privateCollectionDetails(collectionId: Int64, completion: @escaping (_ data: CollectionCompletePrivate?, _ error: Error?) -> Void)
```

Collection details

View a collection

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection Unique identifier

// Collection details
CollectionsAPI.privateCollectionDetails(collectionId: collectionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection Unique identifier | 

### Return type

[**CollectionCompletePrivate**](CollectionCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionPatch**
```swift
    open class func privateCollectionPatch(collectionId: Int64, collection: CollectionUpdate, completion: @escaping (_ data: LocationWarningsUpdate?, _ error: Error?) -> Void)
```

Partially update collection

Partially update a collection by sending only the fields to change.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection Unique identifier
let collection = CollectionUpdate(funding: "funding_example", fundingList: [FundingCreate(id: 123, title: "title_example")], title: "title_example", description: "description_example", articles: [123], authors: [123], categories: [123], categoriesBySourceId: ["categoriesBySourceId_example"], tags: ["tags_example"], keywords: ["keywords_example"], references: ["references_example"], relatedMaterials: [RelatedMaterial(id: 123, identifier: "identifier_example", title: "title_example", relation: "relation_example", identifierType: "identifierType_example", isLinkout: true, link: "link_example")], customFields: 123, customFieldsList: [CustomArticleFieldAdd(name: "name_example", value: 123)], doi: "doi_example", handle: "handle_example", resourceId: "resourceId_example", resourceDoi: "resourceDoi_example", resourceLink: "resourceLink_example", resourceTitle: "resourceTitle_example", resourceVersion: 123, groupId: 123, timeline: TimelineUpdate(firstOnline: "firstOnline_example", publisherPublication: "publisherPublication_example", publisherAcceptance: "publisherAcceptance_example")) // CollectionUpdate | Subset of collection fields to update

// Partially update collection
CollectionsAPI.privateCollectionPatch(collectionId: collectionId, collection: collection) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection Unique identifier | 
 **collection** | [**CollectionUpdate**](CollectionUpdate.md) | Subset of collection fields to update | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionPrivateLinkCreate**
```swift
    open class func privateCollectionPrivateLinkCreate(collectionId: Int64, privateLink: CollectionPrivateLinkCreator? = nil, completion: @escaping (_ data: PrivateLinkResponse?, _ error: Error?) -> Void)
```

Create collection private link

Create new private link

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let privateLink = CollectionPrivateLinkCreator(expiresDate: "expiresDate_example") // CollectionPrivateLinkCreator |  (optional)

// Create collection private link
CollectionsAPI.privateCollectionPrivateLinkCreate(collectionId: collectionId, privateLink: privateLink) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **privateLink** | [**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md) |  | [optional] 

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionPrivateLinkDelete**
```swift
    open class func privateCollectionPrivateLinkDelete(collectionId: Int64, linkId: String, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Disable private link

Disable/delete private link for this collection

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let linkId = "linkId_example" // String | Private link token

// Disable private link
CollectionsAPI.privateCollectionPrivateLinkDelete(collectionId: collectionId, linkId: linkId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **linkId** | **String** | Private link token | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionPrivateLinkDetails**
```swift
    open class func privateCollectionPrivateLinkDetails(collectionId: Int64, linkId: String, completion: @escaping (_ data: PrivateLink?, _ error: Error?) -> Void)
```

View collection private link

View existing private link for this collection

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let linkId = "linkId_example" // String | Private link token

// View collection private link
CollectionsAPI.privateCollectionPrivateLinkDetails(collectionId: collectionId, linkId: linkId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **linkId** | **String** | Private link token | 

### Return type

[**PrivateLink**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionPrivateLinkUpdate**
```swift
    open class func privateCollectionPrivateLinkUpdate(collectionId: Int64, linkId: String, privateLink: CollectionPrivateLinkCreator? = nil, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Update collection private link

Update existing private link for this collection

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let linkId = "linkId_example" // String | Private link token
let privateLink = CollectionPrivateLinkCreator(expiresDate: "expiresDate_example") // CollectionPrivateLinkCreator |  (optional)

// Update collection private link
CollectionsAPI.privateCollectionPrivateLinkUpdate(collectionId: collectionId, linkId: linkId, privateLink: privateLink) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **linkId** | **String** | Private link token | 
 **privateLink** | [**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md) |  | [optional] 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionPrivateLinksList**
```swift
    open class func privateCollectionPrivateLinksList(collectionId: Int64, completion: @escaping (_ data: [PrivateLink]?, _ error: Error?) -> Void)
```

List collection private links

List article private links

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier

// List collection private links
CollectionsAPI.privateCollectionPrivateLinksList(collectionId: collectionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 

### Return type

[**[PrivateLink]**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionPublish**
```swift
    open class func privateCollectionPublish(collectionId: Int64, completion: @escaping (_ data: Location?, _ error: Error?) -> Void)
```

Private Collection Publish

When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection Unique identifier

// Private Collection Publish
CollectionsAPI.privateCollectionPublish(collectionId: collectionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection Unique identifier | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionReserveDoi**
```swift
    open class func privateCollectionReserveDoi(collectionId: Int64, completion: @escaping (_ data: CollectionDOI?, _ error: Error?) -> Void)
```

Private Collection Reserve DOI

Reserve DOI for collection

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection Unique identifier

// Private Collection Reserve DOI
CollectionsAPI.privateCollectionReserveDoi(collectionId: collectionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection Unique identifier | 

### Return type

[**CollectionDOI**](CollectionDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionReserveHandle**
```swift
    open class func privateCollectionReserveHandle(collectionId: Int64, completion: @escaping (_ data: CollectionHandle?, _ error: Error?) -> Void)
```

Private Collection Reserve Handle

Reserve Handle for collection

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection Unique identifier

// Private Collection Reserve Handle
CollectionsAPI.privateCollectionReserveHandle(collectionId: collectionId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection Unique identifier | 

### Return type

[**CollectionHandle**](CollectionHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionResource**
```swift
    open class func privateCollectionResource(collectionId: Int64, resource: Resource, completion: @escaping (_ data: Location?, _ error: Error?) -> Void)
```

Private Collection Resource

Edit collection resource data.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection unique identifier
let resource = Resource(id: "id_example", title: "title_example", doi: "doi_example", link: "link_example", status: "status_example", version: 123) // Resource | Resource data

// Private Collection Resource
CollectionsAPI.privateCollectionResource(collectionId: collectionId, resource: resource) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection unique identifier | 
 **resource** | [**Resource**](Resource.md) | Resource data | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionUpdate**
```swift
    open class func privateCollectionUpdate(collectionId: Int64, collection: CollectionUpdate, completion: @escaping (_ data: LocationWarningsUpdate?, _ error: Error?) -> Void)
```

Update collection

Update a collection by passing full body parameters.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let collectionId = 987 // Int64 | Collection Unique identifier
let collection = CollectionUpdate(funding: "funding_example", fundingList: [FundingCreate(id: 123, title: "title_example")], title: "title_example", description: "description_example", articles: [123], authors: [123], categories: [123], categoriesBySourceId: ["categoriesBySourceId_example"], tags: ["tags_example"], keywords: ["keywords_example"], references: ["references_example"], relatedMaterials: [RelatedMaterial(id: 123, identifier: "identifier_example", title: "title_example", relation: "relation_example", identifierType: "identifierType_example", isLinkout: true, link: "link_example")], customFields: 123, customFieldsList: [CustomArticleFieldAdd(name: "name_example", value: 123)], doi: "doi_example", handle: "handle_example", resourceId: "resourceId_example", resourceDoi: "resourceDoi_example", resourceLink: "resourceLink_example", resourceTitle: "resourceTitle_example", resourceVersion: 123, groupId: 123, timeline: TimelineUpdate(firstOnline: "firstOnline_example", publisherPublication: "publisherPublication_example", publisherAcceptance: "publisherAcceptance_example")) // CollectionUpdate | Collection description

// Update collection
CollectionsAPI.privateCollectionUpdate(collectionId: collectionId, collection: collection) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collectionId** | **Int64** | Collection Unique identifier | 
 **collection** | [**CollectionUpdate**](CollectionUpdate.md) | Collection description | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionsList**
```swift
    open class func privateCollectionsList(page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, order: Order_privateCollectionsList? = nil, orderDirection: OrderDirection_privateCollectionsList? = nil, completion: @escaping (_ data: [Collection]?, _ error: Error?) -> Void)
```

Private Collections List

List private collections

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
let order = "order_example" // String | The field by which to order. Default varies by endpoint/resource. (optional) (default to .publishedDate)
let orderDirection = "orderDirection_example" // String |  (optional) (default to .desc)

// Private Collections List
CollectionsAPI.privateCollectionsList(page: page, pageSize: pageSize, limit: limit, offset: offset, order: order, orderDirection: orderDirection) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **String** | The field by which to order. Default varies by endpoint/resource. | [optional] [default to .publishedDate]
 **orderDirection** | **String** |  | [optional] [default to .desc]

### Return type

[**[Collection]**](Collection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCollectionsSearch**
```swift
    open class func privateCollectionsSearch(search: PrivateCollectionSearch, completion: @escaping (_ data: [Collection]?, _ error: Error?) -> Void)
```

Private Collections Search

Returns a list of private Collections

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let search = PrivateCollectionSearch(resourceId: "resourceId_example", resourceDoi: "resourceDoi_example", doi: "doi_example", handle: "handle_example", order: "order_example", searchFor: "searchFor_example", page: 123, pageSize: 123, limit: 123, offset: 123, orderDirection: "orderDirection_example", institution: 123, publishedSince: "publishedSince_example", modifiedSince: "modifiedSince_example", group: 123) // PrivateCollectionSearch | Search Parameters

// Private Collections Search
CollectionsAPI.privateCollectionsSearch(search: search) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateCollectionSearch**](PrivateCollectionSearch.md) | Search Parameters | 

### Return type

[**[Collection]**](Collection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

