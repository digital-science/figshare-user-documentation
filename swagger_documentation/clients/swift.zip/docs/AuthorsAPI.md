# AuthorsAPI

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**privateAuthorDetails**](AuthorsAPI.md#privateauthordetails) | **GET** /account/authors/{author_id} | Author details
[**privateAuthorsSearch**](AuthorsAPI.md#privateauthorssearch) | **POST** /account/authors/search | Search Authors


# **privateAuthorDetails**
```swift
    open class func privateAuthorDetails(authorId: Int64, completion: @escaping (_ data: AuthorComplete?, _ error: Error?) -> Void)
```

Author details

View author details

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let authorId = 987 // Int64 | Author unique identifier

// Author details
AuthorsAPI.privateAuthorDetails(authorId: authorId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorId** | **Int64** | Author unique identifier | 

### Return type

[**AuthorComplete**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateAuthorsSearch**
```swift
    open class func privateAuthorsSearch(search: PrivateAuthorsSearch? = nil, completion: @escaping (_ data: [AuthorComplete]?, _ error: Error?) -> Void)
```

Search Authors

Search for authors

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let search = PrivateAuthorsSearch(searchFor: "searchFor_example", page: 123, pageSize: 123, limit: 123, offset: 123, institutionId: 123, orcid: "orcid_example", groupId: 123, isActive: false, isPublic: false) // PrivateAuthorsSearch | Search Parameters (optional)

// Search Authors
AuthorsAPI.privateAuthorsSearch(search: search) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateAuthorsSearch**](PrivateAuthorsSearch.md) | Search Parameters | [optional] 

### Return type

[**[AuthorComplete]**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

