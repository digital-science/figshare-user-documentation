# PrivateAuthorsSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**searchFor** | **String** | Search term | [optional] 
**page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
**pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
**institutionId** | **Int64** | Return only authors associated to this institution | [optional] 
**orcid** | **String** | Orcid of author | [optional] 
**groupId** | **Int64** | Return only authors in this group or subgroups of the group | [optional] 
**isActive** | **Bool** | Return only active authors if True | [optional] 
**isPublic** | **Bool** | Return only authors that have published items if True | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


