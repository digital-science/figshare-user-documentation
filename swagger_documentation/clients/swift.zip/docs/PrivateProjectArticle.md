# PrivateProjectArticle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**files** | [PublicFile] | List of up to 10 article files. | 
**embargoOptions** | [GroupEmbargoOptions] | List of embargo options | 
**customFields** | [CustomArticleField] | List of custom fields values | 
**accountId** | **Int64** | ID of the account owning the article | 
**downloadDisabled** | **Bool** | If true, downloading of files for this article is disabled | 
**authors** | [Author] | List of authors | 
**figshareUrl** | **String** | Article public url | 
**curationStatus** | **String** | Curation status of the article | 
**citation** | **String** | Article citation | 
**confidentialReason** | **String** | Confidentiality reason | 
**isConfidential** | **Bool** | Article Confidentiality | 
**size** | **Int64** | Article size | 
**funding** | **String** | Article funding | 
**fundingList** | [FundingInformation] | Full Article funding information | 
**tags** | **[String]** | List of article tags. Keywords can be used instead | 
**keywords** | **[String]** | List of article keywords. Tags can be used instead | 
**version** | **Int64** | Article version | 
**isMetadataRecord** | **Bool** | True if article has no files | 
**metadataReason** | **String** | Article metadata reason | 
**status** | **String** | Article status | 
**description** | **String** | Article description | 
**isEmbargoed** | **Bool** | True if article is embargoed | 
**isPublic** | **Bool** | True if article is published | 
**createdDate** | **String** | Date when article was created | 
**hasLinkedFile** | **Bool** | True if any files are linked to the article | 
**categories** | [Category] | List of categories selected for the article | 
**license** | [**License**](License.md) |  | 
**embargoTitle** | **String** | Title for embargo | 
**embargoReason** | **String** | Reason for embargo | 
**references** | **[String]** | List of references | 
**relatedMaterials** | [RelatedMaterial] | List of related materials; supersedes references and resource DOI/title. | [optional] 
**id** | **Int64** | Unique identifier for article | 
**title** | **String** | Title of article | 
**doi** | **String** | DOI | 
**handle** | **String** | Handle | 
**url** | **String** | Api endpoint for article | 
**urlPublicHtml** | **String** | Public site endpoint for article | 
**urlPublicApi** | **String** | Public Api endpoint for article | 
**urlPrivateHtml** | **String** | Private site endpoint for article | 
**urlPrivateApi** | **String** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) |  | 
**thumb** | **String** | Thumbnail image | 
**definedType** | **Int64** | Type of article identifier | 
**definedTypeName** | **String** | Name of the article type identifier | 
**resourceDoi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to ""]
**resourceTitle** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to ""]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


