# OtherAPI

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categoriesList**](OtherAPI.md#categorieslist) | **GET** /categories | Public Categories
[**fileDownload**](OtherAPI.md#filedownload) | **GET** /file/download/{file_id} | Public File Download
[**itemTypesList**](OtherAPI.md#itemtypeslist) | **GET** /item_types | Item Types
[**licensesList**](OtherAPI.md#licenseslist) | **GET** /licenses | Public Licenses
[**privateAccount**](OtherAPI.md#privateaccount) | **GET** /account | Private Account information
[**privateFundingSearch**](OtherAPI.md#privatefundingsearch) | **POST** /account/funding/search | Search Funding
[**privateLicensesList**](OtherAPI.md#privatelicenseslist) | **GET** /account/licenses | Private Account Licenses


# **categoriesList**
```swift
    open class func categoriesList(completion: @escaping (_ data: [CategoryList]?, _ error: Error?) -> Void)
```

Public Categories

Returns a list of public categories

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient


// Public Categories
OtherAPI.categoriesList() { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[CategoryList]**](CategoryList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **fileDownload**
```swift
    open class func fileDownload(fileId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Public File Download

Starts the download of a file

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let fileId = 987 // Int64 | 

// Public File Download
OtherAPI.fileDownload(fileId: fileId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **fileId** | **Int64** |  | 

### Return type

Void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **itemTypesList**
```swift
    open class func itemTypesList(groupId: Int64? = nil, completion: @escaping (_ data: [ItemType]?, _ error: Error?) -> Void)
```

Item Types

Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let groupId = 987 // Int64 | Identifier of the group for which the item types are requested (optional) (default to 0)

// Item Types
OtherAPI.itemTypesList(groupId: groupId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **Int64** | Identifier of the group for which the item types are requested | [optional] [default to 0]

### Return type

[**[ItemType]**](ItemType.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **licensesList**
```swift
    open class func licensesList(completion: @escaping (_ data: [License]?, _ error: Error?) -> Void)
```

Public Licenses

Returns a list of public licenses

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient


// Public Licenses
OtherAPI.licensesList() { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[License]**](License.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateAccount**
```swift
    open class func privateAccount(completion: @escaping (_ data: Account?, _ error: Error?) -> Void)
```

Private Account information

Account information for token/personal token

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient


// Private Account information
OtherAPI.privateAccount() { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateFundingSearch**
```swift
    open class func privateFundingSearch(search: FundingSearch? = nil, completion: @escaping (_ data: [FundingInformation]?, _ error: Error?) -> Void)
```

Search Funding

Search for fundings

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let search = FundingSearch(searchFor: "searchFor_example") // FundingSearch | Search Parameters (optional)

// Search Funding
OtherAPI.privateFundingSearch(search: search) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**FundingSearch**](FundingSearch.md) | Search Parameters | [optional] 

### Return type

[**[FundingInformation]**](FundingInformation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateLicensesList**
```swift
    open class func privateLicensesList(completion: @escaping (_ data: [License]?, _ error: Error?) -> Void)
```

Private Account Licenses

This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient


// Private Account Licenses
OtherAPI.privateLicensesList() { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[License]**](License.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

