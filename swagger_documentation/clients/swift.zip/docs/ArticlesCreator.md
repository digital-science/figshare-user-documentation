# ArticlesCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | **[Int64]** | List of article ids | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


