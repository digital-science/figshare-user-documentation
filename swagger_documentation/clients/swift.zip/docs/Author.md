# Author

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int64** | Author id | 
**fullName** | **String** | Author full name | 
**firstName** | **String** | Author first name | 
**lastName** | **String** | Author last name | 
**isActive** | **Bool** | True if author has published items | 
**urlName** | **String** | Author url name | 
**orcidId** | **String** | Author Orcid | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


