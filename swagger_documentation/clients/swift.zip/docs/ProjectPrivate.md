# ProjectPrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | **String** | Role inside this project | 
**storage** | **String** | Project storage type | 
**url** | **String** | Api endpoint | 
**id** | **Int64** | Project id | 
**title** | **String** | Project title | 
**createdDate** | **String** | Date when project was created | 
**modifiedDate** | **String** | Date when project was last modified | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


