# CustomArticleField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Custom  metadata name | 
**value** | **AnyCodable** | Custom metadata value (can be either a string or an array of strings) | 
**fieldType** | **String** | Custom field type | 
**settings** | **AnyCodable** | Settings for the custom field | 
**order** | **Int64** | Order of the custom field | 
**isMandatory** | **Bool** | Whether the field is mandatory or not | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


