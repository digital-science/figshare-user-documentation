# InstitutionsAPI

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**accountInstitutionCuration**](InstitutionsAPI.md#accountinstitutioncuration) | **GET** /account/institution/review/{curation_id} | Institution Curation Review
[**accountInstitutionCurations**](InstitutionsAPI.md#accountinstitutioncurations) | **GET** /account/institution/reviews | Institution Curation Reviews
[**customFieldsList**](InstitutionsAPI.md#customfieldslist) | **GET** /account/institution/custom_fields | Private account institution group custom fields
[**customFieldsUpload**](InstitutionsAPI.md#customfieldsupload) | **POST** /account/institution/custom_fields/{custom_field_id}/items/upload | Custom fields values files upload
[**getAccountInstitutionCurationComments**](InstitutionsAPI.md#getaccountinstitutioncurationcomments) | **GET** /account/institution/review/{curation_id}/comments | Institution Curation Review Comments
[**institutionArticles**](InstitutionsAPI.md#institutionarticles) | **GET** /institutions/{institution_string_id}/articles/filter-by | Public Institution Articles
[**institutionHrfeedUpload**](InstitutionsAPI.md#institutionhrfeedupload) | **POST** /institution/hrfeed/upload | Private Institution HRfeed Upload
[**postAccountInstitutionCurationComments**](InstitutionsAPI.md#postaccountinstitutioncurationcomments) | **POST** /account/institution/review/{curation_id}/comments | POST Institution Curation Review Comment
[**privateAccountInstitutionUser**](InstitutionsAPI.md#privateaccountinstitutionuser) | **GET** /account/institution/users/{account_id} | Private Account Institution User
[**privateCategoriesList**](InstitutionsAPI.md#privatecategorieslist) | **GET** /account/categories | Private Account Categories
[**privateGroupEmbargoOptionsDetails**](InstitutionsAPI.md#privategroupembargooptionsdetails) | **GET** /account/institution/groups/{group_id}/embargo_options | Private Account Institution Group Embargo Options
[**privateInstitutionAccount**](InstitutionsAPI.md#privateinstitutionaccount) | **GET** /account/institution/accounts/{account_id} | Private Institution Account information
[**privateInstitutionAccountGroupRoleDelete**](InstitutionsAPI.md#privateinstitutionaccountgrouproledelete) | **DELETE** /account/institution/roles/{account_id}/{group_id}/{role_id} | Delete Institution Account Group Role
[**privateInstitutionAccountGroupRoles**](InstitutionsAPI.md#privateinstitutionaccountgrouproles) | **GET** /account/institution/roles/{account_id} | List Institution Account Group Roles
[**privateInstitutionAccountGroupRolesCreate**](InstitutionsAPI.md#privateinstitutionaccountgrouprolescreate) | **POST** /account/institution/roles/{account_id} | Add Institution Account Group Roles
[**privateInstitutionAccountsCreate**](InstitutionsAPI.md#privateinstitutionaccountscreate) | **POST** /account/institution/accounts | Create new Institution Account
[**privateInstitutionAccountsList**](InstitutionsAPI.md#privateinstitutionaccountslist) | **GET** /account/institution/accounts | Private Account Institution Accounts
[**privateInstitutionAccountsSearch**](InstitutionsAPI.md#privateinstitutionaccountssearch) | **POST** /account/institution/accounts/search | Private Account Institution Accounts Search
[**privateInstitutionAccountsUpdate**](InstitutionsAPI.md#privateinstitutionaccountsupdate) | **PUT** /account/institution/accounts/{account_id} | Update Institution Account
[**privateInstitutionArticles**](InstitutionsAPI.md#privateinstitutionarticles) | **GET** /account/institution/articles | Private Institution Articles
[**privateInstitutionDetails**](InstitutionsAPI.md#privateinstitutiondetails) | **GET** /account/institution | Private Account Institutions
[**privateInstitutionEmbargoOptionsDetails**](InstitutionsAPI.md#privateinstitutionembargooptionsdetails) | **GET** /account/institution/embargo_options | Private Account Institution embargo options
[**privateInstitutionGroupsList**](InstitutionsAPI.md#privateinstitutiongroupslist) | **GET** /account/institution/groups | Private Account Institution Groups
[**privateInstitutionRolesList**](InstitutionsAPI.md#privateinstitutionroleslist) | **GET** /account/institution/roles | Private Account Institution Roles


# **accountInstitutionCuration**
```swift
    open class func accountInstitutionCuration(curationId: Int64, completion: @escaping (_ data: CurationDetail?, _ error: Error?) -> Void)
```

Institution Curation Review

Retrieve a certain curation review by its ID

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let curationId = 987 // Int64 | ID of the curation

// Institution Curation Review
InstitutionsAPI.accountInstitutionCuration(curationId: curationId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curationId** | **Int64** | ID of the curation | 

### Return type

[**CurationDetail**](CurationDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **accountInstitutionCurations**
```swift
    open class func accountInstitutionCurations(groupId: Int64? = nil, articleId: Int64? = nil, status: Status_accountInstitutionCurations? = nil, limit: Int64? = nil, offset: Int64? = nil, completion: @escaping (_ data: Curation?, _ error: Error?) -> Void)
```

Institution Curation Reviews

Retrieve a list of curation reviews for this institution

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let groupId = 987 // Int64 | Filter by the group ID (optional)
let articleId = 987 // Int64 | Retrieve the reviews for this article (optional)
let status = "status_example" // String | Filter by the status of the review (optional)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

// Institution Curation Reviews
InstitutionsAPI.accountInstitutionCurations(groupId: groupId, articleId: articleId, status: status, limit: limit, offset: offset) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **Int64** | Filter by the group ID | [optional] 
 **articleId** | **Int64** | Retrieve the reviews for this article | [optional] 
 **status** | **String** | Filter by the status of the review | [optional] 
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**Curation**](Curation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **customFieldsList**
```swift
    open class func customFieldsList(groupId: Int64? = nil, completion: @escaping (_ data: [ShortCustomField]?, _ error: Error?) -> Void)
```

Private account institution group custom fields

Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let groupId = 987 // Int64 | Group_id (optional)

// Private account institution group custom fields
InstitutionsAPI.customFieldsList(groupId: groupId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **Int64** | Group_id | [optional] 

### Return type

[**[ShortCustomField]**](ShortCustomField.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **customFieldsUpload**
```swift
    open class func customFieldsUpload(customFieldId: Int64, externalFile: URL? = nil, completion: @escaping (_ data: AnyCodable?, _ error: Error?) -> Void)
```

Custom fields values files upload

Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. More details in the <a href=\"#custom_fields\">Custom Fields section</a>

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let customFieldId = 987 // Int64 | Custom field identifier
let externalFile = URL(string: "https://example.com")! // URL | CSV file to be uploaded (optional)

// Custom fields values files upload
InstitutionsAPI.customFieldsUpload(customFieldId: customFieldId, externalFile: externalFile) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customFieldId** | **Int64** | Custom field identifier | 
 **externalFile** | **URL** | CSV file to be uploaded | [optional] 

### Return type

**AnyCodable**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **getAccountInstitutionCurationComments**
```swift
    open class func getAccountInstitutionCurationComments(curationId: Int64, limit: Int64? = nil, offset: Int64? = nil, completion: @escaping (_ data: CurationComment?, _ error: Error?) -> Void)
```

Institution Curation Review Comments

Retrieve a certain curation review's comments.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let curationId = 987 // Int64 | ID of the curation
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

// Institution Curation Review Comments
InstitutionsAPI.getAccountInstitutionCurationComments(curationId: curationId, limit: limit, offset: offset) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curationId** | **Int64** | ID of the curation | 
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**CurationComment**](CurationComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **institutionArticles**
```swift
    open class func institutionArticles(institutionStringId: String, resourceId: String, filename: String, completion: @escaping (_ data: [Article]?, _ error: Error?) -> Void)
```

Public Institution Articles

Returns a list of articles belonging to the institution

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let institutionStringId = "institutionStringId_example" // String | 
let resourceId = "resourceId_example" // String | 
let filename = "filename_example" // String | 

// Public Institution Articles
InstitutionsAPI.institutionArticles(institutionStringId: institutionStringId, resourceId: resourceId, filename: filename) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **institutionStringId** | **String** |  | 
 **resourceId** | **String** |  | 
 **filename** | **String** |  | 

### Return type

[**[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **institutionHrfeedUpload**
```swift
    open class func institutionHrfeedUpload(hrfeed: URL? = nil, completion: @escaping (_ data: ResponseMessage?, _ error: Error?) -> Void)
```

Private Institution HRfeed Upload

More info in the <a href=\"#hr_feed\">HR Feed section</a>

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let hrfeed = URL(string: "https://example.com")! // URL | You can find an example in the Hr Feed section (optional)

// Private Institution HRfeed Upload
InstitutionsAPI.institutionHrfeedUpload(hrfeed: hrfeed) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hrfeed** | **URL** | You can find an example in the Hr Feed section | [optional] 

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **postAccountInstitutionCurationComments**
```swift
    open class func postAccountInstitutionCurationComments(curationId: Int64, curationComment: CurationCommentCreate, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

POST Institution Curation Review Comment

Add a new comment to the review.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let curationId = 987 // Int64 | ID of the curation
let curationComment = CurationCommentCreate(text: "text_example") // CurationCommentCreate | The content/value of the comment.

// POST Institution Curation Review Comment
InstitutionsAPI.postAccountInstitutionCurationComments(curationId: curationId, curationComment: curationComment) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curationId** | **Int64** | ID of the curation | 
 **curationComment** | [**CurationCommentCreate**](CurationCommentCreate.md) | The content/value of the comment. | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateAccountInstitutionUser**
```swift
    open class func privateAccountInstitutionUser(accountId: Int64, completion: @escaping (_ data: User?, _ error: Error?) -> Void)
```

Private Account Institution User

Retrieve institution user information using the account_id

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let accountId = 987 // Int64 | Account identifier the user is associated to

// Private Account Institution User
InstitutionsAPI.privateAccountInstitutionUser(accountId: accountId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountId** | **Int64** | Account identifier the user is associated to | 

### Return type

[**User**](User.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateCategoriesList**
```swift
    open class func privateCategoriesList(completion: @escaping (_ data: [CategoryList]?, _ error: Error?) -> Void)
```

Private Account Categories

List institution categories (including parent Categories)

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient


// Private Account Categories
InstitutionsAPI.privateCategoriesList() { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[CategoryList]**](CategoryList.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateGroupEmbargoOptionsDetails**
```swift
    open class func privateGroupEmbargoOptionsDetails(groupId: Int64, completion: @escaping (_ data: [GroupEmbargoOptions]?, _ error: Error?) -> Void)
```

Private Account Institution Group Embargo Options

Account institution group embargo options details

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let groupId = 987 // Int64 | Group identifier

// Private Account Institution Group Embargo Options
InstitutionsAPI.privateGroupEmbargoOptionsDetails(groupId: groupId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **Int64** | Group identifier | 

### Return type

[**[GroupEmbargoOptions]**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionAccount**
```swift
    open class func privateInstitutionAccount(accountId: Int64, completion: @escaping (_ data: Account?, _ error: Error?) -> Void)
```

Private Institution Account information

Private Institution Account information

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let accountId = 987 // Int64 | Account identifier the user is associated to

// Private Institution Account information
InstitutionsAPI.privateInstitutionAccount(accountId: accountId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountId** | **Int64** | Account identifier the user is associated to | 

### Return type

[**Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionAccountGroupRoleDelete**
```swift
    open class func privateInstitutionAccountGroupRoleDelete(accountId: Int64, groupId: Int64, roleId: Int64, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete Institution Account Group Role

Delete Institution Account Group Role

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let accountId = 987 // Int64 | Account identifier for which to remove the role
let groupId = 987 // Int64 | Group identifier for which to remove the role
let roleId = 987 // Int64 | Role identifier

// Delete Institution Account Group Role
InstitutionsAPI.privateInstitutionAccountGroupRoleDelete(accountId: accountId, groupId: groupId, roleId: roleId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountId** | **Int64** | Account identifier for which to remove the role | 
 **groupId** | **Int64** | Group identifier for which to remove the role | 
 **roleId** | **Int64** | Role identifier | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionAccountGroupRoles**
```swift
    open class func privateInstitutionAccountGroupRoles(accountId: Int64, completion: @escaping (_ data: AnyCodable?, _ error: Error?) -> Void)
```

List Institution Account Group Roles

List Institution Account Group Roles

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let accountId = 987 // Int64 | Account identifier the user is associated to

// List Institution Account Group Roles
InstitutionsAPI.privateInstitutionAccountGroupRoles(accountId: accountId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountId** | **Int64** | Account identifier the user is associated to | 

### Return type

**AnyCodable**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionAccountGroupRolesCreate**
```swift
    open class func privateInstitutionAccountGroupRolesCreate(accountId: Int64, account: AnyCodable, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Add Institution Account Group Roles

Add Institution Account Group Roles

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let accountId = 987 // Int64 | Account identifier the user is associated to
let account = "TODO" // AnyCodable | Account description

// Add Institution Account Group Roles
InstitutionsAPI.privateInstitutionAccountGroupRolesCreate(accountId: accountId, account: account) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountId** | **Int64** | Account identifier the user is associated to | 
 **account** | **AnyCodable** | Account description | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionAccountsCreate**
```swift
    open class func privateInstitutionAccountsCreate(account: AccountCreate, completion: @escaping (_ data: AccountCreateResponse?, _ error: Error?) -> Void)
```

Create new Institution Account

Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let account = AccountCreate(email: "email_example", firstName: "firstName_example", lastName: "lastName_example", groupId: 123, institutionUserId: "institutionUserId_example", symplecticUserId: "symplecticUserId_example", quota: 123, isActive: false) // AccountCreate | Account description

// Create new Institution Account
InstitutionsAPI.privateInstitutionAccountsCreate(account: account) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account** | [**AccountCreate**](AccountCreate.md) | Account description | 

### Return type

[**AccountCreateResponse**](AccountCreateResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionAccountsList**
```swift
    open class func privateInstitutionAccountsList(page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, isActive: Int64? = nil, institutionUserId: String? = nil, email: String? = nil, idLte: Int64? = nil, idGte: Int64? = nil, completion: @escaping (_ data: [ShortAccount]?, _ error: Error?) -> Void)
```

Private Account Institution Accounts

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
let isActive = 987 // Int64 | Filter by active status (optional)
let institutionUserId = "institutionUserId_example" // String | Filter by institution_user_id (optional)
let email = "email_example" // String | Filter by email (optional)
let idLte = 987 // Int64 | Retrieve accounts with an ID lower or equal to the specified value (optional)
let idGte = 987 // Int64 | Retrieve accounts with an ID greater or equal to the specified value (optional)

// Private Account Institution Accounts
InstitutionsAPI.privateInstitutionAccountsList(page: page, pageSize: pageSize, limit: limit, offset: offset, isActive: isActive, institutionUserId: institutionUserId, email: email, idLte: idLte, idGte: idGte) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **isActive** | **Int64** | Filter by active status | [optional] 
 **institutionUserId** | **String** | Filter by institution_user_id | [optional] 
 **email** | **String** | Filter by email | [optional] 
 **idLte** | **Int64** | Retrieve accounts with an ID lower or equal to the specified value | [optional] 
 **idGte** | **Int64** | Retrieve accounts with an ID greater or equal to the specified value | [optional] 

### Return type

[**[ShortAccount]**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionAccountsSearch**
```swift
    open class func privateInstitutionAccountsSearch(search: InstitutionAccountsSearch, completion: @escaping (_ data: [ShortAccount]?, _ error: Error?) -> Void)
```

Private Account Institution Accounts Search

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let search = InstitutionAccountsSearch(searchFor: "searchFor_example", isActive: 123, page: 123, pageSize: 123, limit: 123, offset: 123, institutionUserId: "institutionUserId_example", email: "email_example") // InstitutionAccountsSearch | Search Parameters

// Private Account Institution Accounts Search
InstitutionsAPI.privateInstitutionAccountsSearch(search: search) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**InstitutionAccountsSearch**](InstitutionAccountsSearch.md) | Search Parameters | 

### Return type

[**[ShortAccount]**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionAccountsUpdate**
```swift
    open class func privateInstitutionAccountsUpdate(accountId: Int64, account: AccountUpdate, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Update Institution Account

Update Institution Account

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let accountId = 987 // Int64 | Account identifier the user is associated to
let account = AccountUpdate(groupId: 123, isActive: false) // AccountUpdate | Account description

// Update Institution Account
InstitutionsAPI.privateInstitutionAccountsUpdate(accountId: accountId, account: account) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountId** | **Int64** | Account identifier the user is associated to | 
 **account** | [**AccountUpdate**](AccountUpdate.md) | Account description | 

### Return type

Void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionArticles**
```swift
    open class func privateInstitutionArticles(page: Int64? = nil, pageSize: Int64? = nil, limit: Int64? = nil, offset: Int64? = nil, order: Order_privateInstitutionArticles? = nil, orderDirection: OrderDirection_privateInstitutionArticles? = nil, publishedSince: String? = nil, modifiedSince: String? = nil, status: Int64? = nil, resourceDoi: String? = nil, itemType: Int64? = nil, group: Int64? = nil, completion: @escaping (_ data: [Article]?, _ error: Error?) -> Void)
```

Private Institution Articles

Get Articles from own institution. User must be administrator of the institution

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let page = 987 // Int64 | Page number. Used for pagination with page_size (optional)
let pageSize = 987 // Int64 | The number of results included on a page. Used for pagination with page (optional) (default to 10)
let limit = 987 // Int64 | Number of results included on a page. Used for pagination with query (optional)
let offset = 987 // Int64 | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
let order = "order_example" // String | The field by which to order. Default varies by endpoint/resource. (optional) (default to .publishedDate)
let orderDirection = "orderDirection_example" // String |  (optional) (default to .desc)
let publishedSince = "publishedSince_example" // String | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
let modifiedSince = "modifiedSince_example" // String | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
let status = 987 // Int64 | only return collections with this status (optional)
let resourceDoi = "resourceDoi_example" // String | only return collections with this resource_doi (optional)
let itemType = 987 // Int64 | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional)
let group = 987 // Int64 | only return articles from this group (optional)

// Private Institution Articles
InstitutionsAPI.privateInstitutionArticles(page: page, pageSize: pageSize, limit: limit, offset: offset, order: order, orderDirection: orderDirection, publishedSince: publishedSince, modifiedSince: modifiedSince, status: status, resourceDoi: resourceDoi, itemType: itemType, group: group) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **Int64** | Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **Int64** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **Int64** | Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **Int64** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **String** | The field by which to order. Default varies by endpoint/resource. | [optional] [default to .publishedDate]
 **orderDirection** | **String** |  | [optional] [default to .desc]
 **publishedSince** | **String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **modifiedSince** | **String** | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **status** | **Int64** | only return collections with this status | [optional] 
 **resourceDoi** | **String** | only return collections with this resource_doi | [optional] 
 **itemType** | **Int64** | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
 **group** | **Int64** | only return articles from this group | [optional] 

### Return type

[**[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionDetails**
```swift
    open class func privateInstitutionDetails(completion: @escaping (_ data: Institution?, _ error: Error?) -> Void)
```

Private Account Institutions

Account institution details

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient


// Private Account Institutions
InstitutionsAPI.privateInstitutionDetails() { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Institution**](Institution.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionEmbargoOptionsDetails**
```swift
    open class func privateInstitutionEmbargoOptionsDetails(completion: @escaping (_ data: [GroupEmbargoOptions]?, _ error: Error?) -> Void)
```

Private Account Institution embargo options

Account institution embargo options details

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient


// Private Account Institution embargo options
InstitutionsAPI.privateInstitutionEmbargoOptionsDetails() { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[GroupEmbargoOptions]**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionGroupsList**
```swift
    open class func privateInstitutionGroupsList(completion: @escaping (_ data: [Group]?, _ error: Error?) -> Void)
```

Private Account Institution Groups

Returns the groups for which the account has administrative privileges (assigned and inherited).

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient


// Private Account Institution Groups
InstitutionsAPI.privateInstitutionGroupsList() { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[Group]**](Group.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **privateInstitutionRolesList**
```swift
    open class func privateInstitutionRolesList(completion: @escaping (_ data: [Role]?, _ error: Error?) -> Void)
```

Private Account Institution Roles

Returns the roles available for groups and the institution group.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient


// Private Account Institution Roles
InstitutionsAPI.privateInstitutionRolesList() { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[Role]**](Role.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

