# ArticleVersionUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supplementaryFields** | **[AnyCodable]** | List of supplementary fields to be associated with the article version | [optional] 
**internalMetadata** | **AnyCodable** | List of supplementary fields to be associated with the article version | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


