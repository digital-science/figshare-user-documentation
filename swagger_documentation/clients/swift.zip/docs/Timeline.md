# Timeline

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**firstOnline** | **String** | Online posted date | [optional] 
**publisherPublication** | **String** | Publish date | [optional] 
**publisherAcceptance** | **String** | Date when the item was accepted for publication | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


