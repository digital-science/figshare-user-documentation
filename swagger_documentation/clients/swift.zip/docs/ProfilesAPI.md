# ProfilesAPI

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateUserProfile**](ProfilesAPI.md#updateuserprofile) | **PUT** /account/profile | Update public profile
[**updateUserProfilePicture**](ProfilesAPI.md#updateuserprofilepicture) | **POST** /account/profile/{user_id}/picture | Update public profile picture


# **updateUserProfile**
```swift
    open class func updateUserProfile(userProfileData: ProfileUpdateData, userId: Int64? = nil, institutionUserId: String? = nil, completion: @escaping (_ data: AnyCodable?, _ error: Error?) -> Void)
```

Update public profile

Updates the fields of the user's public profile.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let userProfileData = ProfileUpdateData(firstName: "firstName_example", lastName: "lastName_example", orcid: "orcid_example", jobTitle: "jobTitle_example", fieldsOfInterest: [123], fieldsOfInterestBySourceId: ["fieldsOfInterestBySourceId_example"], location: "location_example", facebook: "facebook_example", x: "x_example", linkedin: "linkedin_example", bio: "bio_example", personalProfiles: [ProfileUpdateData_personal_profiles_inner(label: "label_example", url: "url_example")]) // ProfileUpdateData | 
let userId = 987 // Int64 | User ID (optional)
let institutionUserId = "institutionUserId_example" // String | Institutional user ID (optional)

// Update public profile
ProfilesAPI.updateUserProfile(userProfileData: userProfileData, userId: userId, institutionUserId: institutionUserId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userProfileData** | [**ProfileUpdateData**](ProfileUpdateData.md) |  | 
 **userId** | **Int64** | User ID | [optional] 
 **institutionUserId** | **String** | Institutional user ID | [optional] 

### Return type

**AnyCodable**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **updateUserProfilePicture**
```swift
    open class func updateUserProfilePicture(userId: Int64, profilePicture: URL, completion: @escaping (_ data: AnyCodable?, _ error: Error?) -> Void)
```

Update public profile picture

Updates the profile picture of the user's public profile.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let userId = 987 // Int64 | User ID
let profilePicture = URL(string: "https://example.com")! // URL | User profile picture

// Update public profile picture
ProfilesAPI.updateUserProfilePicture(userId: userId, profilePicture: profilePicture) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **Int64** | User ID | 
 **profilePicture** | **URL** | User profile picture | 

### Return type

**AnyCodable**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

