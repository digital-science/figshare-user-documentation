# UploadFilePart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**partNo** | **Int64** | File part id | [optional] 
**startOffset** | **Int64** | Indexes on byte range. zero-based and inclusive | [optional] 
**endOffset** | **Int64** | Indexes on byte range. zero-based and inclusive | [optional] 
**status** | **String** | part status | [optional] 
**locked** | **Bool** | When a part is being uploaded it is being locked, by setting the locked flag to true. No changes/uploads can happen on this part from other requests. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


