# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int64** | User id | 
**firstName** | **String** | First Name | 
**lastName** | **String** | Last Name | 
**name** | **String** | Full Name | 
**isActive** | **Bool** | Account activity status | 
**urlName** | **String** | Name that appears in website url | 
**isPublic** | **Bool** | Account public status | 
**jobTitle** | **String** | User Job title | 
**orcidId** | **String** | Orcid associated to this User | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


