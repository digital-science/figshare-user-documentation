{-# LANGUAGE CPP #-}
{-# OPTIONS_GHC -fno-warn-unused-imports -fno-warn-unused-matches #-}

module Instances where

import Figshare.Model
import Figshare.Core

import qualified Data.Aeson as A
import qualified Data.ByteString.Lazy as BL
import qualified Data.HashMap.Strict as HM
import qualified Data.Set as Set
import qualified Data.Text as T
import qualified Data.Time as TI
import qualified Data.Vector as V
import Data.String (fromString)

import Control.Monad
import Data.Char (isSpace)
import Data.List (sort)
import Test.QuickCheck

import ApproxEq

instance Arbitrary T.Text where
  arbitrary = T.pack <$> arbitrary

instance Arbitrary TI.Day where
  arbitrary = TI.ModifiedJulianDay . (2000 +) <$> arbitrary
  shrink = (TI.ModifiedJulianDay <$>) . shrink . TI.toModifiedJulianDay

instance Arbitrary TI.UTCTime where
  arbitrary =
    TI.UTCTime <$> arbitrary <*> (TI.secondsToDiffTime <$> choose (0, 86401))

instance Arbitrary BL.ByteString where
    arbitrary = BL.pack <$> arbitrary
    shrink xs = BL.pack <$> shrink (BL.unpack xs)

instance Arbitrary ByteArray where
    arbitrary = ByteArray <$> arbitrary
    shrink (ByteArray xs) = ByteArray <$> shrink xs

instance Arbitrary Binary where
    arbitrary = Binary <$> arbitrary
    shrink (Binary xs) = Binary <$> shrink xs

instance Arbitrary DateTime where
    arbitrary = DateTime <$> arbitrary
    shrink (DateTime xs) = DateTime <$> shrink xs

instance Arbitrary Date where
    arbitrary = Date <$> arbitrary
    shrink (Date xs) = Date <$> shrink xs

#if MIN_VERSION_aeson(2,0,0)
#else
-- | A naive Arbitrary instance for A.Value:
instance Arbitrary A.Value where
  arbitrary = arbitraryValue
#endif

arbitraryValue :: Gen A.Value
arbitraryValue =
  frequency [(3, simpleTypes), (1, arrayTypes), (1, objectTypes)]
    where
      simpleTypes :: Gen A.Value
      simpleTypes =
        frequency
          [ (1, return A.Null)
          , (2, liftM A.Bool (arbitrary :: Gen Bool))
          , (2, liftM (A.Number . fromIntegral) (arbitrary :: Gen Int))
          , (2, liftM (A.String . T.pack) (arbitrary :: Gen String))
          ]
      mapF (k, v) = (fromString k, v)
      simpleAndArrays = frequency [(1, sized sizedArray), (4, simpleTypes)]
      arrayTypes = sized sizedArray
      objectTypes = sized sizedObject
      sizedArray n = liftM (A.Array . V.fromList) $ replicateM n simpleTypes
      sizedObject n =
        liftM (A.object . map mapF) $
        replicateM n $ (,) <$> (arbitrary :: Gen String) <*> simpleAndArrays

-- | Checks if a given list has no duplicates in _O(n log n)_.
hasNoDups
  :: (Ord a)
  => [a] -> Bool
hasNoDups = go Set.empty
  where
    go _ [] = True
    go s (x:xs)
      | s' <- Set.insert x s
      , Set.size s' > Set.size s = go s' xs
      | otherwise = False

instance ApproxEq TI.Day where
  (=~) = (==)

arbitraryReduced :: Arbitrary a => Int -> Gen a
arbitraryReduced n = resize (n `div` 2) arbitrary

arbitraryReducedMaybe :: Arbitrary a => Int -> Gen (Maybe a)
arbitraryReducedMaybe 0 = elements [Nothing]
arbitraryReducedMaybe n = arbitraryReduced n

arbitraryReducedMaybeValue :: Int -> Gen (Maybe A.Value)
arbitraryReducedMaybeValue 0 = elements [Nothing]
arbitraryReducedMaybeValue n = do
  generated <- arbitraryReduced n
  if generated == Just A.Null
    then return Nothing
    else return generated

-- * Models

instance Arbitrary Account where
  arbitrary = sized genAccount

genAccount :: Int -> Gen Account
genAccount n =
  Account
    <$> arbitrary -- accountId :: Integer
    <*> arbitrary -- accountFirstName :: Text
    <*> arbitrary -- accountLastName :: Text
    <*> arbitrary -- accountUsedQuotaPrivate :: Integer
    <*> arbitrary -- accountModifiedDate :: Text
    <*> arbitrary -- accountUsedQuota :: Integer
    <*> arbitrary -- accountCreatedDate :: Text
    <*> arbitrary -- accountQuota :: Integer
    <*> arbitrary -- accountGroupId :: Integer
    <*> arbitrary -- accountInstitutionUserId :: Text
    <*> arbitrary -- accountInstitutionId :: Integer
    <*> arbitrary -- accountEmail :: Text
    <*> arbitrary -- accountUsedQuotaPublic :: Integer
    <*> arbitrary -- accountPendingQuotaRequest :: Bool
    <*> arbitrary -- accountActive :: Integer
    <*> arbitrary -- accountMaximumFileSize :: Integer
    <*> arbitrary -- accountUserId :: Integer
    <*> arbitrary -- accountOrcidId :: Text
    <*> arbitrary -- accountSymplecticUserId :: Text
  
instance Arbitrary AccountCreate where
  arbitrary = sized genAccountCreate

genAccountCreate :: Int -> Gen AccountCreate
genAccountCreate n =
  AccountCreate
    <$> arbitrary -- accountCreateEmail :: Text
    <*> arbitraryReducedMaybe n -- accountCreateFirstName :: Maybe Text
    <*> arbitrary -- accountCreateLastName :: Text
    <*> arbitraryReducedMaybe n -- accountCreateGroupId :: Maybe Integer
    <*> arbitraryReducedMaybe n -- accountCreateInstitutionUserId :: Maybe Text
    <*> arbitraryReducedMaybe n -- accountCreateSymplecticUserId :: Maybe Text
    <*> arbitraryReducedMaybe n -- accountCreateQuota :: Maybe Integer
    <*> arbitraryReducedMaybe n -- accountCreateIsActive :: Maybe Bool
  
instance Arbitrary AccountCreateResponse where
  arbitrary = sized genAccountCreateResponse

genAccountCreateResponse :: Int -> Gen AccountCreateResponse
genAccountCreateResponse n =
  AccountCreateResponse
    <$> arbitrary -- accountCreateResponseAccountId :: Integer
  
instance Arbitrary AccountReport where
  arbitrary = sized genAccountReport

genAccountReport :: Int -> Gen AccountReport
genAccountReport n =
  AccountReport
    <$> arbitrary -- accountReportId :: Integer
    <*> arbitrary -- accountReportAccountId :: Integer
    <*> arbitrary -- accountReportCreatedDate :: Text
    <*> arbitrary -- accountReportStatus :: E'Status
    <*> arbitrary -- accountReportDownloadUrl :: Text
    <*> arbitrary -- accountReportGroupId :: Integer
  
instance Arbitrary AccountUpdate where
  arbitrary = sized genAccountUpdate

genAccountUpdate :: Int -> Gen AccountUpdate
genAccountUpdate n =
  AccountUpdate
    <$> arbitrary -- accountUpdateGroupId :: Integer
    <*> arbitrary -- accountUpdateIsActive :: Bool
  
instance Arbitrary Article where
  arbitrary = sized genArticle

genArticle :: Int -> Gen Article
genArticle n =
  Article
    <$> arbitrary -- articleId :: Integer
    <*> arbitrary -- articleTitle :: Text
    <*> arbitrary -- articleDoi :: Text
    <*> arbitrary -- articleHandle :: Text
    <*> arbitrary -- articleUrl :: Text
    <*> arbitrary -- articleUrlPublicHtml :: Text
    <*> arbitrary -- articleUrlPublicApi :: Text
    <*> arbitrary -- articleUrlPrivateHtml :: Text
    <*> arbitrary -- articleUrlPrivateApi :: Text
    <*> arbitraryReduced n -- articleTimeline :: Timeline
    <*> arbitrary -- articleThumb :: Text
    <*> arbitrary -- articleDefinedType :: Integer
    <*> arbitrary -- articleDefinedTypeName :: Text
    <*> arbitrary -- articleResourceDoi :: Text
    <*> arbitrary -- articleResourceTitle :: Text
    <*> arbitrary -- articleCreatedDate :: Text
  
instance Arbitrary ArticleComplete where
  arbitrary = sized genArticleComplete

genArticleComplete :: Int -> Gen ArticleComplete
genArticleComplete n =
  ArticleComplete
    <$> arbitrary -- articleCompleteFigshareUrl :: Text
    <*> arbitrary -- articleCompleteDownloadDisabled :: Bool
    <*> arbitraryReduced n -- articleCompleteFiles :: [PublicFile]
    <*> arbitraryReduced n -- articleCompleteFolderStructure :: A.Value
    <*> arbitraryReduced n -- articleCompleteAuthors :: [Author]
    <*> arbitraryReduced n -- articleCompleteCustomFields :: [CustomArticleField]
    <*> arbitraryReduced n -- articleCompleteEmbargoOptions :: [GroupEmbargoOptions]
    <*> arbitrary -- articleCompleteCitation :: Text
    <*> arbitrary -- articleCompleteConfidentialReason :: Text
    <*> arbitrary -- articleCompleteIsConfidential :: Bool
    <*> arbitrary -- articleCompleteSize :: Integer
    <*> arbitrary -- articleCompleteFunding :: Text
    <*> arbitraryReduced n -- articleCompleteFundingList :: [FundingInformation]
    <*> arbitrary -- articleCompleteTags :: [Text]
    <*> arbitrary -- articleCompleteKeywords :: [Text]
    <*> arbitrary -- articleCompleteVersion :: Integer
    <*> arbitrary -- articleCompleteIsMetadataRecord :: Bool
    <*> arbitrary -- articleCompleteMetadataReason :: Text
    <*> arbitrary -- articleCompleteStatus :: Text
    <*> arbitrary -- articleCompleteDescription :: Text
    <*> arbitrary -- articleCompleteIsEmbargoed :: Bool
    <*> arbitrary -- articleCompleteIsPublic :: Bool
    <*> arbitrary -- articleCompleteCreatedDate :: Text
    <*> arbitrary -- articleCompleteHasLinkedFile :: Bool
    <*> arbitraryReduced n -- articleCompleteCategories :: [Category]
    <*> arbitraryReduced n -- articleCompleteLicense :: License
    <*> arbitrary -- articleCompleteEmbargoTitle :: Text
    <*> arbitrary -- articleCompleteEmbargoReason :: Text
    <*> arbitrary -- articleCompleteReferences :: [Text]
    <*> arbitraryReducedMaybe n -- articleCompleteRelatedMaterials :: Maybe [RelatedMaterial]
    <*> arbitrary -- articleCompleteId :: Integer
    <*> arbitrary -- articleCompleteTitle :: Text
    <*> arbitrary -- articleCompleteDoi :: Text
    <*> arbitrary -- articleCompleteHandle :: Text
    <*> arbitrary -- articleCompleteUrl :: Text
    <*> arbitrary -- articleCompleteUrlPublicHtml :: Text
    <*> arbitrary -- articleCompleteUrlPublicApi :: Text
    <*> arbitrary -- articleCompleteUrlPrivateHtml :: Text
    <*> arbitrary -- articleCompleteUrlPrivateApi :: Text
    <*> arbitraryReduced n -- articleCompleteTimeline :: Timeline
    <*> arbitrary -- articleCompleteThumb :: Text
    <*> arbitrary -- articleCompleteDefinedType :: Integer
    <*> arbitrary -- articleCompleteDefinedTypeName :: Text
    <*> arbitrary -- articleCompleteResourceDoi :: Text
    <*> arbitrary -- articleCompleteResourceTitle :: Text
  
instance Arbitrary ArticleCompletePrivate where
  arbitrary = sized genArticleCompletePrivate

genArticleCompletePrivate :: Int -> Gen ArticleCompletePrivate
genArticleCompletePrivate n =
  ArticleCompletePrivate
    <$> arbitrary -- articleCompletePrivateAccountId :: Integer
    <*> arbitrary -- articleCompletePrivateCurationStatus :: Text
    <*> arbitrary -- articleCompletePrivateFigshareUrl :: Text
    <*> arbitrary -- articleCompletePrivateDownloadDisabled :: Bool
    <*> arbitraryReduced n -- articleCompletePrivateFiles :: [PublicFile]
    <*> arbitraryReduced n -- articleCompletePrivateFolderStructure :: A.Value
    <*> arbitraryReduced n -- articleCompletePrivateAuthors :: [Author]
    <*> arbitraryReduced n -- articleCompletePrivateCustomFields :: [CustomArticleField]
    <*> arbitraryReduced n -- articleCompletePrivateEmbargoOptions :: [GroupEmbargoOptions]
    <*> arbitrary -- articleCompletePrivateCitation :: Text
    <*> arbitrary -- articleCompletePrivateConfidentialReason :: Text
    <*> arbitrary -- articleCompletePrivateIsConfidential :: Bool
    <*> arbitrary -- articleCompletePrivateSize :: Integer
    <*> arbitrary -- articleCompletePrivateFunding :: Text
    <*> arbitraryReduced n -- articleCompletePrivateFundingList :: [FundingInformation]
    <*> arbitrary -- articleCompletePrivateTags :: [Text]
    <*> arbitrary -- articleCompletePrivateKeywords :: [Text]
    <*> arbitrary -- articleCompletePrivateVersion :: Integer
    <*> arbitrary -- articleCompletePrivateIsMetadataRecord :: Bool
    <*> arbitrary -- articleCompletePrivateMetadataReason :: Text
    <*> arbitrary -- articleCompletePrivateStatus :: Text
    <*> arbitrary -- articleCompletePrivateDescription :: Text
    <*> arbitrary -- articleCompletePrivateIsEmbargoed :: Bool
    <*> arbitrary -- articleCompletePrivateIsPublic :: Bool
    <*> arbitrary -- articleCompletePrivateCreatedDate :: Text
    <*> arbitrary -- articleCompletePrivateHasLinkedFile :: Bool
    <*> arbitraryReduced n -- articleCompletePrivateCategories :: [Category]
    <*> arbitraryReduced n -- articleCompletePrivateLicense :: License
    <*> arbitrary -- articleCompletePrivateEmbargoTitle :: Text
    <*> arbitrary -- articleCompletePrivateEmbargoReason :: Text
    <*> arbitrary -- articleCompletePrivateReferences :: [Text]
    <*> arbitraryReducedMaybe n -- articleCompletePrivateRelatedMaterials :: Maybe [RelatedMaterial]
    <*> arbitrary -- articleCompletePrivateId :: Integer
    <*> arbitrary -- articleCompletePrivateTitle :: Text
    <*> arbitrary -- articleCompletePrivateDoi :: Text
    <*> arbitrary -- articleCompletePrivateHandle :: Text
    <*> arbitrary -- articleCompletePrivateUrl :: Text
    <*> arbitrary -- articleCompletePrivateUrlPublicHtml :: Text
    <*> arbitrary -- articleCompletePrivateUrlPublicApi :: Text
    <*> arbitrary -- articleCompletePrivateUrlPrivateHtml :: Text
    <*> arbitrary -- articleCompletePrivateUrlPrivateApi :: Text
    <*> arbitraryReduced n -- articleCompletePrivateTimeline :: Timeline
    <*> arbitrary -- articleCompletePrivateThumb :: Text
    <*> arbitrary -- articleCompletePrivateDefinedType :: Integer
    <*> arbitrary -- articleCompletePrivateDefinedTypeName :: Text
    <*> arbitrary -- articleCompletePrivateResourceDoi :: Text
    <*> arbitrary -- articleCompletePrivateResourceTitle :: Text
  
instance Arbitrary ArticleConfidentiality where
  arbitrary = sized genArticleConfidentiality

genArticleConfidentiality :: Int -> Gen ArticleConfidentiality
genArticleConfidentiality n =
  ArticleConfidentiality
    <$> arbitrary -- articleConfidentialityIsConfidential :: Bool
    <*> arbitrary -- articleConfidentialityReason :: Text
  
instance Arbitrary ArticleCreate where
  arbitrary = sized genArticleCreate

genArticleCreate :: Int -> Gen ArticleCreate
genArticleCreate n =
  ArticleCreate
    <$> arbitrary -- articleCreateTitle :: Text
    <*> arbitraryReducedMaybe n -- articleCreateDescription :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleCreateIsMetadataRecord :: Maybe Bool
    <*> arbitraryReducedMaybe n -- articleCreateMetadataReason :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleCreateTags :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- articleCreateKeywords :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- articleCreateReferences :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- articleCreateRelatedMaterials :: Maybe [RelatedMaterial]
    <*> arbitraryReducedMaybe n -- articleCreateCategories :: Maybe [Integer]
    <*> arbitraryReducedMaybe n -- articleCreateCategoriesBySourceId :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- articleCreateAuthors :: Maybe [A.Value]
    <*> arbitraryReducedMaybeValue n -- articleCreateCustomFields :: Maybe A.Value
    <*> arbitraryReducedMaybe n -- articleCreateCustomFieldsList :: Maybe [CustomArticleFieldAdd]
    <*> arbitraryReducedMaybe n -- articleCreateDefinedType :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleCreateFunding :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleCreateFundingList :: Maybe [FundingCreate]
    <*> arbitraryReducedMaybe n -- articleCreateLicense :: Maybe Integer
    <*> arbitraryReducedMaybe n -- articleCreateDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleCreateHandle :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleCreateResourceDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleCreateResourceTitle :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleCreateTimeline :: Maybe TimelineUpdate
    <*> arbitraryReducedMaybe n -- articleCreateGroupId :: Maybe Integer
  
instance Arbitrary ArticleDOI where
  arbitrary = sized genArticleDOI

genArticleDOI :: Int -> Gen ArticleDOI
genArticleDOI n =
  ArticleDOI
    <$> arbitrary -- articleDOIDoi :: Text
  
instance Arbitrary ArticleEmbargo where
  arbitrary = sized genArticleEmbargo

genArticleEmbargo :: Int -> Gen ArticleEmbargo
genArticleEmbargo n =
  ArticleEmbargo
    <$> arbitrary -- articleEmbargoIsEmbargoed :: Bool
    <*> arbitrary -- articleEmbargoEmbargoTitle :: Text
    <*> arbitrary -- articleEmbargoEmbargoReason :: Text
    <*> arbitraryReduced n -- articleEmbargoEmbargoOptions :: [A.Value]
  
instance Arbitrary ArticleEmbargoUpdater where
  arbitrary = sized genArticleEmbargoUpdater

genArticleEmbargoUpdater :: Int -> Gen ArticleEmbargoUpdater
genArticleEmbargoUpdater n =
  ArticleEmbargoUpdater
    <$> arbitrary -- articleEmbargoUpdaterIsEmbargoed :: Bool
    <*> arbitrary -- articleEmbargoUpdaterEmbargoDate :: Text
    <*> arbitrary -- articleEmbargoUpdaterEmbargoType :: E'EmbargoType
    <*> arbitraryReducedMaybe n -- articleEmbargoUpdaterEmbargoTitle :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleEmbargoUpdaterEmbargoReason :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleEmbargoUpdaterEmbargoOptions :: Maybe [A.Value]
  
instance Arbitrary ArticleHandle where
  arbitrary = sized genArticleHandle

genArticleHandle :: Int -> Gen ArticleHandle
genArticleHandle n =
  ArticleHandle
    <$> arbitrary -- articleHandleHandle :: Text
  
instance Arbitrary ArticleProjectCreate where
  arbitrary = sized genArticleProjectCreate

genArticleProjectCreate :: Int -> Gen ArticleProjectCreate
genArticleProjectCreate n =
  ArticleProjectCreate
    <$> arbitrary -- articleProjectCreateTitle :: Text
    <*> arbitraryReducedMaybe n -- articleProjectCreateDescription :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleProjectCreateTags :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- articleProjectCreateKeywords :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- articleProjectCreateReferences :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- articleProjectCreateRelatedMaterials :: Maybe [RelatedMaterial]
    <*> arbitraryReducedMaybe n -- articleProjectCreateCategories :: Maybe [Integer]
    <*> arbitraryReducedMaybe n -- articleProjectCreateCategoriesBySourceId :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- articleProjectCreateAuthors :: Maybe [A.Value]
    <*> arbitraryReducedMaybeValue n -- articleProjectCreateCustomFields :: Maybe A.Value
    <*> arbitraryReducedMaybe n -- articleProjectCreateCustomFieldsList :: Maybe [CustomArticleFieldAdd]
    <*> arbitraryReducedMaybe n -- articleProjectCreateDefinedType :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleProjectCreateFunding :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleProjectCreateFundingList :: Maybe [FundingCreate]
    <*> arbitraryReducedMaybe n -- articleProjectCreateLicense :: Maybe Integer
    <*> arbitraryReducedMaybe n -- articleProjectCreateDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleProjectCreateHandle :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleProjectCreateResourceDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleProjectCreateResourceTitle :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleProjectCreateTimeline :: Maybe TimelineUpdate
  
instance Arbitrary ArticleSearch where
  arbitrary = sized genArticleSearch

genArticleSearch :: Int -> Gen ArticleSearch
genArticleSearch n =
  ArticleSearch
    <$> arbitraryReducedMaybe n -- articleSearchResourceDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleSearchItemType :: Maybe Integer
    <*> arbitraryReducedMaybe n -- articleSearchDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleSearchHandle :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleSearchProjectId :: Maybe Integer
    <*> arbitraryReducedMaybe n -- articleSearchOrder :: Maybe E'Order
    <*> arbitraryReducedMaybe n -- articleSearchSearchFor :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleSearchPage :: Maybe Integer
    <*> arbitraryReducedMaybe n -- articleSearchPageSize :: Maybe Integer
    <*> arbitraryReducedMaybe n -- articleSearchLimit :: Maybe Integer
    <*> arbitraryReducedMaybe n -- articleSearchOffset :: Maybe Integer
    <*> arbitraryReducedMaybe n -- articleSearchOrderDirection :: Maybe E'OrderDirection
    <*> arbitraryReducedMaybe n -- articleSearchInstitution :: Maybe Int
    <*> arbitraryReducedMaybe n -- articleSearchPublishedSince :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleSearchModifiedSince :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleSearchGroup :: Maybe Int
  
instance Arbitrary ArticleUnpublishData where
  arbitrary = sized genArticleUnpublishData

genArticleUnpublishData :: Int -> Gen ArticleUnpublishData
genArticleUnpublishData n =
  ArticleUnpublishData
    <$> arbitrary -- articleUnpublishDataReason :: Text
  
instance Arbitrary ArticleUpdate where
  arbitrary = sized genArticleUpdate

genArticleUpdate :: Int -> Gen ArticleUpdate
genArticleUpdate n =
  ArticleUpdate
    <$> arbitraryReducedMaybe n -- articleUpdateTitle :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleUpdateDescription :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleUpdateIsMetadataRecord :: Maybe Bool
    <*> arbitraryReducedMaybe n -- articleUpdateMetadataReason :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleUpdateTags :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- articleUpdateKeywords :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- articleUpdateReferences :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- articleUpdateRelatedMaterials :: Maybe [RelatedMaterial]
    <*> arbitraryReducedMaybe n -- articleUpdateCategories :: Maybe [Integer]
    <*> arbitraryReducedMaybe n -- articleUpdateCategoriesBySourceId :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- articleUpdateAuthors :: Maybe [A.Value]
    <*> arbitraryReducedMaybeValue n -- articleUpdateCustomFields :: Maybe A.Value
    <*> arbitraryReducedMaybe n -- articleUpdateCustomFieldsList :: Maybe [CustomArticleFieldAdd]
    <*> arbitraryReducedMaybe n -- articleUpdateDefinedType :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleUpdateFunding :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleUpdateFundingList :: Maybe [FundingCreate]
    <*> arbitraryReducedMaybe n -- articleUpdateLicense :: Maybe Integer
    <*> arbitraryReducedMaybe n -- articleUpdateDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleUpdateHandle :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleUpdateResourceDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleUpdateResourceTitle :: Maybe Text
    <*> arbitraryReducedMaybe n -- articleUpdateTimeline :: Maybe TimelineUpdate
    <*> arbitraryReducedMaybe n -- articleUpdateDownloadDisabled :: Maybe Bool
    <*> arbitraryReducedMaybe n -- articleUpdateGroupId :: Maybe Integer
  
instance Arbitrary ArticleVersionUpdate where
  arbitrary = sized genArticleVersionUpdate

genArticleVersionUpdate :: Int -> Gen ArticleVersionUpdate
genArticleVersionUpdate n =
  ArticleVersionUpdate
    <$> arbitraryReducedMaybe n -- articleVersionUpdateSupplementaryFields :: Maybe [A.Value]
    <*> arbitraryReducedMaybeValue n -- articleVersionUpdateInternalMetadata :: Maybe A.Value
  
instance Arbitrary ArticleVersions where
  arbitrary = sized genArticleVersions

genArticleVersions :: Int -> Gen ArticleVersions
genArticleVersions n =
  ArticleVersions
    <$> arbitrary -- articleVersionsVersion :: Integer
    <*> arbitrary -- articleVersionsUrl :: Text
  
instance Arbitrary ArticleWithProject where
  arbitrary = sized genArticleWithProject

genArticleWithProject :: Int -> Gen ArticleWithProject
genArticleWithProject n =
  ArticleWithProject
    <$> arbitrary -- articleWithProjectProjectId :: Integer
    <*> arbitrary -- articleWithProjectId :: Integer
    <*> arbitrary -- articleWithProjectTitle :: Text
    <*> arbitrary -- articleWithProjectDoi :: Text
    <*> arbitrary -- articleWithProjectHandle :: Text
    <*> arbitrary -- articleWithProjectUrl :: Text
    <*> arbitrary -- articleWithProjectUrlPublicHtml :: Text
    <*> arbitrary -- articleWithProjectUrlPublicApi :: Text
    <*> arbitrary -- articleWithProjectUrlPrivateHtml :: Text
    <*> arbitrary -- articleWithProjectUrlPrivateApi :: Text
    <*> arbitraryReduced n -- articleWithProjectTimeline :: Timeline
    <*> arbitrary -- articleWithProjectThumb :: Text
    <*> arbitrary -- articleWithProjectDefinedType :: Integer
    <*> arbitrary -- articleWithProjectDefinedTypeName :: Text
    <*> arbitrary -- articleWithProjectResourceDoi :: Text
    <*> arbitrary -- articleWithProjectResourceTitle :: Text
    <*> arbitrary -- articleWithProjectCreatedDate :: Text
  
instance Arbitrary ArticlesCreator where
  arbitrary = sized genArticlesCreator

genArticlesCreator :: Int -> Gen ArticlesCreator
genArticlesCreator n =
  ArticlesCreator
    <$> arbitrary -- articlesCreatorArticles :: [Integer]
  
instance Arbitrary Author where
  arbitrary = sized genAuthor

genAuthor :: Int -> Gen Author
genAuthor n =
  Author
    <$> arbitrary -- authorId :: Integer
    <*> arbitrary -- authorFullName :: Text
    <*> arbitrary -- authorFirstName :: Text
    <*> arbitrary -- authorLastName :: Text
    <*> arbitrary -- authorIsActive :: Bool
    <*> arbitrary -- authorUrlName :: Text
    <*> arbitrary -- authorOrcidId :: Text
  
instance Arbitrary AuthorComplete where
  arbitrary = sized genAuthorComplete

genAuthorComplete :: Int -> Gen AuthorComplete
genAuthorComplete n =
  AuthorComplete
    <$> arbitrary -- authorCompleteInstitutionId :: Integer
    <*> arbitrary -- authorCompleteGroupId :: Integer
    <*> arbitrary -- authorCompleteFirstName :: Text
    <*> arbitrary -- authorCompleteLastName :: Text
    <*> arbitrary -- authorCompleteIsPublic :: Integer
    <*> arbitrary -- authorCompleteJobTitle :: Text
    <*> arbitrary -- authorCompleteId :: Integer
    <*> arbitrary -- authorCompleteFullName :: Text
    <*> arbitrary -- authorCompleteIsActive :: Bool
    <*> arbitrary -- authorCompleteUrlName :: Text
    <*> arbitrary -- authorCompleteOrcidId :: Text
  
instance Arbitrary AuthorsCreator where
  arbitrary = sized genAuthorsCreator

genAuthorsCreator :: Int -> Gen AuthorsCreator
genAuthorsCreator n =
  AuthorsCreator
    <$> arbitraryReduced n -- authorsCreatorAuthors :: [A.Value]
  
instance Arbitrary CategoriesCreator where
  arbitrary = sized genCategoriesCreator

genCategoriesCreator :: Int -> Gen CategoriesCreator
genCategoriesCreator n =
  CategoriesCreator
    <$> arbitrary -- categoriesCreatorCategories :: [Integer]
  
instance Arbitrary Category where
  arbitrary = sized genCategory

genCategory :: Int -> Gen Category
genCategory n =
  Category
    <$> arbitrary -- categoryParentId :: Integer
    <*> arbitrary -- categoryId :: Integer
    <*> arbitrary -- categoryTitle :: Text
    <*> arbitrary -- categoryPath :: Text
    <*> arbitrary -- categorySourceId :: Text
    <*> arbitrary -- categoryTaxonomyId :: Integer
  
instance Arbitrary CategoryList where
  arbitrary = sized genCategoryList

genCategoryList :: Int -> Gen CategoryList
genCategoryList n =
  CategoryList
    <$> arbitrary -- categoryListIsSelectable :: Bool
    <*> arbitrary -- categoryListHasChildren :: Bool
    <*> arbitrary -- categoryListParentId :: Integer
    <*> arbitrary -- categoryListId :: Integer
    <*> arbitrary -- categoryListTitle :: Text
    <*> arbitrary -- categoryListPath :: Text
    <*> arbitrary -- categoryListSourceId :: Text
    <*> arbitrary -- categoryListTaxonomyId :: Integer
  
instance Arbitrary Collaborator where
  arbitrary = sized genCollaborator

genCollaborator :: Int -> Gen Collaborator
genCollaborator n =
  Collaborator
    <$> arbitrary -- collaboratorRoleName :: Text
    <*> arbitrary -- collaboratorUserId :: Int
    <*> arbitrary -- collaboratorName :: Text
  
instance Arbitrary Collection where
  arbitrary = sized genCollection

genCollection :: Int -> Gen Collection
genCollection n =
  Collection
    <$> arbitrary -- collectionId :: Integer
    <*> arbitrary -- collectionTitle :: Text
    <*> arbitrary -- collectionDoi :: Text
    <*> arbitrary -- collectionHandle :: Text
    <*> arbitrary -- collectionUrl :: Text
    <*> arbitraryReduced n -- collectionTimeline :: Timeline
  
instance Arbitrary CollectionComplete where
  arbitrary = sized genCollectionComplete

genCollectionComplete :: Int -> Gen CollectionComplete
genCollectionComplete n =
  CollectionComplete
    <$> arbitraryReduced n -- collectionCompleteFunding :: [FundingInformation]
    <*> arbitrary -- collectionCompleteResourceId :: Text
    <*> arbitrary -- collectionCompleteResourceDoi :: Text
    <*> arbitrary -- collectionCompleteResourceTitle :: Text
    <*> arbitrary -- collectionCompleteResourceLink :: Text
    <*> arbitrary -- collectionCompleteResourceVersion :: Integer
    <*> arbitrary -- collectionCompleteVersion :: Integer
    <*> arbitrary -- collectionCompleteDescription :: Text
    <*> arbitraryReduced n -- collectionCompleteCategories :: [Category]
    <*> arbitrary -- collectionCompleteReferences :: [Text]
    <*> arbitraryReduced n -- collectionCompleteRelatedMaterials :: [RelatedMaterial]
    <*> arbitrary -- collectionCompleteTags :: [Text]
    <*> arbitrary -- collectionCompleteKeywords :: [Text]
    <*> arbitraryReduced n -- collectionCompleteAuthors :: [Author]
    <*> arbitrary -- collectionCompleteInstitutionId :: Integer
    <*> arbitrary -- collectionCompleteGroupId :: Integer
    <*> arbitrary -- collectionCompleteArticlesCount :: Integer
    <*> arbitrary -- collectionCompletePublic :: Bool
    <*> arbitrary -- collectionCompleteCitation :: Text
    <*> arbitraryReduced n -- collectionCompleteCustomFields :: [CustomArticleField]
    <*> arbitrary -- collectionCompleteModifiedDate :: Text
    <*> arbitrary -- collectionCompleteCreatedDate :: Text
    <*> arbitraryReduced n -- collectionCompleteTimeline :: Timeline
    <*> arbitrary -- collectionCompleteId :: Integer
    <*> arbitrary -- collectionCompleteTitle :: Text
    <*> arbitrary -- collectionCompleteDoi :: Text
    <*> arbitrary -- collectionCompleteHandle :: Text
    <*> arbitrary -- collectionCompleteUrl :: Text
  
instance Arbitrary CollectionCompletePrivate where
  arbitrary = sized genCollectionCompletePrivate

genCollectionCompletePrivate :: Int -> Gen CollectionCompletePrivate
genCollectionCompletePrivate n =
  CollectionCompletePrivate
    <$> arbitrary -- collectionCompletePrivateAccountId :: Integer
    <*> arbitraryReduced n -- collectionCompletePrivateFunding :: [FundingInformation]
    <*> arbitrary -- collectionCompletePrivateResourceId :: Text
    <*> arbitrary -- collectionCompletePrivateResourceDoi :: Text
    <*> arbitrary -- collectionCompletePrivateResourceTitle :: Text
    <*> arbitrary -- collectionCompletePrivateResourceLink :: Text
    <*> arbitrary -- collectionCompletePrivateResourceVersion :: Integer
    <*> arbitrary -- collectionCompletePrivateVersion :: Integer
    <*> arbitrary -- collectionCompletePrivateDescription :: Text
    <*> arbitraryReduced n -- collectionCompletePrivateCategories :: [Category]
    <*> arbitrary -- collectionCompletePrivateReferences :: [Text]
    <*> arbitraryReducedMaybe n -- collectionCompletePrivateRelatedMaterials :: Maybe [RelatedMaterial]
    <*> arbitrary -- collectionCompletePrivateTags :: [Text]
    <*> arbitrary -- collectionCompletePrivateKeywords :: [Text]
    <*> arbitraryReduced n -- collectionCompletePrivateAuthors :: [Author]
    <*> arbitrary -- collectionCompletePrivateInstitutionId :: Integer
    <*> arbitrary -- collectionCompletePrivateGroupId :: Integer
    <*> arbitrary -- collectionCompletePrivateArticlesCount :: Integer
    <*> arbitrary -- collectionCompletePrivatePublic :: Bool
    <*> arbitrary -- collectionCompletePrivateCitation :: Text
    <*> arbitraryReduced n -- collectionCompletePrivateCustomFields :: [CustomArticleField]
    <*> arbitrary -- collectionCompletePrivateModifiedDate :: Text
    <*> arbitrary -- collectionCompletePrivateCreatedDate :: Text
    <*> arbitraryReduced n -- collectionCompletePrivateTimeline :: Timeline
    <*> arbitrary -- collectionCompletePrivateId :: Integer
    <*> arbitrary -- collectionCompletePrivateTitle :: Text
    <*> arbitrary -- collectionCompletePrivateDoi :: Text
    <*> arbitrary -- collectionCompletePrivateHandle :: Text
    <*> arbitrary -- collectionCompletePrivateUrl :: Text
  
instance Arbitrary CollectionCreate where
  arbitrary = sized genCollectionCreate

genCollectionCreate :: Int -> Gen CollectionCreate
genCollectionCreate n =
  CollectionCreate
    <$> arbitraryReducedMaybe n -- collectionCreateFunding :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionCreateFundingList :: Maybe [FundingCreate]
    <*> arbitrary -- collectionCreateTitle :: Text
    <*> arbitraryReducedMaybe n -- collectionCreateDescription :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionCreateArticles :: Maybe [Int]
    <*> arbitraryReducedMaybe n -- collectionCreateAuthors :: Maybe [A.Value]
    <*> arbitraryReducedMaybe n -- collectionCreateCategories :: Maybe [Integer]
    <*> arbitraryReducedMaybe n -- collectionCreateCategoriesBySourceId :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- collectionCreateTags :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- collectionCreateKeywords :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- collectionCreateReferences :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- collectionCreateRelatedMaterials :: Maybe [RelatedMaterial]
    <*> arbitraryReducedMaybeValue n -- collectionCreateCustomFields :: Maybe A.Value
    <*> arbitraryReducedMaybe n -- collectionCreateCustomFieldsList :: Maybe [CustomArticleFieldAdd]
    <*> arbitraryReducedMaybe n -- collectionCreateDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionCreateHandle :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionCreateResourceId :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionCreateResourceDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionCreateResourceLink :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionCreateResourceTitle :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionCreateResourceVersion :: Maybe Int
    <*> arbitraryReducedMaybe n -- collectionCreateGroupId :: Maybe Integer
    <*> arbitraryReducedMaybe n -- collectionCreateTimeline :: Maybe TimelineUpdate
  
instance Arbitrary CollectionDOI where
  arbitrary = sized genCollectionDOI

genCollectionDOI :: Int -> Gen CollectionDOI
genCollectionDOI n =
  CollectionDOI
    <$> arbitrary -- collectionDOIDoi :: Text
  
instance Arbitrary CollectionHandle where
  arbitrary = sized genCollectionHandle

genCollectionHandle :: Int -> Gen CollectionHandle
genCollectionHandle n =
  CollectionHandle
    <$> arbitrary -- collectionHandleHandle :: Text
  
instance Arbitrary CollectionPrivateLinkCreator where
  arbitrary = sized genCollectionPrivateLinkCreator

genCollectionPrivateLinkCreator :: Int -> Gen CollectionPrivateLinkCreator
genCollectionPrivateLinkCreator n =
  CollectionPrivateLinkCreator
    <$> arbitraryReducedMaybe n -- collectionPrivateLinkCreatorExpiresDate :: Maybe Text
  
instance Arbitrary CollectionSearch where
  arbitrary = sized genCollectionSearch

genCollectionSearch :: Int -> Gen CollectionSearch
genCollectionSearch n =
  CollectionSearch
    <$> arbitraryReducedMaybe n -- collectionSearchResourceDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionSearchDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionSearchHandle :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionSearchOrder :: Maybe E'Order2
    <*> arbitraryReducedMaybe n -- collectionSearchSearchFor :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionSearchPage :: Maybe Integer
    <*> arbitraryReducedMaybe n -- collectionSearchPageSize :: Maybe Integer
    <*> arbitraryReducedMaybe n -- collectionSearchLimit :: Maybe Integer
    <*> arbitraryReducedMaybe n -- collectionSearchOffset :: Maybe Integer
    <*> arbitraryReducedMaybe n -- collectionSearchOrderDirection :: Maybe E'OrderDirection
    <*> arbitraryReducedMaybe n -- collectionSearchInstitution :: Maybe Int
    <*> arbitraryReducedMaybe n -- collectionSearchPublishedSince :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionSearchModifiedSince :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionSearchGroup :: Maybe Int
  
instance Arbitrary CollectionUpdate where
  arbitrary = sized genCollectionUpdate

genCollectionUpdate :: Int -> Gen CollectionUpdate
genCollectionUpdate n =
  CollectionUpdate
    <$> arbitraryReducedMaybe n -- collectionUpdateFunding :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionUpdateFundingList :: Maybe [FundingCreate]
    <*> arbitraryReducedMaybe n -- collectionUpdateTitle :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionUpdateDescription :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionUpdateArticles :: Maybe [Int]
    <*> arbitraryReducedMaybe n -- collectionUpdateAuthors :: Maybe [A.Value]
    <*> arbitraryReducedMaybe n -- collectionUpdateCategories :: Maybe [Integer]
    <*> arbitraryReducedMaybe n -- collectionUpdateCategoriesBySourceId :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- collectionUpdateTags :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- collectionUpdateKeywords :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- collectionUpdateReferences :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- collectionUpdateRelatedMaterials :: Maybe [RelatedMaterial]
    <*> arbitraryReducedMaybeValue n -- collectionUpdateCustomFields :: Maybe A.Value
    <*> arbitraryReducedMaybe n -- collectionUpdateCustomFieldsList :: Maybe [CustomArticleFieldAdd]
    <*> arbitraryReducedMaybe n -- collectionUpdateDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionUpdateHandle :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionUpdateResourceId :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionUpdateResourceDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionUpdateResourceLink :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionUpdateResourceTitle :: Maybe Text
    <*> arbitraryReducedMaybe n -- collectionUpdateResourceVersion :: Maybe Int
    <*> arbitraryReducedMaybe n -- collectionUpdateGroupId :: Maybe Integer
    <*> arbitraryReducedMaybe n -- collectionUpdateTimeline :: Maybe TimelineUpdate
  
instance Arbitrary CollectionVersions where
  arbitrary = sized genCollectionVersions

genCollectionVersions :: Int -> Gen CollectionVersions
genCollectionVersions n =
  CollectionVersions
    <$> arbitrary -- collectionVersionsVersion :: Integer
    <*> arbitrary -- collectionVersionsUrl :: Text
    <*> arbitraryReduced n -- collectionVersionsFunding :: [FundingInformation]
  
instance Arbitrary CommonSearch where
  arbitrary = sized genCommonSearch

genCommonSearch :: Int -> Gen CommonSearch
genCommonSearch n =
  CommonSearch
    <$> arbitraryReducedMaybe n -- commonSearchSearchFor :: Maybe Text
    <*> arbitraryReducedMaybe n -- commonSearchPage :: Maybe Integer
    <*> arbitraryReducedMaybe n -- commonSearchPageSize :: Maybe Integer
    <*> arbitraryReducedMaybe n -- commonSearchLimit :: Maybe Integer
    <*> arbitraryReducedMaybe n -- commonSearchOffset :: Maybe Integer
    <*> arbitraryReducedMaybe n -- commonSearchOrderDirection :: Maybe E'OrderDirection
    <*> arbitraryReducedMaybe n -- commonSearchInstitution :: Maybe Int
    <*> arbitraryReducedMaybe n -- commonSearchPublishedSince :: Maybe Text
    <*> arbitraryReducedMaybe n -- commonSearchModifiedSince :: Maybe Text
    <*> arbitraryReducedMaybe n -- commonSearchGroup :: Maybe Int
  
instance Arbitrary ConfidentialityCreator where
  arbitrary = sized genConfidentialityCreator

genConfidentialityCreator :: Int -> Gen ConfidentialityCreator
genConfidentialityCreator n =
  ConfidentialityCreator
    <$> arbitrary -- confidentialityCreatorReason :: Text
  
instance Arbitrary CreateOAuthToken where
  arbitrary = sized genCreateOAuthToken

genCreateOAuthToken :: Int -> Gen CreateOAuthToken
genCreateOAuthToken n =
  CreateOAuthToken
    <$> arbitrary -- createOAuthTokenClientId :: Text
    <*> arbitrary -- createOAuthTokenClientSecret :: Text
    <*> arbitrary -- createOAuthTokenGrantType :: E'GrantType
    <*> arbitraryReducedMaybe n -- createOAuthTokenCode :: Maybe Text
    <*> arbitraryReducedMaybe n -- createOAuthTokenRefreshToken :: Maybe Text
    <*> arbitraryReducedMaybe n -- createOAuthTokenUsername :: Maybe Text
    <*> arbitraryReducedMaybe n -- createOAuthTokenPassword :: Maybe Text
  
instance Arbitrary CreateProjectResponse where
  arbitrary = sized genCreateProjectResponse

genCreateProjectResponse :: Int -> Gen CreateProjectResponse
genCreateProjectResponse n =
  CreateProjectResponse
    <$> arbitrary -- createProjectResponseEntityId :: Integer
    <*> arbitrary -- createProjectResponseLocation :: Text
  
instance Arbitrary Curation where
  arbitrary = sized genCuration

genCuration :: Int -> Gen Curation
genCuration n =
  Curation
    <$> arbitrary -- curationId :: Integer
    <*> arbitrary -- curationGroupId :: Integer
    <*> arbitrary -- curationAccountId :: Integer
    <*> arbitrary -- curationAssignedTo :: Integer
    <*> arbitrary -- curationArticleId :: Integer
    <*> arbitrary -- curationVersion :: Integer
    <*> arbitrary -- curationCommentsCount :: Integer
    <*> arbitrary -- curationStatus :: E'Status2
    <*> arbitrary -- curationCreatedDate :: Text
    <*> arbitrary -- curationModifiedDate :: Text
    <*> arbitrary -- curationRequestNumber :: Integer
    <*> arbitrary -- curationResolutionComment :: Text
  
instance Arbitrary CurationComment where
  arbitrary = sized genCurationComment

genCurationComment :: Int -> Gen CurationComment
genCurationComment n =
  CurationComment
    <$> arbitrary -- curationCommentId :: Integer
    <*> arbitrary -- curationCommentAccountId :: Integer
    <*> arbitrary -- curationCommentType :: E'Type
    <*> arbitrary -- curationCommentText :: Text
    <*> arbitrary -- curationCommentCreatedDate :: Text
    <*> arbitrary -- curationCommentModifiedDate :: Text
  
instance Arbitrary CurationCommentCreate where
  arbitrary = sized genCurationCommentCreate

genCurationCommentCreate :: Int -> Gen CurationCommentCreate
genCurationCommentCreate n =
  CurationCommentCreate
    <$> arbitrary -- curationCommentCreateText :: Text
  
instance Arbitrary CurationDetail where
  arbitrary = sized genCurationDetail

genCurationDetail :: Int -> Gen CurationDetail
genCurationDetail n =
  CurationDetail
    <$> arbitraryReduced n -- curationDetailItem :: ArticleComplete
    <*> arbitrary -- curationDetailId :: Integer
    <*> arbitrary -- curationDetailGroupId :: Integer
    <*> arbitrary -- curationDetailAccountId :: Integer
    <*> arbitrary -- curationDetailAssignedTo :: Integer
    <*> arbitrary -- curationDetailArticleId :: Integer
    <*> arbitrary -- curationDetailVersion :: Integer
    <*> arbitrary -- curationDetailCommentsCount :: Integer
    <*> arbitrary -- curationDetailStatus :: E'Status2
    <*> arbitrary -- curationDetailCreatedDate :: Text
    <*> arbitrary -- curationDetailModifiedDate :: Text
    <*> arbitrary -- curationDetailRequestNumber :: Integer
    <*> arbitrary -- curationDetailResolutionComment :: Text
  
instance Arbitrary CustomArticleField where
  arbitrary = sized genCustomArticleField

genCustomArticleField :: Int -> Gen CustomArticleField
genCustomArticleField n =
  CustomArticleField
    <$> arbitrary -- customArticleFieldName :: Text
    <*> arbitraryReduced n -- customArticleFieldValue :: A.Value
    <*> arbitrary -- customArticleFieldFieldType :: E'FieldType
    <*> arbitraryReduced n -- customArticleFieldSettings :: A.Value
    <*> arbitrary -- customArticleFieldOrder :: Integer
    <*> arbitrary -- customArticleFieldIsMandatory :: Bool
  
instance Arbitrary CustomArticleFieldAdd where
  arbitrary = sized genCustomArticleFieldAdd

genCustomArticleFieldAdd :: Int -> Gen CustomArticleFieldAdd
genCustomArticleFieldAdd n =
  CustomArticleFieldAdd
    <$> arbitrary -- customArticleFieldAddName :: Text
    <*> arbitraryReduced n -- customArticleFieldAddValue :: A.Value
  
instance Arbitrary ErrorMessage where
  arbitrary = sized genErrorMessage

genErrorMessage :: Int -> Gen ErrorMessage
genErrorMessage n =
  ErrorMessage
    <$> arbitraryReducedMaybe n -- errorMessageCode :: Maybe Integer
    <*> arbitraryReducedMaybe n -- errorMessageMessage :: Maybe Text
  
instance Arbitrary FileCreator where
  arbitrary = sized genFileCreator

genFileCreator :: Int -> Gen FileCreator
genFileCreator n =
  FileCreator
    <$> arbitraryReducedMaybe n -- fileCreatorLink :: Maybe Text
    <*> arbitraryReducedMaybe n -- fileCreatorMd5 :: Maybe Text
    <*> arbitraryReducedMaybe n -- fileCreatorName :: Maybe Text
    <*> arbitraryReducedMaybe n -- fileCreatorSize :: Maybe Integer
    <*> arbitraryReducedMaybe n -- fileCreatorFolderPath :: Maybe Text
  
instance Arbitrary FileId where
  arbitrary = sized genFileId

genFileId :: Int -> Gen FileId
genFileId n =
  FileId
    <$> arbitraryReducedMaybe n -- fileIdFileId :: Maybe Integer
  
instance Arbitrary FundingCreate where
  arbitrary = sized genFundingCreate

genFundingCreate :: Int -> Gen FundingCreate
genFundingCreate n =
  FundingCreate
    <$> arbitraryReducedMaybe n -- fundingCreateId :: Maybe Integer
    <*> arbitraryReducedMaybe n -- fundingCreateTitle :: Maybe Text
  
instance Arbitrary FundingInformation where
  arbitrary = sized genFundingInformation

genFundingInformation :: Int -> Gen FundingInformation
genFundingInformation n =
  FundingInformation
    <$> arbitrary -- fundingInformationId :: Integer
    <*> arbitrary -- fundingInformationTitle :: Text
    <*> arbitrary -- fundingInformationGrantCode :: Text
    <*> arbitrary -- fundingInformationFunderName :: Text
    <*> arbitrary -- fundingInformationIsUserDefined :: Integer
    <*> arbitrary -- fundingInformationUrl :: Text
  
instance Arbitrary FundingSearch where
  arbitrary = sized genFundingSearch

genFundingSearch :: Int -> Gen FundingSearch
genFundingSearch n =
  FundingSearch
    <$> arbitraryReducedMaybe n -- fundingSearchSearchFor :: Maybe Text
  
instance Arbitrary Group where
  arbitrary = sized genGroup

genGroup :: Int -> Gen Group
genGroup n =
  Group
    <$> arbitrary -- groupId :: Integer
    <*> arbitrary -- groupName :: Text
    <*> arbitrary -- groupResourceId :: Text
    <*> arbitrary -- groupParentId :: Integer
    <*> arbitrary -- groupAssociationCriteria :: Text
  
instance Arbitrary GroupEmbargoOptions where
  arbitrary = sized genGroupEmbargoOptions

genGroupEmbargoOptions :: Int -> Gen GroupEmbargoOptions
genGroupEmbargoOptions n =
  GroupEmbargoOptions
    <$> arbitrary -- groupEmbargoOptionsId :: Integer
    <*> arbitrary -- groupEmbargoOptionsType :: E'Type2
    <*> arbitrary -- groupEmbargoOptionsIpName :: Text
  
instance Arbitrary Institution where
  arbitrary = sized genInstitution

genInstitution :: Int -> Gen Institution
genInstitution n =
  Institution
    <$> arbitrary -- institutionId :: Integer
    <*> arbitrary -- institutionName :: Text
  
instance Arbitrary InstitutionAccountsSearch where
  arbitrary = sized genInstitutionAccountsSearch

genInstitutionAccountsSearch :: Int -> Gen InstitutionAccountsSearch
genInstitutionAccountsSearch n =
  InstitutionAccountsSearch
    <$> arbitraryReducedMaybe n -- institutionAccountsSearchSearchFor :: Maybe Text
    <*> arbitraryReducedMaybe n -- institutionAccountsSearchIsActive :: Maybe Integer
    <*> arbitraryReducedMaybe n -- institutionAccountsSearchPage :: Maybe Integer
    <*> arbitraryReducedMaybe n -- institutionAccountsSearchPageSize :: Maybe Integer
    <*> arbitraryReducedMaybe n -- institutionAccountsSearchLimit :: Maybe Integer
    <*> arbitraryReducedMaybe n -- institutionAccountsSearchOffset :: Maybe Integer
    <*> arbitraryReducedMaybe n -- institutionAccountsSearchInstitutionUserId :: Maybe Text
    <*> arbitraryReducedMaybe n -- institutionAccountsSearchEmail :: Maybe Text
  
instance Arbitrary ItemType where
  arbitrary = sized genItemType

genItemType :: Int -> Gen ItemType
genItemType n =
  ItemType
    <$> arbitrary -- itemTypeId :: Integer
    <*> arbitrary -- itemTypeName :: Text
    <*> arbitrary -- itemTypeStringId :: Text
    <*> arbitrary -- itemTypeIcon :: Text
    <*> arbitrary -- itemTypePublicDescription :: Text
    <*> arbitrary -- itemTypeIsSelectable :: Bool
    <*> arbitrary -- itemTypeUrlName :: Text
  
instance Arbitrary License where
  arbitrary = sized genLicense

genLicense :: Int -> Gen License
genLicense n =
  License
    <$> arbitrary -- licenseValue :: Integer
    <*> arbitrary -- licenseName :: Text
    <*> arbitrary -- licenseUrl :: Text
  
instance Arbitrary Location where
  arbitrary = sized genLocation

genLocation :: Int -> Gen Location
genLocation n =
  Location
    <$> arbitrary -- locationLocation :: Text
  
instance Arbitrary LocationWarnings where
  arbitrary = sized genLocationWarnings

genLocationWarnings :: Int -> Gen LocationWarnings
genLocationWarnings n =
  LocationWarnings
    <$> arbitrary -- locationWarningsEntityId :: Integer
    <*> arbitrary -- locationWarningsLocation :: Text
    <*> arbitrary -- locationWarningsWarnings :: [Text]
  
instance Arbitrary LocationWarningsUpdate where
  arbitrary = sized genLocationWarningsUpdate

genLocationWarningsUpdate :: Int -> Gen LocationWarningsUpdate
genLocationWarningsUpdate n =
  LocationWarningsUpdate
    <$> arbitrary -- locationWarningsUpdateLocation :: Text
    <*> arbitrary -- locationWarningsUpdateWarnings :: [Text]
  
instance Arbitrary OAuthToken where
  arbitrary = sized genOAuthToken

genOAuthToken :: Int -> Gen OAuthToken
genOAuthToken n =
  OAuthToken
    <$> arbitrary -- oAuthTokenAccessToken :: Text
    <*> arbitraryReducedMaybe n -- oAuthTokenToken :: Maybe Text
    <*> arbitrary -- oAuthTokenTokenType :: Text
    <*> arbitrary -- oAuthTokenExpiresIn :: Integer
    <*> arbitraryReducedMaybe n -- oAuthTokenRefreshToken :: Maybe Text
    <*> arbitraryReducedMaybe n -- oAuthTokenScope :: Maybe Text
  
instance Arbitrary PrivateArticleSearch where
  arbitrary = sized genPrivateArticleSearch

genPrivateArticleSearch :: Int -> Gen PrivateArticleSearch
genPrivateArticleSearch n =
  PrivateArticleSearch
    <$> arbitraryReducedMaybe n -- privateArticleSearchResourceId :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateArticleSearchResourceDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateArticleSearchItemType :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateArticleSearchDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateArticleSearchHandle :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateArticleSearchProjectId :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateArticleSearchOrder :: Maybe E'Order
    <*> arbitraryReducedMaybe n -- privateArticleSearchSearchFor :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateArticleSearchPage :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateArticleSearchPageSize :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateArticleSearchLimit :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateArticleSearchOffset :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateArticleSearchOrderDirection :: Maybe E'OrderDirection
    <*> arbitraryReducedMaybe n -- privateArticleSearchInstitution :: Maybe Int
    <*> arbitraryReducedMaybe n -- privateArticleSearchPublishedSince :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateArticleSearchModifiedSince :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateArticleSearchGroup :: Maybe Int
  
instance Arbitrary PrivateAuthorsSearch where
  arbitrary = sized genPrivateAuthorsSearch

genPrivateAuthorsSearch :: Int -> Gen PrivateAuthorsSearch
genPrivateAuthorsSearch n =
  PrivateAuthorsSearch
    <$> arbitraryReducedMaybe n -- privateAuthorsSearchSearchFor :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateAuthorsSearchPage :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateAuthorsSearchPageSize :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateAuthorsSearchLimit :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateAuthorsSearchOffset :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateAuthorsSearchInstitutionId :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateAuthorsSearchOrcid :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateAuthorsSearchGroupId :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateAuthorsSearchIsActive :: Maybe Bool
    <*> arbitraryReducedMaybe n -- privateAuthorsSearchIsPublic :: Maybe Bool
  
instance Arbitrary PrivateCollectionSearch where
  arbitrary = sized genPrivateCollectionSearch

genPrivateCollectionSearch :: Int -> Gen PrivateCollectionSearch
genPrivateCollectionSearch n =
  PrivateCollectionSearch
    <$> arbitraryReducedMaybe n -- privateCollectionSearchResourceId :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateCollectionSearchResourceDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateCollectionSearchDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateCollectionSearchHandle :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateCollectionSearchOrder :: Maybe E'Order2
    <*> arbitraryReducedMaybe n -- privateCollectionSearchSearchFor :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateCollectionSearchPage :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateCollectionSearchPageSize :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateCollectionSearchLimit :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateCollectionSearchOffset :: Maybe Integer
    <*> arbitraryReducedMaybe n -- privateCollectionSearchOrderDirection :: Maybe E'OrderDirection
    <*> arbitraryReducedMaybe n -- privateCollectionSearchInstitution :: Maybe Int
    <*> arbitraryReducedMaybe n -- privateCollectionSearchPublishedSince :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateCollectionSearchModifiedSince :: Maybe Text
    <*> arbitraryReducedMaybe n -- privateCollectionSearchGroup :: Maybe Int
  
instance Arbitrary PrivateFile where
  arbitrary = sized genPrivateFile

genPrivateFile :: Int -> Gen PrivateFile
genPrivateFile n =
  PrivateFile
    <$> arbitrary -- privateFileViewerType :: Text
    <*> arbitrary -- privateFilePreviewState :: Text
    <*> arbitrary -- privateFileUploadUrl :: Text
    <*> arbitrary -- privateFileUploadToken :: Text
    <*> arbitrary -- privateFileIsAttachedToPublicVersion :: Bool
    <*> arbitrary -- privateFileId :: Integer
    <*> arbitrary -- privateFileName :: Text
    <*> arbitrary -- privateFileSize :: Integer
    <*> arbitrary -- privateFileIsLinkOnly :: Bool
    <*> arbitrary -- privateFileDownloadUrl :: Text
    <*> arbitrary -- privateFileSuppliedMd5 :: Text
    <*> arbitrary -- privateFileComputedMd5 :: Text
    <*> arbitraryReducedMaybe n -- privateFileMimetype :: Maybe Text
  
instance Arbitrary PrivateLink where
  arbitrary = sized genPrivateLink

genPrivateLink :: Int -> Gen PrivateLink
genPrivateLink n =
  PrivateLink
    <$> arbitrary -- privateLinkId :: Text
    <*> arbitrary -- privateLinkIsActive :: Bool
    <*> arbitrary -- privateLinkExpiresDate :: Text
    <*> arbitrary -- privateLinkHtmlLocation :: Text
  
instance Arbitrary PrivateLinkCreator where
  arbitrary = sized genPrivateLinkCreator

genPrivateLinkCreator :: Int -> Gen PrivateLinkCreator
genPrivateLinkCreator n =
  PrivateLinkCreator
    <$> arbitraryReducedMaybe n -- privateLinkCreatorExpiresDate :: Maybe Text
  
instance Arbitrary PrivateLinkResponse where
  arbitrary = sized genPrivateLinkResponse

genPrivateLinkResponse :: Int -> Gen PrivateLinkResponse
genPrivateLinkResponse n =
  PrivateLinkResponse
    <$> arbitrary -- privateLinkResponseLocation :: Text
    <*> arbitrary -- privateLinkResponseHtmlLocation :: Text
    <*> arbitrary -- privateLinkResponseToken :: Text
  
instance Arbitrary PrivateProjectArticle where
  arbitrary = sized genPrivateProjectArticle

genPrivateProjectArticle :: Int -> Gen PrivateProjectArticle
genPrivateProjectArticle n =
  PrivateProjectArticle
    <$> arbitraryReduced n -- privateProjectArticleFiles :: [PublicFile]
    <*> arbitraryReduced n -- privateProjectArticleEmbargoOptions :: [GroupEmbargoOptions]
    <*> arbitraryReduced n -- privateProjectArticleCustomFields :: [CustomArticleField]
    <*> arbitrary -- privateProjectArticleAccountId :: Integer
    <*> arbitrary -- privateProjectArticleDownloadDisabled :: Bool
    <*> arbitraryReduced n -- privateProjectArticleAuthors :: [Author]
    <*> arbitrary -- privateProjectArticleFigshareUrl :: Text
    <*> arbitrary -- privateProjectArticleCurationStatus :: Text
    <*> arbitrary -- privateProjectArticleCitation :: Text
    <*> arbitrary -- privateProjectArticleConfidentialReason :: Text
    <*> arbitrary -- privateProjectArticleIsConfidential :: Bool
    <*> arbitrary -- privateProjectArticleSize :: Integer
    <*> arbitrary -- privateProjectArticleFunding :: Text
    <*> arbitraryReduced n -- privateProjectArticleFundingList :: [FundingInformation]
    <*> arbitrary -- privateProjectArticleTags :: [Text]
    <*> arbitrary -- privateProjectArticleKeywords :: [Text]
    <*> arbitrary -- privateProjectArticleVersion :: Integer
    <*> arbitrary -- privateProjectArticleIsMetadataRecord :: Bool
    <*> arbitrary -- privateProjectArticleMetadataReason :: Text
    <*> arbitrary -- privateProjectArticleStatus :: Text
    <*> arbitrary -- privateProjectArticleDescription :: Text
    <*> arbitrary -- privateProjectArticleIsEmbargoed :: Bool
    <*> arbitrary -- privateProjectArticleIsPublic :: Bool
    <*> arbitrary -- privateProjectArticleCreatedDate :: Text
    <*> arbitrary -- privateProjectArticleHasLinkedFile :: Bool
    <*> arbitraryReduced n -- privateProjectArticleCategories :: [Category]
    <*> arbitraryReduced n -- privateProjectArticleLicense :: License
    <*> arbitrary -- privateProjectArticleEmbargoTitle :: Text
    <*> arbitrary -- privateProjectArticleEmbargoReason :: Text
    <*> arbitrary -- privateProjectArticleReferences :: [Text]
    <*> arbitraryReducedMaybe n -- privateProjectArticleRelatedMaterials :: Maybe [RelatedMaterial]
    <*> arbitrary -- privateProjectArticleId :: Integer
    <*> arbitrary -- privateProjectArticleTitle :: Text
    <*> arbitrary -- privateProjectArticleDoi :: Text
    <*> arbitrary -- privateProjectArticleHandle :: Text
    <*> arbitrary -- privateProjectArticleUrl :: Text
    <*> arbitrary -- privateProjectArticleUrlPublicHtml :: Text
    <*> arbitrary -- privateProjectArticleUrlPublicApi :: Text
    <*> arbitrary -- privateProjectArticleUrlPrivateHtml :: Text
    <*> arbitrary -- privateProjectArticleUrlPrivateApi :: Text
    <*> arbitraryReduced n -- privateProjectArticleTimeline :: Timeline
    <*> arbitrary -- privateProjectArticleThumb :: Text
    <*> arbitrary -- privateProjectArticleDefinedType :: Integer
    <*> arbitrary -- privateProjectArticleDefinedTypeName :: Text
    <*> arbitrary -- privateProjectArticleResourceDoi :: Text
    <*> arbitrary -- privateProjectArticleResourceTitle :: Text
  
instance Arbitrary ProfileUpdateData where
  arbitrary = sized genProfileUpdateData

genProfileUpdateData :: Int -> Gen ProfileUpdateData
genProfileUpdateData n =
  ProfileUpdateData
    <$> arbitraryReducedMaybe n -- profileUpdateDataFirstName :: Maybe Text
    <*> arbitraryReducedMaybe n -- profileUpdateDataLastName :: Maybe Text
    <*> arbitraryReducedMaybe n -- profileUpdateDataOrcid :: Maybe Text
    <*> arbitraryReducedMaybe n -- profileUpdateDataJobTitle :: Maybe Text
    <*> arbitraryReducedMaybe n -- profileUpdateDataFieldsOfInterest :: Maybe [Integer]
    <*> arbitraryReducedMaybe n -- profileUpdateDataFieldsOfInterestBySourceId :: Maybe [Text]
    <*> arbitraryReducedMaybe n -- profileUpdateDataLocation :: Maybe Text
    <*> arbitraryReducedMaybe n -- profileUpdateDataFacebook :: Maybe Text
    <*> arbitraryReducedMaybe n -- profileUpdateDataX :: Maybe Text
    <*> arbitraryReducedMaybe n -- profileUpdateDataLinkedin :: Maybe Text
    <*> arbitraryReducedMaybe n -- profileUpdateDataBio :: Maybe Text
    <*> arbitraryReducedMaybe n -- profileUpdateDataPersonalProfiles :: Maybe [ProfileUpdateDataPersonalProfilesInner]
  
instance Arbitrary ProfileUpdateDataPersonalProfilesInner where
  arbitrary = sized genProfileUpdateDataPersonalProfilesInner

genProfileUpdateDataPersonalProfilesInner :: Int -> Gen ProfileUpdateDataPersonalProfilesInner
genProfileUpdateDataPersonalProfilesInner n =
  ProfileUpdateDataPersonalProfilesInner
    <$> arbitraryReducedMaybe n -- profileUpdateDataPersonalProfilesInnerLabel :: Maybe Text
    <*> arbitraryReducedMaybe n -- profileUpdateDataPersonalProfilesInnerUrl :: Maybe Text
  
instance Arbitrary Project where
  arbitrary = sized genProject

genProject :: Int -> Gen Project
genProject n =
  Project
    <$> arbitrary -- projectUrl :: Text
    <*> arbitrary -- projectId :: Integer
    <*> arbitrary -- projectTitle :: Text
    <*> arbitrary -- projectCreatedDate :: Text
    <*> arbitrary -- projectModifiedDate :: Text
  
instance Arbitrary ProjectArticle where
  arbitrary = sized genProjectArticle

genProjectArticle :: Int -> Gen ProjectArticle
genProjectArticle n =
  ProjectArticle
    <$> arbitrary -- projectArticleCitation :: Text
    <*> arbitrary -- projectArticleConfidentialReason :: Text
    <*> arbitrary -- projectArticleIsConfidential :: Bool
    <*> arbitrary -- projectArticleSize :: Integer
    <*> arbitrary -- projectArticleFunding :: Text
    <*> arbitraryReduced n -- projectArticleFundingList :: [FundingInformation]
    <*> arbitrary -- projectArticleTags :: [Text]
    <*> arbitrary -- projectArticleKeywords :: [Text]
    <*> arbitrary -- projectArticleVersion :: Integer
    <*> arbitrary -- projectArticleIsMetadataRecord :: Bool
    <*> arbitrary -- projectArticleMetadataReason :: Text
    <*> arbitrary -- projectArticleStatus :: Text
    <*> arbitrary -- projectArticleDescription :: Text
    <*> arbitrary -- projectArticleIsEmbargoed :: Bool
    <*> arbitrary -- projectArticleIsPublic :: Bool
    <*> arbitrary -- projectArticleCreatedDate :: Text
    <*> arbitrary -- projectArticleHasLinkedFile :: Bool
    <*> arbitraryReduced n -- projectArticleCategories :: [Category]
    <*> arbitraryReduced n -- projectArticleLicense :: License
    <*> arbitrary -- projectArticleEmbargoTitle :: Text
    <*> arbitrary -- projectArticleEmbargoReason :: Text
    <*> arbitrary -- projectArticleReferences :: [Text]
    <*> arbitraryReducedMaybe n -- projectArticleRelatedMaterials :: Maybe [RelatedMaterial]
    <*> arbitrary -- projectArticleId :: Integer
    <*> arbitrary -- projectArticleTitle :: Text
    <*> arbitrary -- projectArticleDoi :: Text
    <*> arbitrary -- projectArticleHandle :: Text
    <*> arbitrary -- projectArticleUrl :: Text
    <*> arbitrary -- projectArticleUrlPublicHtml :: Text
    <*> arbitrary -- projectArticleUrlPublicApi :: Text
    <*> arbitrary -- projectArticleUrlPrivateHtml :: Text
    <*> arbitrary -- projectArticleUrlPrivateApi :: Text
    <*> arbitraryReduced n -- projectArticleTimeline :: Timeline
    <*> arbitrary -- projectArticleThumb :: Text
    <*> arbitrary -- projectArticleDefinedType :: Integer
    <*> arbitrary -- projectArticleDefinedTypeName :: Text
    <*> arbitrary -- projectArticleResourceDoi :: Text
    <*> arbitrary -- projectArticleResourceTitle :: Text
  
instance Arbitrary ProjectCollaborator where
  arbitrary = sized genProjectCollaborator

genProjectCollaborator :: Int -> Gen ProjectCollaborator
genProjectCollaborator n =
  ProjectCollaborator
    <$> arbitrary -- projectCollaboratorStatus :: Text
    <*> arbitrary -- projectCollaboratorRoleName :: Text
    <*> arbitrary -- projectCollaboratorUserId :: Int
    <*> arbitrary -- projectCollaboratorName :: Text
  
instance Arbitrary ProjectCollaboratorInvite where
  arbitrary = sized genProjectCollaboratorInvite

genProjectCollaboratorInvite :: Int -> Gen ProjectCollaboratorInvite
genProjectCollaboratorInvite n =
  ProjectCollaboratorInvite
    <$> arbitrary -- projectCollaboratorInviteRoleName :: E'RoleName
    <*> arbitraryReducedMaybe n -- projectCollaboratorInviteUserId :: Maybe Integer
    <*> arbitraryReducedMaybe n -- projectCollaboratorInviteEmail :: Maybe Text
    <*> arbitraryReducedMaybe n -- projectCollaboratorInviteComment :: Maybe Text
  
instance Arbitrary ProjectComplete where
  arbitrary = sized genProjectComplete

genProjectComplete :: Int -> Gen ProjectComplete
genProjectComplete n =
  ProjectComplete
    <$> arbitrary -- projectCompleteFunding :: Text
    <*> arbitraryReduced n -- projectCompleteFundingList :: [FundingInformation]
    <*> arbitrary -- projectCompleteDescription :: Text
    <*> arbitraryReduced n -- projectCompleteCollaborators :: [Collaborator]
    <*> arbitraryReduced n -- projectCompleteCustomFields :: [CustomArticleField]
    <*> arbitrary -- projectCompleteModifiedDate :: Text
    <*> arbitrary -- projectCompleteCreatedDate :: Text
    <*> arbitrary -- projectCompleteUrl :: Text
    <*> arbitrary -- projectCompleteId :: Integer
    <*> arbitrary -- projectCompleteTitle :: Text
  
instance Arbitrary ProjectCompletePrivate where
  arbitrary = sized genProjectCompletePrivate

genProjectCompletePrivate :: Int -> Gen ProjectCompletePrivate
genProjectCompletePrivate n =
  ProjectCompletePrivate
    <$> arbitrary -- projectCompletePrivateFunding :: Text
    <*> arbitraryReduced n -- projectCompletePrivateFundingList :: [FundingInformation]
    <*> arbitrary -- projectCompletePrivateDescription :: Text
    <*> arbitraryReduced n -- projectCompletePrivateCollaborators :: [Collaborator]
    <*> arbitrary -- projectCompletePrivateQuota :: Integer
    <*> arbitrary -- projectCompletePrivateUsedQuota :: Integer
    <*> arbitrary -- projectCompletePrivateCreatedDate :: Text
    <*> arbitrary -- projectCompletePrivateModifiedDate :: Text
    <*> arbitrary -- projectCompletePrivateUsedQuotaPrivate :: Integer
    <*> arbitrary -- projectCompletePrivateUsedQuotaPublic :: Integer
    <*> arbitrary -- projectCompletePrivateGroupId :: Integer
    <*> arbitrary -- projectCompletePrivateAccountId :: Integer
    <*> arbitraryReduced n -- projectCompletePrivateCustomFields :: [ShortCustomField]
    <*> arbitrary -- projectCompletePrivateRole :: E'Role
    <*> arbitrary -- projectCompletePrivateStorage :: E'Storage
    <*> arbitrary -- projectCompletePrivateUrl :: Text
    <*> arbitrary -- projectCompletePrivateId :: Integer
    <*> arbitrary -- projectCompletePrivateTitle :: Text
  
instance Arbitrary ProjectCreate where
  arbitrary = sized genProjectCreate

genProjectCreate :: Int -> Gen ProjectCreate
genProjectCreate n =
  ProjectCreate
    <$> arbitrary -- projectCreateTitle :: Text
    <*> arbitraryReducedMaybe n -- projectCreateDescription :: Maybe Text
    <*> arbitraryReducedMaybe n -- projectCreateFunding :: Maybe Text
    <*> arbitraryReducedMaybe n -- projectCreateFundingList :: Maybe [FundingCreate]
    <*> arbitraryReducedMaybe n -- projectCreateGroupId :: Maybe Integer
    <*> arbitraryReducedMaybeValue n -- projectCreateCustomFields :: Maybe A.Value
    <*> arbitraryReducedMaybe n -- projectCreateCustomFieldsList :: Maybe [CustomArticleFieldAdd]
  
instance Arbitrary ProjectNote where
  arbitrary = sized genProjectNote

genProjectNote :: Int -> Gen ProjectNote
genProjectNote n =
  ProjectNote
    <$> arbitrary -- projectNoteId :: Integer
    <*> arbitrary -- projectNoteUserId :: Integer
    <*> arbitrary -- projectNoteAbstract :: Text
    <*> arbitrary -- projectNoteUserName :: Text
    <*> arbitrary -- projectNoteCreatedDate :: Text
    <*> arbitrary -- projectNoteModifiedDate :: Text
  
instance Arbitrary ProjectNoteCreate where
  arbitrary = sized genProjectNoteCreate

genProjectNoteCreate :: Int -> Gen ProjectNoteCreate
genProjectNoteCreate n =
  ProjectNoteCreate
    <$> arbitrary -- projectNoteCreateText :: Text
  
instance Arbitrary ProjectNotePrivate where
  arbitrary = sized genProjectNotePrivate

genProjectNotePrivate :: Int -> Gen ProjectNotePrivate
genProjectNotePrivate n =
  ProjectNotePrivate
    <$> arbitrary -- projectNotePrivateText :: Text
    <*> arbitrary -- projectNotePrivateId :: Integer
    <*> arbitrary -- projectNotePrivateUserId :: Integer
    <*> arbitrary -- projectNotePrivateAbstract :: Text
    <*> arbitrary -- projectNotePrivateUserName :: Text
    <*> arbitrary -- projectNotePrivateCreatedDate :: Text
    <*> arbitrary -- projectNotePrivateModifiedDate :: Text
  
instance Arbitrary ProjectPrivate where
  arbitrary = sized genProjectPrivate

genProjectPrivate :: Int -> Gen ProjectPrivate
genProjectPrivate n =
  ProjectPrivate
    <$> arbitrary -- projectPrivateRole :: E'Role
    <*> arbitrary -- projectPrivateStorage :: E'Storage
    <*> arbitrary -- projectPrivateUrl :: Text
    <*> arbitrary -- projectPrivateId :: Integer
    <*> arbitrary -- projectPrivateTitle :: Text
    <*> arbitrary -- projectPrivateCreatedDate :: Text
    <*> arbitrary -- projectPrivateModifiedDate :: Text
  
instance Arbitrary ProjectUpdate where
  arbitrary = sized genProjectUpdate

genProjectUpdate :: Int -> Gen ProjectUpdate
genProjectUpdate n =
  ProjectUpdate
    <$> arbitraryReducedMaybe n -- projectUpdateTitle :: Maybe Text
    <*> arbitraryReducedMaybe n -- projectUpdateDescription :: Maybe Text
    <*> arbitraryReducedMaybe n -- projectUpdateFunding :: Maybe Text
    <*> arbitraryReducedMaybe n -- projectUpdateFundingList :: Maybe [FundingCreate]
    <*> arbitraryReducedMaybeValue n -- projectUpdateCustomFields :: Maybe A.Value
    <*> arbitraryReducedMaybe n -- projectUpdateCustomFieldsList :: Maybe [CustomArticleFieldAdd]
  
instance Arbitrary ProjectsSearch where
  arbitrary = sized genProjectsSearch

genProjectsSearch :: Int -> Gen ProjectsSearch
genProjectsSearch n =
  ProjectsSearch
    <$> arbitraryReducedMaybe n -- projectsSearchOrder :: Maybe E'Order3
    <*> arbitraryReducedMaybe n -- projectsSearchSearchFor :: Maybe Text
    <*> arbitraryReducedMaybe n -- projectsSearchPage :: Maybe Integer
    <*> arbitraryReducedMaybe n -- projectsSearchPageSize :: Maybe Integer
    <*> arbitraryReducedMaybe n -- projectsSearchLimit :: Maybe Integer
    <*> arbitraryReducedMaybe n -- projectsSearchOffset :: Maybe Integer
    <*> arbitraryReducedMaybe n -- projectsSearchOrderDirection :: Maybe E'OrderDirection
    <*> arbitraryReducedMaybe n -- projectsSearchInstitution :: Maybe Int
    <*> arbitraryReducedMaybe n -- projectsSearchPublishedSince :: Maybe Text
    <*> arbitraryReducedMaybe n -- projectsSearchModifiedSince :: Maybe Text
    <*> arbitraryReducedMaybe n -- projectsSearchGroup :: Maybe Int
  
instance Arbitrary PublicFile where
  arbitrary = sized genPublicFile

genPublicFile :: Int -> Gen PublicFile
genPublicFile n =
  PublicFile
    <$> arbitrary -- publicFileId :: Integer
    <*> arbitrary -- publicFileName :: Text
    <*> arbitrary -- publicFileSize :: Integer
    <*> arbitrary -- publicFileIsLinkOnly :: Bool
    <*> arbitrary -- publicFileDownloadUrl :: Text
    <*> arbitrary -- publicFileSuppliedMd5 :: Text
    <*> arbitrary -- publicFileComputedMd5 :: Text
    <*> arbitraryReducedMaybe n -- publicFileMimetype :: Maybe Text
  
instance Arbitrary RelatedMaterial where
  arbitrary = sized genRelatedMaterial

genRelatedMaterial :: Int -> Gen RelatedMaterial
genRelatedMaterial n =
  RelatedMaterial
    <$> arbitraryReducedMaybe n -- relatedMaterialId :: Maybe Integer
    <*> arbitraryReducedMaybe n -- relatedMaterialIdentifier :: Maybe Text
    <*> arbitraryReducedMaybe n -- relatedMaterialTitle :: Maybe Text
    <*> arbitraryReducedMaybe n -- relatedMaterialRelation :: Maybe E'Relation
    <*> arbitraryReducedMaybe n -- relatedMaterialIdentifierType :: Maybe E'IdentifierType
    <*> arbitraryReducedMaybe n -- relatedMaterialIsLinkout :: Maybe Bool
    <*> arbitraryReducedMaybe n -- relatedMaterialLink :: Maybe Text
  
instance Arbitrary Resource where
  arbitrary = sized genResource

genResource :: Int -> Gen Resource
genResource n =
  Resource
    <$> arbitraryReducedMaybe n -- resourceId :: Maybe Text
    <*> arbitraryReducedMaybe n -- resourceTitle :: Maybe Text
    <*> arbitraryReducedMaybe n -- resourceDoi :: Maybe Text
    <*> arbitraryReducedMaybe n -- resourceLink :: Maybe Text
    <*> arbitraryReducedMaybe n -- resourceStatus :: Maybe Text
    <*> arbitraryReducedMaybe n -- resourceVersion :: Maybe Integer
  
instance Arbitrary ResponseMessage where
  arbitrary = sized genResponseMessage

genResponseMessage :: Int -> Gen ResponseMessage
genResponseMessage n =
  ResponseMessage
    <$> arbitrary -- responseMessageMessage :: Text
  
instance Arbitrary Role where
  arbitrary = sized genRole

genRole :: Int -> Gen Role
genRole n =
  Role
    <$> arbitrary -- roleId :: Integer
    <*> arbitrary -- roleName :: Text
    <*> arbitrary -- roleCategory :: Text
    <*> arbitrary -- roleDescription :: Text
  
instance Arbitrary ShortAccount where
  arbitrary = sized genShortAccount

genShortAccount :: Int -> Gen ShortAccount
genShortAccount n =
  ShortAccount
    <$> arbitrary -- shortAccountId :: Integer
    <*> arbitrary -- shortAccountFirstName :: Text
    <*> arbitrary -- shortAccountLastName :: Text
    <*> arbitrary -- shortAccountInstitutionId :: Integer
    <*> arbitrary -- shortAccountEmail :: Text
    <*> arbitrary -- shortAccountActive :: Integer
    <*> arbitrary -- shortAccountInstitutionUserId :: Text
    <*> arbitrary -- shortAccountQuota :: Integer
    <*> arbitrary -- shortAccountUsedQuota :: Integer
    <*> arbitrary -- shortAccountUserId :: Integer
    <*> arbitrary -- shortAccountOrcidId :: Text
    <*> arbitrary -- shortAccountSymplecticUserId :: Text
  
instance Arbitrary ShortCustomField where
  arbitrary = sized genShortCustomField

genShortCustomField :: Int -> Gen ShortCustomField
genShortCustomField n =
  ShortCustomField
    <$> arbitrary -- shortCustomFieldId :: Integer
    <*> arbitrary -- shortCustomFieldName :: Text
    <*> arbitrary -- shortCustomFieldFieldType :: E'FieldType
    <*> arbitraryReducedMaybeValue n -- shortCustomFieldSettings :: Maybe A.Value
    <*> arbitraryReducedMaybe n -- shortCustomFieldOrder :: Maybe Integer
    <*> arbitraryReducedMaybe n -- shortCustomFieldIsMandatory :: Maybe Bool
  
instance Arbitrary Timeline where
  arbitrary = sized genTimeline

genTimeline :: Int -> Gen Timeline
genTimeline n =
  Timeline
    <$> arbitraryReducedMaybe n -- timelineFirstOnline :: Maybe Text
    <*> arbitraryReducedMaybe n -- timelinePublisherPublication :: Maybe Text
    <*> arbitraryReducedMaybe n -- timelinePublisherAcceptance :: Maybe Text
  
instance Arbitrary TimelineUpdate where
  arbitrary = sized genTimelineUpdate

genTimelineUpdate :: Int -> Gen TimelineUpdate
genTimelineUpdate n =
  TimelineUpdate
    <$> arbitraryReducedMaybe n -- timelineUpdateFirstOnline :: Maybe Text
    <*> arbitraryReducedMaybe n -- timelineUpdatePublisherPublication :: Maybe Text
    <*> arbitraryReducedMaybe n -- timelineUpdatePublisherAcceptance :: Maybe Text
  
instance Arbitrary UploadFilePart where
  arbitrary = sized genUploadFilePart

genUploadFilePart :: Int -> Gen UploadFilePart
genUploadFilePart n =
  UploadFilePart
    <$> arbitraryReducedMaybe n -- uploadFilePartPartNo :: Maybe Integer
    <*> arbitraryReducedMaybe n -- uploadFilePartStartOffset :: Maybe Integer
    <*> arbitraryReducedMaybe n -- uploadFilePartEndOffset :: Maybe Integer
    <*> arbitraryReducedMaybe n -- uploadFilePartStatus :: Maybe E'Status3
    <*> arbitraryReducedMaybe n -- uploadFilePartLocked :: Maybe Bool
  
instance Arbitrary UploadInfo where
  arbitrary = sized genUploadInfo

genUploadInfo :: Int -> Gen UploadInfo
genUploadInfo n =
  UploadInfo
    <$> arbitraryReducedMaybe n -- uploadInfoToken :: Maybe Text
    <*> arbitraryReducedMaybe n -- uploadInfoMd5 :: Maybe Text
    <*> arbitraryReducedMaybe n -- uploadInfoSize :: Maybe Integer
    <*> arbitraryReducedMaybe n -- uploadInfoName :: Maybe Text
    <*> arbitraryReducedMaybe n -- uploadInfoStatus :: Maybe E'Status4
    <*> arbitraryReducedMaybe n -- uploadInfoParts :: Maybe [UploadFilePart]
  
instance Arbitrary User where
  arbitrary = sized genUser

genUser :: Int -> Gen User
genUser n =
  User
    <$> arbitrary -- userId :: Integer
    <*> arbitrary -- userFirstName :: Text
    <*> arbitrary -- userLastName :: Text
    <*> arbitrary -- userName :: Text
    <*> arbitrary -- userIsActive :: Bool
    <*> arbitrary -- userUrlName :: Text
    <*> arbitrary -- userIsPublic :: Bool
    <*> arbitrary -- userJobTitle :: Text
    <*> arbitrary -- userOrcidId :: Text
  



instance Arbitrary E'EmbargoType where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'FieldType where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'GrantType where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'IdentifierType where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Order where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Order2 where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Order3 where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Order4 where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Order5 where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Order6 where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Order7 where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'OrderDirection where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Relation where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Role where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'RoleName where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Status where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Status2 where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Status3 where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Status4 where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Storage where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Storage2 where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Type where
  arbitrary = arbitraryBoundedEnum

instance Arbitrary E'Type2 where
  arbitrary = arbitraryBoundedEnum

