# CurationComment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The ID of the comment. | [default to null]
**AccountId** | **int64** | The ID of the account which generated this comment. | [default to null]
**Type_** | **string** | The ID of the account which generated this comment. | [default to null]
**Text** | **string** | The value/content of the comment. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


