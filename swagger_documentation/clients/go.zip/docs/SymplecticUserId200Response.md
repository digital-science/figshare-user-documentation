# SymplecticUserId200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstitutionUserId** | Pointer to **string** |  | [optional] 

## Methods

### NewSymplecticUserId200Response

`func NewSymplecticUserId200Response() *SymplecticUserId200Response`

NewSymplecticUserId200Response instantiates a new SymplecticUserId200Response object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewSymplecticUserId200ResponseWithDefaults

`func NewSymplecticUserId200ResponseWithDefaults() *SymplecticUserId200Response`

NewSymplecticUserId200ResponseWithDefaults instantiates a new SymplecticUserId200Response object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInstitutionUserId

`func (o *SymplecticUserId200Response) GetInstitutionUserId() string`

GetInstitutionUserId returns the InstitutionUserId field if non-nil, zero value otherwise.

### GetInstitutionUserIdOk

`func (o *SymplecticUserId200Response) GetInstitutionUserIdOk() (*string, bool)`

GetInstitutionUserIdOk returns a tuple with the InstitutionUserId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstitutionUserId

`func (o *SymplecticUserId200Response) SetInstitutionUserId(v string)`

SetInstitutionUserId sets InstitutionUserId field to given value.

### HasInstitutionUserId

`func (o *SymplecticUserId200Response) HasInstitutionUserId() bool`

HasInstitutionUserId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


