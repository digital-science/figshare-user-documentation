# AltmetricInstitution

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Institution id | 
**Name** | **string** | Institution name | 
**CustomDomain** | Pointer to **NullableString** | Custom domain for the institution | [optional] 

## Methods

### NewAltmetricInstitution

`func NewAltmetricInstitution(id int32, name string, ) *AltmetricInstitution`

NewAltmetricInstitution instantiates a new AltmetricInstitution object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAltmetricInstitutionWithDefaults

`func NewAltmetricInstitutionWithDefaults() *AltmetricInstitution`

NewAltmetricInstitutionWithDefaults instantiates a new AltmetricInstitution object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *AltmetricInstitution) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *AltmetricInstitution) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *AltmetricInstitution) SetId(v int32)`

SetId sets Id field to given value.


### GetName

`func (o *AltmetricInstitution) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *AltmetricInstitution) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *AltmetricInstitution) SetName(v string)`

SetName sets Name field to given value.


### GetCustomDomain

`func (o *AltmetricInstitution) GetCustomDomain() string`

GetCustomDomain returns the CustomDomain field if non-nil, zero value otherwise.

### GetCustomDomainOk

`func (o *AltmetricInstitution) GetCustomDomainOk() (*string, bool)`

GetCustomDomainOk returns a tuple with the CustomDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCustomDomain

`func (o *AltmetricInstitution) SetCustomDomain(v string)`

SetCustomDomain sets CustomDomain field to given value.

### HasCustomDomain

`func (o *AltmetricInstitution) HasCustomDomain() bool`

HasCustomDomain returns a boolean if a field has been set.

### SetCustomDomainNil

`func (o *AltmetricInstitution) SetCustomDomainNil(b bool)`

 SetCustomDomainNil sets the value for CustomDomain to be an explicit nil

### UnsetCustomDomain
`func (o *AltmetricInstitution) UnsetCustomDomain()`

UnsetCustomDomain ensures that no value is present for CustomDomain, not even an explicit nil

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


