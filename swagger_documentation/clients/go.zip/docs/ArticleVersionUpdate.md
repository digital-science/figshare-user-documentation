# ArticleVersionUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SupplementaryFields** | **[]interface{}** | List of supplementary fields to be associated with the article version | [optional] [default to null]
**InternalMetadata** | **interface{}** | List of supplementary fields to be associated with the article version | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


