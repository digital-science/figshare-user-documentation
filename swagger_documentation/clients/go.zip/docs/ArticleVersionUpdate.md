# ArticleVersionUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SupplementaryFields** | Pointer to **[]map[string]interface{}** | List of supplementary fields to be associated with the article version | [optional] 
**InternalMetadata** | Pointer to **map[string]interface{}** | List of supplementary fields to be associated with the article version | [optional] 

## Methods

### NewArticleVersionUpdate

`func NewArticleVersionUpdate() *ArticleVersionUpdate`

NewArticleVersionUpdate instantiates a new ArticleVersionUpdate object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewArticleVersionUpdateWithDefaults

`func NewArticleVersionUpdateWithDefaults() *ArticleVersionUpdate`

NewArticleVersionUpdateWithDefaults instantiates a new ArticleVersionUpdate object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSupplementaryFields

`func (o *ArticleVersionUpdate) GetSupplementaryFields() []map[string]interface{}`

GetSupplementaryFields returns the SupplementaryFields field if non-nil, zero value otherwise.

### GetSupplementaryFieldsOk

`func (o *ArticleVersionUpdate) GetSupplementaryFieldsOk() (*[]map[string]interface{}, bool)`

GetSupplementaryFieldsOk returns a tuple with the SupplementaryFields field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupplementaryFields

`func (o *ArticleVersionUpdate) SetSupplementaryFields(v []map[string]interface{})`

SetSupplementaryFields sets SupplementaryFields field to given value.

### HasSupplementaryFields

`func (o *ArticleVersionUpdate) HasSupplementaryFields() bool`

HasSupplementaryFields returns a boolean if a field has been set.

### GetInternalMetadata

`func (o *ArticleVersionUpdate) GetInternalMetadata() map[string]interface{}`

GetInternalMetadata returns the InternalMetadata field if non-nil, zero value otherwise.

### GetInternalMetadataOk

`func (o *ArticleVersionUpdate) GetInternalMetadataOk() (*map[string]interface{}, bool)`

GetInternalMetadataOk returns a tuple with the InternalMetadata field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInternalMetadata

`func (o *ArticleVersionUpdate) SetInternalMetadata(v map[string]interface{})`

SetInternalMetadata sets InternalMetadata field to given value.

### HasInternalMetadata

`func (o *ArticleVersionUpdate) HasInternalMetadata() bool`

HasInternalMetadata returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


