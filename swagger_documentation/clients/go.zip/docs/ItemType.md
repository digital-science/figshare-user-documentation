# ItemType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | The ID of the item type. | 
**Name** | **string** | The name of the item type | 
**StringId** | **string** | The string identifier of the item type. | 
**Icon** | **string** | The string identifying the icon of the item type. | 
**PublicDescription** | **string** | The description of the item type. | 
**IsSelectable** | **bool** | The selectable status | 
**UrlName** | **string** | The URL name of the item type. | 

## Methods

### NewItemType

`func NewItemType(id int64, name string, stringId string, icon string, publicDescription string, isSelectable bool, urlName string, ) *ItemType`

NewItemType instantiates a new ItemType object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewItemTypeWithDefaults

`func NewItemTypeWithDefaults() *ItemType`

NewItemTypeWithDefaults instantiates a new ItemType object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *ItemType) GetId() int64`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *ItemType) GetIdOk() (*int64, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *ItemType) SetId(v int64)`

SetId sets Id field to given value.


### GetName

`func (o *ItemType) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *ItemType) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *ItemType) SetName(v string)`

SetName sets Name field to given value.


### GetStringId

`func (o *ItemType) GetStringId() string`

GetStringId returns the StringId field if non-nil, zero value otherwise.

### GetStringIdOk

`func (o *ItemType) GetStringIdOk() (*string, bool)`

GetStringIdOk returns a tuple with the StringId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStringId

`func (o *ItemType) SetStringId(v string)`

SetStringId sets StringId field to given value.


### GetIcon

`func (o *ItemType) GetIcon() string`

GetIcon returns the Icon field if non-nil, zero value otherwise.

### GetIconOk

`func (o *ItemType) GetIconOk() (*string, bool)`

GetIconOk returns a tuple with the Icon field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIcon

`func (o *ItemType) SetIcon(v string)`

SetIcon sets Icon field to given value.


### GetPublicDescription

`func (o *ItemType) GetPublicDescription() string`

GetPublicDescription returns the PublicDescription field if non-nil, zero value otherwise.

### GetPublicDescriptionOk

`func (o *ItemType) GetPublicDescriptionOk() (*string, bool)`

GetPublicDescriptionOk returns a tuple with the PublicDescription field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPublicDescription

`func (o *ItemType) SetPublicDescription(v string)`

SetPublicDescription sets PublicDescription field to given value.


### GetIsSelectable

`func (o *ItemType) GetIsSelectable() bool`

GetIsSelectable returns the IsSelectable field if non-nil, zero value otherwise.

### GetIsSelectableOk

`func (o *ItemType) GetIsSelectableOk() (*bool, bool)`

GetIsSelectableOk returns a tuple with the IsSelectable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsSelectable

`func (o *ItemType) SetIsSelectable(v bool)`

SetIsSelectable sets IsSelectable field to given value.


### GetUrlName

`func (o *ItemType) GetUrlName() string`

GetUrlName returns the UrlName field if non-nil, zero value otherwise.

### GetUrlNameOk

`func (o *ItemType) GetUrlNameOk() (*string, bool)`

GetUrlNameOk returns a tuple with the UrlName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUrlName

`func (o *ItemType) SetUrlName(v string)`

SetUrlName sets UrlName field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


