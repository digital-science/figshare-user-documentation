# CustomArticleField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Custom  metadata name | [default to null]
**Value** | **interface{}** | Custom metadata value (can be either a string or an array of strings) | [default to null]
**FieldType** | **string** | Custom field type | [default to null]
**Settings** | **interface{}** | Settings for the custom field | [default to null]
**Order** | **int64** | Order of the custom field | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


