# CollectionDOI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Doi** | **string** | Reserved DOI | 

## Methods

### NewCollectionDOI

`func NewCollectionDOI(doi string, ) *CollectionDOI`

NewCollectionDOI instantiates a new CollectionDOI object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCollectionDOIWithDefaults

`func NewCollectionDOIWithDefaults() *CollectionDOI`

NewCollectionDOIWithDefaults instantiates a new CollectionDOI object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDoi

`func (o *CollectionDOI) GetDoi() string`

GetDoi returns the Doi field if non-nil, zero value otherwise.

### GetDoiOk

`func (o *CollectionDOI) GetDoiOk() (*string, bool)`

GetDoiOk returns a tuple with the Doi field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDoi

`func (o *CollectionDOI) SetDoi(v string)`

SetDoi sets Doi field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


