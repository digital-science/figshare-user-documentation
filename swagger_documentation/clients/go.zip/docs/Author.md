# Author

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | Author id | 
**FullName** | **string** | Author full name | 
**FirstName** | **string** | Author first name | 
**LastName** | **string** | Author last name | 
**IsActive** | **bool** | True if author has published items | 
**UrlName** | **string** | Author url name | 
**OrcidId** | **string** | Author Orcid | 

## Methods

### NewAuthor

`func NewAuthor(id int64, fullName string, firstName string, lastName string, isActive bool, urlName string, orcidId string, ) *Author`

NewAuthor instantiates a new Author object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAuthorWithDefaults

`func NewAuthorWithDefaults() *Author`

NewAuthorWithDefaults instantiates a new Author object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *Author) GetId() int64`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Author) GetIdOk() (*int64, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Author) SetId(v int64)`

SetId sets Id field to given value.


### GetFullName

`func (o *Author) GetFullName() string`

GetFullName returns the FullName field if non-nil, zero value otherwise.

### GetFullNameOk

`func (o *Author) GetFullNameOk() (*string, bool)`

GetFullNameOk returns a tuple with the FullName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFullName

`func (o *Author) SetFullName(v string)`

SetFullName sets FullName field to given value.


### GetFirstName

`func (o *Author) GetFirstName() string`

GetFirstName returns the FirstName field if non-nil, zero value otherwise.

### GetFirstNameOk

`func (o *Author) GetFirstNameOk() (*string, bool)`

GetFirstNameOk returns a tuple with the FirstName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirstName

`func (o *Author) SetFirstName(v string)`

SetFirstName sets FirstName field to given value.


### GetLastName

`func (o *Author) GetLastName() string`

GetLastName returns the LastName field if non-nil, zero value otherwise.

### GetLastNameOk

`func (o *Author) GetLastNameOk() (*string, bool)`

GetLastNameOk returns a tuple with the LastName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastName

`func (o *Author) SetLastName(v string)`

SetLastName sets LastName field to given value.


### GetIsActive

`func (o *Author) GetIsActive() bool`

GetIsActive returns the IsActive field if non-nil, zero value otherwise.

### GetIsActiveOk

`func (o *Author) GetIsActiveOk() (*bool, bool)`

GetIsActiveOk returns a tuple with the IsActive field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsActive

`func (o *Author) SetIsActive(v bool)`

SetIsActive sets IsActive field to given value.


### GetUrlName

`func (o *Author) GetUrlName() string`

GetUrlName returns the UrlName field if non-nil, zero value otherwise.

### GetUrlNameOk

`func (o *Author) GetUrlNameOk() (*string, bool)`

GetUrlNameOk returns a tuple with the UrlName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUrlName

`func (o *Author) SetUrlName(v string)`

SetUrlName sets UrlName field to given value.


### GetOrcidId

`func (o *Author) GetOrcidId() string`

GetOrcidId returns the OrcidId field if non-nil, zero value otherwise.

### GetOrcidIdOk

`func (o *Author) GetOrcidIdOk() (*string, bool)`

GetOrcidIdOk returns a tuple with the OrcidId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOrcidId

`func (o *Author) SetOrcidId(v string)`

SetOrcidId sets OrcidId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


