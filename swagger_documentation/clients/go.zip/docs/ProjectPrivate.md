# ProjectPrivate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Role** | **string** | Role inside this project | 
**Storage** | **string** | Project storage type | 
**Url** | **string** | Api endpoint | 
**Id** | **int64** | Project id | 
**Title** | **string** | Project title | 
**CreatedDate** | **string** | Date when project was created | 
**ModifiedDate** | **string** | Date when project was last modified | 

## Methods

### NewProjectPrivate

`func NewProjectPrivate(role string, storage string, url string, id int64, title string, createdDate string, modifiedDate string, ) *ProjectPrivate`

NewProjectPrivate instantiates a new ProjectPrivate object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewProjectPrivateWithDefaults

`func NewProjectPrivateWithDefaults() *ProjectPrivate`

NewProjectPrivateWithDefaults instantiates a new ProjectPrivate object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRole

`func (o *ProjectPrivate) GetRole() string`

GetRole returns the Role field if non-nil, zero value otherwise.

### GetRoleOk

`func (o *ProjectPrivate) GetRoleOk() (*string, bool)`

GetRoleOk returns a tuple with the Role field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRole

`func (o *ProjectPrivate) SetRole(v string)`

SetRole sets Role field to given value.


### GetStorage

`func (o *ProjectPrivate) GetStorage() string`

GetStorage returns the Storage field if non-nil, zero value otherwise.

### GetStorageOk

`func (o *ProjectPrivate) GetStorageOk() (*string, bool)`

GetStorageOk returns a tuple with the Storage field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorage

`func (o *ProjectPrivate) SetStorage(v string)`

SetStorage sets Storage field to given value.


### GetUrl

`func (o *ProjectPrivate) GetUrl() string`

GetUrl returns the Url field if non-nil, zero value otherwise.

### GetUrlOk

`func (o *ProjectPrivate) GetUrlOk() (*string, bool)`

GetUrlOk returns a tuple with the Url field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUrl

`func (o *ProjectPrivate) SetUrl(v string)`

SetUrl sets Url field to given value.


### GetId

`func (o *ProjectPrivate) GetId() int64`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *ProjectPrivate) GetIdOk() (*int64, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *ProjectPrivate) SetId(v int64)`

SetId sets Id field to given value.


### GetTitle

`func (o *ProjectPrivate) GetTitle() string`

GetTitle returns the Title field if non-nil, zero value otherwise.

### GetTitleOk

`func (o *ProjectPrivate) GetTitleOk() (*string, bool)`

GetTitleOk returns a tuple with the Title field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTitle

`func (o *ProjectPrivate) SetTitle(v string)`

SetTitle sets Title field to given value.


### GetCreatedDate

`func (o *ProjectPrivate) GetCreatedDate() string`

GetCreatedDate returns the CreatedDate field if non-nil, zero value otherwise.

### GetCreatedDateOk

`func (o *ProjectPrivate) GetCreatedDateOk() (*string, bool)`

GetCreatedDateOk returns a tuple with the CreatedDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreatedDate

`func (o *ProjectPrivate) SetCreatedDate(v string)`

SetCreatedDate sets CreatedDate field to given value.


### GetModifiedDate

`func (o *ProjectPrivate) GetModifiedDate() string`

GetModifiedDate returns the ModifiedDate field if non-nil, zero value otherwise.

### GetModifiedDateOk

`func (o *ProjectPrivate) GetModifiedDateOk() (*string, bool)`

GetModifiedDateOk returns a tuple with the ModifiedDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModifiedDate

`func (o *ProjectPrivate) SetModifiedDate(v string)`

SetModifiedDate sets ModifiedDate field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


