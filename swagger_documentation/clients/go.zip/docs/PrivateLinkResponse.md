# PrivateLinkResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Location** | **string** | Url for private link | 
**HtmlLocation** | **string** | HTML url for private link | 
**Token** | **string** | Token for private link | 

## Methods

### NewPrivateLinkResponse

`func NewPrivateLinkResponse(location string, htmlLocation string, token string, ) *PrivateLinkResponse`

NewPrivateLinkResponse instantiates a new PrivateLinkResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewPrivateLinkResponseWithDefaults

`func NewPrivateLinkResponseWithDefaults() *PrivateLinkResponse`

NewPrivateLinkResponseWithDefaults instantiates a new PrivateLinkResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLocation

`func (o *PrivateLinkResponse) GetLocation() string`

GetLocation returns the Location field if non-nil, zero value otherwise.

### GetLocationOk

`func (o *PrivateLinkResponse) GetLocationOk() (*string, bool)`

GetLocationOk returns a tuple with the Location field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocation

`func (o *PrivateLinkResponse) SetLocation(v string)`

SetLocation sets Location field to given value.


### GetHtmlLocation

`func (o *PrivateLinkResponse) GetHtmlLocation() string`

GetHtmlLocation returns the HtmlLocation field if non-nil, zero value otherwise.

### GetHtmlLocationOk

`func (o *PrivateLinkResponse) GetHtmlLocationOk() (*string, bool)`

GetHtmlLocationOk returns a tuple with the HtmlLocation field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHtmlLocation

`func (o *PrivateLinkResponse) SetHtmlLocation(v string)`

SetHtmlLocation sets HtmlLocation field to given value.


### GetToken

`func (o *PrivateLinkResponse) GetToken() string`

GetToken returns the Token field if non-nil, zero value otherwise.

### GetTokenOk

`func (o *PrivateLinkResponse) GetTokenOk() (*string, bool)`

GetTokenOk returns a tuple with the Token field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetToken

`func (o *PrivateLinkResponse) SetToken(v string)`

SetToken sets Token field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


