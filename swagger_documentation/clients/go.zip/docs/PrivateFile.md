# PrivateFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int64** | File id | [default to null]
**Name** | **string** | File name | [default to null]
**Size** | **int64** | File size | [default to null]
**IsLinkOnly** | **bool** | True if file is hosted somewhere else | [default to null]
**DownloadUrl** | **string** | Url for file download | [default to null]
**SuppliedMd5** | **string** | File supplied md5 | [default to null]
**ComputedMd5** | **string** | File computed md5 | [default to null]
**Mimetype** | **string** | MIME Type of the file, it defaults to an empty string | [optional] [default to null]
**ViewerType** | **string** | File viewer type | [default to null]
**PreviewState** | **string** | File preview state | [default to null]
**UploadUrl** | **string** | Upload url for file | [default to null]
**UploadToken** | **string** | Token for file upload | [default to null]
**IsAttachedToPublicVersion** | **bool** | True if the file is attached to a public item version | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


