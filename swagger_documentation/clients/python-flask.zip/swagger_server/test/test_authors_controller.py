# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.author_complete import AuthorComplete  # noqa: E501
from swagger_server.models.error_message import ErrorMessage  # noqa: E501
from swagger_server.models.private_authors_search import PrivateAuthorsSearch  # noqa: E501
from swagger_server.test import BaseTestCase


class TestAuthorsController(BaseTestCase):
    """AuthorsController integration test stubs"""

    def test_private_author_details(self):
        """Test case for private_author_details

        Author details
        """
        response = self.client.open(
            '/v2/account/authors/{author_id}'.format(author_id=2),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_authors_search(self):
        """Test case for private_authors_search

        Search Authors
        """
        search = PrivateAuthorsSearch()
        response = self.client.open(
            '/v2/account/authors/search',
            method='POST',
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
