# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.create_o_auth_token import CreateOAuthToken  # noqa: E501
from swagger_server.models.error_message import ErrorMessage  # noqa: E501
from swagger_server.models.o_auth_token import OAuthToken  # noqa: E501
from swagger_server.test import BaseTestCase


class TestOauthController(BaseTestCase):
    """OauthController integration test stubs"""

    def test_create_token(self):
        """Test case for create_token

        Create OAuth token
        """
        body = CreateOAuthToken()
        response = self.client.open(
            '/v2/token',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_token_info(self):
        """Test case for get_token_info

        Get OAuth token information
        """
        query_string = [('access_token', 'access_token_example')]
        response = self.client.open(
            '/v2/token',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
