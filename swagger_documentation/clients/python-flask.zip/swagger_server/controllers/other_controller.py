import connexion
import six

from swagger_server.models.account import Account  # noqa: E501
from swagger_server.models.category import Category  # noqa: E501
from swagger_server.models.error_message import ErrorMessage  # noqa: E501
from swagger_server.models.funding_information import FundingInformation  # noqa: E501
from swagger_server.models.funding_search import FundingSearch  # noqa: E501
from swagger_server.models.item_type import ItemType  # noqa: E501
from swagger_server.models.license import License  # noqa: E501
from swagger_server import util


def categories_list():  # noqa: E501
    """Public Categories

    Returns a list of public categories # noqa: E501


    :rtype: List[Category]
    """
    return 'do some magic!'


def file_download(file_id):  # noqa: E501
    """Public File Download

    Starts the download of a file # noqa: E501

    :param file_id: 
    :type file_id: int

    :rtype: None
    """
    return 'do some magic!'


def item_types_list(group_id=None):  # noqa: E501
    """Item Types

    Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare. # noqa: E501

    :param group_id: Identifier of the group for which the item types are requested
    :type group_id: int

    :rtype: List[ItemType]
    """
    return 'do some magic!'


def licenses_list():  # noqa: E501
    """Public Licenses

    Returns a list of public licenses # noqa: E501


    :rtype: List[License]
    """
    return 'do some magic!'


def private_account():  # noqa: E501
    """Private Account information

    Account information for token/personal token # noqa: E501


    :rtype: Account
    """
    return 'do some magic!'


def private_funding_search(search=None):  # noqa: E501
    """Search Funding

    Search for fundings # noqa: E501

    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: List[FundingInformation]
    """
    if connexion.request.is_json:
        search = FundingSearch.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_licenses_list():  # noqa: E501
    """Private Account Licenses

    This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account&#39;s institution. # noqa: E501


    :rtype: List[License]
    """
    return 'do some magic!'
