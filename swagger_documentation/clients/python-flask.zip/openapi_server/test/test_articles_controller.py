import unittest

from flask import json

from openapi_server.models.account_report import AccountReport  # noqa: E501
from openapi_server.models.article import Article  # noqa: E501
from openapi_server.models.article_complete import ArticleComplete  # noqa: E501
from openapi_server.models.article_complete_private import ArticleCompletePrivate  # noqa: E501
from openapi_server.models.article_confidentiality import ArticleConfidentiality  # noqa: E501
from openapi_server.models.article_create import ArticleCreate  # noqa: E501
from openapi_server.models.article_doi import ArticleDOI  # noqa: E501
from openapi_server.models.article_embargo import ArticleEmbargo  # noqa: E501
from openapi_server.models.article_embargo_updater import ArticleEmbargoUpdater  # noqa: E501
from openapi_server.models.article_handle import ArticleHandle  # noqa: E501
from openapi_server.models.article_search import ArticleSearch  # noqa: E501
from openapi_server.models.article_unpublish_data import ArticleUnpublishData  # noqa: E501
from openapi_server.models.article_update import ArticleUpdate  # noqa: E501
from openapi_server.models.article_version_update import ArticleVersionUpdate  # noqa: E501
from openapi_server.models.article_versions import ArticleVersions  # noqa: E501
from openapi_server.models.article_with_project import ArticleWithProject  # noqa: E501
from openapi_server.models.author import Author  # noqa: E501
from openapi_server.models.authors_creator import AuthorsCreator  # noqa: E501
from openapi_server.models.categories_creator import CategoriesCreator  # noqa: E501
from openapi_server.models.category import Category  # noqa: E501
from openapi_server.models.confidentiality_creator import ConfidentialityCreator  # noqa: E501
from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.file_creator import FileCreator  # noqa: E501
from openapi_server.models.file_id import FileId  # noqa: E501
from openapi_server.models.location import Location  # noqa: E501
from openapi_server.models.location_warnings import LocationWarnings  # noqa: E501
from openapi_server.models.location_warnings_update import LocationWarningsUpdate  # noqa: E501
from openapi_server.models.private_article_search import PrivateArticleSearch  # noqa: E501
from openapi_server.models.private_file import PrivateFile  # noqa: E501
from openapi_server.models.private_link import PrivateLink  # noqa: E501
from openapi_server.models.private_link_creator import PrivateLinkCreator  # noqa: E501
from openapi_server.models.private_link_response import PrivateLinkResponse  # noqa: E501
from openapi_server.models.public_file import PublicFile  # noqa: E501
from openapi_server.models.resource import Resource  # noqa: E501
from openapi_server.test import BaseTestCase


class TestArticlesController(BaseTestCase):
    """ArticlesController integration test stubs"""

    def test_account_article_publish(self):
        """Test case for account_article_publish

        Private Article Publish
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/publish'.format(article_id=56),
            method='POST',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_account_article_report(self):
        """Test case for account_article_report

        Account Article Report
        """
        query_string = [('group_id', 56)]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/export',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_account_article_report_generate(self):
        """Test case for account_article_report_generate

        Initiate a new Report
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/export',
            method='POST',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_account_article_unpublish(self):
        """Test case for account_article_unpublish

        Public Article Unpublish
        """
        reason = {"reason":"Unpublish article reason"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/unpublish'.format(article_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(reason),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_article_details(self):
        """Test case for article_details

        View article details
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/articles/{article_id}'.format(article_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_article_file_details(self):
        """Test case for article_file_details

        Article file details
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/articles/{article_id}/files/{file_id}'.format(article_id=56, file_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_article_files(self):
        """Test case for article_files

        List article files
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56)]
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/articles/{article_id}/files'.format(article_id=56),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_article_version_confidentiality(self):
        """Test case for article_version_confidentiality

        Public Article Confidentiality for article version
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/articles/{article_id}/versions/{version_id}/confidentiality'.format(article_id=56, version_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_article_version_details(self):
        """Test case for article_version_details

        Article details for version
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/articles/{article_id}/versions/{version_id}'.format(article_id=56, version_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_article_version_embargo(self):
        """Test case for article_version_embargo

        Public Article Embargo for article version
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/articles/{article_id}/versions/{version_id}/embargo'.format(article_id=56, version_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_article_version_files(self):
        """Test case for article_version_files

        Public Article version files
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56)]
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/articles/{article_id}/versions/{version_id}/files'.format(article_id=56, version_id=56),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_article_version_partial_update(self):
        """Test case for article_version_partial_update

        Partially update article version
        """
        article = {"supplementary_fields":[{"name":"abc","value":"def"},{"name":"fname","value":"fvalue"}],"internal_metadata":{"curation_review_date":"2021-11-16T13:03:38","export_pdf_download_url":null}}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/versions/{version_id}'.format(article_id=56, version_id=56),
            method='PATCH',
            headers=headers,
            data=json.dumps(article),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_article_version_update(self):
        """Test case for article_version_update

        Update article version
        """
        article = {"supplementary_fields":[{"name":"abc","value":"def"},{"name":"fname","value":"fvalue"}],"internal_metadata":{"curation_review_date":"2021-11-16T13:03:38","export_pdf_download_url":null}}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/versions/{version_id}'.format(article_id=56, version_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(article),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_article_version_update_thumb(self):
        """Test case for article_version_update_thumb

        Update article version thumbnail
        """
        file_id = {"file_id":123}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/versions/{version_id}/update_thumb'.format(article_id=56, version_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(file_id),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_article_versions(self):
        """Test case for article_versions

        List article versions
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/articles/{article_id}/versions'.format(article_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_articles_list(self):
        """Test case for articles_list

        Public Articles
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56),
                        ('order', published_date),
                        ('order_direction', desc),
                        ('institution', 56),
                        ('published_since', 'published_since_example'),
                        ('modified_since', 'modified_since_example'),
                        ('group', 56),
                        ('resource_doi', 'resource_doi_example'),
                        ('item_type', 56),
                        ('doi', 'doi_example'),
                        ('handle', 'handle_example')]
        headers = { 
            'Accept': 'application/json',
            'x_cursor': 'x_cursor_example',
        }
        response = self.client.open(
            '/v2/articles',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_articles_search(self):
        """Test case for articles_search

        Public Articles Search
        """
        search = {"project_id":1,"resource_doi":"10.6084/m9.figshare.1407024","item_type":1,"handle":"111084/m9.figshare.14074","doi":"10.6084/m9.figshare.1407024","order":"published_date"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'x_cursor': 'x_cursor_example',
        }
        response = self.client.open(
            '/v2/articles/search',
            method='POST',
            headers=headers,
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_author_delete(self):
        """Test case for private_article_author_delete

        Delete article author
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/authors/{author_id}'.format(article_id=56, author_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_authors_add(self):
        """Test case for private_article_authors_add

        Add article authors
        """
        authors = {"authors":[{"id":12121},{"id":34345},{"name":"John Doe"}]}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/authors'.format(article_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(authors),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_authors_list(self):
        """Test case for private_article_authors_list

        List article authors
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/authors'.format(article_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_authors_replace(self):
        """Test case for private_article_authors_replace

        Replace article authors
        """
        authors = {"authors":[{"id":12121},{"id":34345},{"name":"John Doe"}]}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/authors'.format(article_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(authors),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_categories_add(self):
        """Test case for private_article_categories_add

        Add article categories
        """
        categories = {"categories":[1,10,11]}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/categories'.format(article_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(categories),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_categories_list(self):
        """Test case for private_article_categories_list

        List article categories
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/categories'.format(article_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_categories_replace(self):
        """Test case for private_article_categories_replace

        Replace article categories
        """
        categories = {"categories":[1,10,11]}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/categories'.format(article_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(categories),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_category_delete(self):
        """Test case for private_article_category_delete

        Delete article category
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/categories/{category_id}'.format(article_id=56, category_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_confidentiality_delete(self):
        """Test case for private_article_confidentiality_delete

        Delete article confidentiality
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/confidentiality'.format(article_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_confidentiality_details(self):
        """Test case for private_article_confidentiality_details

        Article confidentiality details
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/confidentiality'.format(article_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_confidentiality_update(self):
        """Test case for private_article_confidentiality_update

        Update article confidentiality
        """
        reason = {"reason":"reason"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/confidentiality'.format(article_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(reason),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_create(self):
        """Test case for private_article_create

        Create new Article
        """
        article = {"categories_by_source_id":["300204","400207"],"custom_fields_list":[{"name":"key","value":"value"},{"name":"key","value":"value"}],"funding":"","keywords":["tag1","tag2"],"references":["http://figshare.com","http://api.figshare.com"],"custom_fields":{"defined_key":"value for it"},"related_materials":[{"id":10432,"identifier":"10.6084/m9.figshare.1407024","identifier_type":"DOI","relation":"IsSupplementTo","title":"Figshare for institutions brochure","is_linkout":False}],"description":"Test description of article","handle":"","title":"Test article title","tags":["tag1","tag2"],"defined_type":"media","funding_list":[{"id":0,"title":"title"},{"id":0,"title":"title"}],"license":1,"group_id":6,"resource_doi":"","resource_title":"","is_metadata_record":True,"timeline":{"firstOnline":"2015-12-31","publisherAcceptance":"2015-12-31","publisherPublication":"2015-12-31"},"metadata_reason":"hosted somewhere else","categories":[1,10,11],"authors":[{"name":"John Doe"},{"id":1000008}],"doi":""}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles',
            method='POST',
            headers=headers,
            data=json.dumps(article),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_delete(self):
        """Test case for private_article_delete

        Delete article
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}'.format(article_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_details(self):
        """Test case for private_article_details

        Article details
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}'.format(article_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_download(self):
        """Test case for private_article_download

        Private Article Download
        """
        query_string = [('folder_path', 'folder_path_example')]
        headers = { 
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/download'.format(article_id=56),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_embargo_delete(self):
        """Test case for private_article_embargo_delete

        Delete Article Embargo
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/embargo'.format(article_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_embargo_details(self):
        """Test case for private_article_embargo_details

        Article Embargo Details
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/embargo'.format(article_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_embargo_update(self):
        """Test case for private_article_embargo_update

        Update Article Embargo
        """
        embargo = {"embargo_type":"file","is_embargoed":True,"embargo_date":"2018-05-22T04:04:04","embargo_title":"File(s) under embargo","embargo_reason":"","embargo_options":[{"id":1321},{"id":3345},{"id":54621,"group_ids":[4332,5433,678]}]}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/embargo'.format(article_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(embargo),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_file(self):
        """Test case for private_article_file

        Single File
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/files/{file_id}'.format(article_id=56, file_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_file_delete(self):
        """Test case for private_article_file_delete

        File Delete
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/files/{file_id}'.format(article_id=56, file_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_files_list(self):
        """Test case for private_article_files_list

        List article files
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56)]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/files'.format(article_id=56),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_partial_update(self):
        """Test case for private_article_partial_update

        Partially update article
        """
        article = {"categories_by_source_id":["300204","400207"],"custom_fields_list":[{"name":"key","value":"value"},{"name":"key","value":"value"}],"funding":"","keywords":["tag1","tag2"],"references":["http://figshare.com","http://api.figshare.com"],"custom_fields":{"defined_key":"value for it"},"download_disabled":False,"related_materials":[{"id":10432,"identifier":"10.6084/m9.figshare.1407024","identifier_type":"DOI","relation":"IsSupplementTo","title":"Figshare for institutions brochure","is_linkout":False}],"description":"Test description of article","handle":"","title":"Test article title","tags":["tag1","tag2"],"defined_type":"media","funding_list":[{"id":0,"title":"title"},{"id":0,"title":"title"}],"license":1,"group_id":0,"resource_doi":"","resource_title":"","is_metadata_record":True,"timeline":{"firstOnline":"2015-12-31","publisherAcceptance":"2015-12-31","publisherPublication":"2015-12-31"},"metadata_reason":"hosted somewhere else","categories":[1,10,11],"authors":[{"name":"John Doe"},{"id":1000008}],"doi":""}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}'.format(article_id=56),
            method='PATCH',
            headers=headers,
            data=json.dumps(article),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_private_link(self):
        """Test case for private_article_private_link

        List private links
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/private_links'.format(article_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_private_link_create(self):
        """Test case for private_article_private_link_create

        Create private link
        """
        private_link = {"expires_date":"2018-02-22 22:22:22"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/private_links'.format(article_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(private_link),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_private_link_delete(self):
        """Test case for private_article_private_link_delete

        Disable private link
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/private_links/{link_id}'.format(article_id=56, link_id='link_id_example'),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_private_link_update(self):
        """Test case for private_article_private_link_update

        Update private link
        """
        private_link = {"expires_date":"2018-02-22 22:22:22"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/private_links/{link_id}'.format(article_id=56, link_id='link_id_example'),
            method='PUT',
            headers=headers,
            data=json.dumps(private_link),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_reserve_doi(self):
        """Test case for private_article_reserve_doi

        Private Article Reserve DOI
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/reserve_doi'.format(article_id=56),
            method='POST',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_reserve_handle(self):
        """Test case for private_article_reserve_handle

        Private Article Reserve Handle
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/reserve_handle'.format(article_id=56),
            method='POST',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_resource(self):
        """Test case for private_article_resource

        Private Article Resource
        """
        resource = {"link":"https://docs.figshare.com","id":"aaaa23512","title":"Test title","version":1,"doi":"","status":"frozen"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/resource'.format(article_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(resource),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_update(self):
        """Test case for private_article_update

        Update article
        """
        article = {"categories_by_source_id":["300204","400207"],"custom_fields_list":[{"name":"key","value":"value"},{"name":"key","value":"value"}],"funding":"","keywords":["tag1","tag2"],"references":["http://figshare.com","http://api.figshare.com"],"custom_fields":{"defined_key":"value for it"},"download_disabled":False,"related_materials":[{"id":10432,"identifier":"10.6084/m9.figshare.1407024","identifier_type":"DOI","relation":"IsSupplementTo","title":"Figshare for institutions brochure","is_linkout":False}],"description":"Test description of article","handle":"","title":"Test article title","tags":["tag1","tag2"],"defined_type":"media","funding_list":[{"id":0,"title":"title"},{"id":0,"title":"title"}],"license":1,"group_id":0,"resource_doi":"","resource_title":"","is_metadata_record":True,"timeline":{"firstOnline":"2015-12-31","publisherAcceptance":"2015-12-31","publisherPublication":"2015-12-31"},"metadata_reason":"hosted somewhere else","categories":[1,10,11],"authors":[{"name":"John Doe"},{"id":1000008}],"doi":""}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}'.format(article_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(article),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_upload_complete(self):
        """Test case for private_article_upload_complete

        Complete Upload
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/files/{file_id}'.format(article_id=56, file_id=56),
            method='POST',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_article_upload_initiate(self):
        """Test case for private_article_upload_initiate

        Initiate Upload
        """
        file = {"size":70,"link":"http://figshare.com/file.txt","name":"test.py","folder_path":"/level1/level2/level3","md5":"6c16e6e7d7587bd078e5117dda01d565"}
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56)]
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/{article_id}/files'.format(article_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(file),
            content_type='application/json',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_articles_list(self):
        """Test case for private_articles_list

        Private Articles
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56)]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_articles_search(self):
        """Test case for private_articles_search

        Private Articles search
        """
        search = {"resource_id":"1407024"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/articles/search',
            method='POST',
            headers=headers,
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_public_article_download(self):
        """Test case for public_article_download

        Public Article Download
        """
        query_string = [('folder_path', 'folder_path_example')]
        headers = { 
        }
        response = self.client.open(
            '/v2/articles/{article_id}/download'.format(article_id=56),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_public_article_version_download(self):
        """Test case for public_article_version_download

        Public Article Version Download
        """
        query_string = [('folder_path', 'folder_path_example')]
        headers = { 
        }
        response = self.client.open(
            '/v2/articles/{article_id}/versions/{version_id}/download'.format(article_id=56, version_id=56),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
