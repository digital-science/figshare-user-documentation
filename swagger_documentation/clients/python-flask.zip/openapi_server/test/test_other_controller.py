import unittest

from flask import json

from openapi_server.models.account import Account  # noqa: E501
from openapi_server.models.category_list import CategoryList  # noqa: E501
from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.funding_information import FundingInformation  # noqa: E501
from openapi_server.models.funding_search import FundingSearch  # noqa: E501
from openapi_server.models.item_type import ItemType  # noqa: E501
from openapi_server.models.license import License  # noqa: E501
from openapi_server.test import BaseTestCase


class TestOtherController(BaseTestCase):
    """OtherController integration test stubs"""

    def test_categories_list(self):
        """Test case for categories_list

        Public Categories
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/categories',
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_file_download(self):
        """Test case for file_download

        Public File Download
        """
        headers = { 
        }
        response = self.client.open(
            '/v2/file/download/{file_id}'.format(file_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_item_types_list(self):
        """Test case for item_types_list

        Item Types
        """
        query_string = [('group_id', 0)]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/item_types',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_licenses_list(self):
        """Test case for licenses_list

        Public Licenses
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/licenses',
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_account(self):
        """Test case for private_account

        Private Account information
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account',
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_funding_search(self):
        """Test case for private_funding_search

        Search Funding
        """
        search = {"search_for":"search_for"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/funding/search',
            method='POST',
            headers=headers,
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_licenses_list(self):
        """Test case for private_licenses_list

        Private Account Licenses
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/licenses',
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
