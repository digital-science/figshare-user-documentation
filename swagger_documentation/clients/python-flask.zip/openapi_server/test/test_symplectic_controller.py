import unittest

from flask import json

from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.symplectic_accounts_ids200_response_inner import SymplecticAccountsIds200ResponseInner  # noqa: E501
from openapi_server.models.symplectic_user_id200_response import SymplecticUserId200Response  # noqa: E501
from openapi_server.test import BaseTestCase


class TestSymplecticController(BaseTestCase):
    """SymplecticController integration test stubs"""

    def test_symplectic_account_articles(self):
        """Test case for symplectic_account_articles

        Get articles for a specific account
        """
        query_string = [('offset', 0),
                        ('limit', 10),
                        ('status', 'status_example'),
                        ('is_embargoed', 'is_embargoed_example')]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/symplectic/accounts/{external_user_id}/articles'.format(external_user_id='external_user_id_example'),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_symplectic_accounts_ids(self):
        """Test case for symplectic_accounts_ids

        Get changed accounts for Symplectic Elements
        """
        query_string = [('since', '2015-01-01 00:00:00')]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/symplectic/accounts',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_symplectic_article(self):
        """Test case for symplectic_article

        Get article details for Symplectic Elements
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/symplectic/articles/{article_id}'.format(article_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_symplectic_changed_articles(self):
        """Test case for symplectic_changed_articles

        Get changed articles for Symplectic Elements
        """
        query_string = [('since', '2015-01-01 00:00:00'),
                        ('offset', 0),
                        ('limit', 10),
                        ('status', 'status_example'),
                        ('is_embargoed', 'is_embargoed_example')]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/symplectic/articles',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_symplectic_user_id(self):
        """Test case for symplectic_user_id

        Get institutional user ID for a user
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/symplectic/users/{user_id}'.format(user_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
