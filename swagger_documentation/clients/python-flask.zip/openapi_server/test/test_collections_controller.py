import unittest

from flask import json

from openapi_server.models.article import Article  # noqa: E501
from openapi_server.models.articles_creator import ArticlesCreator  # noqa: E501
from openapi_server.models.author import Author  # noqa: E501
from openapi_server.models.authors_creator import AuthorsCreator  # noqa: E501
from openapi_server.models.categories_creator import CategoriesCreator  # noqa: E501
from openapi_server.models.category import Category  # noqa: E501
from openapi_server.models.collection import Collection  # noqa: E501
from openapi_server.models.collection_complete import CollectionComplete  # noqa: E501
from openapi_server.models.collection_complete_private import CollectionCompletePrivate  # noqa: E501
from openapi_server.models.collection_create import CollectionCreate  # noqa: E501
from openapi_server.models.collection_doi import CollectionDOI  # noqa: E501
from openapi_server.models.collection_handle import CollectionHandle  # noqa: E501
from openapi_server.models.collection_private_link_creator import CollectionPrivateLinkCreator  # noqa: E501
from openapi_server.models.collection_search import CollectionSearch  # noqa: E501
from openapi_server.models.collection_update import CollectionUpdate  # noqa: E501
from openapi_server.models.collection_versions import CollectionVersions  # noqa: E501
from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.location import Location  # noqa: E501
from openapi_server.models.location_warnings import LocationWarnings  # noqa: E501
from openapi_server.models.location_warnings_update import LocationWarningsUpdate  # noqa: E501
from openapi_server.models.private_collection_search import PrivateCollectionSearch  # noqa: E501
from openapi_server.models.private_link import PrivateLink  # noqa: E501
from openapi_server.models.private_link_response import PrivateLinkResponse  # noqa: E501
from openapi_server.models.resource import Resource  # noqa: E501
from openapi_server.test import BaseTestCase


class TestCollectionsController(BaseTestCase):
    """CollectionsController integration test stubs"""

    def test_collection_articles(self):
        """Test case for collection_articles

        Public Collection Articles
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56)]
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/collections/{collection_id}/articles'.format(collection_id=56),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_collection_details(self):
        """Test case for collection_details

        Collection details
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/collections/{collection_id}'.format(collection_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_collection_version_details(self):
        """Test case for collection_version_details

        Collection Version details
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/collections/{collection_id}/versions/{version_id}'.format(collection_id=56, version_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_collection_versions(self):
        """Test case for collection_versions

        Collection Versions list
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/collections/{collection_id}/versions'.format(collection_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_collections_list(self):
        """Test case for collections_list

        Public Collections
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56),
                        ('order', published_date),
                        ('order_direction', desc),
                        ('institution', 56),
                        ('published_since', 'published_since_example'),
                        ('modified_since', 'modified_since_example'),
                        ('group', 56),
                        ('resource_doi', 'resource_doi_example'),
                        ('doi', 'doi_example'),
                        ('handle', 'handle_example')]
        headers = { 
            'Accept': 'application/json',
            'x_cursor': 'x_cursor_example',
        }
        response = self.client.open(
            '/collections',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_collections_search(self):
        """Test case for collections_search

        Public Collections Search
        """
        search = {"resource_doi":"10.6084/m9.figshare.1407024","handle":"10084/figshare.1407024","doi":"10.6084/m9.figshare.1407024","order":"published_date"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'x_cursor': 'x_cursor_example',
        }
        response = self.client.open(
            '/collections/search',
            method='POST',
            headers=headers,
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_article_delete(self):
        """Test case for private_collection_article_delete

        Delete collection article
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/articles/{article_id}'.format(collection_id=56, article_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_articles_add(self):
        """Test case for private_collection_articles_add

        Add collection articles
        """
        articles = {"articles":[2000003,2000004]}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/articles'.format(collection_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(articles),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_articles_list(self):
        """Test case for private_collection_articles_list

        List collection articles
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56)]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/articles'.format(collection_id=56),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_articles_replace(self):
        """Test case for private_collection_articles_replace

        Replace collection articles
        """
        articles = {"articles":[2000003,2000004]}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/articles'.format(collection_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(articles),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_author_delete(self):
        """Test case for private_collection_author_delete

        Delete collection author
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/authors/{author_id}'.format(collection_id=56, author_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_authors_add(self):
        """Test case for private_collection_authors_add

        Add collection authors
        """
        authors = {"authors":[{"id":12121},{"id":34345},{"name":"John Doe"}]}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/authors'.format(collection_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(authors),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_authors_list(self):
        """Test case for private_collection_authors_list

        List collection authors
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/authors'.format(collection_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_authors_replace(self):
        """Test case for private_collection_authors_replace

        Replace collection authors
        """
        authors = {"authors":[{"id":12121},{"id":34345},{"name":"John Doe"}]}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/authors'.format(collection_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(authors),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_categories_add(self):
        """Test case for private_collection_categories_add

        Add collection categories
        """
        categories = {"categories":[1,10,11]}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/categories'.format(collection_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(categories),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_categories_list(self):
        """Test case for private_collection_categories_list

        List collection categories
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/categories'.format(collection_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_categories_replace(self):
        """Test case for private_collection_categories_replace

        Replace collection categories
        """
        categories = {"categories":[1,10,11]}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/categories'.format(collection_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(categories),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_category_delete(self):
        """Test case for private_collection_category_delete

        Delete collection category
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/categories/{category_id}'.format(collection_id=56, category_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_create(self):
        """Test case for private_collection_create

        Create collection
        """
        collection = {"categories_by_source_id":["300204","400207"],"custom_fields_list":[{"name":"key","value":"value"},{"name":"key","value":"value"}],"funding":"","keywords":["tag1","tag2"],"references":["http://figshare.com","http://api.figshare.com"],"custom_fields":{"defined_key":"value for it"},"related_materials":[{"id":10432,"identifier":"10.6084/m9.figshare.1407024","identifier_type":"DOI","relation":"IsSupplementTo","title":"Figshare for institutions brochure","is_linkout":False}],"description":"Test description of article","handle":"","title":"Test collection title","resource_version":0,"tags":["tag1","tag2"],"funding_list":[{"id":0,"title":"title"},{"id":0,"title":"title"}],"resource_link":"resource_link","group_id":6,"resource_doi":"","resource_title":"","resource_id":"resource_id","timeline":{"firstOnline":"2015-12-31","publisherAcceptance":"2015-12-31","publisherPublication":"2015-12-31"},"categories":[1,10,11],"articles":[2000001,2000005],"authors":[{"name":"John Doe"},{"id":20005}],"doi":""}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections',
            method='POST',
            headers=headers,
            data=json.dumps(collection),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_delete(self):
        """Test case for private_collection_delete

        Delete collection
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}'.format(collection_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_details(self):
        """Test case for private_collection_details

        Collection details
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}'.format(collection_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_patch(self):
        """Test case for private_collection_patch

        Partially update collection
        """
        collection = {"categories_by_source_id":["300204","400207"],"custom_fields_list":[{"name":"key","value":"value"},{"name":"key","value":"value"}],"funding":"","keywords":["tag1","tag2"],"references":["http://figshare.com","http://api.figshare.com"],"custom_fields":{"defined_key":"value for it"},"related_materials":[{"id":10432,"identifier":"10.6084/m9.figshare.1407024","identifier_type":"DOI","relation":"IsSupplementTo","title":"Figshare for institutions brochure","is_linkout":False}],"description":"Test description of collection","handle":"","title":"Test collection title","resource_version":0,"tags":["tag1","tag2"],"funding_list":[{"id":0,"title":"title"},{"id":0,"title":"title"}],"resource_link":"resource_link","group_id":6,"resource_doi":"","resource_title":"","resource_id":"resource_id","timeline":{"firstOnline":"2015-12-31","publisherAcceptance":"2015-12-31","publisherPublication":"2015-12-31"},"categories":[1,10,11],"articles":[2000001,2000005],"authors":[{"name":"John Doe"},{"id":20005}],"doi":""}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}'.format(collection_id=56),
            method='PATCH',
            headers=headers,
            data=json.dumps(collection),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_private_link_create(self):
        """Test case for private_collection_private_link_create

        Create collection private link
        """
        private_link = {"expires_date":"2018-02-22 22:22:22"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/private_links'.format(collection_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(private_link),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_private_link_delete(self):
        """Test case for private_collection_private_link_delete

        Disable private link
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/private_links/{link_id}'.format(collection_id=56, link_id='link_id_example'),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_private_link_details(self):
        """Test case for private_collection_private_link_details

        View collection private link
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/private_links/{link_id}'.format(collection_id=56, link_id='link_id_example'),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_private_link_update(self):
        """Test case for private_collection_private_link_update

        Update collection private link
        """
        private_link = {"expires_date":"2018-02-22 22:22:22"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/private_links/{link_id}'.format(collection_id=56, link_id='link_id_example'),
            method='PUT',
            headers=headers,
            data=json.dumps(private_link),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_private_links_list(self):
        """Test case for private_collection_private_links_list

        List collection private links
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/private_links'.format(collection_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_publish(self):
        """Test case for private_collection_publish

        Private Collection Publish
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/publish'.format(collection_id=56),
            method='POST',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_reserve_doi(self):
        """Test case for private_collection_reserve_doi

        Private Collection Reserve DOI
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/reserve_doi'.format(collection_id=56),
            method='POST',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_reserve_handle(self):
        """Test case for private_collection_reserve_handle

        Private Collection Reserve Handle
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/reserve_handle'.format(collection_id=56),
            method='POST',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_resource(self):
        """Test case for private_collection_resource

        Private Collection Resource
        """
        resource = {"link":"https://docs.figshare.com","id":"aaaa23512","title":"Test title","version":1,"doi":"","status":"frozen"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}/resource'.format(collection_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(resource),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collection_update(self):
        """Test case for private_collection_update

        Update collection
        """
        collection = {"categories_by_source_id":["300204","400207"],"custom_fields_list":[{"name":"key","value":"value"},{"name":"key","value":"value"}],"funding":"","keywords":["tag1","tag2"],"references":["http://figshare.com","http://api.figshare.com"],"custom_fields":{"defined_key":"value for it"},"related_materials":[{"id":10432,"identifier":"10.6084/m9.figshare.1407024","identifier_type":"DOI","relation":"IsSupplementTo","title":"Figshare for institutions brochure","is_linkout":False}],"description":"Test description of collection","handle":"","title":"Test collection title","resource_version":0,"tags":["tag1","tag2"],"funding_list":[{"id":0,"title":"title"},{"id":0,"title":"title"}],"resource_link":"resource_link","group_id":6,"resource_doi":"","resource_title":"","resource_id":"resource_id","timeline":{"firstOnline":"2015-12-31","publisherAcceptance":"2015-12-31","publisherPublication":"2015-12-31"},"categories":[1,10,11],"articles":[2000001,2000005],"authors":[{"name":"John Doe"},{"id":20005}],"doi":""}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/{collection_id}'.format(collection_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(collection),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collections_list(self):
        """Test case for private_collections_list

        Private Collections List
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56),
                        ('order', published_date),
                        ('order_direction', desc)]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_collections_search(self):
        """Test case for private_collections_search

        Private Collections Search
        """
        search = {"resource_id":"1407024"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/account/collections/search',
            method='POST',
            headers=headers,
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
