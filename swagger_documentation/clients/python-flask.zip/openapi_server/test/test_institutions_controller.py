import unittest

from flask import json

from openapi_server.models.account import Account  # noqa: E501
from openapi_server.models.account_create import AccountCreate  # noqa: E501
from openapi_server.models.account_create_response import AccountCreateResponse  # noqa: E501
from openapi_server.models.account_update import AccountUpdate  # noqa: E501
from openapi_server.models.article import Article  # noqa: E501
from openapi_server.models.category_list import CategoryList  # noqa: E501
from openapi_server.models.curation import Curation  # noqa: E501
from openapi_server.models.curation_comment import CurationComment  # noqa: E501
from openapi_server.models.curation_comment_create import CurationCommentCreate  # noqa: E501
from openapi_server.models.curation_detail import CurationDetail  # noqa: E501
from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.group import Group  # noqa: E501
from openapi_server.models.group_embargo_options import GroupEmbargoOptions  # noqa: E501
from openapi_server.models.institution import Institution  # noqa: E501
from openapi_server.models.institution_accounts_search import InstitutionAccountsSearch  # noqa: E501
from openapi_server.models.response_message import ResponseMessage  # noqa: E501
from openapi_server.models.role import Role  # noqa: E501
from openapi_server.models.short_account import ShortAccount  # noqa: E501
from openapi_server.models.short_custom_field import ShortCustomField  # noqa: E501
from openapi_server.models.user import User  # noqa: E501
from openapi_server.test import BaseTestCase


class TestInstitutionsController(BaseTestCase):
    """InstitutionsController integration test stubs"""

    def test_account_institution_curation(self):
        """Test case for account_institution_curation

        Institution Curation Review
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/review/{curation_id}'.format(curation_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_account_institution_curations(self):
        """Test case for account_institution_curations

        Institution Curation Reviews
        """
        query_string = [('group_id', 56),
                        ('article_id', 56),
                        ('status', 'status_example'),
                        ('limit', 56),
                        ('offset', 56)]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/reviews',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_custom_fields_list(self):
        """Test case for custom_fields_list

        Private account institution group custom fields
        """
        query_string = [('group_id', 56)]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/custom_fields',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("multipart/form-data not supported by Connexion")
    def test_custom_fields_upload(self):
        """Test case for custom_fields_upload

        Custom fields values files upload
        """
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'multipart/form-data',
            'Authorization': 'Bearer special-key',
        }
        data = dict(external_file='/path/to/file')
        response = self.client.open(
            '/v2/account/institution/custom_fields/{custom_field_id}/items/upload'.format(custom_field_id=56),
            method='POST',
            headers=headers,
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_account_institution_curation_comments(self):
        """Test case for get_account_institution_curation_comments

        Institution Curation Review Comments
        """
        query_string = [('limit', 56),
                        ('offset', 56)]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/review/{curation_id}/comments'.format(curation_id=56),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_institution_articles(self):
        """Test case for institution_articles

        Public Institution Articles
        """
        query_string = [('resource_id', 'resource_id_example'),
                        ('filename', 'filename_example')]
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/institutions/{institution_string_id}/articles/filter-by'.format(institution_string_id='institution_string_id_example'),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("multipart/form-data not supported by Connexion")
    def test_institution_hrfeed_upload(self):
        """Test case for institution_hrfeed_upload

        Private Institution HRfeed Upload
        """
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'multipart/form-data',
            'Authorization': 'Bearer special-key',
        }
        data = dict(hrfeed='/path/to/file')
        response = self.client.open(
            '/v2/institution/hrfeed/upload',
            method='POST',
            headers=headers,
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_post_account_institution_curation_comments(self):
        """Test case for post_account_institution_curation_comments

        POST Institution Curation Review Comment
        """
        curation_comment = {"text":"text"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/review/{curation_id}/comments'.format(curation_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(curation_comment),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_account_institution_user(self):
        """Test case for private_account_institution_user

        Private Account Institution User
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/users/{account_id}'.format(account_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_categories_list(self):
        """Test case for private_categories_list

        Private Account Categories
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/categories',
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_group_embargo_options_details(self):
        """Test case for private_group_embargo_options_details

        Private Account Institution Group Embargo Options
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/groups/{group_id}/embargo_options'.format(group_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_account(self):
        """Test case for private_institution_account

        Private Institution Account information
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/accounts/{account_id}'.format(account_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_account_group_role_delete(self):
        """Test case for private_institution_account_group_role_delete

        Delete Institution Account Group Role
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/roles/{account_id}/{group_id}/{role_id}'.format(account_id=56, group_id=56, role_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_account_group_roles(self):
        """Test case for private_institution_account_group_roles

        List Institution Account Group Roles
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/roles/{account_id}'.format(account_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_account_group_roles_create(self):
        """Test case for private_institution_account_group_roles_create

        Add Institution Account Group Roles
        """
        account = None
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/roles/{account_id}'.format(account_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(account),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_accounts_create(self):
        """Test case for private_institution_accounts_create

        Create new Institution Account
        """
        account = {"is_active":True,"group_id":0,"institution_user_id":"johndoe","quota":1000,"last_name":"Doe","first_name":"John","email":"johndoe@example.com","symplectic_user_id":"johndoe"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/accounts',
            method='POST',
            headers=headers,
            data=json.dumps(account),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_accounts_list(self):
        """Test case for private_institution_accounts_list

        Private Account Institution Accounts
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56),
                        ('is_active', 56),
                        ('institution_user_id', 'institution_user_id_example'),
                        ('email', 'email_example'),
                        ('id_lte', 56),
                        ('id_gte', 56)]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/accounts',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_accounts_search(self):
        """Test case for private_institution_accounts_search

        Private Account Institution Accounts Search
        """
        search = {"is_active":0,"offset":0,"institution_user_id":"alan","limit":10,"page":1,"search_for":"figshare","email":"alan@institution.com","page_size":10}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/accounts/search',
            method='POST',
            headers=headers,
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_accounts_update(self):
        """Test case for private_institution_accounts_update

        Update Institution Account
        """
        account = {"is_active":True,"group_id":0}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/accounts/{account_id}'.format(account_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(account),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_articles(self):
        """Test case for private_institution_articles

        Private Institution Articles
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56),
                        ('order', published_date),
                        ('order_direction', desc),
                        ('published_since', 'published_since_example'),
                        ('modified_since', 'modified_since_example'),
                        ('status', 56),
                        ('resource_doi', 'resource_doi_example'),
                        ('item_type', 56),
                        ('group', 56)]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/articles',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_details(self):
        """Test case for private_institution_details

        Private Account Institutions
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution',
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_embargo_options_details(self):
        """Test case for private_institution_embargo_options_details

        Private Account Institution embargo options
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/embargo_options',
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_groups_list(self):
        """Test case for private_institution_groups_list

        Private Account Institution Groups
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/groups',
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_institution_roles_list(self):
        """Test case for private_institution_roles_list

        Private Account Institution Roles
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/institution/roles',
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
