import unittest

from flask import json

from openapi_server.models.article import Article  # noqa: E501
from openapi_server.models.article_complete_private import ArticleCompletePrivate  # noqa: E501
from openapi_server.models.article_project_create import ArticleProjectCreate  # noqa: E501
from openapi_server.models.create_project_response import CreateProjectResponse  # noqa: E501
from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.location import Location  # noqa: E501
from openapi_server.models.private_file import PrivateFile  # noqa: E501
from openapi_server.models.project import Project  # noqa: E501
from openapi_server.models.project_collaborator import ProjectCollaborator  # noqa: E501
from openapi_server.models.project_collaborator_invite import ProjectCollaboratorInvite  # noqa: E501
from openapi_server.models.project_complete import ProjectComplete  # noqa: E501
from openapi_server.models.project_complete_private import ProjectCompletePrivate  # noqa: E501
from openapi_server.models.project_create import ProjectCreate  # noqa: E501
from openapi_server.models.project_note import ProjectNote  # noqa: E501
from openapi_server.models.project_note_create import ProjectNoteCreate  # noqa: E501
from openapi_server.models.project_note_private import ProjectNotePrivate  # noqa: E501
from openapi_server.models.project_private import ProjectPrivate  # noqa: E501
from openapi_server.models.project_update import ProjectUpdate  # noqa: E501
from openapi_server.models.projects_search import ProjectsSearch  # noqa: E501
from openapi_server.models.response_message import ResponseMessage  # noqa: E501
from openapi_server.test import BaseTestCase


class TestProjectsController(BaseTestCase):
    """ProjectsController integration test stubs"""

    def test_private_project_article_delete(self):
        """Test case for private_project_article_delete

        Delete project article
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/articles/{article_id}'.format(project_id=56, article_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_article_details(self):
        """Test case for private_project_article_details

        Project article details
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/articles/{article_id}'.format(project_id=56, article_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_article_file(self):
        """Test case for private_project_article_file

        Project article file details
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/articles/{article_id}/files/{file_id}'.format(project_id=56, article_id=56, file_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_article_files(self):
        """Test case for private_project_article_files

        Project article list files
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/articles/{article_id}/files'.format(project_id=56, article_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_articles_create(self):
        """Test case for private_project_articles_create

        Create project article
        """
        article = {"categories_by_source_id":["300204","400207"],"custom_fields_list":[{"name":"key","value":"value"},{"name":"key","value":"value"}],"funding":"","keywords":["tag1","tag2"],"references":["http://figshare.com","http://api.figshare.com"],"custom_fields":{"defined_key":"value for it"},"related_materials":[{"id":10432,"identifier":"10.6084/m9.figshare.1407024","identifier_type":"DOI","relation":"IsSupplementTo","title":"Figshare for institutions brochure","is_linkout":False}],"description":"Test description of article","handle":"","title":"Test article title","tags":["tag1","tag2"],"defined_type":"media","funding_list":[{"id":0,"title":"title"},{"id":0,"title":"title"}],"license":1,"resource_doi":"","resource_title":"","timeline":{"firstOnline":"2015-12-31","publisherAcceptance":"2015-12-31","publisherPublication":"2015-12-31"},"categories":[1,10,11],"authors":[{"name":"John Doe"},{"id":1000008}],"doi":""}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/articles'.format(project_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(article),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_articles_list(self):
        """Test case for private_project_articles_list

        List project articles
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/articles'.format(project_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_collaborator_delete(self):
        """Test case for private_project_collaborator_delete

        Remove project collaborator
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/collaborators/{user_id}'.format(project_id=56, user_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_collaborators_invite(self):
        """Test case for private_project_collaborators_invite

        Invite project collaborators
        """
        collaborator = {"role_name":"viewer","user_id":100008,"comment":"hey","email":"user@domain.com"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/collaborators'.format(project_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(collaborator),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_collaborators_list(self):
        """Test case for private_project_collaborators_list

        List project collaborators
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/collaborators'.format(project_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_create(self):
        """Test case for private_project_create

        Create project
        """
        project = {"funding_list":[{"id":0,"title":"title"},{"id":0,"title":"title"}],"custom_fields_list":[{"name":"key","value":"value"},{"name":"key","value":"value"}],"funding":"","group_id":0,"custom_fields":{"defined_key":"value for it"},"description":"project description","title":"project title"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects',
            method='POST',
            headers=headers,
            data=json.dumps(project),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_delete(self):
        """Test case for private_project_delete

        Delete project
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}'.format(project_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_details(self):
        """Test case for private_project_details

        View project details
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}'.format(project_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_leave(self):
        """Test case for private_project_leave

        Private Project Leave
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/leave'.format(project_id=56),
            method='POST',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_note(self):
        """Test case for private_project_note

        Project note details
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/notes/{note_id}'.format(project_id=56, note_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_note_delete(self):
        """Test case for private_project_note_delete

        Delete project note
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/notes/{note_id}'.format(project_id=56, note_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_note_update(self):
        """Test case for private_project_note_update

        Update project note
        """
        note = {"text":"note to remember"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/notes/{note_id}'.format(project_id=56, note_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(note),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_notes_create(self):
        """Test case for private_project_notes_create

        Create project note
        """
        note = {"text":"note to remember"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/notes'.format(project_id=56),
            method='POST',
            headers=headers,
            data=json.dumps(note),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_notes_list(self):
        """Test case for private_project_notes_list

        List project notes
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56)]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/notes'.format(project_id=56),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_partial_update(self):
        """Test case for private_project_partial_update

        Partially update project
        """
        project = {"funding_list":[{"id":0,"title":"title"},{"id":0,"title":"title"}],"custom_fields_list":[{"name":"key","value":"value"},{"name":"key","value":"value"}],"funding":"","custom_fields":{"defined_key":"value for it"},"description":"project description","title":"project title"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}'.format(project_id=56),
            method='PATCH',
            headers=headers,
            data=json.dumps(project),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_publish(self):
        """Test case for private_project_publish

        Private Project Publish
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}/publish'.format(project_id=56),
            method='POST',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_project_update(self):
        """Test case for private_project_update

        Update project
        """
        project = {"funding_list":[{"id":0,"title":"title"},{"id":0,"title":"title"}],"custom_fields_list":[{"name":"key","value":"value"},{"name":"key","value":"value"}],"funding":"","custom_fields":{"defined_key":"value for it"},"description":"project description","title":"project title"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects/{project_id}'.format(project_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(project),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_projects_list(self):
        """Test case for private_projects_list

        Private Projects
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56),
                        ('order', published_date),
                        ('order_direction', desc),
                        ('storage', 'storage_example'),
                        ('roles', 'roles_example')]
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/projects',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_projects_search(self):
        """Test case for private_projects_search

        Private Projects search
        """
        search = {"order":"published_date"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
        response = self.client.open(
            '/v2/account/projects/search',
            method='POST',
            headers=headers,
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_project_articles(self):
        """Test case for project_articles

        Public Project Articles
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56)]
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/projects/{project_id}/articles'.format(project_id=56),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_project_details(self):
        """Test case for project_details

        Public Project
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/projects/{project_id}'.format(project_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_projects_list(self):
        """Test case for projects_list

        Public Projects
        """
        query_string = [('page', 56),
                        ('page_size', 10),
                        ('limit', 56),
                        ('offset', 56),
                        ('order', published_date),
                        ('order_direction', desc),
                        ('institution', 56),
                        ('published_since', 'published_since_example'),
                        ('group', 56)]
        headers = { 
            'Accept': 'application/json',
            'x_cursor': 'x_cursor_example',
        }
        response = self.client.open(
            '/v2/projects',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_projects_search(self):
        """Test case for projects_search

        Public Projects Search
        """
        search = {"order":"published_date"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'x_cursor': 'x_cursor_example',
        }
        response = self.client.open(
            '/v2/projects/search',
            method='POST',
            headers=headers,
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
