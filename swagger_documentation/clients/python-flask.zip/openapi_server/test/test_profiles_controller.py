import unittest

from flask import json

from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.profile_update_data import ProfileUpdateData  # noqa: E501
from openapi_server.test import BaseTestCase


class TestProfilesController(BaseTestCase):
    """ProfilesController integration test stubs"""

    def test_update_user_profile(self):
        """Test case for update_user_profile

        Update public profile
        """
        user_profile_data = {"facebook":"https://facebook.com/profile/1","x":"https://x.com/profile/1","last_name":"Doe","fields_of_interest":[1,2],"bio":"Biographical information","orcid":"0000-0001-YYYY-XXXX","location":"London, UK","linkedin":"https://linkedin.com/profile/2","first_name":"John","job_title":"Researcher at institution X","fields_of_interest_by_source_id":["3204","320401"],"personal_profiles":[{"label":"ResearchGate","url":"https://researchgate.net/profile/1"},{"label":"","url":"https://academia.edu/profile/1"}]}
        query_string = [('user_id', 56),
                        ('institution_user_id', 'institution_user_id_example')]
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/profile',
            method='PUT',
            headers=headers,
            data=json.dumps(user_profile_data),
            content_type='application/json',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("multipart/form-data not supported by Connexion")
    def test_update_user_profile_picture(self):
        """Test case for update_user_profile_picture

        Update public profile picture
        """
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'multipart/form-data',
            'Authorization': 'Bearer special-key',
        }
        data = dict(profile_picture='/path/to/file')
        response = self.client.open(
            '/v2/account/profile/{user_id}/picture'.format(user_id=56),
            method='POST',
            headers=headers,
            data=data,
            content_type='multipart/form-data')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
