import unittest

from flask import json

from openapi_server.models.author_complete import AuthorComplete  # noqa: E501
from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.private_authors_search import PrivateAuthorsSearch  # noqa: E501
from openapi_server.test import BaseTestCase


class TestAuthorsController(BaseTestCase):
    """AuthorsController integration test stubs"""

    def test_private_author_details(self):
        """Test case for private_author_details

        Author details
        """
        headers = { 
            'Accept': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/authors/{author_id}'.format(author_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_private_authors_search(self):
        """Test case for private_authors_search

        Search Authors
        """
        search = {"is_active":True,"offset":0,"group_id":0,"limit":10,"is_public":True,"orcid":"orcid","page":1,"search_for":"figshare","page_size":10,"institution_id":1}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer special-key',
        }
        response = self.client.open(
            '/v2/account/authors/search',
            method='POST',
            headers=headers,
            data=json.dumps(search),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
