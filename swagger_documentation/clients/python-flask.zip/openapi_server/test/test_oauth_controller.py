import unittest

from flask import json

from openapi_server.models.create_o_auth_token import CreateOAuthToken  # noqa: E501
from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.o_auth_token import OAuthToken  # noqa: E501
from openapi_server.test import BaseTestCase


class TestOauthController(BaseTestCase):
    """OauthController integration test stubs"""

    def test_create_token(self):
        """Test case for create_token

        Create OAuth token
        """
        body = {"refresh_token":"refresh_token","password":"password","code":"code","grant_type":"authorization_code","client_secret":"client_secret","client_id":"client_id","username":"username"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
        response = self.client.open(
            '/v2/token',
            method='POST',
            headers=headers,
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_token_info(self):
        """Test case for get_token_info

        Get OAuth token information
        """
        query_string = [('access_token', 'access_token_example')]
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/v2/token',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
