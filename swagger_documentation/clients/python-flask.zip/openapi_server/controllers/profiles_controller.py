import connexion
from typing import Dict
from typing import Tuple
from typing import Union

from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.profile_update_data import ProfileUpdateData  # noqa: E501
from openapi_server import util


def update_user_profile(user_profile_data, user_id=None, institution_user_id=None):  # noqa: E501
    """Update public profile

    Updates the fields of the user&#39;s public profile. # noqa: E501

    :param user_profile_data: 
    :type user_profile_data: dict | bytes
    :param user_id: User ID
    :type user_id: int
    :param institution_user_id: Institutional user ID
    :type institution_user_id: str

    :rtype: Union[object, Tuple[object, int], Tuple[object, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        user_profile_data = ProfileUpdateData.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def update_user_profile_picture(user_id, profile_picture):  # noqa: E501
    """Update public profile picture

    Updates the profile picture of the user&#39;s public profile. # noqa: E501

    :param user_id: User ID
    :type user_id: int
    :param profile_picture: User profile picture
    :type profile_picture: str

    :rtype: Union[object, Tuple[object, int], Tuple[object, int, Dict[str, str]]
    """
    return 'do some magic!'
