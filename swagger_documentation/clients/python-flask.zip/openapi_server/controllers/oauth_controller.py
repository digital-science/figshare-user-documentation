import connexion
from typing import Dict
from typing import Tuple
from typing import Union

from openapi_server.models.create_o_auth_token import CreateOAuthToken  # noqa: E501
from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.o_auth_token import OAuthToken  # noqa: E501
from openapi_server import util


def create_token(body=None):  # noqa: E501
    """Create OAuth token

    Creates OAuth token using various grant types # noqa: E501

    :param body: Create OAuth Token Parameters
    :type body: dict | bytes

    :rtype: Union[OAuthToken, Tuple[OAuthToken, int], Tuple[OAuthToken, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        body = CreateOAuthToken.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def get_token_info(access_token=None):  # noqa: E501
    """Get OAuth token information

    Returns information about the current OAuth token # noqa: E501

    :param access_token: OAuth access token
    :type access_token: str

    :rtype: Union[OAuthToken, Tuple[OAuthToken, int], Tuple[OAuthToken, int, Dict[str, str]]
    """
    return 'do some magic!'
