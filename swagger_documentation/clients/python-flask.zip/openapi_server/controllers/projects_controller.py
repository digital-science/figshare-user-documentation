import connexion
from typing import Dict
from typing import Tuple
from typing import Union

from openapi_server.models.article import Article  # noqa: E501
from openapi_server.models.article_complete_private import ArticleCompletePrivate  # noqa: E501
from openapi_server.models.article_project_create import ArticleProjectCreate  # noqa: E501
from openapi_server.models.create_project_response import CreateProjectResponse  # noqa: E501
from openapi_server.models.error_message import ErrorMessage  # noqa: E501
from openapi_server.models.location import Location  # noqa: E501
from openapi_server.models.private_file import PrivateFile  # noqa: E501
from openapi_server.models.project import Project  # noqa: E501
from openapi_server.models.project_collaborator import ProjectCollaborator  # noqa: E501
from openapi_server.models.project_collaborator_invite import ProjectCollaboratorInvite  # noqa: E501
from openapi_server.models.project_complete import ProjectComplete  # noqa: E501
from openapi_server.models.project_complete_private import ProjectCompletePrivate  # noqa: E501
from openapi_server.models.project_create import ProjectCreate  # noqa: E501
from openapi_server.models.project_note import ProjectNote  # noqa: E501
from openapi_server.models.project_note_create import ProjectNoteCreate  # noqa: E501
from openapi_server.models.project_note_private import ProjectNotePrivate  # noqa: E501
from openapi_server.models.project_private import ProjectPrivate  # noqa: E501
from openapi_server.models.project_update import ProjectUpdate  # noqa: E501
from openapi_server.models.projects_search import ProjectsSearch  # noqa: E501
from openapi_server.models.response_message import ResponseMessage  # noqa: E501
from openapi_server import util


def private_project_article_delete(project_id, article_id):  # noqa: E501
    """Delete project article

    Delete project article # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param article_id: Project Article unique identifier
    :type article_id: int

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_article_details(project_id, article_id):  # noqa: E501
    """Project article details

    Project article details # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param article_id: Project Article unique identifier
    :type article_id: int

    :rtype: Union[ArticleCompletePrivate, Tuple[ArticleCompletePrivate, int], Tuple[ArticleCompletePrivate, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_article_file(project_id, article_id, file_id):  # noqa: E501
    """Project article file details

    Project article file details # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param article_id: Project Article unique identifier
    :type article_id: int
    :param file_id: File unique identifier
    :type file_id: int

    :rtype: Union[PrivateFile, Tuple[PrivateFile, int], Tuple[PrivateFile, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_article_files(project_id, article_id):  # noqa: E501
    """Project article list files

    List article files # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param article_id: Project Article unique identifier
    :type article_id: int

    :rtype: Union[List[PrivateFile], Tuple[List[PrivateFile], int], Tuple[List[PrivateFile], int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_articles_create(project_id, article):  # noqa: E501
    """Create project article

    Create a new Article and associate it with this project # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param article: Article description
    :type article: dict | bytes

    :rtype: Union[Location, Tuple[Location, int], Tuple[Location, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        article = ArticleProjectCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_project_articles_list(project_id):  # noqa: E501
    """List project articles

    List project articles # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: Union[List[Article], Tuple[List[Article], int], Tuple[List[Article], int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_collaborator_delete(project_id, user_id):  # noqa: E501
    """Remove project collaborator

    Remove project collaborator # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param user_id: User unique identifier
    :type user_id: int

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_collaborators_invite(project_id, collaborator):  # noqa: E501
    """Invite project collaborators

    Invite users to collaborate on project or view the project # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param collaborator: viewer or collaborator role. User user_id or email of user
    :type collaborator: dict | bytes

    :rtype: Union[ResponseMessage, Tuple[ResponseMessage, int], Tuple[ResponseMessage, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        collaborator = ProjectCollaboratorInvite.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_project_collaborators_list(project_id):  # noqa: E501
    """List project collaborators

    List Project collaborators and invited users # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: Union[List[ProjectCollaborator], Tuple[List[ProjectCollaborator], int], Tuple[List[ProjectCollaborator], int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_create(project):  # noqa: E501
    """Create project

    Create a new project # noqa: E501

    :param project: Project  description
    :type project: dict | bytes

    :rtype: Union[CreateProjectResponse, Tuple[CreateProjectResponse, int], Tuple[CreateProjectResponse, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        project = ProjectCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_project_delete(project_id):  # noqa: E501
    """Delete project

    A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project.  # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_details(project_id):  # noqa: E501
    """View project details

    View a private project # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: Union[ProjectCompletePrivate, Tuple[ProjectCompletePrivate, int], Tuple[ProjectCompletePrivate, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_leave(project_id):  # noqa: E501
    """Private Project Leave

    Please note: project&#39;s owner cannot leave the project. # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_note(project_id, note_id):  # noqa: E501
    """Project note details

     # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param note_id: Note unique identifier
    :type note_id: int

    :rtype: Union[ProjectNotePrivate, Tuple[ProjectNotePrivate, int], Tuple[ProjectNotePrivate, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_note_delete(project_id, note_id):  # noqa: E501
    """Delete project note

     # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param note_id: Note unique identifier
    :type note_id: int

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_note_update(project_id, note_id, note):  # noqa: E501
    """Update project note

     # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param note_id: Note unique identifier
    :type note_id: int
    :param note: Note message
    :type note: dict | bytes

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        note = ProjectNoteCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_project_notes_create(project_id, note):  # noqa: E501
    """Create project note

    Create a new project note # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param note: Note message
    :type note: dict | bytes

    :rtype: Union[Location, Tuple[Location, int], Tuple[Location, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        note = ProjectNoteCreate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_project_notes_list(project_id, page=None, page_size=None, limit=None, offset=None):  # noqa: E501
    """List project notes

    List project notes # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: Union[List[ProjectNote], Tuple[List[ProjectNote], int], Tuple[List[ProjectNote], int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_partial_update(project_id, project=None):  # noqa: E501
    """Partially update project

    Partially update a project; only provided fields will be changed. # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param project: Fields to update
    :type project: dict | bytes

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        project = ProjectUpdate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_project_publish(project_id):  # noqa: E501
    """Private Project Publish

    Publish a project. Possible after all items inside it are public # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int

    :rtype: Union[ResponseMessage, Tuple[ResponseMessage, int], Tuple[ResponseMessage, int, Dict[str, str]]
    """
    return 'do some magic!'


def private_project_update(project_id, project):  # noqa: E501
    """Update project

    Updating an project by passing body parameters. # noqa: E501

    :param project_id: Project unique identifier
    :type project_id: int
    :param project: Project description
    :type project: dict | bytes

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        project = ProjectUpdate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def private_projects_list(page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None, storage=None, roles=None):  # noqa: E501
    """Private Projects

    List private projects # noqa: E501

    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order.
    :type order: str
    :param order_direction: 
    :type order_direction: str
    :param storage: only return collections from this institution
    :type storage: str
    :param roles: Any combination of owner, collaborator, viewer separated by comma. Examples: \&quot;owner\&quot; or \&quot;owner,collaborator\&quot;.
    :type roles: str

    :rtype: Union[List[ProjectPrivate], Tuple[List[ProjectPrivate], int], Tuple[List[ProjectPrivate], int, Dict[str, str]]
    """
    return 'do some magic!'


def private_projects_search(search=None):  # noqa: E501
    """Private Projects search

    Search inside the private projects # noqa: E501

    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: Union[List[ProjectPrivate], Tuple[List[ProjectPrivate], int], Tuple[List[ProjectPrivate], int, Dict[str, str]]
    """
    if connexion.request.is_json:
        search = ProjectsSearch.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def project_articles(project_id, page=None, page_size=None, limit=None, offset=None):  # noqa: E501
    """Public Project Articles

    List articles in project # noqa: E501

    :param project_id: Project Unique identifier
    :type project_id: int
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int

    :rtype: Union[List[Article], Tuple[List[Article], int], Tuple[List[Article], int, Dict[str, str]]
    """
    return 'do some magic!'


def project_details(project_id):  # noqa: E501
    """Public Project

    View a project # noqa: E501

    :param project_id: Project Unique identifier
    :type project_id: int

    :rtype: Union[ProjectComplete, Tuple[ProjectComplete, int], Tuple[ProjectComplete, int, Dict[str, str]]
    """
    return 'do some magic!'


def projects_list(x_cursor=None, page=None, page_size=None, limit=None, offset=None, order=None, order_direction=None, institution=None, published_since=None, group=None):  # noqa: E501
    """Public Projects

    Returns a list of public projects # noqa: E501

    :param x_cursor: Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
    :type x_cursor: str
    :type x_cursor: str
    :param page: Page number. Used for pagination with page_size
    :type page: int
    :param page_size: The number of results included on a page. Used for pagination with page
    :type page_size: int
    :param limit: Number of results included on a page. Used for pagination with query
    :type limit: int
    :param offset: Where to start the listing (the offset of the first result). Used for pagination with limit
    :type offset: int
    :param order: The field by which to order. Default varies by endpoint/resource.
    :type order: str
    :param order_direction: 
    :type order_direction: str
    :param institution: only return collections from this institution
    :type institution: int
    :param published_since: Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
    :type published_since: str
    :param group: only return collections from this group
    :type group: int

    :rtype: Union[List[Project], Tuple[List[Project], int], Tuple[List[Project], int, Dict[str, str]]
    """
    return 'do some magic!'


def projects_search(x_cursor=None, search=None):  # noqa: E501
    """Public Projects Search

    Returns a list of public articles # noqa: E501

    :param x_cursor: Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
    :type x_cursor: str
    :type x_cursor: str
    :param search: Search Parameters
    :type search: dict | bytes

    :rtype: Union[List[Project], Tuple[List[Project], int], Tuple[List[Project], int, Dict[str, str]]
    """
    if connexion.request.is_json:
        search = ProjectsSearch.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
