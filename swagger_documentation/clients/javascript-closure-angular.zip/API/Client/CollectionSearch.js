goog.provide('API.Client.CollectionSearch');

/**
 * @record
 */
API.Client.CollectionSearch = function() {}

/**
 * Search term
 * @type {!string}
 * @export
 */
API.Client.CollectionSearch.prototype.searchFor;

/**
 * Page number. Used for pagination with page_size
 * @type {!number}
 * @export
 */
API.Client.CollectionSearch.prototype.page;

/**
 * The number of results included on a page. Used for pagination with page
 * @type {!number}
 * @export
 */
API.Client.CollectionSearch.prototype.pageSize;

/**
 * Number of results included on a page. Used for pagination with query
 * @type {!number}
 * @export
 */
API.Client.CollectionSearch.prototype.limit;

/**
 * Where to start the listing(the offset of the first result). Used for pagination with limit
 * @type {!number}
 * @export
 */
API.Client.CollectionSearch.prototype.offset;

/**
 * Direction of ordering
 * @type {!string}
 * @export
 */
API.Client.CollectionSearch.prototype.orderDirection;

/**
 * only return collections from this institution
 * @type {!number}
 * @export
 */
API.Client.CollectionSearch.prototype.institution;

/**
 * Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
 * @type {!string}
 * @export
 */
API.Client.CollectionSearch.prototype.publishedSince;

/**
 * Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
 * @type {!string}
 * @export
 */
API.Client.CollectionSearch.prototype.modifiedSince;

/**
 * only return collections from this group
 * @type {!number}
 * @export
 */
API.Client.CollectionSearch.prototype.group;

/**
 * Only return collections with this resource_doi
 * @type {!string}
 * @export
 */
API.Client.CollectionSearch.prototype.resourceDoi;

/**
 * Only return collections with this doi
 * @type {!string}
 * @export
 */
API.Client.CollectionSearch.prototype.doi;

/**
 * Only return collections with this handle
 * @type {!string}
 * @export
 */
API.Client.CollectionSearch.prototype.handle;

/**
 * The field by which to order.
 * @type {!string}
 * @export
 */
API.Client.CollectionSearch.prototype.order;

/** @enum {string} */
API.Client.CollectionSearch.OrderDirectionEnum = { 
  asc: 'asc',
  desc: 'desc',
}
/** @enum {string} */
API.Client.CollectionSearch.OrderEnum = { 
  created_date: 'created_date',
  published_date: 'published_date',
  modified_date: 'modified_date',
  views: 'views',
  shares: 'shares',
  cites: 'cites',
}
