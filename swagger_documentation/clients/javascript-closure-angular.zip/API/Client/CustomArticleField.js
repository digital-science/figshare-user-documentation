goog.provide('API.Client.CustomArticleField');

/**
 * @record
 */
API.Client.CustomArticleField = function() {}

/**
 * Custom  metadata name
 * @type {!string}
 * @export
 */
API.Client.CustomArticleField.prototype.name;

/**
 * Custom metadata value (can be either a string or an array of strings)
 * @type {!API.Client.Object}
 * @export
 */
API.Client.CustomArticleField.prototype.value;

/**
 * Custom field type
 * @type {!string}
 * @export
 */
API.Client.CustomArticleField.prototype.fieldType;

/**
 * Settings for the custom field
 * @type {!API.Client.Object}
 * @export
 */
API.Client.CustomArticleField.prototype.settings;

/**
 * Order of the custom field
 * @type {!number}
 * @export
 */
API.Client.CustomArticleField.prototype.order;

/**
 * Whether the field is mandatory or not
 * @type {!boolean}
 * @export
 */
API.Client.CustomArticleField.prototype.isMandatory;

/** @enum {string} */
API.Client.CustomArticleField.FieldTypeEnum = { 
  text: 'text',
  textarea: 'textarea',
  dropdown: 'dropdown',
  url: 'url',
  email: 'email',
  date: 'date',
  dropdown_large_list: 'dropdown_large_list',
}
