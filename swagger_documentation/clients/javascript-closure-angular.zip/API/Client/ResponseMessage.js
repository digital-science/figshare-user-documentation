goog.provide('API.Client.ResponseMessage');

/**
 * @record
 */
API.Client.ResponseMessage = function() {}

/**
 * Response message text
 * @type {!string}
 * @export
 */
API.Client.ResponseMessage.prototype.message;

