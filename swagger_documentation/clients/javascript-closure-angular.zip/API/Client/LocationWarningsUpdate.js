goog.provide('API.Client.LocationWarningsUpdate');

/**
 * @record
 */
API.Client.LocationWarningsUpdate = function() {}

/**
 * Url for entity
 * @type {!string}
 * @export
 */
API.Client.LocationWarningsUpdate.prototype.location;

/**
 * Issues encountered during the operation
 * @type {!Array<!string>}
 * @export
 */
API.Client.LocationWarningsUpdate.prototype.warnings;

