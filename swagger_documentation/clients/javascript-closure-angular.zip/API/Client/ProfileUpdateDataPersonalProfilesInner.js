goog.provide('API.Client.ProfileUpdateData_personal_profiles_inner');

/**
 * @record
 */
API.Client.ProfileUpdateDataPersonalProfilesInner = function() {}

/**
 * Label for the personal profile link
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateDataPersonalProfilesInner.prototype.label;

/**
 * URL for the personal profile link
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateDataPersonalProfilesInner.prototype.url;

