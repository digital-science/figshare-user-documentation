goog.provide('API.Client.ArticleProjectCreate');

/**
 * @record
 */
API.Client.ArticleProjectCreate = function() {}

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.title;

/**
 * The article description. In a publisher case, usually this is the remote article description
 * @type {!string}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.description;

/**
 * List of tags to be associated with the article. Keywords can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.tags;

/**
 * List of tags to be associated with the article. Tags can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.keywords;

/**
 * List of links to be associated with the article (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.references;

/**
 * List of related materials; supersedes references and resource DOI/title.
 * @type {!Array<!API.Client.RelatedMaterial>}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.relatedMaterials;

/**
 * List of category ids to be associated with the article(e.g [1, 23, 33, 66])
 * @type {!Array<!number>}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.categories;

/**
 * List of category source ids to be associated with the article, supersedes the categories property
 * @type {!Array<!string>}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.categoriesBySourceId;

/**
 * List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint.
 * @type {!Array<!API.Client.Object>}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.authors;

/**
 * List of key, values pairs to be associated with the article
 * @type {!API.Client.Object}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.customFields;

/**
 * List of custom fields values, supersedes custom_fields parameter
 * @type {!Array<!API.Client.CustomArticleFieldAdd>}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.customFieldsList;

/**
 * <b>One of:</b> <code>figure</code> <code>online resource</code> <code>preprint</code> <code>book</code> <code>conference contribution</code> <code>media</code> <code>dataset</code> <code>poster</code> <code>journal contribution</code> <code>presentation</code> <code>thesis</code> <code>software</code>
 * @type {!string}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.definedType;

/**
 * Grant number or funding authority
 * @type {!string}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.funding;

/**
 * Funding creation / update items
 * @type {!Array<!API.Client.FundingCreate>}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.fundingList;

/**
 * License id for this article.
 * @type {!number}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.license;

/**
 * Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
 * @type {!string}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.doi;

/**
 * Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
 * @type {!string}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.handle;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI.
 * @type {!string}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.resourceDoi;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title.
 * @type {!string}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.resourceTitle;

/**
 * @type {!API.Client.TimelineUpdate}
 * @export
 */
API.Client.ArticleProjectCreate.prototype.timeline;

