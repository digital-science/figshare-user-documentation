goog.provide('API.Client.ArticleVersions');

/**
 * @record
 */
API.Client.ArticleVersions = function() {}

/**
 * Version number
 * @type {!number}
 * @export
 */
API.Client.ArticleVersions.prototype.version;

/**
 * Api endpoint for the item version
 * @type {!string}
 * @export
 */
API.Client.ArticleVersions.prototype.url;

