goog.provide('API.Client.ProjectsSearch');

/**
 * @record
 */
API.Client.ProjectsSearch = function() {}

/**
 * Search term
 * @type {!string}
 * @export
 */
API.Client.ProjectsSearch.prototype.searchFor;

/**
 * Page number. Used for pagination with page_size
 * @type {!number}
 * @export
 */
API.Client.ProjectsSearch.prototype.page;

/**
 * The number of results included on a page. Used for pagination with page
 * @type {!number}
 * @export
 */
API.Client.ProjectsSearch.prototype.pageSize;

/**
 * Number of results included on a page. Used for pagination with query
 * @type {!number}
 * @export
 */
API.Client.ProjectsSearch.prototype.limit;

/**
 * Where to start the listing(the offset of the first result). Used for pagination with limit
 * @type {!number}
 * @export
 */
API.Client.ProjectsSearch.prototype.offset;

/**
 * Direction of ordering
 * @type {!string}
 * @export
 */
API.Client.ProjectsSearch.prototype.orderDirection;

/**
 * only return collections from this institution
 * @type {!number}
 * @export
 */
API.Client.ProjectsSearch.prototype.institution;

/**
 * Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
 * @type {!string}
 * @export
 */
API.Client.ProjectsSearch.prototype.publishedSince;

/**
 * Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
 * @type {!string}
 * @export
 */
API.Client.ProjectsSearch.prototype.modifiedSince;

/**
 * only return collections from this group
 * @type {!number}
 * @export
 */
API.Client.ProjectsSearch.prototype.group;

/**
 * The field by which to order.
 * @type {!string}
 * @export
 */
API.Client.ProjectsSearch.prototype.order;

/** @enum {string} */
API.Client.ProjectsSearch.OrderDirectionEnum = { 
  asc: 'asc',
  desc: 'desc',
}
/** @enum {string} */
API.Client.ProjectsSearch.OrderEnum = { 
  published_date: 'published_date',
  modified_date: 'modified_date',
  views: 'views',
}
