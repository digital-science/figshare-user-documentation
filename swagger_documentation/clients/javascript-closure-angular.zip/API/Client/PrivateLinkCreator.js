goog.provide('API.Client.PrivateLinkCreator');

/**
 * @record
 */
API.Client.PrivateLinkCreator = function() {}

/**
 * Date when this private link should expire - optional. By default private links expire in 365 days.
 * @type {!string}
 * @export
 */
API.Client.PrivateLinkCreator.prototype.expiresDate;

