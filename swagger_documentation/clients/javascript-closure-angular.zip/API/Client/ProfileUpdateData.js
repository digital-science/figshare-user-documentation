goog.provide('API.Client.ProfileUpdateData');

/**
 * @record
 */
API.Client.ProfileUpdateData = function() {}

/**
 * First name
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateData.prototype.firstName;

/**
 * Last Name
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateData.prototype.lastName;

/**
 * User ORCID
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateData.prototype.orcid;

/**
 * User job title
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateData.prototype.jobTitle;

/**
 * User fields of interest (category ids)
 * @type {!Array<!number>}
 * @export
 */
API.Client.ProfileUpdateData.prototype.fieldsOfInterest;

/**
 * User fields of interest (category source IDs), supersedes the fields_of_interest property
 * @type {!Array<!string>}
 * @export
 */
API.Client.ProfileUpdateData.prototype.fieldsOfInterestBySourceId;

/**
 * User location
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateData.prototype.location;

/**
 * User facebook URL
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateData.prototype.facebook;

/**
 * User X (twitter) URL
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateData.prototype.x;

/**
 * User linkedin URL
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateData.prototype.linkedin;

/**
 * User biographical information
 * @type {!string}
 * @export
 */
API.Client.ProfileUpdateData.prototype.bio;

/**
 * Add up to 10 additional personal profile links
 * @type {!Array<!API.Client.ProfileUpdateData_personal_profiles_inner>}
 * @export
 */
API.Client.ProfileUpdateData.prototype.personalProfiles;

