goog.provide('API.Client.Category');

/**
 * @record
 */
API.Client.Category = function() {}

/**
 * Parent category
 * @type {!number}
 * @export
 */
API.Client.Category.prototype.parentId;

/**
 * Category id
 * @type {!number}
 * @export
 */
API.Client.Category.prototype.id;

/**
 * Category title
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.title;

/**
 * Path to all ancestor ids
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.path;

/**
 * ID in original standard taxonomy
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.sourceId;

/**
 * Internal id of taxonomy the category is part of
 * @type {!number}
 * @export
 */
API.Client.Category.prototype.taxonomyId;

