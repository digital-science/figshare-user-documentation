goog.provide('API.Client.AccountUpdate');

/**
 * @record
 */
API.Client.AccountUpdate = function() {}

/**
 * Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
 * @type {!number}
 * @export
 */
API.Client.AccountUpdate.prototype.groupId;

/**
 * Is account active
 * @type {!boolean}
 * @export
 */
API.Client.AccountUpdate.prototype.isActive;

