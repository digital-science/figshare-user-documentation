goog.provide('API.Client.CustomArticleFieldAdd');

/**
 * @record
 */
API.Client.CustomArticleFieldAdd = function() {}

/**
 * Custom  metadata name
 * @type {!string}
 * @export
 */
API.Client.CustomArticleFieldAdd.prototype.name;

/**
 * @type {!API.Client.CustomArticleFieldAdd_value}
 * @export
 */
API.Client.CustomArticleFieldAdd.prototype.value;

