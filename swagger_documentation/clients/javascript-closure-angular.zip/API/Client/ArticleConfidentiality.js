goog.provide('API.Client.ArticleConfidentiality');

/**
 * @record
 */
API.Client.ArticleConfidentiality = function() {}

/**
 * True if article is confidential
 * @type {!boolean}
 * @export
 */
API.Client.ArticleConfidentiality.prototype.isConfidential;

/**
 * Reason for confidentiality
 * @type {!string}
 * @export
 */
API.Client.ArticleConfidentiality.prototype.reason;

