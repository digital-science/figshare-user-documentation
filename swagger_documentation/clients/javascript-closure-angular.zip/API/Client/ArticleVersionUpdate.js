goog.provide('API.Client.ArticleVersionUpdate');

/**
 * @record
 */
API.Client.ArticleVersionUpdate = function() {}

/**
 * List of supplementary fields to be associated with the article version
 * @type {!Array<!API.Client.Object>}
 * @export
 */
API.Client.ArticleVersionUpdate.prototype.supplementaryFields;

/**
 * List of supplementary fields to be associated with the article version
 * @type {!API.Client.Object}
 * @export
 */
API.Client.ArticleVersionUpdate.prototype.internalMetadata;

