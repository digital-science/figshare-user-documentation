goog.provide('API.Client.CurationComment');

/**
 * @record
 */
API.Client.CurationComment = function() {}

/**
 * The ID of the comment.
 * @type {!number}
 * @export
 */
API.Client.CurationComment.prototype.id;

/**
 * The ID of the account which generated this comment.
 * @type {!number}
 * @export
 */
API.Client.CurationComment.prototype.accountId;

/**
 * The ID of the account which generated this comment.
 * @type {!string}
 * @export
 */
API.Client.CurationComment.prototype.type;

/**
 * The value/content of the comment.
 * @type {!string}
 * @export
 */
API.Client.CurationComment.prototype.text;

/** @enum {string} */
API.Client.CurationComment.TypeEnum = { 
  comment: 'comment',
  approved: 'approved',
  rejected: 'rejected',
  closed: 'closed',
}
