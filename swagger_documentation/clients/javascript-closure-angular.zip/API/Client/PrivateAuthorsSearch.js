goog.provide('API.Client.PrivateAuthorsSearch');

/**
 * @record
 */
API.Client.PrivateAuthorsSearch = function() {}

/**
 * Search term
 * @type {!string}
 * @export
 */
API.Client.PrivateAuthorsSearch.prototype.searchFor;

/**
 * Page number. Used for pagination with page_size
 * @type {!number}
 * @export
 */
API.Client.PrivateAuthorsSearch.prototype.page;

/**
 * The number of results included on a page. Used for pagination with page
 * @type {!number}
 * @export
 */
API.Client.PrivateAuthorsSearch.prototype.pageSize;

/**
 * Number of results included on a page. Used for pagination with query
 * @type {!number}
 * @export
 */
API.Client.PrivateAuthorsSearch.prototype.limit;

/**
 * Where to start the listing(the offset of the first result). Used for pagination with limit
 * @type {!number}
 * @export
 */
API.Client.PrivateAuthorsSearch.prototype.offset;

/**
 * The field by which to order. Default varies by endpoint/resource.
 * @type {!string}
 * @export
 */
API.Client.PrivateAuthorsSearch.prototype.order;

/**
 * Direction of ordering
 * @type {!string}
 * @export
 */
API.Client.PrivateAuthorsSearch.prototype.orderDirection;

/**
 * Return only authors associated to this institution
 * @type {!number}
 * @export
 */
API.Client.PrivateAuthorsSearch.prototype.institutionId;

/**
 * Orcid of author
 * @type {!string}
 * @export
 */
API.Client.PrivateAuthorsSearch.prototype.orcid;

/**
 * Return only authors in this group or subgroups of the group
 * @type {!number}
 * @export
 */
API.Client.PrivateAuthorsSearch.prototype.groupId;

/**
 * Return only active authors if True
 * @type {!boolean}
 * @export
 */
API.Client.PrivateAuthorsSearch.prototype.isActive;

/**
 * Return only authors that have published items if True
 * @type {!boolean}
 * @export
 */
API.Client.PrivateAuthorsSearch.prototype.isPublic;

/** @enum {string} */
API.Client.PrivateAuthorsSearch.OrderEnum = { 
  published_date: 'published_date',
  modified_date: 'modified_date',
  views: 'views',
  shares: 'shares',
  downloads: 'downloads',
  cites: 'cites',
}
/** @enum {string} */
API.Client.PrivateAuthorsSearch.OrderDirectionEnum = { 
  asc: 'asc',
  desc: 'desc',
}
