goog.provide('API.Client.ShortCustomField');

/**
 * @record
 */
API.Client.ShortCustomField = function() {}

/**
 * Custom field id
 * @type {!number}
 * @export
 */
API.Client.ShortCustomField.prototype.id;

/**
 * Custom field name
 * @type {!string}
 * @export
 */
API.Client.ShortCustomField.prototype.name;

/**
 * Custom field type
 * @type {!string}
 * @export
 */
API.Client.ShortCustomField.prototype.fieldType;

/**
 * Settings for the custom field
 * @type {!API.Client.Object}
 * @export
 */
API.Client.ShortCustomField.prototype.settings;

/**
 * Order of the field in the group
 * @type {!number}
 * @export
 */
API.Client.ShortCustomField.prototype.order;

/** @enum {string} */
API.Client.ShortCustomField.FieldTypeEnum = { 
  text: 'text',
  textarea: 'textarea',
  dropdown: 'dropdown',
  url: 'url',
  email: 'email',
  date: 'date',
  dropdown_large_list: 'dropdown_large_list',
}
