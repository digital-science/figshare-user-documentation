goog.provide('API.Client.User');

/**
 * @record
 */
API.Client.User = function() {}

/**
 * User id
 * @type {!number}
 * @export
 */
API.Client.User.prototype.id;

/**
 * First Name
 * @type {!string}
 * @export
 */
API.Client.User.prototype.firstName;

/**
 * Last Name
 * @type {!string}
 * @export
 */
API.Client.User.prototype.lastName;

/**
 * Full Name
 * @type {!string}
 * @export
 */
API.Client.User.prototype.name;

/**
 * Account activity status
 * @type {!boolean}
 * @export
 */
API.Client.User.prototype.isActive;

/**
 * Name that appears in website url
 * @type {!string}
 * @export
 */
API.Client.User.prototype.urlName;

/**
 * Account public status
 * @type {!boolean}
 * @export
 */
API.Client.User.prototype.isPublic;

/**
 * User Job title
 * @type {!string}
 * @export
 */
API.Client.User.prototype.jobTitle;

/**
 * Orcid associated to this User
 * @type {!string}
 * @export
 */
API.Client.User.prototype.orcidId;

