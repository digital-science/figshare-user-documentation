goog.provide('API.Client.ArticleUnpublish');

/**
 * @record
 */
API.Client.ArticleUnpublish = function() {}

/**
 * Reason of article unpublishing
 * @type {!string}
 * @export
 */
API.Client.ArticleUnpublish.prototype.reason;

