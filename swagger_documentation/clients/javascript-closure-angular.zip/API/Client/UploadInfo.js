goog.provide('API.Client.UploadInfo');

/**
 * @record
 */
API.Client.UploadInfo = function() {}

/**
 * token received after initializing a file upload
 * @type {!string}
 * @export
 */
API.Client.UploadInfo.prototype.token;

/**
 * md5 provided on upload initialization
 * @type {!string}
 * @export
 */
API.Client.UploadInfo.prototype.md5;

/**
 * size of file in bytes
 * @type {!number}
 * @export
 */
API.Client.UploadInfo.prototype.size;

/**
 * name of file on upload server
 * @type {!string}
 * @export
 */
API.Client.UploadInfo.prototype.name;

/**
 * Upload status
 * @type {!string}
 * @export
 */
API.Client.UploadInfo.prototype.status;

/**
 * Uploads parts
 * @type {!Array<!API.Client.UploadFilePart>}
 * @export
 */
API.Client.UploadInfo.prototype.parts;

/** @enum {string} */
API.Client.UploadInfo.StatusEnum = { 
  PENDING: 'PENDING',
  COMPLETED: 'COMPLETED',
  ABORTED: 'ABORTED',
}
