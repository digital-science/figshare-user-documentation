goog.provide('API.Client.PrivateArticleSearch');

/**
 * @record
 */
API.Client.PrivateArticleSearch = function() {}

/**
 * only return collections with this resource_id
 * @type {!string}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.resourceId;

/**
 * Only return articles with this resource_doi
 * @type {!string}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.resourceDoi;

/**
 * Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
 * @type {!number}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.itemType;

/**
 * Only return articles with this doi
 * @type {!string}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.doi;

/**
 * Only return articles with this handle
 * @type {!string}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.handle;

/**
 * Only return articles in this project
 * @type {!number}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.projectId;

/**
 * The field by which to order
 * @type {!string}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.order;

/**
 * Search term
 * @type {!string}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.searchFor;

/**
 * Page number. Used for pagination with page_size
 * @type {!number}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.page;

/**
 * The number of results included on a page. Used for pagination with page
 * @type {!number}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.pageSize;

/**
 * Number of results included on a page. Used for pagination with query
 * @type {!number}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.limit;

/**
 * Where to start the listing(the offset of the first result). Used for pagination with limit
 * @type {!number}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.offset;

/**
 * Direction of ordering
 * @type {!string}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.orderDirection;

/**
 * only return collections from this institution
 * @type {!number}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.institution;

/**
 * Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
 * @type {!string}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.publishedSince;

/**
 * Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
 * @type {!string}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.modifiedSince;

/**
 * only return collections from this group
 * @type {!number}
 * @export
 */
API.Client.PrivateArticleSearch.prototype.group;

/** @enum {string} */
API.Client.PrivateArticleSearch.OrderEnum = { 
  created_date: 'created_date',
  published_date: 'published_date',
  modified_date: 'modified_date',
  views: 'views',
  shares: 'shares',
  downloads: 'downloads',
  cites: 'cites',
}
/** @enum {string} */
API.Client.PrivateArticleSearch.OrderDirectionEnum = { 
  asc: 'asc',
  desc: 'desc',
}
