goog.provide('API.Client.CustomArticleFieldAdd_value');

/**
 * Custom metadata value (can be either a string, an array of strings, or empty)
 * @record
 */
API.Client.CustomArticleFieldAddValue = function() {}

