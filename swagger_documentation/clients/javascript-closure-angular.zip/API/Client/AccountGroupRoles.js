goog.provide('API.Client.AccountGroupRoles');

/**
 * @record
 */
API.Client.AccountGroupRoles = function() {}

