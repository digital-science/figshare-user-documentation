goog.provide('API.Client.CommonSearch');

/**
 * @record
 */
API.Client.CommonSearch = function() {}

/**
 * Search term
 * @type {!string}
 * @export
 */
API.Client.CommonSearch.prototype.searchFor;

/**
 * Page number. Used for pagination with page_size
 * @type {!number}
 * @export
 */
API.Client.CommonSearch.prototype.page;

/**
 * The number of results included on a page. Used for pagination with page
 * @type {!number}
 * @export
 */
API.Client.CommonSearch.prototype.pageSize;

/**
 * Number of results included on a page. Used for pagination with query
 * @type {!number}
 * @export
 */
API.Client.CommonSearch.prototype.limit;

/**
 * Where to start the listing(the offset of the first result). Used for pagination with limit
 * @type {!number}
 * @export
 */
API.Client.CommonSearch.prototype.offset;

/**
 * Direction of ordering
 * @type {!string}
 * @export
 */
API.Client.CommonSearch.prototype.orderDirection;

/**
 * only return collections from this institution
 * @type {!number}
 * @export
 */
API.Client.CommonSearch.prototype.institution;

/**
 * Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
 * @type {!string}
 * @export
 */
API.Client.CommonSearch.prototype.publishedSince;

/**
 * Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
 * @type {!string}
 * @export
 */
API.Client.CommonSearch.prototype.modifiedSince;

/**
 * only return collections from this group
 * @type {!number}
 * @export
 */
API.Client.CommonSearch.prototype.group;

/** @enum {string} */
API.Client.CommonSearch.OrderDirectionEnum = { 
  asc: 'asc',
  desc: 'desc',
}
