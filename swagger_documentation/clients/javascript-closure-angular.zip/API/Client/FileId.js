goog.provide('API.Client.FileId');

/**
 * @record
 */
API.Client.FileId = function() {}

/**
 * File ID
 * @type {!number}
 * @export
 */
API.Client.FileId.prototype.fileId;

