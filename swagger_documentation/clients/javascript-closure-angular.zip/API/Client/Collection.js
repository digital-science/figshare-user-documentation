goog.provide('API.Client.Collection');

/**
 * @record
 */
API.Client.Collection = function() {}

/**
 * Collection id
 * @type {!number}
 * @export
 */
API.Client.Collection.prototype.id;

/**
 * Collection title
 * @type {!string}
 * @export
 */
API.Client.Collection.prototype.title;

/**
 * Collection DOI
 * @type {!string}
 * @export
 */
API.Client.Collection.prototype.doi;

/**
 * Collection Handle
 * @type {!string}
 * @export
 */
API.Client.Collection.prototype.handle;

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.Collection.prototype.url;

/**
 * Various timeline dates
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.Collection.prototype.timeline;

