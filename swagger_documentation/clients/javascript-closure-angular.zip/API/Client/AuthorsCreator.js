goog.provide('API.Client.AuthorsCreator');

/**
 * @record
 */
API.Client.AuthorsCreator = function() {}

/**
 * List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint.
 * @type {!Array<!API.Client.Object>}
 * @export
 */
API.Client.AuthorsCreator.prototype.authors;

