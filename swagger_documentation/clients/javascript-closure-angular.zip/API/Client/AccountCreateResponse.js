goog.provide('API.Client.AccountCreateResponse');

/**
 * @record
 */
API.Client.AccountCreateResponse = function() {}

/**
 * ID of created account
 * @type {!number}
 * @export
 */
API.Client.AccountCreateResponse.prototype.accountId;

