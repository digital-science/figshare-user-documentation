goog.provide('API.Client.CreateProjectResponse');

/**
 * @record
 */
API.Client.CreateProjectResponse = function() {}

/**
 * Figshare ID of the entity
 * @type {!number}
 * @export
 */
API.Client.CreateProjectResponse.prototype.entityId;

/**
 * Url for entity
 * @type {!string}
 * @export
 */
API.Client.CreateProjectResponse.prototype.location;

