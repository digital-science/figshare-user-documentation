goog.provide('API.Client.CollectionUpdate');

/**
 * @record
 */
API.Client.CollectionUpdate = function() {}

/**
 * Grant number or funding authority
 * @type {!string}
 * @export
 */
API.Client.CollectionUpdate.prototype.funding;

/**
 * Funding creation / update items
 * @type {!Array<!API.Client.FundingCreate>}
 * @export
 */
API.Client.CollectionUpdate.prototype.fundingList;

/**
 * Title of collection
 * @type {!string}
 * @export
 */
API.Client.CollectionUpdate.prototype.title;

/**
 * The collection description. In a publisher case, usually this is the remote collection description
 * @type {!string}
 * @export
 */
API.Client.CollectionUpdate.prototype.description;

/**
 * List of articles to be associated with the collection
 * @type {!Array<!number>}
 * @export
 */
API.Client.CollectionUpdate.prototype.articles;

/**
 * List of authors to be associated with the collection. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint.
 * @type {!Array<!API.Client.Object>}
 * @export
 */
API.Client.CollectionUpdate.prototype.authors;

/**
 * List of category ids to be associated with the collection (e.g [1, 23, 33, 66])
 * @type {!Array<!number>}
 * @export
 */
API.Client.CollectionUpdate.prototype.categories;

/**
 * List of category source ids to be associated with the article, supersedes the categories property
 * @type {!Array<!string>}
 * @export
 */
API.Client.CollectionUpdate.prototype.categoriesBySourceId;

/**
 * List of tags to be associated with the collection. Keywords can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.CollectionUpdate.prototype.tags;

/**
 * List of tags to be associated with the collection. Tags can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.CollectionUpdate.prototype.keywords;

/**
 * List of links to be associated with the collection (e.g [\"http://link1\", \"http://link2\", \"http://link3\"])
 * @type {!Array<!string>}
 * @export
 */
API.Client.CollectionUpdate.prototype.references;

/**
 * List of related materials; supersedes references and resource DOI/title.
 * @type {!Array<!API.Client.RelatedMaterial>}
 * @export
 */
API.Client.CollectionUpdate.prototype.relatedMaterials;

/**
 * List of key, values pairs to be associated with the collection
 * @type {!API.Client.Object}
 * @export
 */
API.Client.CollectionUpdate.prototype.customFields;

/**
 * List of custom fields values, supersedes custom_fields parameter
 * @type {!Array<!API.Client.CustomArticleFieldAdd>}
 * @export
 */
API.Client.CollectionUpdate.prototype.customFieldsList;

/**
 * Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
 * @type {!string}
 * @export
 */
API.Client.CollectionUpdate.prototype.doi;

/**
 * Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system.
 * @type {!string}
 * @export
 */
API.Client.CollectionUpdate.prototype.handle;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article id
 * @type {!string}
 * @export
 */
API.Client.CollectionUpdate.prototype.resourceId;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article DOI.
 * @type {!string}
 * @export
 */
API.Client.CollectionUpdate.prototype.resourceDoi;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article link
 * @type {!string}
 * @export
 */
API.Client.CollectionUpdate.prototype.resourceLink;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article title.
 * @type {!string}
 * @export
 */
API.Client.CollectionUpdate.prototype.resourceTitle;

/**
 * Not applicable to regular users. In a publisher case, this is the publisher article version
 * @type {!number}
 * @export
 */
API.Client.CollectionUpdate.prototype.resourceVersion;

/**
 * Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups
 * @type {!number}
 * @export
 */
API.Client.CollectionUpdate.prototype.groupId;

/**
 * Various timeline dates
 * @type {!API.Client.TimelineUpdate}
 * @export
 */
API.Client.CollectionUpdate.prototype.timeline;

