goog.provide('API.Client.PrivateCollectionSearch');

/**
 * @record
 */
API.Client.PrivateCollectionSearch = function() {}

/**
 * Only return collections with this resource_doi
 * @type {!string}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.resourceDoi;

/**
 * Only return collections with this doi
 * @type {!string}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.doi;

/**
 * Only return collections with this handle
 * @type {!string}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.handle;

/**
 * The field by which to order.
 * @type {!string}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.order;

/**
 * Search term
 * @type {!string}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.searchFor;

/**
 * Page number. Used for pagination with page_size
 * @type {!number}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.page;

/**
 * The number of results included on a page. Used for pagination with page
 * @type {!number}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.pageSize;

/**
 * Number of results included on a page. Used for pagination with query
 * @type {!number}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.limit;

/**
 * Where to start the listing(the offset of the first result). Used for pagination with limit
 * @type {!number}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.offset;

/**
 * Direction of ordering
 * @type {!string}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.orderDirection;

/**
 * only return collections from this institution
 * @type {!number}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.institution;

/**
 * Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
 * @type {!string}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.publishedSince;

/**
 * Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
 * @type {!string}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.modifiedSince;

/**
 * only return collections from this group
 * @type {!number}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.group;

/**
 * only return collections with this resource_id
 * @type {!string}
 * @export
 */
API.Client.PrivateCollectionSearch.prototype.resourceId;

/** @enum {string} */
API.Client.PrivateCollectionSearch.OrderEnum = { 
  created_date: 'created_date',
  published_date: 'published_date',
  modified_date: 'modified_date',
  views: 'views',
  shares: 'shares',
  cites: 'cites',
}
/** @enum {string} */
API.Client.PrivateCollectionSearch.OrderDirectionEnum = { 
  asc: 'asc',
  desc: 'desc',
}
