goog.provide('API.Client.CollectionComplete');

/**
 * @record
 */
API.Client.CollectionComplete = function() {}

/**
 * Collection id
 * @type {!number}
 * @export
 */
API.Client.CollectionComplete.prototype.id;

/**
 * Collection title
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.title;

/**
 * Collection DOI
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.doi;

/**
 * Collection Handle
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.handle;

/**
 * Api endpoint
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.url;

/**
 * Various timeline dates
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.CollectionComplete.prototype.timeline;

/**
 * Full Collection funding information
 * @type {!Array<!API.Client.FundingInformation>}
 * @export
 */
API.Client.CollectionComplete.prototype.funding;

/**
 * Collection resource id
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.resourceId;

/**
 * Collection resource doi
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.resourceDoi;

/**
 * Collection resource title
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.resourceTitle;

/**
 * Collection resource link
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.resourceLink;

/**
 * Collection resource version
 * @type {!number}
 * @export
 */
API.Client.CollectionComplete.prototype.resourceVersion;

/**
 * Collection version
 * @type {!number}
 * @export
 */
API.Client.CollectionComplete.prototype.version;

/**
 * Collection description
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.description;

/**
 * List of collection categories
 * @type {!Array<!API.Client.Category>}
 * @export
 */
API.Client.CollectionComplete.prototype.categories;

/**
 * List of collection references
 * @type {!Array<!string>}
 * @export
 */
API.Client.CollectionComplete.prototype.references;

/**
 * List of related materials; supersedes references and resource DOI/title.
 * @type {!Array<!API.Client.RelatedMaterial>}
 * @export
 */
API.Client.CollectionComplete.prototype.relatedMaterials;

/**
 * List of collection tags. Keywords can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.CollectionComplete.prototype.tags;

/**
 * List of collection keywords. Tags can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.CollectionComplete.prototype.keywords;

/**
 * List of collection authors
 * @type {!Array<!API.Client.Author>}
 * @export
 */
API.Client.CollectionComplete.prototype.authors;

/**
 * Collection institution
 * @type {!number}
 * @export
 */
API.Client.CollectionComplete.prototype.institutionId;

/**
 * Collection group
 * @type {!number}
 * @export
 */
API.Client.CollectionComplete.prototype.groupId;

/**
 * Number of articles in collection
 * @type {!number}
 * @export
 */
API.Client.CollectionComplete.prototype.articlesCount;

/**
 * True if collection is published
 * @type {!boolean}
 * @export
 */
API.Client.CollectionComplete.prototype._public;

/**
 * Collection citation
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.citation;

/**
 * Collection custom fields
 * @type {!Array<!API.Client.CustomArticleField>}
 * @export
 */
API.Client.CollectionComplete.prototype.customFields;

/**
 * Date when collection was last modified
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.modifiedDate;

/**
 * Date when collection was created
 * @type {!string}
 * @export
 */
API.Client.CollectionComplete.prototype.createdDate;

