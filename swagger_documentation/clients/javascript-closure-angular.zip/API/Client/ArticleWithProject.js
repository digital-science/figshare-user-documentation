goog.provide('API.Client.ArticleWithProject');

/**
 * @record
 */
API.Client.ArticleWithProject = function() {}

/**
 * Project id for this article.
 * @type {!number}
 * @export
 */
API.Client.ArticleWithProject.prototype.projectId;

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ArticleWithProject.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.urlPrivateApi;

/**
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.ArticleWithProject.prototype.timeline;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.thumb;

/**
 * Type of article identifier
 * @type {!number}
 * @export
 */
API.Client.ArticleWithProject.prototype.definedType;

/**
 * Name of the article type identifier
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.definedTypeName;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI.
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.resourceDoi;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title.
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.resourceTitle;

/**
 * Date when article was created
 * @type {!string}
 * @export
 */
API.Client.ArticleWithProject.prototype.createdDate;

