goog.provide('API.Client.OAuthToken');

/**
 * @record
 */
API.Client.OAuthToken = function() {}

/**
 * The OAuth access token
 * @type {!string}
 * @export
 */
API.Client.OAuthToken.prototype.accessToken;

/**
 * The OAuth access token
 * @type {!string}
 * @export
 */
API.Client.OAuthToken.prototype.token;

/**
 * The type of token issued
 * @type {!string}
 * @export
 */
API.Client.OAuthToken.prototype.tokenType;

/**
 * Token expiration time in seconds
 * @type {!number}
 * @export
 */
API.Client.OAuthToken.prototype.expiresIn;

/**
 * The refresh token (only provided for certain grant types)
 * @type {!string}
 * @export
 */
API.Client.OAuthToken.prototype.refreshToken;

/**
 * The scope of the access token
 * @type {!string}
 * @export
 */
API.Client.OAuthToken.prototype.scope;

