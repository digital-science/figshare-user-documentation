goog.provide('API.Client.Institution');

/**
 * @record
 */
API.Client.Institution = function() {}

/**
 * Institution id
 * @type {!number}
 * @export
 */
API.Client.Institution.prototype.id;

/**
 * Institution name
 * @type {!string}
 * @export
 */
API.Client.Institution.prototype.name;

