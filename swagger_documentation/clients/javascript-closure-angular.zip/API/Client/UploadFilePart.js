goog.provide('API.Client.UploadFilePart');

/**
 * @record
 */
API.Client.UploadFilePart = function() {}

/**
 * File part id
 * @type {!number}
 * @export
 */
API.Client.UploadFilePart.prototype.partNo;

/**
 * Indexes on byte range. zero-based and inclusive
 * @type {!number}
 * @export
 */
API.Client.UploadFilePart.prototype.startOffset;

/**
 * Indexes on byte range. zero-based and inclusive
 * @type {!number}
 * @export
 */
API.Client.UploadFilePart.prototype.endOffset;

/**
 * part status
 * @type {!string}
 * @export
 */
API.Client.UploadFilePart.prototype.status;

/**
 * When a part is being uploaded it is being locked, by setting the locked flag to true. No changes/uploads can happen on this part from other requests.
 * @type {!boolean}
 * @export
 */
API.Client.UploadFilePart.prototype.locked;

/** @enum {string} */
API.Client.UploadFilePart.StatusEnum = { 
  PENDING: 'PENDING',
  COMPLETE: 'COMPLETE',
}
