goog.provide('API.Client.ProjectArticle');

/**
 * @record
 */
API.Client.ProjectArticle = function() {}

/**
 * Unique identifier for article
 * @type {!number}
 * @export
 */
API.Client.ProjectArticle.prototype.id;

/**
 * Title of article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.title;

/**
 * DOI
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.doi;

/**
 * Handle
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.handle;

/**
 * Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.url;

/**
 * Public site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPublicHtml;

/**
 * Public Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPublicApi;

/**
 * Private site endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPrivateHtml;

/**
 * Private Api endpoint for article
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.urlPrivateApi;

/**
 * Various timeline dates
 * @type {!API.Client.Timeline}
 * @export
 */
API.Client.ProjectArticle.prototype.timeline;

/**
 * Thumbnail image
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.thumb;

/**
 * Type of article identifier
 * @type {!number}
 * @export
 */
API.Client.ProjectArticle.prototype.definedType;

/**
 * Name of the article type identifier
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.definedTypeName;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI.
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.resourceDoi;

/**
 * Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title.
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.resourceTitle;

/**
 * Date when article was created
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.createdDate;

/**
 * Article citation
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.citation;

/**
 * Confidentiality reason
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.confidentialReason;

/**
 * Article Confidentiality
 * @type {!boolean}
 * @export
 */
API.Client.ProjectArticle.prototype.isConfidential;

/**
 * Article size
 * @type {!number}
 * @export
 */
API.Client.ProjectArticle.prototype.size;

/**
 * Article funding
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.funding;

/**
 * Full Article funding information
 * @type {!Array<!API.Client.FundingInformation>}
 * @export
 */
API.Client.ProjectArticle.prototype.fundingList;

/**
 * List of article tags. Keywords can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.ProjectArticle.prototype.tags;

/**
 * List of article keywords. Tags can be used instead
 * @type {!Array<!string>}
 * @export
 */
API.Client.ProjectArticle.prototype.keywords;

/**
 * Article version
 * @type {!number}
 * @export
 */
API.Client.ProjectArticle.prototype.version;

/**
 * True if article has no files
 * @type {!boolean}
 * @export
 */
API.Client.ProjectArticle.prototype.isMetadataRecord;

/**
 * Article metadata reason
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.metadataReason;

/**
 * Article status
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.status;

/**
 * Article description
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.description;

/**
 * True if article is embargoed
 * @type {!boolean}
 * @export
 */
API.Client.ProjectArticle.prototype.isEmbargoed;

/**
 * True if article is published
 * @type {!boolean}
 * @export
 */
API.Client.ProjectArticle.prototype.isPublic;

/**
 * True if any files are linked to the article
 * @type {!boolean}
 * @export
 */
API.Client.ProjectArticle.prototype.hasLinkedFile;

/**
 * List of categories selected for the article
 * @type {!Array<!API.Client.Category>}
 * @export
 */
API.Client.ProjectArticle.prototype.categories;

/**
 * Article selected license
 * @type {!API.Client.License}
 * @export
 */
API.Client.ProjectArticle.prototype.license;

/**
 * Title for embargo
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.embargoTitle;

/**
 * Reason for embargo
 * @type {!string}
 * @export
 */
API.Client.ProjectArticle.prototype.embargoReason;

/**
 * List of references
 * @type {!Array<!string>}
 * @export
 */
API.Client.ProjectArticle.prototype.references;

/**
 * List of related materials; supersedes references and resource DOI/title.
 * @type {!Array<!API.Client.RelatedMaterial>}
 * @export
 */
API.Client.ProjectArticle.prototype.relatedMaterials;

