goog.provide('API.Client.LocationWarnings');

/**
 * @record
 */
API.Client.LocationWarnings = function() {}

/**
 * Figshare ID of the entity
 * @type {!number}
 * @export
 */
API.Client.LocationWarnings.prototype.entityId;

/**
 * Url for entity
 * @type {!string}
 * @export
 */
API.Client.LocationWarnings.prototype.location;

/**
 * Issues encountered during the operation
 * @type {!Array<!string>}
 * @export
 */
API.Client.LocationWarnings.prototype.warnings;

