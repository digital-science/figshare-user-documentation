goog.provide('API.Client.symplectic_user_id_200_response');

/**
 * @record
 */
API.Client.SymplecticUserId200Response = function() {}

/**
 * @type {!string}
 * @export
 */
API.Client.SymplecticUserId200Response.prototype.institutionUserId;

