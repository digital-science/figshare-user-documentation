/**
 * The ArticlesController file is a very simple one, which does not need to be changed manually,
 * unless there's a case where business logic routes the request to an entity which is not
 * the service.
 * The heavy lifting of the Controller item is done in Request.js - that is where request
 * parameters are extracted and sent to the service, and where response is handled.
 */

const Controller = require('./Controller');
const service = require('../services/ArticlesService');
const account_article_publish = async (request, response) => {
  await Controller.handleRequest(request, response, service.account_article_publish);
};

const account_article_report = async (request, response) => {
  await Controller.handleRequest(request, response, service.account_article_report);
};

const account_article_report_generate = async (request, response) => {
  await Controller.handleRequest(request, response, service.account_article_report_generate);
};

const account_article_unpublish = async (request, response) => {
  await Controller.handleRequest(request, response, service.account_article_unpublish);
};

const article_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.article_details);
};

const article_file_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.article_file_details);
};

const article_files = async (request, response) => {
  await Controller.handleRequest(request, response, service.article_files);
};

const article_version_confidentiality = async (request, response) => {
  await Controller.handleRequest(request, response, service.article_version_confidentiality);
};

const article_version_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.article_version_details);
};

const article_version_embargo = async (request, response) => {
  await Controller.handleRequest(request, response, service.article_version_embargo);
};

const article_version_files = async (request, response) => {
  await Controller.handleRequest(request, response, service.article_version_files);
};

const article_version_partial_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.article_version_partial_update);
};

const article_version_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.article_version_update);
};

const article_version_update_thumb = async (request, response) => {
  await Controller.handleRequest(request, response, service.article_version_update_thumb);
};

const article_versions = async (request, response) => {
  await Controller.handleRequest(request, response, service.article_versions);
};

const articles_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.articles_list);
};

const articles_search = async (request, response) => {
  await Controller.handleRequest(request, response, service.articles_search);
};

const private_article_author_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_author_delete);
};

const private_article_authors_add = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_authors_add);
};

const private_article_authors_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_authors_list);
};

const private_article_authors_replace = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_authors_replace);
};

const private_article_categories_add = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_categories_add);
};

const private_article_categories_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_categories_list);
};

const private_article_categories_replace = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_categories_replace);
};

const private_article_category_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_category_delete);
};

const private_article_confidentiality_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_confidentiality_delete);
};

const private_article_confidentiality_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_confidentiality_details);
};

const private_article_confidentiality_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_confidentiality_update);
};

const private_article_create = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_create);
};

const private_article_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_delete);
};

const private_article_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_details);
};

const private_article_download = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_download);
};

const private_article_embargo_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_embargo_delete);
};

const private_article_embargo_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_embargo_details);
};

const private_article_embargo_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_embargo_update);
};

const private_article_file = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_file);
};

const private_article_file_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_file_delete);
};

const private_article_files_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_files_list);
};

const private_article_partial_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_partial_update);
};

const private_article_private_link = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_private_link);
};

const private_article_private_link_create = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_private_link_create);
};

const private_article_private_link_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_private_link_delete);
};

const private_article_private_link_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_private_link_update);
};

const private_article_reserve_doi = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_reserve_doi);
};

const private_article_reserve_handle = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_reserve_handle);
};

const private_article_resource = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_resource);
};

const private_article_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_update);
};

const private_article_upload_complete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_upload_complete);
};

const private_article_upload_initiate = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_article_upload_initiate);
};

const private_articles_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_articles_list);
};

const private_articles_search = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_articles_search);
};

const public_article_download = async (request, response) => {
  await Controller.handleRequest(request, response, service.public_article_download);
};

const public_article_version_download = async (request, response) => {
  await Controller.handleRequest(request, response, service.public_article_version_download);
};


module.exports = {
  account_article_publish,
  account_article_report,
  account_article_report_generate,
  account_article_unpublish,
  article_details,
  article_file_details,
  article_files,
  article_version_confidentiality,
  article_version_details,
  article_version_embargo,
  article_version_files,
  article_version_partial_update,
  article_version_update,
  article_version_update_thumb,
  article_versions,
  articles_list,
  articles_search,
  private_article_author_delete,
  private_article_authors_add,
  private_article_authors_list,
  private_article_authors_replace,
  private_article_categories_add,
  private_article_categories_list,
  private_article_categories_replace,
  private_article_category_delete,
  private_article_confidentiality_delete,
  private_article_confidentiality_details,
  private_article_confidentiality_update,
  private_article_create,
  private_article_delete,
  private_article_details,
  private_article_download,
  private_article_embargo_delete,
  private_article_embargo_details,
  private_article_embargo_update,
  private_article_file,
  private_article_file_delete,
  private_article_files_list,
  private_article_partial_update,
  private_article_private_link,
  private_article_private_link_create,
  private_article_private_link_delete,
  private_article_private_link_update,
  private_article_reserve_doi,
  private_article_reserve_handle,
  private_article_resource,
  private_article_update,
  private_article_upload_complete,
  private_article_upload_initiate,
  private_articles_list,
  private_articles_search,
  public_article_download,
  public_article_version_download,
};
