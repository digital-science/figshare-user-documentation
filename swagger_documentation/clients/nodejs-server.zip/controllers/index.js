const ArticlesController = require('./ArticlesController');
const AuthorsController = require('./AuthorsController');
const CollectionsController = require('./CollectionsController');
const InstitutionsController = require('./InstitutionsController');
const OauthController = require('./OauthController');
const OtherController = require('./OtherController');
const ProfilesController = require('./ProfilesController');
const ProjectsController = require('./ProjectsController');

module.exports = {
  ArticlesController,
  AuthorsController,
  CollectionsController,
  InstitutionsController,
  OauthController,
  OtherController,
  ProfilesController,
  ProjectsController,
};
