/**
 * The ProjectsController file is a very simple one, which does not need to be changed manually,
 * unless there's a case where business logic routes the request to an entity which is not
 * the service.
 * The heavy lifting of the Controller item is done in Request.js - that is where request
 * parameters are extracted and sent to the service, and where response is handled.
 */

const Controller = require('./Controller');
const service = require('../services/ProjectsService');
const private_project_article_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_article_delete);
};

const private_project_article_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_article_details);
};

const private_project_article_file = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_article_file);
};

const private_project_article_files = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_article_files);
};

const private_project_articles_create = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_articles_create);
};

const private_project_articles_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_articles_list);
};

const private_project_collaborator__Delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_collaborator__Delete);
};

const private_project_collaborators_invite = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_collaborators_invite);
};

const private_project_collaborators_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_collaborators_list);
};

const private_project_create = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_create);
};

const private_project_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_delete);
};

const private_project_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_details);
};

const private_project_leave = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_leave);
};

const private_project_note = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_note);
};

const private_project_note_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_note_delete);
};

const private_project_note_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_note_update);
};

const private_project_notes_create = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_notes_create);
};

const private_project_notes_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_notes_list);
};

const private_project_partial_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_partial_update);
};

const private_project_publish = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_publish);
};

const private_project_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_project_update);
};

const private_projects_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_projects_list);
};

const private_projects_search = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_projects_search);
};

const project_articles = async (request, response) => {
  await Controller.handleRequest(request, response, service.project_articles);
};

const project_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.project_details);
};

const projects_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.projects_list);
};

const projects_search = async (request, response) => {
  await Controller.handleRequest(request, response, service.projects_search);
};


module.exports = {
  private_project_article_delete,
  private_project_article_details,
  private_project_article_file,
  private_project_article_files,
  private_project_articles_create,
  private_project_articles_list,
  private_project_collaborator__Delete,
  private_project_collaborators_invite,
  private_project_collaborators_list,
  private_project_create,
  private_project_delete,
  private_project_details,
  private_project_leave,
  private_project_note,
  private_project_note_delete,
  private_project_note_update,
  private_project_notes_create,
  private_project_notes_list,
  private_project_partial_update,
  private_project_publish,
  private_project_update,
  private_projects_list,
  private_projects_search,
  project_articles,
  project_details,
  projects_list,
  projects_search,
};
