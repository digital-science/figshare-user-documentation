/**
 * The AuthorsController file is a very simple one, which does not need to be changed manually,
 * unless there's a case where business logic routes the request to an entity which is not
 * the service.
 * The heavy lifting of the Controller item is done in Request.js - that is where request
 * parameters are extracted and sent to the service, and where response is handled.
 */

const Controller = require('./Controller');
const service = require('../services/AuthorsService');
const private_author_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_author_details);
};

const private_authors_search = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_authors_search);
};


module.exports = {
  private_author_details,
  private_authors_search,
};
