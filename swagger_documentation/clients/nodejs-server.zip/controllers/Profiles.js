'use strict';

var utils = require('../utils/writer.js');
var Profiles = require('../service/ProfilesService');

module.exports.update_user_profile = function update_user_profile (req, res, next) {
  var user profile data = req.swagger.params['User profile data'].value;
  var user_id = req.swagger.params['user_id'].value;
  var institution_user_id = req.swagger.params['institution_user_id'].value;
  Profiles.update_user_profile(user profile data,user_id,institution_user_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.update_user_profile_picture = function update_user_profile_picture (req, res, next) {
  var user_id = req.swagger.params['user_id'].value;
  var profile_picture = req.swagger.params['profile_picture'].value;
  Profiles.update_user_profile_picture(user_id,profile_picture)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
