'use strict';

var utils = require('../utils/writer.js');
var Collections = require('../service/CollectionsService');

module.exports.collection_articles = function collection_articles (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  Collections.collection_articles(collection_id,page,page_size,limit,offset)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.collection_details = function collection_details (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  Collections.collection_details(collection_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.collection_version_details = function collection_version_details (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var version_id = req.swagger.params['version_id'].value;
  Collections.collection_version_details(collection_id,version_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.collection_versions = function collection_versions (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  Collections.collection_versions(collection_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.collections_list = function collections_list (req, res, next) {
  var xCursor = req.swagger.params['X-Cursor'].value;
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  var order = req.swagger.params['order'].value;
  var order_direction = req.swagger.params['order_direction'].value;
  var institution = req.swagger.params['institution'].value;
  var published_since = req.swagger.params['published_since'].value;
  var modified_since = req.swagger.params['modified_since'].value;
  var group = req.swagger.params['group'].value;
  var resource_doi = req.swagger.params['resource_doi'].value;
  var doi = req.swagger.params['doi'].value;
  var handle = req.swagger.params['handle'].value;
  Collections.collections_list(xCursor,page,page_size,limit,offset,order,order_direction,institution,published_since,modified_since,group,resource_doi,doi,handle)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.collections_search = function collections_search (req, res, next) {
  var xCursor = req.swagger.params['X-Cursor'].value;
  var search = req.swagger.params['search'].value;
  Collections.collections_search(xCursor,search)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_article_delete = function private_collection_article_delete (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var article_id = req.swagger.params['article_id'].value;
  Collections.private_collection_article_delete(collection_id,article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_articles_add = function private_collection_articles_add (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var articles = req.swagger.params['articles'].value;
  Collections.private_collection_articles_add(collection_id,articles)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_articles_list = function private_collection_articles_list (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  Collections.private_collection_articles_list(collection_id,page,page_size,limit,offset)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_articles_replace = function private_collection_articles_replace (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var articles = req.swagger.params['articles'].value;
  Collections.private_collection_articles_replace(collection_id,articles)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_author_delete = function private_collection_author_delete (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var author_id = req.swagger.params['author_id'].value;
  Collections.private_collection_author_delete(collection_id,author_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_authors_add = function private_collection_authors_add (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var authors = req.swagger.params['Authors'].value;
  Collections.private_collection_authors_add(collection_id,authors)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_authors_list = function private_collection_authors_list (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  Collections.private_collection_authors_list(collection_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_authors_replace = function private_collection_authors_replace (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var authors = req.swagger.params['Authors'].value;
  Collections.private_collection_authors_replace(collection_id,authors)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_categories_add = function private_collection_categories_add (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var categories = req.swagger.params['categories'].value;
  Collections.private_collection_categories_add(collection_id,categories)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_categories_list = function private_collection_categories_list (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  Collections.private_collection_categories_list(collection_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_categories_replace = function private_collection_categories_replace (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var categories = req.swagger.params['categories'].value;
  Collections.private_collection_categories_replace(collection_id,categories)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_category_delete = function private_collection_category_delete (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var category_id = req.swagger.params['category_id'].value;
  Collections.private_collection_category_delete(collection_id,category_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_create = function private_collection_create (req, res, next) {
  var collection = req.swagger.params['Collection'].value;
  Collections.private_collection_create(collection)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_delete = function private_collection_delete (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  Collections.private_collection_delete(collection_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_details = function private_collection_details (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  Collections.private_collection_details(collection_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_patch = function private_collection_patch (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var collection = req.swagger.params['Collection'].value;
  Collections.private_collection_patch(collection_id,collection)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_private_link_create = function private_collection_private_link_create (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var private_link = req.swagger.params['private_link'].value;
  Collections.private_collection_private_link_create(collection_id,private_link)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_private_link_delete = function private_collection_private_link_delete (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var link_id = req.swagger.params['link_id'].value;
  Collections.private_collection_private_link_delete(collection_id,link_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_private_link_details = function private_collection_private_link_details (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var link_id = req.swagger.params['link_id'].value;
  Collections.private_collection_private_link_details(collection_id,link_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_private_link_update = function private_collection_private_link_update (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var link_id = req.swagger.params['link_id'].value;
  var private_link = req.swagger.params['private_link'].value;
  Collections.private_collection_private_link_update(collection_id,link_id,private_link)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_private_links_list = function private_collection_private_links_list (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  Collections.private_collection_private_links_list(collection_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_publish = function private_collection_publish (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  Collections.private_collection_publish(collection_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_reserve_doi = function private_collection_reserve_doi (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  Collections.private_collection_reserve_doi(collection_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_reserve_handle = function private_collection_reserve_handle (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  Collections.private_collection_reserve_handle(collection_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_resource = function private_collection_resource (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var resource = req.swagger.params['Resource'].value;
  Collections.private_collection_resource(collection_id,resource)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collection_update = function private_collection_update (req, res, next) {
  var collection_id = req.swagger.params['collection_id'].value;
  var collection = req.swagger.params['Collection'].value;
  Collections.private_collection_update(collection_id,collection)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collections_list = function private_collections_list (req, res, next) {
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  var order = req.swagger.params['order'].value;
  var order_direction = req.swagger.params['order_direction'].value;
  Collections.private_collections_list(page,page_size,limit,offset,order,order_direction)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_collections_search = function private_collections_search (req, res, next) {
  var search = req.swagger.params['search'].value;
  Collections.private_collections_search(search)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
