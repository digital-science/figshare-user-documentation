'use strict';

var utils = require('../utils/writer.js');
var Institutions = require('../service/InstitutionsService');

module.exports.account_institution_curation = function account_institution_curation (req, res, next) {
  var curation_id = req.swagger.params['curation_id'].value;
  Institutions.account_institution_curation(curation_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.account_institution_curations = function account_institution_curations (req, res, next) {
  var group_id = req.swagger.params['group_id'].value;
  var article_id = req.swagger.params['article_id'].value;
  var status = req.swagger.params['status'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  Institutions.account_institution_curations(group_id,article_id,status,limit,offset)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.custom_fields_list = function custom_fields_list (req, res, next) {
  var group_id = req.swagger.params['group_id'].value;
  Institutions.custom_fields_list(group_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.custom_fields_upload = function custom_fields_upload (req, res, next) {
  var custom_field_id = req.swagger.params['custom_field_id'].value;
  var external_file = req.swagger.params['external_file'].value;
  Institutions.custom_fields_upload(custom_field_id,external_file)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.get_account_institution_curation_comments = function get_account_institution_curation_comments (req, res, next) {
  var curation_id = req.swagger.params['curation_id'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  Institutions.get_account_institution_curation_comments(curation_id,limit,offset)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.institution_articles = function institution_articles (req, res, next) {
  var institution_string_id = req.swagger.params['institution_string_id'].value;
  var resource_id = req.swagger.params['resource_id'].value;
  var filename = req.swagger.params['filename'].value;
  Institutions.institution_articles(institution_string_id,resource_id,filename)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.institution_hrfeed_upload = function institution_hrfeed_upload (req, res, next) {
  var hrfeed = req.swagger.params['hrfeed'].value;
  Institutions.institution_hrfeed_upload(hrfeed)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.post_account_institution_curation_comments = function post_account_institution_curation_comments (req, res, next) {
  var curation_id = req.swagger.params['curation_id'].value;
  var curationComment = req.swagger.params['CurationComment'].value;
  Institutions.post_account_institution_curation_comments(curation_id,curationComment)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_account_institution_user = function private_account_institution_user (req, res, next) {
  var account_id = req.swagger.params['account_id'].value;
  Institutions.private_account_institution_user(account_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_categories_list = function private_categories_list (req, res, next) {
  Institutions.private_categories_list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_group_embargo_options_details = function private_group_embargo_options_details (req, res, next) {
  var group_id = req.swagger.params['group_id'].value;
  Institutions.private_group_embargo_options_details(group_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_institution_account_group_role_delete = function private_institution_account_group_role_delete (req, res, next) {
  var account_id = req.swagger.params['account_id'].value;
  var group_id = req.swagger.params['group_id'].value;
  var role_id = req.swagger.params['role_id'].value;
  Institutions.private_institution_account_group_role_delete(account_id,group_id,role_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_institution_account_group_roles = function private_institution_account_group_roles (req, res, next) {
  var account_id = req.swagger.params['account_id'].value;
  Institutions.private_institution_account_group_roles(account_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_institution_account_group_roles_create = function private_institution_account_group_roles_create (req, res, next) {
  var account_id = req.swagger.params['account_id'].value;
  var account = req.swagger.params['Account'].value;
  Institutions.private_institution_account_group_roles_create(account_id,account)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_institution_accounts_create = function private_institution_accounts_create (req, res, next) {
  var account = req.swagger.params['Account'].value;
  Institutions.private_institution_accounts_create(account)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_institution_accounts_list = function private_institution_accounts_list (req, res, next) {
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  var is_active = req.swagger.params['is_active'].value;
  var institution_user_id = req.swagger.params['institution_user_id'].value;
  var email = req.swagger.params['email'].value;
  var id_lte = req.swagger.params['id_lte'].value;
  var id_gte = req.swagger.params['id_gte'].value;
  Institutions.private_institution_accounts_list(page,page_size,limit,offset,is_active,institution_user_id,email,id_lte,id_gte)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_institution_accounts_search = function private_institution_accounts_search (req, res, next) {
  var search = req.swagger.params['search'].value;
  Institutions.private_institution_accounts_search(search)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_institution_accounts_update = function private_institution_accounts_update (req, res, next) {
  var account_id = req.swagger.params['account_id'].value;
  var account = req.swagger.params['Account'].value;
  Institutions.private_institution_accounts_update(account_id,account)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_institution_articles = function private_institution_articles (req, res, next) {
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  var order = req.swagger.params['order'].value;
  var order_direction = req.swagger.params['order_direction'].value;
  var published_since = req.swagger.params['published_since'].value;
  var modified_since = req.swagger.params['modified_since'].value;
  var status = req.swagger.params['status'].value;
  var resource_doi = req.swagger.params['resource_doi'].value;
  var item_type = req.swagger.params['item_type'].value;
  var group = req.swagger.params['group'].value;
  Institutions.private_institution_articles(page,page_size,limit,offset,order,order_direction,published_since,modified_since,status,resource_doi,item_type,group)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_institution_details = function private_institution_details (req, res, next) {
  Institutions.private_institution_details()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_institution_embargo_options_details = function private_institution_embargo_options_details (req, res, next) {
  Institutions.private_institution_embargo_options_details()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_institution_groups_list = function private_institution_groups_list (req, res, next) {
  Institutions.private_institution_groups_list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_institution_roles_list = function private_institution_roles_list (req, res, next) {
  Institutions.private_institution_roles_list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
