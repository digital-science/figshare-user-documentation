'use strict';

var utils = require('../utils/writer.js');
var Authors = require('../service/AuthorsService');

module.exports.private_author_details = function private_author_details (req, res, next) {
  var author_id = req.swagger.params['author_id'].value;
  Authors.private_author_details(author_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_authors_search = function private_authors_search (req, res, next) {
  var search = req.swagger.params['search'].value;
  Authors.private_authors_search(search)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
