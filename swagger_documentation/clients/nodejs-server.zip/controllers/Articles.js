'use strict';

var utils = require('../utils/writer.js');
var Articles = require('../service/ArticlesService');

module.exports.account_article_publish = function account_article_publish (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.account_article_publish(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.account_article_report = function account_article_report (req, res, next) {
  var group_id = req.swagger.params['group_id'].value;
  Articles.account_article_report(group_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.account_article_report_generate = function account_article_report_generate (req, res, next) {
  Articles.account_article_report_generate()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.account_article_unpublish = function account_article_unpublish (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var reason = req.swagger.params['reason'].value;
  Articles.account_article_unpublish(article_id,reason)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.article_details = function article_details (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.article_details(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.article_file_details = function article_file_details (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var file_id = req.swagger.params['file_id'].value;
  Articles.article_file_details(article_id,file_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.article_files = function article_files (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  Articles.article_files(article_id,page,page_size,limit,offset)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.article_version_confidentiality = function article_version_confidentiality (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var v_number = req.swagger.params['v_number'].value;
  Articles.article_version_confidentiality(article_id,v_number)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.article_version_details = function article_version_details (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var v_number = req.swagger.params['v_number'].value;
  Articles.article_version_details(article_id,v_number)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.article_version_embargo = function article_version_embargo (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var v_number = req.swagger.params['v_number'].value;
  Articles.article_version_embargo(article_id,v_number)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.article_version_update = function article_version_update (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var version_id = req.swagger.params['version_id'].value;
  var article = req.swagger.params['Article'].value;
  Articles.article_version_update(article_id,version_id,article)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.article_version_update_thumb = function article_version_update_thumb (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var version_id = req.swagger.params['version_id'].value;
  var fileId = req.swagger.params['FileId'].value;
  Articles.article_version_update_thumb(article_id,version_id,fileId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.article_versions = function article_versions (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.article_versions(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.articles_list = function articles_list (req, res, next) {
  var xCursor = req.swagger.params['X-Cursor'].value;
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  var order = req.swagger.params['order'].value;
  var order_direction = req.swagger.params['order_direction'].value;
  var institution = req.swagger.params['institution'].value;
  var published_since = req.swagger.params['published_since'].value;
  var modified_since = req.swagger.params['modified_since'].value;
  var group = req.swagger.params['group'].value;
  var resource_doi = req.swagger.params['resource_doi'].value;
  var item_type = req.swagger.params['item_type'].value;
  var doi = req.swagger.params['doi'].value;
  var handle = req.swagger.params['handle'].value;
  Articles.articles_list(xCursor,page,page_size,limit,offset,order,order_direction,institution,published_since,modified_since,group,resource_doi,item_type,doi,handle)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.articles_search = function articles_search (req, res, next) {
  var xCursor = req.swagger.params['X-Cursor'].value;
  var search = req.swagger.params['search'].value;
  Articles.articles_search(xCursor,search)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_author_delete = function private_article_author_delete (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var author_id = req.swagger.params['author_id'].value;
  Articles.private_article_author_delete(article_id,author_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_authors_add = function private_article_authors_add (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var authors = req.swagger.params['Authors'].value;
  Articles.private_article_authors_add(article_id,authors)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_authors_list = function private_article_authors_list (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.private_article_authors_list(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_authors_replace = function private_article_authors_replace (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var authors = req.swagger.params['Authors'].value;
  Articles.private_article_authors_replace(article_id,authors)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_categories_add = function private_article_categories_add (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var categories = req.swagger.params['categories'].value;
  Articles.private_article_categories_add(article_id,categories)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_categories_list = function private_article_categories_list (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.private_article_categories_list(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_categories_replace = function private_article_categories_replace (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var categories = req.swagger.params['categories'].value;
  Articles.private_article_categories_replace(article_id,categories)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_category_delete = function private_article_category_delete (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var category_id = req.swagger.params['category_id'].value;
  Articles.private_article_category_delete(article_id,category_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_confidentiality_delete = function private_article_confidentiality_delete (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.private_article_confidentiality_delete(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_confidentiality_details = function private_article_confidentiality_details (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.private_article_confidentiality_details(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_confidentiality_update = function private_article_confidentiality_update (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var reason = req.swagger.params['reason'].value;
  Articles.private_article_confidentiality_update(article_id,reason)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_create = function private_article_create (req, res, next) {
  var article = req.swagger.params['Article'].value;
  Articles.private_article_create(article)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_delete = function private_article_delete (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.private_article_delete(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_details = function private_article_details (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.private_article_details(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_embargo_delete = function private_article_embargo_delete (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.private_article_embargo_delete(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_embargo_details = function private_article_embargo_details (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.private_article_embargo_details(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_embargo_update = function private_article_embargo_update (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var embargo = req.swagger.params['Embargo'].value;
  Articles.private_article_embargo_update(article_id,embargo)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_file = function private_article_file (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var file_id = req.swagger.params['file_id'].value;
  Articles.private_article_file(article_id,file_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_file_delete = function private_article_file_delete (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var file_id = req.swagger.params['file_id'].value;
  Articles.private_article_file_delete(article_id,file_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_files_list = function private_article_files_list (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  Articles.private_article_files_list(article_id,page,page_size,limit,offset)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_private_link = function private_article_private_link (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.private_article_private_link(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_private_link_create = function private_article_private_link_create (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var private_link = req.swagger.params['private_link'].value;
  Articles.private_article_private_link_create(article_id,private_link)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_private_link_delete = function private_article_private_link_delete (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var link_id = req.swagger.params['link_id'].value;
  Articles.private_article_private_link_delete(article_id,link_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_private_link_update = function private_article_private_link_update (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var link_id = req.swagger.params['link_id'].value;
  var private_link = req.swagger.params['private_link'].value;
  Articles.private_article_private_link_update(article_id,link_id,private_link)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_reserve_doi = function private_article_reserve_doi (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.private_article_reserve_doi(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_reserve_handle = function private_article_reserve_handle (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  Articles.private_article_reserve_handle(article_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_resource = function private_article_resource (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var resource = req.swagger.params['Resource'].value;
  Articles.private_article_resource(article_id,resource)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_update = function private_article_update (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var article = req.swagger.params['Article'].value;
  Articles.private_article_update(article_id,article)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_upload_complete = function private_article_upload_complete (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var file_id = req.swagger.params['file_id'].value;
  Articles.private_article_upload_complete(article_id,file_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_article_upload_initiate = function private_article_upload_initiate (req, res, next) {
  var article_id = req.swagger.params['article_id'].value;
  var file = req.swagger.params['File'].value;
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  Articles.private_article_upload_initiate(article_id,file,page,page_size,limit,offset)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_articles_list = function private_articles_list (req, res, next) {
  var page = req.swagger.params['page'].value;
  var page_size = req.swagger.params['page_size'].value;
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  Articles.private_articles_list(page,page_size,limit,offset)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_articles_search = function private_articles_search (req, res, next) {
  var search = req.swagger.params['search'].value;
  Articles.private_articles_search(search)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
