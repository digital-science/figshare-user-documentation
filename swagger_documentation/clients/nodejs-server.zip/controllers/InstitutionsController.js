/**
 * The InstitutionsController file is a very simple one, which does not need to be changed manually,
 * unless there's a case where business logic routes the request to an entity which is not
 * the service.
 * The heavy lifting of the Controller item is done in Request.js - that is where request
 * parameters are extracted and sent to the service, and where response is handled.
 */

const Controller = require('./Controller');
const service = require('../services/InstitutionsService');
const account_institution_curation = async (request, response) => {
  await Controller.handleRequest(request, response, service.account_institution_curation);
};

const account_institution_curations = async (request, response) => {
  await Controller.handleRequest(request, response, service.account_institution_curations);
};

const custom_fields_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.custom_fields_list);
};

const custom_fields_upload = async (request, response) => {
  await Controller.handleRequest(request, response, service.custom_fields_upload);
};

const get_account_institution_curation_comments = async (request, response) => {
  await Controller.handleRequest(request, response, service.get_account_institution_curation_comments);
};

const institution_articles = async (request, response) => {
  await Controller.handleRequest(request, response, service.institution_articles);
};

const institution_hrfeed_upload = async (request, response) => {
  await Controller.handleRequest(request, response, service.institution_hrfeed_upload);
};

const post_account_institution_curation_comments = async (request, response) => {
  await Controller.handleRequest(request, response, service.post_account_institution_curation_comments);
};

const private_account_institution_user = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_account_institution_user);
};

const private_categories_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_categories_list);
};

const private_group_embargo_options_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_group_embargo_options_details);
};

const private_institution_account = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_account);
};

const private_institution_account_group_role_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_account_group_role_delete);
};

const private_institution_account_group_roles = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_account_group_roles);
};

const private_institution_account_group_roles_create = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_account_group_roles_create);
};

const private_institution_accounts_create = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_accounts_create);
};

const private_institution_accounts_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_accounts_list);
};

const private_institution_accounts_search = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_accounts_search);
};

const private_institution_accounts_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_accounts_update);
};

const private_institution_articles = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_articles);
};

const private_institution_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_details);
};

const private_institution_embargo_options_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_embargo_options_details);
};

const private_institution_groups_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_groups_list);
};

const private_institution_roles_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_institution_roles_list);
};


module.exports = {
  account_institution_curation,
  account_institution_curations,
  custom_fields_list,
  custom_fields_upload,
  get_account_institution_curation_comments,
  institution_articles,
  institution_hrfeed_upload,
  post_account_institution_curation_comments,
  private_account_institution_user,
  private_categories_list,
  private_group_embargo_options_details,
  private_institution_account,
  private_institution_account_group_role_delete,
  private_institution_account_group_roles,
  private_institution_account_group_roles_create,
  private_institution_accounts_create,
  private_institution_accounts_list,
  private_institution_accounts_search,
  private_institution_accounts_update,
  private_institution_articles,
  private_institution_details,
  private_institution_embargo_options_details,
  private_institution_groups_list,
  private_institution_roles_list,
};
