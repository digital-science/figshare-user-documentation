/**
 * The OtherController file is a very simple one, which does not need to be changed manually,
 * unless there's a case where business logic routes the request to an entity which is not
 * the service.
 * The heavy lifting of the Controller item is done in Request.js - that is where request
 * parameters are extracted and sent to the service, and where response is handled.
 */

const Controller = require('./Controller');
const service = require('../services/OtherService');
const categories_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.categories_list);
};

const file_download = async (request, response) => {
  await Controller.handleRequest(request, response, service.file_download);
};

const item_types_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.item_types_list);
};

const licenses_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.licenses_list);
};

const private_account = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_account);
};

const private_funding_search = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_funding_search);
};

const private_licenses_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_licenses_list);
};


module.exports = {
  categories_list,
  file_download,
  item_types_list,
  licenses_list,
  private_account,
  private_funding_search,
  private_licenses_list,
};
