/**
 * The CollectionsController file is a very simple one, which does not need to be changed manually,
 * unless there's a case where business logic routes the request to an entity which is not
 * the service.
 * The heavy lifting of the Controller item is done in Request.js - that is where request
 * parameters are extracted and sent to the service, and where response is handled.
 */

const Controller = require('./Controller');
const service = require('../services/CollectionsService');
const collection_articles = async (request, response) => {
  await Controller.handleRequest(request, response, service.collection_articles);
};

const collection_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.collection_details);
};

const collection_version_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.collection_version_details);
};

const collection_versions = async (request, response) => {
  await Controller.handleRequest(request, response, service.collection_versions);
};

const collections_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.collections_list);
};

const collections_search = async (request, response) => {
  await Controller.handleRequest(request, response, service.collections_search);
};

const private_collection_article_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_article_delete);
};

const private_collection_articles_add = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_articles_add);
};

const private_collection_articles_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_articles_list);
};

const private_collection_articles_replace = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_articles_replace);
};

const private_collection_author_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_author_delete);
};

const private_collection_authors_add = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_authors_add);
};

const private_collection_authors_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_authors_list);
};

const private_collection_authors_replace = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_authors_replace);
};

const private_collection_categories_add = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_categories_add);
};

const private_collection_categories_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_categories_list);
};

const private_collection_categories_replace = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_categories_replace);
};

const private_collection_category_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_category_delete);
};

const private_collection_create = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_create);
};

const private_collection_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_delete);
};

const private_collection_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_details);
};

const private_collection_patch = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_patch);
};

const private_collection_private_link_create = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_private_link_create);
};

const private_collection_private_link_delete = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_private_link_delete);
};

const private_collection_private_link_details = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_private_link_details);
};

const private_collection_private_link_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_private_link_update);
};

const private_collection_private_links_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_private_links_list);
};

const private_collection_publish = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_publish);
};

const private_collection_reserve_doi = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_reserve_doi);
};

const private_collection_reserve_handle = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_reserve_handle);
};

const private_collection_resource = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_resource);
};

const private_collection_update = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collection_update);
};

const private_collections_list = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collections_list);
};

const private_collections_search = async (request, response) => {
  await Controller.handleRequest(request, response, service.private_collections_search);
};


module.exports = {
  collection_articles,
  collection_details,
  collection_version_details,
  collection_versions,
  collections_list,
  collections_search,
  private_collection_article_delete,
  private_collection_articles_add,
  private_collection_articles_list,
  private_collection_articles_replace,
  private_collection_author_delete,
  private_collection_authors_add,
  private_collection_authors_list,
  private_collection_authors_replace,
  private_collection_categories_add,
  private_collection_categories_list,
  private_collection_categories_replace,
  private_collection_category_delete,
  private_collection_create,
  private_collection_delete,
  private_collection_details,
  private_collection_patch,
  private_collection_private_link_create,
  private_collection_private_link_delete,
  private_collection_private_link_details,
  private_collection_private_link_update,
  private_collection_private_links_list,
  private_collection_publish,
  private_collection_reserve_doi,
  private_collection_reserve_handle,
  private_collection_resource,
  private_collection_update,
  private_collections_list,
  private_collections_search,
};
