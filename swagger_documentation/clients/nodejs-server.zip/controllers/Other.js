'use strict';

var utils = require('../utils/writer.js');
var Other = require('../service/OtherService');

module.exports.categories_list = function categories_list (req, res, next) {
  Other.categories_list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.file_download = function file_download (req, res, next) {
  var file_id = req.swagger.params['file_id'].value;
  Other.file_download(file_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.item_types_list = function item_types_list (req, res, next) {
  var group_id = req.swagger.params['group_id'].value;
  Other.item_types_list(group_id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.licenses_list = function licenses_list (req, res, next) {
  Other.licenses_list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_account = function private_account (req, res, next) {
  Other.private_account()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_funding_search = function private_funding_search (req, res, next) {
  var search = req.swagger.params['search'].value;
  Other.private_funding_search(search)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.private_licenses_list = function private_licenses_list (req, res, next) {
  Other.private_licenses_list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
