/* eslint-disable no-unused-vars */
const Service = require('./Service');

/**
* Public Collection Articles
* Returns a list of public collection articles
*
* collectionUnderscoreid Long Collection Unique identifier
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* returns List
* */
const collection_articles = ({ collectionUnderscoreid, page, pageUnderscoresize, limit, offset }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        page,
        pageUnderscoresize,
        limit,
        offset,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Collection details
* View a collection
*
* collectionUnderscoreid Long Collection Unique identifier
* returns CollectionComplete
* */
const collection_details = ({ collectionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Collection Version details
* View details for a certain version of a collection
*
* collectionUnderscoreid Long Collection Unique identifier
* versionUnderscoreid Long Version Number
* returns CollectionComplete
* */
const collection_version_details = ({ collectionUnderscoreid, versionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        versionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Collection Versions list
* Returns a list of public collection Versions
*
* collectionUnderscoreid Long Collection Unique identifier
* returns List
* */
const collection_versions = ({ collectionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Collections
* Returns a list of public collections
*
* xCursor UUID Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* order String The field by which to order. Default varies by endpoint/resource. (optional)
* orderUnderscoredirection String  (optional)
* institution Long only return collections from this institution (optional)
* publishedUnderscoresince String Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD (optional)
* modifiedUnderscoresince String Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD (optional)
* group Long only return collections from this group (optional)
* resourceUnderscoredoi String only return collections with this resource_doi (optional)
* doi String only return collections with this doi (optional)
* handle String only return collections with this handle (optional)
* returns List
* */
const collections_list = ({ xCursor, page, pageUnderscoresize, limit, offset, order, orderUnderscoredirection, institution, publishedUnderscoresince, modifiedUnderscoresince, group, resourceUnderscoredoi, doi, handle }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        xCursor,
        page,
        pageUnderscoresize,
        limit,
        offset,
        order,
        orderUnderscoredirection,
        institution,
        publishedUnderscoresince,
        modifiedUnderscoresince,
        group,
        resourceUnderscoredoi,
        doi,
        handle,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Collections Search
* Returns a list of public collections
*
* xCursor UUID Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
* search CollectionSearch Search Parameters (optional)
* returns List
* */
const collections_search = ({ xCursor, search }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        xCursor,
        search,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Delete collection article
* De-associate article from collection
*
* collectionUnderscoreid Long Collection unique identifier
* articleUnderscoreid Long Collection article unique identifier
* no response value expected for this operation
* */
const private_collection_article_delete = ({ collectionUnderscoreid, articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Add collection articles
* Associate new articles with the collection. This will add new articles to the list of already associated articles
*
* collectionUnderscoreid Long Collection unique identifier
* articles ArticlesCreator Articles list
* returns Location
* */
const private_collection_articles_add = ({ collectionUnderscoreid, articles }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        articles,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List collection articles
* List collection articles
*
* collectionUnderscoreid Long Collection unique identifier
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* returns List
* */
const private_collection_articles_list = ({ collectionUnderscoreid, page, pageUnderscoresize, limit, offset }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        page,
        pageUnderscoresize,
        limit,
        offset,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Replace collection articles
* Associate new articles with the collection. This will remove all already associated articles and add these new ones
*
* collectionUnderscoreid Long Collection unique identifier
* articles ArticlesCreator Articles List
* no response value expected for this operation
* */
const private_collection_articles_replace = ({ collectionUnderscoreid, articles }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        articles,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Delete collection author
* Delete collection author
*
* collectionUnderscoreid Long Collection unique identifier
* authorUnderscoreid Long Collection Author unique identifier
* no response value expected for this operation
* */
const private_collection_author_delete = ({ collectionUnderscoreid, authorUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        authorUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Add collection authors
* Associate new authors with the collection. This will add new authors to the list of already associated authors
*
* collectionUnderscoreid Long Collection unique identifier
* authors AuthorsCreator List of authors
* returns Location
* */
const private_collection_authors_add = ({ collectionUnderscoreid, authors }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        authors,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List collection authors
* List collection authors
*
* collectionUnderscoreid Long Collection unique identifier
* returns List
* */
const private_collection_authors_list = ({ collectionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Replace collection authors
* Associate new authors with the collection. This will remove all already associated authors and add these new ones
*
* collectionUnderscoreid Long Collection unique identifier
* authors AuthorsCreator List of authors
* no response value expected for this operation
* */
const private_collection_authors_replace = ({ collectionUnderscoreid, authors }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        authors,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Add collection categories
* Associate new categories with the collection. This will add new categories to the list of already associated categories
*
* collectionUnderscoreid Long Collection unique identifier
* categories CategoriesCreator Categories list
* returns Location
* */
const private_collection_categories_add = ({ collectionUnderscoreid, categories }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        categories,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List collection categories
* List collection categories
*
* collectionUnderscoreid Long Collection unique identifier
* returns List
* */
const private_collection_categories_list = ({ collectionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Replace collection categories
* Associate new categories with the collection. This will remove all already associated categories and add these new ones
*
* collectionUnderscoreid Long Collection unique identifier
* categories CategoriesCreator Categories list
* no response value expected for this operation
* */
const private_collection_categories_replace = ({ collectionUnderscoreid, categories }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        categories,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Delete collection category
* De-associate category from collection
*
* collectionUnderscoreid Long Collection unique identifier
* categoryUnderscoreid Long Collection category unique identifier
* no response value expected for this operation
* */
const private_collection_category_delete = ({ collectionUnderscoreid, categoryUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        categoryUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Create collection
* Create a new Collection by sending collection information
*
* collection CollectionCreate Collection description
* returns LocationWarnings
* */
const private_collection_create = ({ collection }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collection,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Delete collection
* Delete n collection
*
* collectionUnderscoreid Long Collection Unique identifier
* no response value expected for this operation
* */
const private_collection_delete = ({ collectionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Collection details
* View a collection
*
* collectionUnderscoreid Long Collection Unique identifier
* returns CollectionCompletePrivate
* */
const private_collection_details = ({ collectionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Partially update collection
* Partially update a collection by sending only the fields to change.
*
* collectionUnderscoreid Long Collection Unique identifier
* collection CollectionUpdate Subset of collection fields to update
* returns LocationWarningsUpdate
* */
const private_collection_patch = ({ collectionUnderscoreid, collection }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        collection,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Create collection private link
* Create new private link
*
* collectionUnderscoreid Long Collection unique identifier
* privateUnderscorelink CollectionPrivateLinkCreator  (optional)
* returns PrivateLinkResponse
* */
const private_collection_private_link_create = ({ collectionUnderscoreid, privateUnderscorelink }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        privateUnderscorelink,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Disable private link
* Disable/delete private link for this collection
*
* collectionUnderscoreid Long Collection unique identifier
* linkUnderscoreid String Private link token
* no response value expected for this operation
* */
const private_collection_private_link_delete = ({ collectionUnderscoreid, linkUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        linkUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* View collection private link
* View existing private link for this collection
*
* collectionUnderscoreid Long Collection unique identifier
* linkUnderscoreid String Private link token
* returns PrivateLink
* */
const private_collection_private_link_details = ({ collectionUnderscoreid, linkUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        linkUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Update collection private link
* Update existing private link for this collection
*
* collectionUnderscoreid Long Collection unique identifier
* linkUnderscoreid String Private link token
* privateUnderscorelink CollectionPrivateLinkCreator  (optional)
* no response value expected for this operation
* */
const private_collection_private_link_update = ({ collectionUnderscoreid, linkUnderscoreid, privateUnderscorelink }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        linkUnderscoreid,
        privateUnderscorelink,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List collection private links
* List article private links
*
* collectionUnderscoreid Long Collection unique identifier
* returns List
* */
const private_collection_private_links_list = ({ collectionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Collection Publish
* When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.
*
* collectionUnderscoreid Long Collection Unique identifier
* returns Location
* */
const private_collection_publish = ({ collectionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Collection Reserve DOI
* Reserve DOI for collection
*
* collectionUnderscoreid Long Collection Unique identifier
* returns CollectionDOI
* */
const private_collection_reserve_doi = ({ collectionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Collection Reserve Handle
* Reserve Handle for collection
*
* collectionUnderscoreid Long Collection Unique identifier
* returns CollectionHandle
* */
const private_collection_reserve_handle = ({ collectionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Collection Resource
* Edit collection resource data.
*
* collectionUnderscoreid Long Collection unique identifier
* resource Resource Resource data
* returns Location
* */
const private_collection_resource = ({ collectionUnderscoreid, resource }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        resource,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Update collection
* Update a collection by passing full body parameters.
*
* collectionUnderscoreid Long Collection Unique identifier
* collection CollectionUpdate Collection description
* returns LocationWarningsUpdate
* */
const private_collection_update = ({ collectionUnderscoreid, collection }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        collectionUnderscoreid,
        collection,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Collections List
* List private collections
*
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* order String The field by which to order. Default varies by endpoint/resource. (optional)
* orderUnderscoredirection String  (optional)
* returns List
* */
const private_collections_list = ({ page, pageUnderscoresize, limit, offset, order, orderUnderscoredirection }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        page,
        pageUnderscoresize,
        limit,
        offset,
        order,
        orderUnderscoredirection,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Collections Search
* Returns a list of private Collections
*
* search PrivateCollectionSearch Search Parameters
* returns List
* */
const private_collections_search = ({ search }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        search,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);

module.exports = {
  collection_articles,
  collection_details,
  collection_version_details,
  collection_versions,
  collections_list,
  collections_search,
  private_collection_article_delete,
  private_collection_articles_add,
  private_collection_articles_list,
  private_collection_articles_replace,
  private_collection_author_delete,
  private_collection_authors_add,
  private_collection_authors_list,
  private_collection_authors_replace,
  private_collection_categories_add,
  private_collection_categories_list,
  private_collection_categories_replace,
  private_collection_category_delete,
  private_collection_create,
  private_collection_delete,
  private_collection_details,
  private_collection_patch,
  private_collection_private_link_create,
  private_collection_private_link_delete,
  private_collection_private_link_details,
  private_collection_private_link_update,
  private_collection_private_links_list,
  private_collection_publish,
  private_collection_reserve_doi,
  private_collection_reserve_handle,
  private_collection_resource,
  private_collection_update,
  private_collections_list,
  private_collections_search,
};
