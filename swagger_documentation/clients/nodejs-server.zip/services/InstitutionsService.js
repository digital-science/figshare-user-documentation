/* eslint-disable no-unused-vars */
const Service = require('./Service');

/**
* Institution Curation Review
* Retrieve a certain curation review by its ID
*
* curationUnderscoreid Long ID of the curation
* returns CurationDetail
* */
const account_institution_curation = ({ curationUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        curationUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Institution Curation Reviews
* Retrieve a list of curation reviews for this institution
*
* groupUnderscoreid Long Filter by the group ID (optional)
* articleUnderscoreid Long Retrieve the reviews for this article (optional)
* status String Filter by the status of the review (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* returns Curation
* */
const account_institution_curations = ({ groupUnderscoreid, articleUnderscoreid, status, limit, offset }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        groupUnderscoreid,
        articleUnderscoreid,
        status,
        limit,
        offset,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private account institution group custom fields
* Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access.
*
* groupUnderscoreid Long Group_id (optional)
* returns List
* */
const custom_fields_list = ({ groupUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        groupUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Custom fields values files upload
* Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. More details in the <a href=\"#custom_fields\">Custom Fields section</a>
*
* customUnderscorefieldUnderscoreid Long Custom field identifier
* externalUnderscorefile File CSV file to be uploaded (optional)
* returns Object
* */
const custom_fields_upload = ({ customUnderscorefieldUnderscoreid, externalUnderscorefile }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        customUnderscorefieldUnderscoreid,
        externalUnderscorefile,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Institution Curation Review Comments
* Retrieve a certain curation review's comments.
*
* curationUnderscoreid Long ID of the curation
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* returns CurationComment
* */
const get_account_institution_curation_comments = ({ curationUnderscoreid, limit, offset }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        curationUnderscoreid,
        limit,
        offset,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Institution Articles
* Returns a list of articles belonging to the institution
*
* institutionUnderscorestringUnderscoreid String 
* resourceUnderscoreid String 
* filename String 
* returns List
* */
const institution_articles = ({ institutionUnderscorestringUnderscoreid, resourceUnderscoreid, filename }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        institutionUnderscorestringUnderscoreid,
        resourceUnderscoreid,
        filename,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Institution HRfeed Upload
* More info in the <a href=\"#hr_feed\">HR Feed section</a>
*
* hrfeed File You can find an example in the Hr Feed section (optional)
* returns ResponseMessage
* */
const institution_hrfeed_upload = ({ hrfeed }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        hrfeed,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* POST Institution Curation Review Comment
* Add a new comment to the review.
*
* curationUnderscoreid Long ID of the curation
* curationComment CurationCommentCreate The content/value of the comment.
* no response value expected for this operation
* */
const post_account_institution_curation_comments = ({ curationUnderscoreid, curationComment }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        curationUnderscoreid,
        curationComment,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Account Institution User
* Retrieve institution user information using the account_id
*
* accountUnderscoreid Long Account identifier the user is associated to
* returns User
* */
const private_account_institution_user = ({ accountUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        accountUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Account Categories
* List institution categories (including parent Categories)
*
* returns List
* */
const private_categories_list = () => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Account Institution Group Embargo Options
* Account institution group embargo options details
*
* groupUnderscoreid Long Group identifier
* returns List
* */
const private_group_embargo_options_details = ({ groupUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        groupUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Institution Account information
* Private Institution Account information
*
* accountUnderscoreid Long Account identifier the user is associated to
* returns Account
* */
const private_institution_account = ({ accountUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        accountUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Delete Institution Account Group Role
* Delete Institution Account Group Role
*
* accountUnderscoreid Long Account identifier for which to remove the role
* groupUnderscoreid Long Group identifier for which to remove the role
* roleUnderscoreid Long Role identifier
* no response value expected for this operation
* */
const private_institution_account_group_role_delete = ({ accountUnderscoreid, groupUnderscoreid, roleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        accountUnderscoreid,
        groupUnderscoreid,
        roleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List Institution Account Group Roles
* List Institution Account Group Roles
*
* accountUnderscoreid Long Account identifier the user is associated to
* returns Object
* */
const private_institution_account_group_roles = ({ accountUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        accountUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Add Institution Account Group Roles
* Add Institution Account Group Roles
*
* accountUnderscoreid Long Account identifier the user is associated to
* account Object Account description
* no response value expected for this operation
* */
const private_institution_account_group_roles_create = ({ accountUnderscoreid, account }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        accountUnderscoreid,
        account,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Create new Institution Account
* Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created.
*
* account AccountCreate Account description
* returns AccountCreateResponse
* */
const private_institution_accounts_create = ({ account }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        account,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Account Institution Accounts
* Returns the accounts for which the account has administrative privileges (assigned and inherited).
*
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* isUnderscoreactive Long Filter by active status (optional)
* institutionUnderscoreuserUnderscoreid String Filter by institution_user_id (optional)
* email String Filter by email (optional)
* idUnderscorelte Long Retrieve accounts with an ID lower or equal to the specified value (optional)
* idUnderscoregte Long Retrieve accounts with an ID greater or equal to the specified value (optional)
* returns List
* */
const private_institution_accounts_list = ({ page, pageUnderscoresize, limit, offset, isUnderscoreactive, institutionUnderscoreuserUnderscoreid, email, idUnderscorelte, idUnderscoregte }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        page,
        pageUnderscoresize,
        limit,
        offset,
        isUnderscoreactive,
        institutionUnderscoreuserUnderscoreid,
        email,
        idUnderscorelte,
        idUnderscoregte,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Account Institution Accounts Search
* Returns the accounts for which the account has administrative privileges (assigned and inherited).
*
* search InstitutionAccountsSearch Search Parameters
* returns List
* */
const private_institution_accounts_search = ({ search }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        search,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Update Institution Account
* Update Institution Account
*
* accountUnderscoreid Long Account identifier the user is associated to
* account AccountUpdate Account description
* no response value expected for this operation
* */
const private_institution_accounts_update = ({ accountUnderscoreid, account }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        accountUnderscoreid,
        account,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Institution Articles
* Get Articles from own institution. User must be administrator of the institution
*
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* order String The field by which to order. Default varies by endpoint/resource. (optional)
* orderUnderscoredirection String  (optional)
* publishedUnderscoresince String Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
* modifiedUnderscoresince String Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
* status Long only return collections with this status (optional)
* resourceUnderscoredoi String only return collections with this resource_doi (optional)
* itemUnderscoretype Long Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional)
* group Long only return articles from this group (optional)
* returns List
* */
const private_institution_articles = ({ page, pageUnderscoresize, limit, offset, order, orderUnderscoredirection, publishedUnderscoresince, modifiedUnderscoresince, status, resourceUnderscoredoi, itemUnderscoretype, group }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        page,
        pageUnderscoresize,
        limit,
        offset,
        order,
        orderUnderscoredirection,
        publishedUnderscoresince,
        modifiedUnderscoresince,
        status,
        resourceUnderscoredoi,
        itemUnderscoretype,
        group,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Account Institutions
* Account institution details
*
* returns Institution
* */
const private_institution_details = () => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Account Institution embargo options
* Account institution embargo options details
*
* returns List
* */
const private_institution_embargo_options_details = () => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Account Institution Groups
* Returns the groups for which the account has administrative privileges (assigned and inherited).
*
* returns List
* */
const private_institution_groups_list = () => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Account Institution Roles
* Returns the roles available for groups and the institution group.
*
* returns List
* */
const private_institution_roles_list = () => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);

module.exports = {
  account_institution_curation,
  account_institution_curations,
  custom_fields_list,
  custom_fields_upload,
  get_account_institution_curation_comments,
  institution_articles,
  institution_hrfeed_upload,
  post_account_institution_curation_comments,
  private_account_institution_user,
  private_categories_list,
  private_group_embargo_options_details,
  private_institution_account,
  private_institution_account_group_role_delete,
  private_institution_account_group_roles,
  private_institution_account_group_roles_create,
  private_institution_accounts_create,
  private_institution_accounts_list,
  private_institution_accounts_search,
  private_institution_accounts_update,
  private_institution_articles,
  private_institution_details,
  private_institution_embargo_options_details,
  private_institution_groups_list,
  private_institution_roles_list,
};
