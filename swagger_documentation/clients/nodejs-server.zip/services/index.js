const ArticlesService = require('./ArticlesService');
const AuthorsService = require('./AuthorsService');
const CollectionsService = require('./CollectionsService');
const InstitutionsService = require('./InstitutionsService');
const OauthService = require('./OauthService');
const OtherService = require('./OtherService');
const ProfilesService = require('./ProfilesService');
const ProjectsService = require('./ProjectsService');

module.exports = {
  ArticlesService,
  AuthorsService,
  CollectionsService,
  InstitutionsService,
  OauthService,
  OtherService,
  ProfilesService,
  ProjectsService,
};
