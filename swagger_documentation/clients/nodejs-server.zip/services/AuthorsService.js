/* eslint-disable no-unused-vars */
const Service = require('./Service');

/**
* Author details
* View author details
*
* authorUnderscoreid Long Author unique identifier
* returns AuthorComplete
* */
const private_author_details = ({ authorUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        authorUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Search Authors
* Search for authors
*
* search PrivateAuthorsSearch Search Parameters (optional)
* returns List
* */
const private_authors_search = ({ search }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        search,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);

module.exports = {
  private_author_details,
  private_authors_search,
};
