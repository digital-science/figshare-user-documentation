/* eslint-disable no-unused-vars */
const Service = require('./Service');

/**
* List Altmetric Institutions
* Returns a list of institutions available for Altmetric reporting
*
* offset Integer Where to start the listing. The offset of the first item. (optional)
* returns List
* */
const altmetric_institutions_list = ({ offset }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        offset,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);

module.exports = {
  altmetric_institutions_list,
};
