/* eslint-disable no-unused-vars */
const Service = require('./Service');

/**
* Update public profile
* Updates the fields of the user's public profile.
*
* user profile data ProfileUpdateData 
* userUnderscoreid Long User ID (optional)
* institutionUnderscoreuserUnderscoreid String Institutional user ID (optional)
* returns Object
* */
const update_user_profile = ({ user profile data, userUnderscoreid, institutionUnderscoreuserUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        user profile data,
        userUnderscoreid,
        institutionUnderscoreuserUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Update public profile picture
* Updates the profile picture of the user's public profile.
*
* userUnderscoreid Long User ID
* profileUnderscorepicture File User profile picture
* returns Object
* */
const update_user_profile_picture = ({ userUnderscoreid, profileUnderscorepicture }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        userUnderscoreid,
        profileUnderscorepicture,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);

module.exports = {
  update_user_profile,
  update_user_profile_picture,
};
