/* eslint-disable no-unused-vars */
const Service = require('./Service');

/**
* Get articles for a specific account
* Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id).
*
* externalUnderscoreuserUnderscoreid String External user ID (symplectic_user_id or institution_user_id)
* offset Integer Number of results to skip for pagination (optional)
* limit Integer Maximum number of results to return (optional)
* status String Filter by article status (optional)
* isUnderscoreembargoed String Filter by embargo status (optional)
* returns List
* */
const symplectic_account_articles = ({ externalUnderscoreuserUnderscoreid, offset, limit, status, isUnderscoreembargoed }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        externalUnderscoreuserUnderscoreid,
        offset,
        limit,
        status,
        isUnderscoreembargoed,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Get changed accounts for Symplectic Elements
* Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration.
*
* since String ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
* returns List
* */
const symplectic_accounts_ids = ({ since }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        since,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Get article details for Symplectic Elements
* Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information.
*
* articleUnderscoreid Integer Article ID
* returns Object
* */
const symplectic_article = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Get changed articles for Symplectic Elements
* Returns a list of articles for Symplectic Elements integration to synchronize article data.
*
* since String ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
* offset Integer Number of results to skip for pagination (optional)
* limit Integer Maximum number of results to return (optional)
* status String Filter by article status (optional)
* isUnderscoreembargoed String Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type (optional)
* returns List
* */
const symplectic_changed_articles = ({ since, offset, limit, status, isUnderscoreembargoed }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        since,
        offset,
        limit,
        status,
        isUnderscoreembargoed,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Get institutional user ID for a user
* Returns the institution user ID for a given user within the authenticated account's institution.
*
* userUnderscoreid Integer User ID
* returns symplectic_user_id_200_response
* */
const symplectic_user_id = ({ userUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        userUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);

module.exports = {
  symplectic_account_articles,
  symplectic_accounts_ids,
  symplectic_article,
  symplectic_changed_articles,
  symplectic_user_id,
};
