/* eslint-disable no-unused-vars */
const Service = require('./Service');

/**
* Delete project article
* Delete project article
*
* projectUnderscoreid Long Project unique identifier
* articleUnderscoreid Long Project Article unique identifier
* no response value expected for this operation
* */
const private_project_article_delete = ({ projectUnderscoreid, articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Project article details
* Project article details
*
* projectUnderscoreid Long Project unique identifier
* articleUnderscoreid Long Project Article unique identifier
* returns ArticleCompletePrivate
* */
const private_project_article_details = ({ projectUnderscoreid, articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Project article file details
* Project article file details
*
* projectUnderscoreid Long Project unique identifier
* articleUnderscoreid Long Project Article unique identifier
* fileUnderscoreid Long File unique identifier
* returns PrivateFile
* */
const private_project_article_file = ({ projectUnderscoreid, articleUnderscoreid, fileUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        articleUnderscoreid,
        fileUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Project article list files
* List article files
*
* projectUnderscoreid Long Project unique identifier
* articleUnderscoreid Long Project Article unique identifier
* returns List
* */
const private_project_article_files = ({ projectUnderscoreid, articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Create project article
* Create a new Article and associate it with this project
*
* projectUnderscoreid Long Project unique identifier
* article ArticleProjectCreate Article description
* returns Location
* */
const private_project_articles_create = ({ projectUnderscoreid, article }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        article,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List project articles
* List project articles
*
* projectUnderscoreid Long Project unique identifier
* returns List
* */
const private_project_articles_list = ({ projectUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Remove project collaborator
* Remove project collaborator
*
* projectUnderscoreid Long Project unique identifier
* userUnderscoreid Long User unique identifier
* no response value expected for this operation
* */
const private_project_collaborator__Delete = ({ projectUnderscoreid, userUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        userUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Invite project collaborators
* Invite users to collaborate on project or view the project
*
* projectUnderscoreid Long Project unique identifier
* collaborator ProjectCollaboratorInvite viewer or collaborator role. User user_id or email of user
* returns ResponseMessage
* */
const private_project_collaborators_invite = ({ projectUnderscoreid, collaborator }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        collaborator,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List project collaborators
* List Project collaborators and invited users
*
* projectUnderscoreid Long Project unique identifier
* returns List
* */
const private_project_collaborators_list = ({ projectUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Create project
* Create a new project
*
* project ProjectCreate Project  description
* returns CreateProjectResponse
* */
const private_project_create = ({ project }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        project,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Delete project
* A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project. 
*
* projectUnderscoreid Long Project unique identifier
* no response value expected for this operation
* */
const private_project_delete = ({ projectUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* View project details
* View a private project
*
* projectUnderscoreid Long Project unique identifier
* returns ProjectCompletePrivate
* */
const private_project_details = ({ projectUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Project Leave
* Please note: project's owner cannot leave the project.
*
* projectUnderscoreid Long Project unique identifier
* no response value expected for this operation
* */
const private_project_leave = ({ projectUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Project note details
*
* projectUnderscoreid Long Project unique identifier
* noteUnderscoreid Long Note unique identifier
* returns ProjectNotePrivate
* */
const private_project_note = ({ projectUnderscoreid, noteUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        noteUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Delete project note
*
* projectUnderscoreid Long Project unique identifier
* noteUnderscoreid Long Note unique identifier
* no response value expected for this operation
* */
const private_project_note_delete = ({ projectUnderscoreid, noteUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        noteUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Update project note
*
* projectUnderscoreid Long Project unique identifier
* noteUnderscoreid Long Note unique identifier
* note ProjectNoteCreate Note message
* no response value expected for this operation
* */
const private_project_note_update = ({ projectUnderscoreid, noteUnderscoreid, note }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        noteUnderscoreid,
        note,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Create project note
* Create a new project note
*
* projectUnderscoreid Long Project unique identifier
* note ProjectNoteCreate Note message
* returns Location
* */
const private_project_notes_create = ({ projectUnderscoreid, note }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        note,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List project notes
* List project notes
*
* projectUnderscoreid Long Project unique identifier
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* returns List
* */
const private_project_notes_list = ({ projectUnderscoreid, page, pageUnderscoresize, limit, offset }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        page,
        pageUnderscoresize,
        limit,
        offset,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Partially update project
* Partially update a project; only provided fields will be changed.
*
* projectUnderscoreid Long Project unique identifier
* project ProjectUpdate Fields to update (optional)
* no response value expected for this operation
* */
const private_project_partial_update = ({ projectUnderscoreid, project }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        project,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Project Publish
* Publish a project. Possible after all items inside it are public
*
* projectUnderscoreid Long Project unique identifier
* returns ResponseMessage
* */
const private_project_publish = ({ projectUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Update project
* Updating an project by passing body parameters.
*
* projectUnderscoreid Long Project unique identifier
* project ProjectUpdate Project description
* no response value expected for this operation
* */
const private_project_update = ({ projectUnderscoreid, project }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        project,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Projects
* List private projects
*
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* order String The field by which to order. (optional)
* orderUnderscoredirection String  (optional)
* storage String only return collections from this institution (optional)
* roles String Any combination of owner, collaborator, viewer separated by comma. Examples: \"owner\" or \"owner,collaborator\". (optional)
* returns List
* */
const private_projects_list = ({ page, pageUnderscoresize, limit, offset, order, orderUnderscoredirection, storage, roles }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        page,
        pageUnderscoresize,
        limit,
        offset,
        order,
        orderUnderscoredirection,
        storage,
        roles,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Projects search
* Search inside the private projects
*
* search ProjectsSearch Search Parameters (optional)
* returns List
* */
const private_projects_search = ({ search }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        search,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Project Articles
* List articles in project
*
* projectUnderscoreid Long Project Unique identifier
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* returns List
* */
const project_articles = ({ projectUnderscoreid, page, pageUnderscoresize, limit, offset }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
        page,
        pageUnderscoresize,
        limit,
        offset,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Project
* View a project
*
* projectUnderscoreid Long Project Unique identifier
* returns ProjectComplete
* */
const project_details = ({ projectUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        projectUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Projects
* Returns a list of public projects
*
* xCursor UUID Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* order String The field by which to order. Default varies by endpoint/resource. (optional)
* orderUnderscoredirection String  (optional)
* institution Long only return collections from this institution (optional)
* publishedUnderscoresince String Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional)
* group Long only return collections from this group (optional)
* returns List
* */
const projects_list = ({ xCursor, page, pageUnderscoresize, limit, offset, order, orderUnderscoredirection, institution, publishedUnderscoresince, group }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        xCursor,
        page,
        pageUnderscoresize,
        limit,
        offset,
        order,
        orderUnderscoredirection,
        institution,
        publishedUnderscoresince,
        group,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Projects Search
* Returns a list of public articles
*
* xCursor UUID Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
* search ProjectsSearch Search Parameters (optional)
* returns List
* */
const projects_search = ({ xCursor, search }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        xCursor,
        search,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);

module.exports = {
  private_project_article_delete,
  private_project_article_details,
  private_project_article_file,
  private_project_article_files,
  private_project_articles_create,
  private_project_articles_list,
  private_project_collaborator__Delete,
  private_project_collaborators_invite,
  private_project_collaborators_list,
  private_project_create,
  private_project_delete,
  private_project_details,
  private_project_leave,
  private_project_note,
  private_project_note_delete,
  private_project_note_update,
  private_project_notes_create,
  private_project_notes_list,
  private_project_partial_update,
  private_project_publish,
  private_project_update,
  private_projects_list,
  private_projects_search,
  project_articles,
  project_details,
  projects_list,
  projects_search,
};
