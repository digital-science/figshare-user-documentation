/* eslint-disable no-unused-vars */
const Service = require('./Service');

/**
* Create OAuth token
* Creates OAuth token using various grant types
*
* body CreateOAuthToken Create OAuth Token Parameters (optional)
* returns OAuthToken
* */
const create_token = ({ body }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        body,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Get OAuth token information
* Returns information about the current OAuth token
*
* accessUnderscoretoken String OAuth access token (optional)
* returns OAuthToken
* */
const get_token_info = ({ accessUnderscoretoken }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        accessUnderscoretoken,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);

module.exports = {
  create_token,
  get_token_info,
};
