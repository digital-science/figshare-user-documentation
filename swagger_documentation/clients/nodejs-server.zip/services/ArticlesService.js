/* eslint-disable no-unused-vars */
const Service = require('./Service');

/**
* Private Article Publish
* - If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.
*
* articleUnderscoreid Long Article unique identifier
* returns Location
* */
const account_article_publish = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Account Article Report
* Return status on all reports generated for the account from the oauth credentials
*
* groupUnderscoreid Long A group ID to filter by (optional)
* returns List
* */
const account_article_report = ({ groupUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        groupUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Initiate a new Report
* Initiate a new Article Report for this Account. There is a limit of 1 report per day.
*
* returns AccountReport
* */
const account_article_report_generate = () => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Article Unpublish
* Allows authorized users to unpublish an article.
*
* articleUnderscoreid Long Article unique identifier
* reason ArticleUnpublishData Article unpublish data
* no response value expected for this operation
* */
const account_article_unpublish = ({ articleUnderscoreid, reason }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        reason,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* View article details
* View an article
*
* articleUnderscoreid Long Article Unique identifier
* returns ArticleComplete
* */
const article_details = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Article file details
* File by id
*
* articleUnderscoreid Long Article Unique identifier
* fileUnderscoreid Long File Unique identifier
* returns PublicFile
* */
const article_file_details = ({ articleUnderscoreid, fileUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        fileUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List article files
* Files list for article
*
* articleUnderscoreid Long Article Unique identifier
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* returns List
* */
const article_files = ({ articleUnderscoreid, page, pageUnderscoresize, limit, offset }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        page,
        pageUnderscoresize,
        limit,
        offset,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Article Confidentiality for article version
* Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.
*
* articleUnderscoreid Long Article Unique identifier
* versionUnderscoreid Long Version Number
* returns ArticleConfidentiality
* */
const article_version_confidentiality = ({ articleUnderscoreid, versionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        versionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Article details for version
* Article with specified version
*
* articleUnderscoreid Long Article Unique identifier
* versionUnderscoreid Long Article Version Number
* returns ArticleComplete
* */
const article_version_details = ({ articleUnderscoreid, versionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        versionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Article Embargo for article version
* Embargo for article version
*
* articleUnderscoreid Long Article Unique identifier
* versionUnderscoreid Long Version Number
* returns ArticleEmbargo
* */
const article_version_embargo = ({ articleUnderscoreid, versionUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        versionUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Article version files
* Article version file details
*
* articleUnderscoreid Long Article Unique identifier
* versionUnderscoreid Long Article Version Unique identifier
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* returns List
* */
const article_version_files = ({ articleUnderscoreid, versionUnderscoreid, page, pageUnderscoresize, limit, offset }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        versionUnderscoreid,
        page,
        pageUnderscoresize,
        limit,
        offset,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Partially update article version
* Partially updating an article version by passing only the fields to change.
*
* articleUnderscoreid Long Article unique identifier
* versionUnderscoreid Long Article version identifier
* article ArticleVersionUpdate Subset of article version fields to update
* returns LocationWarningsUpdate
* */
const article_version_partial_update = ({ articleUnderscoreid, versionUnderscoreid, article }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        versionUnderscoreid,
        article,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Update article version
* Updating an article version by passing body parameters.
*
* articleUnderscoreid Long Article unique identifier
* versionUnderscoreid Long Article version identifier
* article ArticleVersionUpdate Article description
* returns LocationWarningsUpdate
* */
const article_version_update = ({ articleUnderscoreid, versionUnderscoreid, article }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        versionUnderscoreid,
        article,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Update article version thumbnail
* For a given public article version update the article thumbnail by choosing one of the associated files
*
* articleUnderscoreid Long Article unique identifier
* versionUnderscoreid Long Article version identifier
* fileId FileId File ID
* no response value expected for this operation
* */
const article_version_update_thumb = ({ articleUnderscoreid, versionUnderscoreid, fileId }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        versionUnderscoreid,
        fileId,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List article versions
* List public article versions
*
* articleUnderscoreid Long Article Unique identifier
* returns List
* */
const article_versions = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Articles
* Returns a list of public articles
*
* xCursor UUID Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* order String The field by which to order. Default varies by endpoint/resource. (optional)
* orderUnderscoredirection String  (optional)
* institution Long only return articles from this institution (optional)
* publishedUnderscoresince String Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
* modifiedUnderscoresince String Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
* group Long only return articles from this group (optional)
* resourceUnderscoredoi String Deprecated by related materials. Only return articles with this resource_doi (optional)
* itemUnderscoretype Long Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional)
* doi String only return articles with this doi (optional)
* handle String only return articles with this handle (optional)
* returns List
* */
const articles_list = ({ xCursor, page, pageUnderscoresize, limit, offset, order, orderUnderscoredirection, institution, publishedUnderscoresince, modifiedUnderscoresince, group, resourceUnderscoredoi, itemUnderscoretype, doi, handle }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        xCursor,
        page,
        pageUnderscoresize,
        limit,
        offset,
        order,
        orderUnderscoredirection,
        institution,
        publishedUnderscoresince,
        modifiedUnderscoresince,
        group,
        resourceUnderscoredoi,
        itemUnderscoretype,
        doi,
        handle,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Articles Search
* Returns a list of public articles, filtered by the search parameters
*
* xCursor UUID Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
* search ArticleSearch Search Parameters (optional)
* returns List
* */
const articles_search = ({ xCursor, search }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        xCursor,
        search,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Delete article author
* De-associate author from article
*
* articleUnderscoreid Long Article unique identifier
* authorUnderscoreid Long Article Author unique identifier
* no response value expected for this operation
* */
const private_article_author_delete = ({ articleUnderscoreid, authorUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        authorUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Add article authors
* Associate new authors with the article. This will add new authors to the list of already associated authors
*
* articleUnderscoreid Long Article unique identifier
* authors AuthorsCreator Authors description
* no response value expected for this operation
* */
const private_article_authors_add = ({ articleUnderscoreid, authors }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        authors,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List article authors
* List article authors
*
* articleUnderscoreid Long Article unique identifier
* returns List
* */
const private_article_authors_list = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Replace article authors
* Associate new authors with the article. This will remove all already associated authors and add these new ones
*
* articleUnderscoreid Long Article unique identifier
* authors AuthorsCreator Authors description
* no response value expected for this operation
* */
const private_article_authors_replace = ({ articleUnderscoreid, authors }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        authors,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Add article categories
* Associate new categories with the article. This will add new categories to the list of already associated categories
*
* articleUnderscoreid Long Article unique identifier
* categories CategoriesCreator 
* no response value expected for this operation
* */
const private_article_categories_add = ({ articleUnderscoreid, categories }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        categories,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List article categories
* List article categories
*
* articleUnderscoreid Long Article unique identifier
* returns List
* */
const private_article_categories_list = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Replace article categories
* Associate new categories with the article. This will remove all already associated categories and add these new ones
*
* articleUnderscoreid Long Article unique identifier
* categories CategoriesCreator 
* no response value expected for this operation
* */
const private_article_categories_replace = ({ articleUnderscoreid, categories }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        categories,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Delete article category
* De-associate category from article
*
* articleUnderscoreid Long Article unique identifier
* categoryUnderscoreid Long Category unique identifier
* no response value expected for this operation
* */
const private_article_category_delete = ({ articleUnderscoreid, categoryUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        categoryUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Delete article confidentiality
* Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.
*
* articleUnderscoreid Long Article unique identifier
* no response value expected for this operation
* */
const private_article_confidentiality_delete = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Article confidentiality details
* View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.
*
* articleUnderscoreid Long Article unique identifier
* returns ArticleConfidentiality
* */
const private_article_confidentiality_details = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Update article confidentiality
* Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.
*
* articleUnderscoreid Long Article unique identifier
* reason ConfidentialityCreator 
* no response value expected for this operation
* */
const private_article_confidentiality_update = ({ articleUnderscoreid, reason }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        reason,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Create new Article
* Create a new Article by sending article information
*
* article ArticleCreate Article description
* returns LocationWarnings
* */
const private_article_create = ({ article }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        article,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Delete article
* Delete an article
*
* articleUnderscoreid Long Article unique identifier
* no response value expected for this operation
* */
const private_article_delete = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Article details
* View a private article
*
* articleUnderscoreid Long Article unique identifier
* returns ArticleCompletePrivate
* */
const private_article_details = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Article Download
* Download files from a private article preserving the folder structure
*
* articleUnderscoreid Long Article unique identifier
* folderUnderscorepath String Folder path to download. If not provided, all files from the article will be downloaded (optional)
* no response value expected for this operation
* */
const private_article_download = ({ articleUnderscoreid, folderUnderscorepath }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        folderUnderscorepath,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Delete Article Embargo
* Will lift the embargo for the specified article
*
* articleUnderscoreid Long Article unique identifier
* no response value expected for this operation
* */
const private_article_embargo_delete = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Article Embargo Details
* View a private article embargo details
*
* articleUnderscoreid Long Article unique identifier
* returns ArticleEmbargo
* */
const private_article_embargo_details = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Update Article Embargo
* Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.
*
* articleUnderscoreid Long Article unique identifier
* embargo ArticleEmbargoUpdater Embargo description
* no response value expected for this operation
* */
const private_article_embargo_update = ({ articleUnderscoreid, embargo }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        embargo,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Single File
* View details of file for specified article
*
* articleUnderscoreid Long Article unique identifier
* fileUnderscoreid Long File unique identifier
* returns PrivateFile
* */
const private_article_file = ({ articleUnderscoreid, fileUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        fileUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* File Delete
* Complete file upload
*
* articleUnderscoreid Long Article unique identifier
* fileUnderscoreid Long File unique identifier
* no response value expected for this operation
* */
const private_article_file_delete = ({ articleUnderscoreid, fileUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        fileUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List article files
* List private files
*
* articleUnderscoreid Long Article unique identifier
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* returns List
* */
const private_article_files_list = ({ articleUnderscoreid, page, pageUnderscoresize, limit, offset }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        page,
        pageUnderscoresize,
        limit,
        offset,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Partially update article
* Partially update an article by sending only the fields to change.
*
* articleUnderscoreid Long Article unique identifier
* article ArticleUpdate Subset of article fields to update
* returns LocationWarningsUpdate
* */
const private_article_partial_update = ({ articleUnderscoreid, article }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        article,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* List private links
* List private links
*
* articleUnderscoreid Long Article unique identifier
* returns List
* */
const private_article_private_link = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Create private link
* Create new private link for this article
*
* articleUnderscoreid Long Article unique identifier
* privateUnderscorelink PrivateLinkCreator  (optional)
* returns PrivateLinkResponse
* */
const private_article_private_link_create = ({ articleUnderscoreid, privateUnderscorelink }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        privateUnderscorelink,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Disable private link
* Disable/delete private link for this article
*
* articleUnderscoreid Long Article unique identifier
* linkUnderscoreid String Private link token
* no response value expected for this operation
* */
const private_article_private_link_delete = ({ articleUnderscoreid, linkUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        linkUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Update private link
* Update existing private link for this article
*
* articleUnderscoreid Long Article unique identifier
* linkUnderscoreid String Private link token
* privateUnderscorelink PrivateLinkCreator  (optional)
* no response value expected for this operation
* */
const private_article_private_link_update = ({ articleUnderscoreid, linkUnderscoreid, privateUnderscorelink }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        linkUnderscoreid,
        privateUnderscorelink,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Article Reserve DOI
* Reserve DOI for article
*
* articleUnderscoreid Long Article unique identifier
* returns ArticleDOI
* */
const private_article_reserve_doi = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Article Reserve Handle
* Reserve Handle for article
*
* articleUnderscoreid Long Article unique identifier
* returns ArticleHandle
* */
const private_article_reserve_handle = ({ articleUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Article Resource
* Edit article resource data.
*
* articleUnderscoreid Long Article unique identifier
* resource Resource Resource data
* returns Location
* */
const private_article_resource = ({ articleUnderscoreid, resource }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        resource,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Update article
* Update an article by passing full body parameters.
*
* articleUnderscoreid Long Article unique identifier
* article ArticleUpdate Full article representation
* returns LocationWarningsUpdate
* */
const private_article_update = ({ articleUnderscoreid, article }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        article,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Complete Upload
* Complete file upload
*
* articleUnderscoreid Long Article unique identifier
* fileUnderscoreid Long File unique identifier
* no response value expected for this operation
* */
const private_article_upload_complete = ({ articleUnderscoreid, fileUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        fileUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Initiate Upload
* Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).
*
* articleUnderscoreid Long Article unique identifier
* file FileCreator 
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* returns Location
* */
const private_article_upload_initiate = ({ articleUnderscoreid, file, page, pageUnderscoresize, limit, offset }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        file,
        page,
        pageUnderscoresize,
        limit,
        offset,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Articles
* Get Own Articles
*
* page Long Page number. Used for pagination with page_size (optional)
* pageUnderscoresize Long The number of results included on a page. Used for pagination with page (optional)
* limit Long Number of results included on a page. Used for pagination with query (optional)
* offset Long Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
* returns List
* */
const private_articles_list = ({ page, pageUnderscoresize, limit, offset }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        page,
        pageUnderscoresize,
        limit,
        offset,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Articles search
* Returns a list of private articles filtered by the search parameters
*
* search PrivateArticleSearch Search Parameters
* returns List
* */
const private_articles_search = ({ search }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        search,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Article Download
* Download files from a public article preserving the folder structure
*
* articleUnderscoreid Long Article unique identifier
* folderUnderscorepath String Folder path to download. If not provided, all files from the article will be downloaded (optional)
* no response value expected for this operation
* */
const public_article_download = ({ articleUnderscoreid, folderUnderscorepath }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        folderUnderscorepath,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Article Version Download
* Download files from a certain version of an public article preserving the folder structure
*
* articleUnderscoreid Long Article unique identifier
* versionUnderscoreid Long Version Number
* folderUnderscorepath String Folder path to download. If not provided, all files from the article will be downloaded (optional)
* no response value expected for this operation
* */
const public_article_version_download = ({ articleUnderscoreid, versionUnderscoreid, folderUnderscorepath }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        articleUnderscoreid,
        versionUnderscoreid,
        folderUnderscorepath,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);

module.exports = {
  account_article_publish,
  account_article_report,
  account_article_report_generate,
  account_article_unpublish,
  article_details,
  article_file_details,
  article_files,
  article_version_confidentiality,
  article_version_details,
  article_version_embargo,
  article_version_files,
  article_version_partial_update,
  article_version_update,
  article_version_update_thumb,
  article_versions,
  articles_list,
  articles_search,
  private_article_author_delete,
  private_article_authors_add,
  private_article_authors_list,
  private_article_authors_replace,
  private_article_categories_add,
  private_article_categories_list,
  private_article_categories_replace,
  private_article_category_delete,
  private_article_confidentiality_delete,
  private_article_confidentiality_details,
  private_article_confidentiality_update,
  private_article_create,
  private_article_delete,
  private_article_details,
  private_article_download,
  private_article_embargo_delete,
  private_article_embargo_details,
  private_article_embargo_update,
  private_article_file,
  private_article_file_delete,
  private_article_files_list,
  private_article_partial_update,
  private_article_private_link,
  private_article_private_link_create,
  private_article_private_link_delete,
  private_article_private_link_update,
  private_article_reserve_doi,
  private_article_reserve_handle,
  private_article_resource,
  private_article_update,
  private_article_upload_complete,
  private_article_upload_initiate,
  private_articles_list,
  private_articles_search,
  public_article_download,
  public_article_version_download,
};
