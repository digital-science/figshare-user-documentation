/* eslint-disable no-unused-vars */
const Service = require('./Service');

/**
* Public Categories
* Returns a list of public categories
*
* returns List
* */
const categories_list = () => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public File Download
* Starts the download of a file
*
* fileUnderscoreid Long 
* no response value expected for this operation
* */
const file_download = ({ fileUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        fileUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Item Types
* Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare.
*
* groupUnderscoreid Long Identifier of the group for which the item types are requested (optional)
* returns List
* */
const item_types_list = ({ groupUnderscoreid }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        groupUnderscoreid,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Public Licenses
* Returns a list of public licenses
*
* returns List
* */
const licenses_list = () => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Account information
* Account information for token/personal token
*
* returns Account
* */
const private_account = () => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Search Funding
* Search for fundings
*
* search FundingSearch Search Parameters (optional)
* returns List
* */
const private_funding_search = ({ search }) => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
        search,
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);
/**
* Private Account Licenses
* This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution.
*
* returns List
* */
const private_licenses_list = () => new Promise(
  async (resolve, reject) => {
    try {
      resolve(Service.successResponse({
      }));
    } catch (e) {
      reject(Service.rejectResponse(
        e.message || 'Invalid input',
        e.status || 405,
      ));
    }
  },
);

module.exports = {
  categories_list,
  file_download,
  item_types_list,
  licenses_list,
  private_account,
  private_funding_search,
  private_licenses_list,
};
