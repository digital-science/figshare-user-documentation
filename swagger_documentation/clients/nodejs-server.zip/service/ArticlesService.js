'use strict';


/**
 * Private Article Publish
 * - If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.
 *
 * article_id Long Article unique identifier
 * returns Location
 **/
exports.account_article_publish = function(article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Account Article Report
 * Return status on all reports generated for the account from the oauth credentials
 *
 * group_id Long A group ID to filter by (optional)
 * returns List
 **/
exports.account_article_report = function(group_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Initiate a new Report
 * Initiate a new Article Report for this Account. There is a limit of 1 report per day.
 *
 * returns AccountReport
 **/
exports.account_article_report_generate = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Article Unpublish
 * Allows authorized users to unpublish an article.
 *
 * article_id Long Article unique identifier
 * reason ArticleUnpublishData Article unpublish data
 * no response value expected for this operation
 **/
exports.account_article_unpublish = function(article_id,reason) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * View article details
 * View an article
 *
 * article_id Long Article Unique identifier
 * returns ArticleComplete
 **/
exports.article_details = function(article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Article file details
 * File by id
 *
 * article_id Long Article Unique identifier
 * file_id Long File Unique identifier
 * returns PublicFile
 **/
exports.article_file_details = function(article_id,file_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List article files
 * Files list for article
 *
 * article_id Long Article Unique identifier
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * returns List
 **/
exports.article_files = function(article_id,page,page_size,limit,offset) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Article Confidentiality for article version
 * Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.
 *
 * article_id Long Article Unique identifier
 * v_number Long Version Number
 * returns ArticleConfidentiality
 **/
exports.article_version_confidentiality = function(article_id,v_number) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Article details for version
 * Article with specified version
 *
 * article_id Long Article Unique identifier
 * v_number Long Article Version Number
 * returns ArticleComplete
 **/
exports.article_version_details = function(article_id,v_number) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Article Embargo for article version
 * Embargo for article version
 *
 * article_id Long Article Unique identifier
 * v_number Long Version Number
 * returns ArticleEmbargo
 **/
exports.article_version_embargo = function(article_id,v_number) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update article version
 * Updating an article version by passing body parameters; request can also be made with the PATCH method.
 *
 * article_id Long Article unique identifier
 * version_id Long Article version identifier
 * article ArticleVersionUpdate Article description
 * returns LocationWarningsUpdate
 **/
exports.article_version_update = function(article_id,version_id,article) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update article version thumbnail
 * For a given public article version update the article thumbnail by choosing one of the associated files
 *
 * article_id Long Article unique identifier
 * version_id Long Article version identifier
 * fileId FileId File ID
 * no response value expected for this operation
 **/
exports.article_version_update_thumb = function(article_id,version_id,fileId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * List article versions
 * List public article versions
 *
 * article_id Long Article Unique identifier
 * returns List
 **/
exports.article_versions = function(article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Articles
 * Returns a list of public articles
 *
 * xCursor UUID Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * order String The field by which to order. Default varies by endpoint/resource. (optional)
 * order_direction String  (optional)
 * institution Long only return articles from this institution (optional)
 * published_since String Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
 * modified_since String Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
 * group Long only return articles from this group (optional)
 * resource_doi String Deprecated by related materials. Only return articles with this resource_doi (optional)
 * item_type Long Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional)
 * doi String only return articles with this doi (optional)
 * handle String only return articles with this handle (optional)
 * returns List
 **/
exports.articles_list = function(xCursor,page,page_size,limit,offset,order,order_direction,institution,published_since,modified_since,group,resource_doi,item_type,doi,handle) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Public Articles Search
 * Returns a list of public articles, filtered by the search parameters
 *
 * xCursor UUID Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
 * search ArticleSearch Search Parameters (optional)
 * returns List
 **/
exports.articles_search = function(xCursor,search) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete article author
 * De-associate author from article
 *
 * article_id Long Article unique identifier
 * author_id Long Article Author unique identifier
 * no response value expected for this operation
 **/
exports.private_article_author_delete = function(article_id,author_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Add article authors
 * Associate new authors with the article. This will add new authors to the list of already associated authors
 *
 * article_id Long Article unique identifier
 * authors AuthorsCreator Authors description
 * no response value expected for this operation
 **/
exports.private_article_authors_add = function(article_id,authors) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * List article authors
 * List article authors
 *
 * article_id Long Article unique identifier
 * returns List
 **/
exports.private_article_authors_list = function(article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Replace article authors
 * Associate new authors with the article. This will remove all already associated authors and add these new ones
 *
 * article_id Long Article unique identifier
 * authors AuthorsCreator Authors description
 * no response value expected for this operation
 **/
exports.private_article_authors_replace = function(article_id,authors) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Add article categories
 * Associate new categories with the article. This will add new categories to the list of already associated categories
 *
 * article_id Long Article unique identifier
 * categories CategoriesCreator 
 * no response value expected for this operation
 **/
exports.private_article_categories_add = function(article_id,categories) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * List article categories
 * List article categories
 *
 * article_id Long Article unique identifier
 * returns List
 **/
exports.private_article_categories_list = function(article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Replace article categories
 * Associate new categories with the article. This will remove all already associated categories and add these new ones
 *
 * article_id Long Article unique identifier
 * categories CategoriesCreator 
 * no response value expected for this operation
 **/
exports.private_article_categories_replace = function(article_id,categories) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete article category
 * De-associate category from article
 *
 * article_id Long Article unique identifier
 * category_id Long Category unique identifier
 * no response value expected for this operation
 **/
exports.private_article_category_delete = function(article_id,category_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete article confidentiality
 * Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.
 *
 * article_id Long Article unique identifier
 * no response value expected for this operation
 **/
exports.private_article_confidentiality_delete = function(article_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Article confidentiality details
 * View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.
 *
 * article_id Long Article unique identifier
 * returns ArticleConfidentiality
 **/
exports.private_article_confidentiality_details = function(article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update article confidentiality
 * Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.
 *
 * article_id Long Article unique identifier
 * reason ConfidentialityCreator 
 * no response value expected for this operation
 **/
exports.private_article_confidentiality_update = function(article_id,reason) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Create new Article
 * Create a new Article by sending article information
 *
 * article ArticleCreate Article description
 * returns LocationWarnings
 **/
exports.private_article_create = function(article) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete article
 * Delete an article
 *
 * article_id Long Article unique identifier
 * no response value expected for this operation
 **/
exports.private_article_delete = function(article_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Article details
 * View a private article
 *
 * article_id Long Article unique identifier
 * returns ArticleCompletePrivate
 **/
exports.private_article_details = function(article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Article Embargo
 * Will lift the embargo for the specified article
 *
 * article_id Long Article unique identifier
 * no response value expected for this operation
 **/
exports.private_article_embargo_delete = function(article_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Article Embargo Details
 * View a private article embargo details
 *
 * article_id Long Article unique identifier
 * returns ArticleEmbargo
 **/
exports.private_article_embargo_details = function(article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Article Embargo
 * Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.
 *
 * article_id Long Article unique identifier
 * embargo ArticleEmbargoUpdater Embargo description
 * no response value expected for this operation
 **/
exports.private_article_embargo_update = function(article_id,embargo) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Single File
 * View details of file for specified article
 *
 * article_id Long Article unique identifier
 * file_id Long File unique identifier
 * returns PrivateFile
 **/
exports.private_article_file = function(article_id,file_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * File Delete
 * Complete file upload
 *
 * article_id Long Article unique identifier
 * file_id Long File unique identifier
 * no response value expected for this operation
 **/
exports.private_article_file_delete = function(article_id,file_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * List article files
 * List private files
 *
 * article_id Long Article unique identifier
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * returns List
 **/
exports.private_article_files_list = function(article_id,page,page_size,limit,offset) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List private links
 * List private links
 *
 * article_id Long Article unique identifier
 * returns List
 **/
exports.private_article_private_link = function(article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create private link
 * Create new private link for this article
 *
 * article_id Long Article unique identifier
 * private_link PrivateLinkCreator  (optional)
 * returns PrivateLinkResponse
 **/
exports.private_article_private_link_create = function(article_id,private_link) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Disable private link
 * Disable/delete private link for this article
 *
 * article_id Long Article unique identifier
 * link_id String Private link token
 * no response value expected for this operation
 **/
exports.private_article_private_link_delete = function(article_id,link_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update private link
 * Update existing private link for this article
 *
 * article_id Long Article unique identifier
 * link_id String Private link token
 * private_link PrivateLinkCreator  (optional)
 * no response value expected for this operation
 **/
exports.private_article_private_link_update = function(article_id,link_id,private_link) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Private Article Reserve DOI
 * Reserve DOI for article
 *
 * article_id Long Article unique identifier
 * returns ArticleDOI
 **/
exports.private_article_reserve_doi = function(article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Article Reserve Handle
 * Reserve Handle for article
 *
 * article_id Long Article unique identifier
 * returns ArticleHandle
 **/
exports.private_article_reserve_handle = function(article_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Article Resource
 * Edit article resource data.
 *
 * article_id Long Article unique identifier
 * resource Resource Resource data
 * returns Location
 **/
exports.private_article_resource = function(article_id,resource) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update article
 * Updating an article by passing body parameters; request can also be made with the PATCH method.
 *
 * article_id Long Article unique identifier
 * article ArticleUpdate Article description
 * returns LocationWarningsUpdate
 **/
exports.private_article_update = function(article_id,article) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Complete Upload
 * Complete file upload
 *
 * article_id Long Article unique identifier
 * file_id Long File unique identifier
 * no response value expected for this operation
 **/
exports.private_article_upload_complete = function(article_id,file_id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Initiate Upload
 * Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).
 *
 * article_id Long Article unique identifier
 * file FileCreator 
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * returns Location
 **/
exports.private_article_upload_initiate = function(article_id,file,page,page_size,limit,offset) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Articles
 * Get Own Articles
 *
 * page Long Page number. Used for pagination with page_size (optional)
 * page_size Long The number of results included on a page. Used for pagination with page (optional)
 * limit Long Number of results included on a page. Used for pagination with query (optional)
 * offset Long Where to start the listing(the offset of the first result). Used for pagination with limit (optional)
 * returns List
 **/
exports.private_articles_list = function(page,page_size,limit,offset) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Private Articles search
 * Returns a list of private articles filtered by the search parameters
 *
 * search PrivateArticleSearch Search Parameters
 * returns List
 **/
exports.private_articles_search = function(search) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

