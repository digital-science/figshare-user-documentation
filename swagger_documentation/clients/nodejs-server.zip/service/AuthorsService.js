'use strict';


/**
 * Author details
 * View author details
 *
 * author_id Long Author unique identifier
 * returns AuthorComplete
 **/
exports.private_author_details = function(author_id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blank": true,
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Search Authors
 * Search for authors
 *
 * search PrivateAuthorsSearch Search Parameters (optional)
 * returns List
 **/
exports.private_authors_search = function(search) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

