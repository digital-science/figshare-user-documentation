'use strict';


/**
 * Create OAuth token
 * Creates OAuth token using various grant types
 *
 * body CreateOAuthToken Create OAuth Token Parameters (optional)
 * returns OAuthToken
 **/
exports.create_token = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get OAuth token information
 * Returns information about the current OAuth token
 *
 * access_token String OAuth access token (optional)
 * returns OAuthToken
 **/
exports.get_token_info = function(access_token) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {"empty": false};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

