# Swagger\Client\OauthApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createToken**](OauthApi.md#createToken) | **POST** /token | Create OAuth token
[**getTokenInfo**](OauthApi.md#getTokenInfo) | **GET** /token | Get OAuth token information


# **createToken**
> \Swagger\Client\Model\OAuthToken createToken($body)

Create OAuth token

Creates OAuth token using various grant types

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\OauthApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = new \Swagger\Client\Model\CreateOAuthToken(); // \Swagger\Client\Model\CreateOAuthToken | Create OAuth Token Parameters

try {
    $result = $apiInstance->createToken($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OauthApi->createToken: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\CreateOAuthToken**](../Model/CreateOAuthToken.md)| Create OAuth Token Parameters | [optional]

### Return type

[**\Swagger\Client\Model\OAuthToken**](../Model/OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getTokenInfo**
> \Swagger\Client\Model\OAuthToken getTokenInfo($access_token)

Get OAuth token information

Returns information about the current OAuth token

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\OauthApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$access_token = "access_token_example"; // string | OAuth access token

try {
    $result = $apiInstance->getTokenInfo($access_token);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OauthApi->getTokenInfo: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **access_token** | **string**| OAuth access token | [optional]

### Return type

[**\Swagger\Client\Model\OAuthToken**](../Model/OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

