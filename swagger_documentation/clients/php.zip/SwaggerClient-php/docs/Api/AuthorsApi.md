# Swagger\Client\AuthorsApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**privateAuthorDetails**](AuthorsApi.md#privateAuthorDetails) | **GET** /account/authors/{author_id} | Author details
[**privateAuthorsSearch**](AuthorsApi.md#privateAuthorsSearch) | **POST** /account/authors/search | Search Authors


# **privateAuthorDetails**
> \Swagger\Client\Model\AuthorComplete privateAuthorDetails($author_id)

Author details

View author details

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\AuthorsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$author_id = 789; // int | Author unique identifier

try {
    $result = $apiInstance->privateAuthorDetails($author_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AuthorsApi->privateAuthorDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **author_id** | **int**| Author unique identifier |

### Return type

[**\Swagger\Client\Model\AuthorComplete**](../Model/AuthorComplete.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **privateAuthorsSearch**
> \Swagger\Client\Model\Author[] privateAuthorsSearch($search)

Search Authors

Search for authors

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\AuthorsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$search = new \Swagger\Client\Model\PrivateAuthorsSearch(); // \Swagger\Client\Model\PrivateAuthorsSearch | Search Parameters

try {
    $result = $apiInstance->privateAuthorsSearch($search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AuthorsApi->privateAuthorsSearch: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**\Swagger\Client\Model\PrivateAuthorsSearch**](../Model/PrivateAuthorsSearch.md)| Search Parameters | [optional]

### Return type

[**\Swagger\Client\Model\Author[]**](../Model/Author.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

