# Project

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **string** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **string** | Project title | 
**created_date** | **string** | Date when project was created | 
**modified_date** | **string** | Date when project was last modified | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


