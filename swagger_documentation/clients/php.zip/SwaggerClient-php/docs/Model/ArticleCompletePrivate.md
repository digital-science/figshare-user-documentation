# ArticleCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**figshare_url** | **string** | Article public url | [optional] 
**download_disabled** | **bool** | If true, downloading of files for this article is disabled | [optional] 
**files** | [**\Swagger\Client\Model\PublicFile[]**](PublicFile.md) | List of article files. | [optional] 
**folder_structure** | **object** | Mapping of file ids to folder paths, if folders are used | [optional] 
**authors** | [**\Swagger\Client\Model\Author[]**](Author.md) | List of article authors | [optional] 
**custom_fields** | [**\Swagger\Client\Model\CustomArticleField[]**](CustomArticleField.md) | List of custom fields values | [optional] 
**embargo_options** | [**\Swagger\Client\Model\GroupEmbargoOptions[]**](GroupEmbargoOptions.md) | List of embargo options | [optional] 
**citation** | **string** | Article citation | [optional] 
**confidential_reason** | **string** | Confidentiality reason | [optional] 
**is_confidential** | **bool** | Article Confidentiality | [optional] 
**size** | **int** | Article size | [optional] 
**funding** | **string** | Article funding | [optional] 
**funding_list** | [**\Swagger\Client\Model\FundingInformation[]**](FundingInformation.md) | Full Article funding information | [optional] 
**tags** | **string[]** | List of article tags. Keywords can be used instead | [optional] 
**keywords** | **string[]** | List of article keywords. Tags can be used instead | [optional] 
**version** | **int** | Article version | [optional] 
**is_metadata_record** | **bool** | True if article has no files | [optional] 
**metadata_reason** | **string** | Article metadata reason | [optional] 
**status** | **string** | Article status | [optional] 
**description** | **string** | Article description | [optional] 
**is_embargoed** | **bool** | True if article is embargoed | [optional] 
**is_public** | **bool** | True if article is published | [optional] 
**created_date** | **string** | Date when article was created | 
**has_linked_file** | **bool** | True if any files are linked to the article | [optional] 
**categories** | [**\Swagger\Client\Model\Category[]**](Category.md) | List of categories selected for the article | [optional] 
**license** | [**\Swagger\Client\Model\License**](License.md) | Article selected license | [optional] 
**embargo_title** | **string** | Title for embargo | [optional] 
**embargo_reason** | **string** | Reason for embargo | [optional] 
**references** | **string[]** | List of references | [optional] 
**related_materials** | [**\Swagger\Client\Model\RelatedMaterial[]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 
**id** | **int** | Unique identifier for article | 
**title** | **string** | Title of article | 
**doi** | **string** | DOI | 
**handle** | **string** | Handle | 
**url** | **string** | Api endpoint for article | 
**url_public_html** | **string** | Public site endpoint for article | 
**url_public_api** | **string** | Public Api endpoint for article | 
**url_private_html** | **string** | Private site endpoint for article | 
**url_private_api** | **string** | Private Api endpoint for article | 
**timeline** | [**\Swagger\Client\Model\Timeline**](Timeline.md) | Various timeline dates | 
**thumb** | **string** | Thumbnail image | 
**defined_type** | **int** | Type of article identifier | 
**defined_type_name** | **string** | Name of the article type identifier | 
**resource_doi** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to '']
**resource_title** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to '']
**account_id** | **int** | ID of the account owning the article | 
**curation_status** | **string** | Curation status of the article | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


