# ProjectArticle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique identifier for article | 
**title** | **string** | Title of article | 
**doi** | **string** | DOI | 
**handle** | **string** | Handle | 
**url** | **string** | Api endpoint for article | 
**url_public_html** | **string** | Public site endpoint for article | 
**url_public_api** | **string** | Public Api endpoint for article | 
**url_private_html** | **string** | Private site endpoint for article | 
**url_private_api** | **string** | Private Api endpoint for article | 
**timeline** | [**\Swagger\Client\Model\Timeline**](Timeline.md) | Various timeline dates | 
**thumb** | **string** | Thumbnail image | 
**defined_type** | **int** | Type of article identifier | 
**defined_type_name** | **string** | Name of the article type identifier | 
**resource_doi** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to '']
**resource_title** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to '']
**created_date** | **string** | Date when article was created | 
**citation** | **string** | Article citation | 
**confidential_reason** | **string** | Confidentiality reason | 
**is_confidential** | **bool** | Article Confidentiality | 
**size** | **int** | Article size | 
**funding** | **string** | Article funding | 
**funding_list** | [**\Swagger\Client\Model\FundingInformation[]**](FundingInformation.md) | Full Article funding information | 
**keywords** | **string[]** | List of article keywords | 
**version** | **int** | Article version | 
**is_metadata_record** | **bool** | True if article has no files | 
**metadata_reason** | **string** | Article metadata reason | 
**status** | **string** | Article status | 
**description** | **string** | Article description | 
**is_embargoed** | **bool** | True if article is embargoed | 
**is_public** | **bool** | True if article is published | 
**has_linked_file** | **bool** | True if any files are linked to the article | 
**categories** | [**\Swagger\Client\Model\Category[]**](Category.md) | List of categories selected for the article | 
**license** | [**\Swagger\Client\Model\License**](License.md) | Article selected license | 
**embargo_title** | **string** | Title for embargo | 
**embargo_reason** | **string** | Reason for embargo | 
**references** | **string[]** | List of references | 
**related_materials** | [**\Swagger\Client\Model\RelatedMaterial[]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


