# UploadInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **string** | token received after initializing a file upload | [optional] 
**md5** | **string** | md5 provided on upload initialization | [optional] 
**size** | **int** | size of file in bytes | [optional] 
**name** | **string** | name of file on upload server | [optional] 
**status** | **string** | Upload status | [optional] 
**parts** | [**\Swagger\Client\Model\UploadFilePart[]**](UploadFilePart.md) | Uploads parts | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


