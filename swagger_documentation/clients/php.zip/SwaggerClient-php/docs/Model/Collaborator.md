# Collaborator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role_name** | **string** | Collaborator role | 
**user_id** | **int** | Collaborator id | 
**name** | **string** | Collaborator name | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


