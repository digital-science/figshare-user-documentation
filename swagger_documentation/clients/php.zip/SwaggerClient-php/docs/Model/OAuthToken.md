# OAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_token** | **string** | The OAuth access token | 
**token** | **string** | The OAuth access token | [optional] 
**token_type** | **string** | The type of token issued | 
**expires_in** | **int** | Token expiration time in seconds | 
**refresh_token** | **string** | The refresh token (only provided for certain grant types) | [optional] 
**scope** | **string** | The scope of the access token | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


