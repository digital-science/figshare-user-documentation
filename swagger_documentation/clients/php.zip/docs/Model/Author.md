# # Author

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Author id |
**full_name** | **string** | Author full name |
**first_name** | **string** | Author first name |
**last_name** | **string** | Author last name |
**is_active** | **bool** | True if author has published items |
**url_name** | **string** | Author url name |
**orcid_id** | **string** | Author Orcid |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
