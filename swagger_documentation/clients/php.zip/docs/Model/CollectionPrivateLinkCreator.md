# # CollectionPrivateLinkCreator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expires_date** | **string** | Date when this private link should expire - optional. By default private links expire in 365 days. | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
