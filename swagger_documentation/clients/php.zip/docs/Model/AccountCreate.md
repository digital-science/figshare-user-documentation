# # AccountCreate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **string** | Email of account |
**first_name** | **string** | First Name | [optional] [default to '']
**last_name** | **string** | Last Name | [default to '']
**group_id** | **int** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional]
**institution_user_id** | **string** | Institution user id | [optional] [default to '']
**symplectic_user_id** | **string** | Symplectic user id | [optional] [default to '']
**quota** | **int** | Account quota | [optional]
**is_active** | **bool** | Is account active | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
