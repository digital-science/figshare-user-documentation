# # CustomArticleFieldAdd

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Custom  metadata name |
**value** | **object** | Custom metadata value (can be either a string or an array of strings) |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
