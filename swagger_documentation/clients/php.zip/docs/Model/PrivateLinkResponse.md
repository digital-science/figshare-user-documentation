# # PrivateLinkResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **string** | Url for private link |
**html_location** | **string** | HTML url for private link |
**token** | **string** | Token for private link |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
