# # TimelineUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_online** | **string** | Online posted date | [optional]
**publisher_publication** | **string** | Publish date | [optional]
**publisher_acceptance** | **string** | Date when the item was accepted for publication | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
