# # CustomArticleField

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Custom  metadata name |
**value** | **object** | Custom metadata value (can be either a string or an array of strings) |
**field_type** | **string** | Custom field type |
**settings** | **object** | Settings for the custom field |
**order** | **int** | Order of the custom field |
**is_mandatory** | **bool** | Whether the field is mandatory or not |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
