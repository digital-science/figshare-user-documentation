# # Collection

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Collection id |
**title** | **string** | Collection title |
**doi** | **string** | Collection DOI |
**handle** | **string** | Collection Handle |
**url** | **string** | Api endpoint |
**timeline** | [**\OpenAPI\Client\Model\Timeline**](Timeline.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
