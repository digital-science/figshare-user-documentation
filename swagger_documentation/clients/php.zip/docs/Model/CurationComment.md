# # CurationComment

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The ID of the comment. |
**account_id** | **int** | The ID of the account which generated this comment. |
**type** | **string** | The ID of the account which generated this comment. |
**text** | **string** | The value/content of the comment. |
**created_date** | **string** | The creation date of the comment. |
**modified_date** | **string** | The date the comment has been modified. |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
