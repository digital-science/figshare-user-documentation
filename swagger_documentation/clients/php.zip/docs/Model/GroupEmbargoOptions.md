# # GroupEmbargoOptions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Embargo option id |
**type** | **string** | Embargo permission type |
**ip_name** | **string** | IP range name; value appears if type is ip_range |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
