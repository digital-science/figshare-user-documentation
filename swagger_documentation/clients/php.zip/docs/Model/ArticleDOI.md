# # ArticleDOI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**doi** | **string** | Reserved DOI |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
