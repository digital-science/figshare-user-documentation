# # PrivateFile

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**viewer_type** | **string** | File viewer type |
**preview_state** | **string** | File preview state |
**upload_url** | **string** | Upload url for file |
**upload_token** | **string** | Token for file upload |
**is_attached_to_public_version** | **bool** | True if the file is attached to a public item version |
**id** | **int** | File id |
**name** | **string** | File name |
**size** | **int** | File size |
**is_link_only** | **bool** | True if file is hosted somewhere else |
**download_url** | **string** | Url for file download |
**supplied_md5** | **string** | File supplied md5 |
**computed_md5** | **string** | File computed md5 |
**mimetype** | **string** | MIME Type of the file, it defaults to an empty string | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
