# # CreateOAuthToken

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**client_id** | **string** |  |
**client_secret** | **string** |  |
**grant_type** | **string** |  |
**code** | **string** | Required if grant_type is &#39;authorization_code&#39; | [optional]
**refresh_token** | **string** | Required if grant_type is &#39;refresh_token&#39; | [optional]
**username** | **string** | Required if grant_type is &#39;password&#39; | [optional]
**password** | **string** | Required if grant_type is &#39;password&#39; | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
