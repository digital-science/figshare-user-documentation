# # ProjectPrivate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | **string** | Role inside this project |
**storage** | **string** | Project storage type |
**url** | **string** | Api endpoint |
**id** | **int** | Project id |
**title** | **string** | Project title |
**created_date** | **string** | Date when project was created |
**modified_date** | **string** | Date when project was last modified |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
