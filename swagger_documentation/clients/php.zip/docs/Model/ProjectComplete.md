# # ProjectComplete

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **string** | Project funding |
**funding_list** | [**\OpenAPI\Client\Model\FundingInformation[]**](FundingInformation.md) | Full Project funding information |
**description** | **string** | Project description |
**collaborators** | [**\OpenAPI\Client\Model\Collaborator[]**](Collaborator.md) | List of project collaborators |
**custom_fields** | [**\OpenAPI\Client\Model\CustomArticleField[]**](CustomArticleField.md) | Project custom fields |
**modified_date** | **string** | Date when project was last modified |
**created_date** | **string** | Date when project was created |
**url** | **string** | Api endpoint |
**id** | **int** | Project id |
**title** | **string** | Project title |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
