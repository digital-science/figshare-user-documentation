# # CategoryList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_selectable** | **bool** | The selectable status |
**has_children** | **bool** | True if category has children |
**parent_id** | **int** | Parent category |
**id** | **int** | Category id |
**title** | **string** | Category title |
**path** | **string** | Path to all ancestor ids |
**source_id** | **string** | ID in original standard taxonomy |
**taxonomy_id** | **int** | Internal id of taxonomy the category is part of |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
