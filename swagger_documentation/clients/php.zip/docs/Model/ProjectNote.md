# # ProjectNote

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Project note id |
**user_id** | **int** | User who wrote the note |
**abstract** | **string** | Note Abstract - short/truncated content |
**user_name** | **string** | Username of the one who wrote the note |
**created_date** | **string** | Date when note was created |
**modified_date** | **string** | Date when note was last modified |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
