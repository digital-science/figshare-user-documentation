# # CollectionCompletePrivate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account_id** | **int** | ID of the account owning the collection |
**funding** | [**\OpenAPI\Client\Model\FundingInformation[]**](FundingInformation.md) | Full Collection funding information |
**resource_id** | **string** | Collection resource id |
**resource_doi** | **string** | Collection resource doi |
**resource_title** | **string** | Collection resource title |
**resource_link** | **string** | Collection resource link |
**resource_version** | **int** | Collection resource version |
**version** | **int** | Collection version |
**description** | **string** | Collection description |
**categories** | [**\OpenAPI\Client\Model\Category[]**](Category.md) | List of collection categories |
**references** | **string[]** | List of collection references |
**related_materials** | [**\OpenAPI\Client\Model\RelatedMaterial[]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional]
**tags** | **string[]** | List of collection tags. Keywords can be used instead |
**keywords** | **string[]** | List of collection keywords. Tags can be used instead |
**authors** | [**\OpenAPI\Client\Model\Author[]**](Author.md) | List of collection authors |
**institution_id** | **int** | Collection institution |
**group_id** | **int** | Collection group |
**articles_count** | **int** | Number of articles in collection |
**public** | **bool** | True if collection is published |
**citation** | **string** | Collection citation |
**custom_fields** | [**\OpenAPI\Client\Model\CustomArticleField[]**](CustomArticleField.md) | Collection custom fields |
**modified_date** | **string** | Date when collection was last modified |
**created_date** | **string** | Date when collection was created |
**timeline** | [**\OpenAPI\Client\Model\Timeline**](Timeline.md) |  |
**id** | **int** | Collection id |
**title** | **string** | Collection title |
**doi** | **string** | Collection DOI |
**handle** | **string** | Collection Handle |
**url** | **string** | Api endpoint |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
