# # FundingCreate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | A funding ID as returned by the Funding Search endpoint | [optional]
**title** | **string** | The title of the new user created funding | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
