# # FundingInformation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Funding id |
**title** | **string** | The funding name |
**grant_code** | **string** | The grant code |
**funder_name** | **string** | Funder&#39;s name |
**is_user_defined** | **int** | Return 1 whether the grant has been introduced manually, 0 otherwise |
**url** | **string** | The grant url |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
