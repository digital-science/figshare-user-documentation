# # PrivateLink

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | Private link id |
**is_active** | **bool** | True if private link is active |
**expires_date** | **string** | Date when link will expire |
**html_location** | **string** | HTML url for private link |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
