# # ProfileUpdateData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_name** | **string** | First name | [optional]
**last_name** | **string** | Last Name | [optional]
**orcid** | **string** | User ORCID | [optional]
**job_title** | **string** | User job title | [optional]
**fields_of_interest** | **int[]** | User fields of interest (category ids) | [optional]
**fields_of_interest_by_source_id** | **string[]** | User fields of interest (category source IDs), supersedes the fields_of_interest property | [optional]
**location** | **string** | User location | [optional]
**facebook** | **string** | User facebook URL | [optional]
**x** | **string** | User X (twitter) URL | [optional]
**linkedin** | **string** | User linkedin URL | [optional]
**bio** | **string** | User biographical information | [optional]
**personal_profiles** | [**\OpenAPI\Client\Model\ProfileUpdateDataPersonalProfilesInner[]**](ProfileUpdateDataPersonalProfilesInner.md) | Add up to 10 additional personal profile links | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
