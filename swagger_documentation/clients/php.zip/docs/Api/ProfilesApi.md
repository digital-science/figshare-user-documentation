# OpenAPI\Client\ProfilesApi

All URIs are relative to http://localhost, except if the operation defines another base path.

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**updateUserProfile()**](ProfilesApi.md#updateUserProfile) | **PUT** /account/profile | Update public profile |
| [**updateUserProfilePicture()**](ProfilesApi.md#updateUserProfilePicture) | **POST** /account/profile/{user_id}/picture | Update public profile picture |


## `updateUserProfile()`

```php
updateUserProfile($user_profile_data, $user_id, $institution_user_id): object
```

Update public profile

Updates the fields of the user's public profile.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ProfilesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$user_profile_data = new \OpenAPI\Client\Model\ProfileUpdateData(); // \OpenAPI\Client\Model\ProfileUpdateData
$user_id = 56; // int | User ID
$institution_user_id = 'institution_user_id_example'; // string | Institutional user ID

try {
    $result = $apiInstance->updateUserProfile($user_profile_data, $user_id, $institution_user_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProfilesApi->updateUserProfile: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **user_profile_data** | [**\OpenAPI\Client\Model\ProfileUpdateData**](../Model/ProfileUpdateData.md)|  | |
| **user_id** | **int**| User ID | [optional] |
| **institution_user_id** | **string**| Institutional user ID | [optional] |

### Return type

**object**

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `updateUserProfilePicture()`

```php
updateUserProfilePicture($user_id, $profile_picture): object
```

Update public profile picture

Updates the profile picture of the user's public profile.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ProfilesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$user_id = 56; // int | User ID
$profile_picture = "/path/to/file.txt"; // \SplFileObject | User profile picture

try {
    $result = $apiInstance->updateUserProfilePicture($user_id, $profile_picture);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProfilesApi->updateUserProfilePicture: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **user_id** | **int**| User ID | |
| **profile_picture** | **\SplFileObject****\SplFileObject**| User profile picture | |

### Return type

**object**

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `multipart/form-data`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
