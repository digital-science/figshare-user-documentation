# OpenAPI\Client\AltmetricApi

All URIs are relative to http://localhost, except if the operation defines another base path.

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**altmetricInstitutionsList()**](AltmetricApi.md#altmetricInstitutionsList) | **GET** /altmetric/institutions | List Altmetric Institutions |


## `altmetricInstitutionsList()`

```php
altmetricInstitutionsList($offset): \OpenAPI\Client\Model\AltmetricInstitution[]
```

List Altmetric Institutions

Returns a list of institutions available for Altmetric reporting

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\AltmetricApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$offset = 0; // int | Where to start the listing. The offset of the first item.

try {
    $result = $apiInstance->altmetricInstitutionsList($offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AltmetricApi->altmetricInstitutionsList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **offset** | **int**| Where to start the listing. The offset of the first item. | [optional] [default to 0] |

### Return type

[**\OpenAPI\Client\Model\AltmetricInstitution[]**](../Model/AltmetricInstitution.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
