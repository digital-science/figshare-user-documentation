# OpenAPI\Client\AuthorsApi

All URIs are relative to https://api.figsh.com/v2, except if the operation defines another base path.

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**privateAuthorDetails()**](AuthorsApi.md#privateAuthorDetails) | **GET** /account/authors/{author_id} | Author details |
| [**privateAuthorsSearch()**](AuthorsApi.md#privateAuthorsSearch) | **POST** /account/authors/search | Search Authors |


## `privateAuthorDetails()`

```php
privateAuthorDetails($author_id): \OpenAPI\Client\Model\AuthorComplete
```

Author details

View author details

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AuthorsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$author_id = 56; // int | Author unique identifier

try {
    $result = $apiInstance->privateAuthorDetails($author_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AuthorsApi->privateAuthorDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **author_id** | **int**| Author unique identifier | |

### Return type

[**\OpenAPI\Client\Model\AuthorComplete**](../Model/AuthorComplete.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateAuthorsSearch()`

```php
privateAuthorsSearch($search): \OpenAPI\Client\Model\AuthorComplete[]
```

Search Authors

Search for authors

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AuthorsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$search = new \OpenAPI\Client\Model\PrivateAuthorsSearch(); // \OpenAPI\Client\Model\PrivateAuthorsSearch | Search Parameters

try {
    $result = $apiInstance->privateAuthorsSearch($search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AuthorsApi->privateAuthorsSearch: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**\OpenAPI\Client\Model\PrivateAuthorsSearch**](../Model/PrivateAuthorsSearch.md)| Search Parameters | [optional] |

### Return type

[**\OpenAPI\Client\Model\AuthorComplete[]**](../Model/AuthorComplete.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
