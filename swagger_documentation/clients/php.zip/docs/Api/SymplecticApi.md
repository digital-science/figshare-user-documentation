# OpenAPI\Client\SymplecticApi

All URIs are relative to http://localhost, except if the operation defines another base path.

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**symplecticAccountArticles()**](SymplecticApi.md#symplecticAccountArticles) | **GET** /symplectic/accounts/{external_user_id}/articles | Get articles for a specific account |
| [**symplecticAccountsIds()**](SymplecticApi.md#symplecticAccountsIds) | **GET** /symplectic/accounts | Get changed accounts for Symplectic Elements |
| [**symplecticArticle()**](SymplecticApi.md#symplecticArticle) | **GET** /symplectic/articles/{article_id} | Get article details for Symplectic Elements |
| [**symplecticChangedArticles()**](SymplecticApi.md#symplecticChangedArticles) | **GET** /symplectic/articles | Get changed articles for Symplectic Elements |
| [**symplecticUserId()**](SymplecticApi.md#symplecticUserId) | **GET** /symplectic/users/{user_id} | Get institutional user ID for a user |


## `symplecticAccountArticles()`

```php
symplecticAccountArticles($external_user_id, $offset, $limit, $status, $is_embargoed): object[]
```

Get articles for a specific account

Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id).

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\SymplecticApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$external_user_id = 'external_user_id_example'; // string | External user ID (symplectic_user_id or institution_user_id)
$offset = 0; // int | Number of results to skip for pagination
$limit = 10; // int | Maximum number of results to return
$status = 'status_example'; // string | Filter by article status
$is_embargoed = 'is_embargoed_example'; // string | Filter by embargo status

try {
    $result = $apiInstance->symplecticAccountArticles($external_user_id, $offset, $limit, $status, $is_embargoed);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SymplecticApi->symplecticAccountArticles: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **external_user_id** | **string**| External user ID (symplectic_user_id or institution_user_id) | |
| **offset** | **int**| Number of results to skip for pagination | [optional] [default to 0] |
| **limit** | **int**| Maximum number of results to return | [optional] [default to 10] |
| **status** | **string**| Filter by article status | [optional] |
| **is_embargoed** | **string**| Filter by embargo status | [optional] |

### Return type

**object[]**

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `symplecticAccountsIds()`

```php
symplecticAccountsIds($since): \OpenAPI\Client\Model\SymplecticAccountsIds200ResponseInner[]
```

Get changed accounts for Symplectic Elements

Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\SymplecticApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$since = 2015-01-01 00:00:00; // string | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)

try {
    $result = $apiInstance->symplecticAccountsIds($since);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SymplecticApi->symplecticAccountsIds: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **since** | **string**| ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | |

### Return type

[**\OpenAPI\Client\Model\SymplecticAccountsIds200ResponseInner[]**](../Model/SymplecticAccountsIds200ResponseInner.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `symplecticArticle()`

```php
symplecticArticle($article_id): object
```

Get article details for Symplectic Elements

Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\SymplecticApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article ID

try {
    $result = $apiInstance->symplecticArticle($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SymplecticApi->symplecticArticle: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **article_id** | **int**| Article ID | |

### Return type

**object**

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `symplecticChangedArticles()`

```php
symplecticChangedArticles($since, $offset, $limit, $status, $is_embargoed): object[]
```

Get changed articles for Symplectic Elements

Returns a list of articles for Symplectic Elements integration to synchronize article data.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\SymplecticApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$since = 2015-01-01 00:00:00; // string | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS)
$offset = 0; // int | Number of results to skip for pagination
$limit = 10; // int | Maximum number of results to return
$status = 'status_example'; // string | Filter by article status
$is_embargoed = 'is_embargoed_example'; // string | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type

try {
    $result = $apiInstance->symplecticChangedArticles($since, $offset, $limit, $status, $is_embargoed);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SymplecticApi->symplecticChangedArticles: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **since** | **string**| ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | |
| **offset** | **int**| Number of results to skip for pagination | [optional] [default to 0] |
| **limit** | **int**| Maximum number of results to return | [optional] [default to 10] |
| **status** | **string**| Filter by article status | [optional] |
| **is_embargoed** | **string**| Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type | [optional] |

### Return type

**object[]**

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `symplecticUserId()`

```php
symplecticUserId($user_id): \OpenAPI\Client\Model\SymplecticUserId200Response
```

Get institutional user ID for a user

Returns the institution user ID for a given user within the authenticated account's institution.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\SymplecticApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$user_id = 56; // int | User ID

try {
    $result = $apiInstance->symplecticUserId($user_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SymplecticApi->symplecticUserId: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **user_id** | **int**| User ID | |

### Return type

[**\OpenAPI\Client\Model\SymplecticUserId200Response**](../Model/SymplecticUserId200Response.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
