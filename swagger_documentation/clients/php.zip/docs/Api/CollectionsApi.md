# OpenAPI\Client\CollectionsApi

All URIs are relative to http://localhost, except if the operation defines another base path.

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**collectionArticles()**](CollectionsApi.md#collectionArticles) | **GET** /collections/{collection_id}/articles | Public Collection Articles |
| [**collectionDetails()**](CollectionsApi.md#collectionDetails) | **GET** /collections/{collection_id} | Collection details |
| [**collectionVersionDetails()**](CollectionsApi.md#collectionVersionDetails) | **GET** /collections/{collection_id}/versions/{version_id} | Collection Version details |
| [**collectionVersions()**](CollectionsApi.md#collectionVersions) | **GET** /collections/{collection_id}/versions | Collection Versions list |
| [**collectionsList()**](CollectionsApi.md#collectionsList) | **GET** /collections | Public Collections |
| [**collectionsSearch()**](CollectionsApi.md#collectionsSearch) | **POST** /collections/search | Public Collections Search |
| [**privateCollectionArticleDelete()**](CollectionsApi.md#privateCollectionArticleDelete) | **DELETE** /account/collections/{collection_id}/articles/{article_id} | Delete collection article |
| [**privateCollectionArticlesAdd()**](CollectionsApi.md#privateCollectionArticlesAdd) | **POST** /account/collections/{collection_id}/articles | Add collection articles |
| [**privateCollectionArticlesList()**](CollectionsApi.md#privateCollectionArticlesList) | **GET** /account/collections/{collection_id}/articles | List collection articles |
| [**privateCollectionArticlesReplace()**](CollectionsApi.md#privateCollectionArticlesReplace) | **PUT** /account/collections/{collection_id}/articles | Replace collection articles |
| [**privateCollectionAuthorDelete()**](CollectionsApi.md#privateCollectionAuthorDelete) | **DELETE** /account/collections/{collection_id}/authors/{author_id} | Delete collection author |
| [**privateCollectionAuthorsAdd()**](CollectionsApi.md#privateCollectionAuthorsAdd) | **POST** /account/collections/{collection_id}/authors | Add collection authors |
| [**privateCollectionAuthorsList()**](CollectionsApi.md#privateCollectionAuthorsList) | **GET** /account/collections/{collection_id}/authors | List collection authors |
| [**privateCollectionAuthorsReplace()**](CollectionsApi.md#privateCollectionAuthorsReplace) | **PUT** /account/collections/{collection_id}/authors | Replace collection authors |
| [**privateCollectionCategoriesAdd()**](CollectionsApi.md#privateCollectionCategoriesAdd) | **POST** /account/collections/{collection_id}/categories | Add collection categories |
| [**privateCollectionCategoriesList()**](CollectionsApi.md#privateCollectionCategoriesList) | **GET** /account/collections/{collection_id}/categories | List collection categories |
| [**privateCollectionCategoriesReplace()**](CollectionsApi.md#privateCollectionCategoriesReplace) | **PUT** /account/collections/{collection_id}/categories | Replace collection categories |
| [**privateCollectionCategoryDelete()**](CollectionsApi.md#privateCollectionCategoryDelete) | **DELETE** /account/collections/{collection_id}/categories/{category_id} | Delete collection category |
| [**privateCollectionCreate()**](CollectionsApi.md#privateCollectionCreate) | **POST** /account/collections | Create collection |
| [**privateCollectionDelete()**](CollectionsApi.md#privateCollectionDelete) | **DELETE** /account/collections/{collection_id} | Delete collection |
| [**privateCollectionDetails()**](CollectionsApi.md#privateCollectionDetails) | **GET** /account/collections/{collection_id} | Collection details |
| [**privateCollectionPatch()**](CollectionsApi.md#privateCollectionPatch) | **PATCH** /account/collections/{collection_id} | Partially update collection |
| [**privateCollectionPrivateLinkCreate()**](CollectionsApi.md#privateCollectionPrivateLinkCreate) | **POST** /account/collections/{collection_id}/private_links | Create collection private link |
| [**privateCollectionPrivateLinkDelete()**](CollectionsApi.md#privateCollectionPrivateLinkDelete) | **DELETE** /account/collections/{collection_id}/private_links/{link_id} | Disable private link |
| [**privateCollectionPrivateLinkDetails()**](CollectionsApi.md#privateCollectionPrivateLinkDetails) | **GET** /account/collections/{collection_id}/private_links/{link_id} | View collection private link |
| [**privateCollectionPrivateLinkUpdate()**](CollectionsApi.md#privateCollectionPrivateLinkUpdate) | **PUT** /account/collections/{collection_id}/private_links/{link_id} | Update collection private link |
| [**privateCollectionPrivateLinksList()**](CollectionsApi.md#privateCollectionPrivateLinksList) | **GET** /account/collections/{collection_id}/private_links | List collection private links |
| [**privateCollectionPublish()**](CollectionsApi.md#privateCollectionPublish) | **POST** /account/collections/{collection_id}/publish | Private Collection Publish |
| [**privateCollectionReserveDoi()**](CollectionsApi.md#privateCollectionReserveDoi) | **POST** /account/collections/{collection_id}/reserve_doi | Private Collection Reserve DOI |
| [**privateCollectionReserveHandle()**](CollectionsApi.md#privateCollectionReserveHandle) | **POST** /account/collections/{collection_id}/reserve_handle | Private Collection Reserve Handle |
| [**privateCollectionResource()**](CollectionsApi.md#privateCollectionResource) | **POST** /account/collections/{collection_id}/resource | Private Collection Resource |
| [**privateCollectionUpdate()**](CollectionsApi.md#privateCollectionUpdate) | **PUT** /account/collections/{collection_id} | Update collection |
| [**privateCollectionsList()**](CollectionsApi.md#privateCollectionsList) | **GET** /account/collections | Private Collections List |
| [**privateCollectionsSearch()**](CollectionsApi.md#privateCollectionsSearch) | **POST** /account/collections/search | Private Collections Search |


## `collectionArticles()`

```php
collectionArticles($collection_id, $page, $page_size, $limit, $offset): \OpenAPI\Client\Model\Article[]
```

Public Collection Articles

Returns a list of public collection articles

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$collection_id = 56; // int | Collection Unique identifier
$page = 56; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit

try {
    $result = $apiInstance->collectionArticles($collection_id, $page, $page_size, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->collectionArticles: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection Unique identifier | |
| **page** | **int**| Page number. Used for pagination with page_size | [optional] |
| **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**\OpenAPI\Client\Model\Article[]**](../Model/Article.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `collectionDetails()`

```php
collectionDetails($collection_id): \OpenAPI\Client\Model\CollectionComplete
```

Collection details

View a collection

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$collection_id = 56; // int | Collection Unique identifier

try {
    $result = $apiInstance->collectionDetails($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->collectionDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection Unique identifier | |

### Return type

[**\OpenAPI\Client\Model\CollectionComplete**](../Model/CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `collectionVersionDetails()`

```php
collectionVersionDetails($collection_id, $version_id): \OpenAPI\Client\Model\CollectionComplete
```

Collection Version details

View details for a certain version of a collection

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$collection_id = 56; // int | Collection Unique identifier
$version_id = 56; // int | Version Number

try {
    $result = $apiInstance->collectionVersionDetails($collection_id, $version_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->collectionVersionDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection Unique identifier | |
| **version_id** | **int**| Version Number | |

### Return type

[**\OpenAPI\Client\Model\CollectionComplete**](../Model/CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `collectionVersions()`

```php
collectionVersions($collection_id): \OpenAPI\Client\Model\CollectionVersions[]
```

Collection Versions list

Returns a list of public collection Versions

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$collection_id = 56; // int | Collection Unique identifier

try {
    $result = $apiInstance->collectionVersions($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->collectionVersions: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection Unique identifier | |

### Return type

[**\OpenAPI\Client\Model\CollectionVersions[]**](../Model/CollectionVersions.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `collectionsList()`

```php
collectionsList($x_cursor, $page, $page_size, $limit, $offset, $order, $order_direction, $institution, $published_since, $modified_since, $group, $resource_doi, $doi, $handle): \OpenAPI\Client\Model\Collection[]
```

Public Collections

Returns a list of public collections

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$x_cursor = 'x_cursor_example'; // string | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
$page = 56; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit
$order = 'published_date'; // string | The field by which to order. Default varies by endpoint/resource.
$order_direction = 'desc'; // string
$institution = 56; // int | only return collections from this institution
$published_since = 'published_since_example'; // string | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD
$modified_since = 'modified_since_example'; // string | Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD
$group = 56; // int | only return collections from this group
$resource_doi = 'resource_doi_example'; // string | only return collections with this resource_doi
$doi = 'doi_example'; // string | only return collections with this doi
$handle = 'handle_example'; // string | only return collections with this handle

try {
    $result = $apiInstance->collectionsList($x_cursor, $page, $page_size, $limit, $offset, $order, $order_direction, $institution, $published_since, $modified_since, $group, $resource_doi, $doi, $handle);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->collectionsList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **x_cursor** | **string**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **page** | **int**| Page number. Used for pagination with page_size | [optional] |
| **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to &#39;published_date&#39;] |
| **order_direction** | **string**|  | [optional] [default to &#39;desc&#39;] |
| **institution** | **int**| only return collections from this institution | [optional] |
| **published_since** | **string**| Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional] |
| **modified_since** | **string**| Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD | [optional] |
| **group** | **int**| only return collections from this group | [optional] |
| **resource_doi** | **string**| only return collections with this resource_doi | [optional] |
| **doi** | **string**| only return collections with this doi | [optional] |
| **handle** | **string**| only return collections with this handle | [optional] |

### Return type

[**\OpenAPI\Client\Model\Collection[]**](../Model/Collection.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `collectionsSearch()`

```php
collectionsSearch($x_cursor, $search): \OpenAPI\Client\Model\Collection[]
```

Public Collections Search

Returns a list of public collections

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$x_cursor = 'x_cursor_example'; // string | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
$search = new \OpenAPI\Client\Model\CollectionSearch(); // \OpenAPI\Client\Model\CollectionSearch | Search Parameters

try {
    $result = $apiInstance->collectionsSearch($x_cursor, $search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->collectionsSearch: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **x_cursor** | **string**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **search** | [**\OpenAPI\Client\Model\CollectionSearch**](../Model/CollectionSearch.md)| Search Parameters | [optional] |

### Return type

[**\OpenAPI\Client\Model\Collection[]**](../Model/Collection.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionArticleDelete()`

```php
privateCollectionArticleDelete($collection_id, $article_id)
```

Delete collection article

De-associate article from collection

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$article_id = 56; // int | Collection article unique identifier

try {
    $apiInstance->privateCollectionArticleDelete($collection_id, $article_id);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionArticleDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **article_id** | **int**| Collection article unique identifier | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionArticlesAdd()`

```php
privateCollectionArticlesAdd($collection_id, $articles): \OpenAPI\Client\Model\Location
```

Add collection articles

Associate new articles with the collection. This will add new articles to the list of already associated articles

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$articles = new \OpenAPI\Client\Model\ArticlesCreator(); // \OpenAPI\Client\Model\ArticlesCreator | Articles list

try {
    $result = $apiInstance->privateCollectionArticlesAdd($collection_id, $articles);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionArticlesAdd: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **articles** | [**\OpenAPI\Client\Model\ArticlesCreator**](../Model/ArticlesCreator.md)| Articles list | |

### Return type

[**\OpenAPI\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionArticlesList()`

```php
privateCollectionArticlesList($collection_id, $page, $page_size, $limit, $offset): \OpenAPI\Client\Model\Article[]
```

List collection articles

List collection articles

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$page = 56; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit

try {
    $result = $apiInstance->privateCollectionArticlesList($collection_id, $page, $page_size, $limit, $offset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionArticlesList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **page** | **int**| Page number. Used for pagination with page_size | [optional] |
| **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**\OpenAPI\Client\Model\Article[]**](../Model/Article.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionArticlesReplace()`

```php
privateCollectionArticlesReplace($collection_id, $articles)
```

Replace collection articles

Associate new articles with the collection. This will remove all already associated articles and add these new ones

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$articles = new \OpenAPI\Client\Model\ArticlesCreator(); // \OpenAPI\Client\Model\ArticlesCreator | Articles List

try {
    $apiInstance->privateCollectionArticlesReplace($collection_id, $articles);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionArticlesReplace: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **articles** | [**\OpenAPI\Client\Model\ArticlesCreator**](../Model/ArticlesCreator.md)| Articles List | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionAuthorDelete()`

```php
privateCollectionAuthorDelete($collection_id, $author_id)
```

Delete collection author

Delete collection author

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$author_id = 56; // int | Collection Author unique identifier

try {
    $apiInstance->privateCollectionAuthorDelete($collection_id, $author_id);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionAuthorDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **author_id** | **int**| Collection Author unique identifier | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionAuthorsAdd()`

```php
privateCollectionAuthorsAdd($collection_id, $authors): \OpenAPI\Client\Model\Location
```

Add collection authors

Associate new authors with the collection. This will add new authors to the list of already associated authors

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$authors = new \OpenAPI\Client\Model\AuthorsCreator(); // \OpenAPI\Client\Model\AuthorsCreator | List of authors

try {
    $result = $apiInstance->privateCollectionAuthorsAdd($collection_id, $authors);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionAuthorsAdd: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **authors** | [**\OpenAPI\Client\Model\AuthorsCreator**](../Model/AuthorsCreator.md)| List of authors | |

### Return type

[**\OpenAPI\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionAuthorsList()`

```php
privateCollectionAuthorsList($collection_id): \OpenAPI\Client\Model\Author[]
```

List collection authors

List collection authors

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier

try {
    $result = $apiInstance->privateCollectionAuthorsList($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionAuthorsList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |

### Return type

[**\OpenAPI\Client\Model\Author[]**](../Model/Author.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionAuthorsReplace()`

```php
privateCollectionAuthorsReplace($collection_id, $authors)
```

Replace collection authors

Associate new authors with the collection. This will remove all already associated authors and add these new ones

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$authors = new \OpenAPI\Client\Model\AuthorsCreator(); // \OpenAPI\Client\Model\AuthorsCreator | List of authors

try {
    $apiInstance->privateCollectionAuthorsReplace($collection_id, $authors);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionAuthorsReplace: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **authors** | [**\OpenAPI\Client\Model\AuthorsCreator**](../Model/AuthorsCreator.md)| List of authors | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionCategoriesAdd()`

```php
privateCollectionCategoriesAdd($collection_id, $categories): \OpenAPI\Client\Model\Location
```

Add collection categories

Associate new categories with the collection. This will add new categories to the list of already associated categories

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$categories = new \OpenAPI\Client\Model\CategoriesCreator(); // \OpenAPI\Client\Model\CategoriesCreator | Categories list

try {
    $result = $apiInstance->privateCollectionCategoriesAdd($collection_id, $categories);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionCategoriesAdd: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **categories** | [**\OpenAPI\Client\Model\CategoriesCreator**](../Model/CategoriesCreator.md)| Categories list | |

### Return type

[**\OpenAPI\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionCategoriesList()`

```php
privateCollectionCategoriesList($collection_id): \OpenAPI\Client\Model\Category[]
```

List collection categories

List collection categories

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier

try {
    $result = $apiInstance->privateCollectionCategoriesList($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionCategoriesList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |

### Return type

[**\OpenAPI\Client\Model\Category[]**](../Model/Category.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionCategoriesReplace()`

```php
privateCollectionCategoriesReplace($collection_id, $categories)
```

Replace collection categories

Associate new categories with the collection. This will remove all already associated categories and add these new ones

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$categories = new \OpenAPI\Client\Model\CategoriesCreator(); // \OpenAPI\Client\Model\CategoriesCreator | Categories list

try {
    $apiInstance->privateCollectionCategoriesReplace($collection_id, $categories);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionCategoriesReplace: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **categories** | [**\OpenAPI\Client\Model\CategoriesCreator**](../Model/CategoriesCreator.md)| Categories list | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionCategoryDelete()`

```php
privateCollectionCategoryDelete($collection_id, $category_id)
```

Delete collection category

De-associate category from collection

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$category_id = 56; // int | Collection category unique identifier

try {
    $apiInstance->privateCollectionCategoryDelete($collection_id, $category_id);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionCategoryDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **category_id** | **int**| Collection category unique identifier | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionCreate()`

```php
privateCollectionCreate($collection): \OpenAPI\Client\Model\LocationWarnings
```

Create collection

Create a new Collection by sending collection information

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection = new \OpenAPI\Client\Model\CollectionCreate(); // \OpenAPI\Client\Model\CollectionCreate | Collection description

try {
    $result = $apiInstance->privateCollectionCreate($collection);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionCreate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection** | [**\OpenAPI\Client\Model\CollectionCreate**](../Model/CollectionCreate.md)| Collection description | |

### Return type

[**\OpenAPI\Client\Model\LocationWarnings**](../Model/LocationWarnings.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionDelete()`

```php
privateCollectionDelete($collection_id)
```

Delete collection

Delete n collection

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection Unique identifier

try {
    $apiInstance->privateCollectionDelete($collection_id);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection Unique identifier | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionDetails()`

```php
privateCollectionDetails($collection_id): \OpenAPI\Client\Model\CollectionCompletePrivate
```

Collection details

View a collection

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection Unique identifier

try {
    $result = $apiInstance->privateCollectionDetails($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection Unique identifier | |

### Return type

[**\OpenAPI\Client\Model\CollectionCompletePrivate**](../Model/CollectionCompletePrivate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionPatch()`

```php
privateCollectionPatch($collection_id, $collection): \OpenAPI\Client\Model\LocationWarningsUpdate
```

Partially update collection

Partially update a collection by sending only the fields to change.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection Unique identifier
$collection = new \OpenAPI\Client\Model\CollectionUpdate(); // \OpenAPI\Client\Model\CollectionUpdate | Subset of collection fields to update

try {
    $result = $apiInstance->privateCollectionPatch($collection_id, $collection);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionPatch: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection Unique identifier | |
| **collection** | [**\OpenAPI\Client\Model\CollectionUpdate**](../Model/CollectionUpdate.md)| Subset of collection fields to update | |

### Return type

[**\OpenAPI\Client\Model\LocationWarningsUpdate**](../Model/LocationWarningsUpdate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionPrivateLinkCreate()`

```php
privateCollectionPrivateLinkCreate($collection_id, $private_link): \OpenAPI\Client\Model\PrivateLinkResponse
```

Create collection private link

Create new private link

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$private_link = new \OpenAPI\Client\Model\CollectionPrivateLinkCreator(); // \OpenAPI\Client\Model\CollectionPrivateLinkCreator

try {
    $result = $apiInstance->privateCollectionPrivateLinkCreate($collection_id, $private_link);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionPrivateLinkCreate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **private_link** | [**\OpenAPI\Client\Model\CollectionPrivateLinkCreator**](../Model/CollectionPrivateLinkCreator.md)|  | [optional] |

### Return type

[**\OpenAPI\Client\Model\PrivateLinkResponse**](../Model/PrivateLinkResponse.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionPrivateLinkDelete()`

```php
privateCollectionPrivateLinkDelete($collection_id, $link_id)
```

Disable private link

Disable/delete private link for this collection

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$link_id = 'link_id_example'; // string | Private link token

try {
    $apiInstance->privateCollectionPrivateLinkDelete($collection_id, $link_id);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionPrivateLinkDelete: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **link_id** | **string**| Private link token | |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionPrivateLinkDetails()`

```php
privateCollectionPrivateLinkDetails($collection_id, $link_id): \OpenAPI\Client\Model\PrivateLink
```

View collection private link

View existing private link for this collection

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$link_id = 'link_id_example'; // string | Private link token

try {
    $result = $apiInstance->privateCollectionPrivateLinkDetails($collection_id, $link_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionPrivateLinkDetails: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **link_id** | **string**| Private link token | |

### Return type

[**\OpenAPI\Client\Model\PrivateLink**](../Model/PrivateLink.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionPrivateLinkUpdate()`

```php
privateCollectionPrivateLinkUpdate($collection_id, $link_id, $private_link)
```

Update collection private link

Update existing private link for this collection

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$link_id = 'link_id_example'; // string | Private link token
$private_link = new \OpenAPI\Client\Model\CollectionPrivateLinkCreator(); // \OpenAPI\Client\Model\CollectionPrivateLinkCreator

try {
    $apiInstance->privateCollectionPrivateLinkUpdate($collection_id, $link_id, $private_link);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionPrivateLinkUpdate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **link_id** | **string**| Private link token | |
| **private_link** | [**\OpenAPI\Client\Model\CollectionPrivateLinkCreator**](../Model/CollectionPrivateLinkCreator.md)|  | [optional] |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionPrivateLinksList()`

```php
privateCollectionPrivateLinksList($collection_id): \OpenAPI\Client\Model\PrivateLink[]
```

List collection private links

List article private links

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier

try {
    $result = $apiInstance->privateCollectionPrivateLinksList($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionPrivateLinksList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |

### Return type

[**\OpenAPI\Client\Model\PrivateLink[]**](../Model/PrivateLink.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionPublish()`

```php
privateCollectionPublish($collection_id): \OpenAPI\Client\Model\Location
```

Private Collection Publish

When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection Unique identifier

try {
    $result = $apiInstance->privateCollectionPublish($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionPublish: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection Unique identifier | |

### Return type

[**\OpenAPI\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionReserveDoi()`

```php
privateCollectionReserveDoi($collection_id): \OpenAPI\Client\Model\CollectionDOI
```

Private Collection Reserve DOI

Reserve DOI for collection

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection Unique identifier

try {
    $result = $apiInstance->privateCollectionReserveDoi($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionReserveDoi: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection Unique identifier | |

### Return type

[**\OpenAPI\Client\Model\CollectionDOI**](../Model/CollectionDOI.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionReserveHandle()`

```php
privateCollectionReserveHandle($collection_id): \OpenAPI\Client\Model\CollectionHandle
```

Private Collection Reserve Handle

Reserve Handle for collection

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection Unique identifier

try {
    $result = $apiInstance->privateCollectionReserveHandle($collection_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionReserveHandle: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection Unique identifier | |

### Return type

[**\OpenAPI\Client\Model\CollectionHandle**](../Model/CollectionHandle.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionResource()`

```php
privateCollectionResource($collection_id, $resource): \OpenAPI\Client\Model\Location
```

Private Collection Resource

Edit collection resource data.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection unique identifier
$resource = new \OpenAPI\Client\Model\Resource(); // \OpenAPI\Client\Model\Resource | Resource data

try {
    $result = $apiInstance->privateCollectionResource($collection_id, $resource);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionResource: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection unique identifier | |
| **resource** | [**\OpenAPI\Client\Model\Resource**](../Model/Resource.md)| Resource data | |

### Return type

[**\OpenAPI\Client\Model\Location**](../Model/Location.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionUpdate()`

```php
privateCollectionUpdate($collection_id, $collection): \OpenAPI\Client\Model\LocationWarningsUpdate
```

Update collection

Update a collection by passing full body parameters.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$collection_id = 56; // int | Collection Unique identifier
$collection = new \OpenAPI\Client\Model\CollectionUpdate(); // \OpenAPI\Client\Model\CollectionUpdate | Collection description

try {
    $result = $apiInstance->privateCollectionUpdate($collection_id, $collection);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionUpdate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **collection_id** | **int**| Collection Unique identifier | |
| **collection** | [**\OpenAPI\Client\Model\CollectionUpdate**](../Model/CollectionUpdate.md)| Collection description | |

### Return type

[**\OpenAPI\Client\Model\LocationWarningsUpdate**](../Model/LocationWarningsUpdate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionsList()`

```php
privateCollectionsList($page, $page_size, $limit, $offset, $order, $order_direction): \OpenAPI\Client\Model\Collection[]
```

Private Collections List

List private collections

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$page = 56; // int | Page number. Used for pagination with page_size
$page_size = 10; // int | The number of results included on a page. Used for pagination with page
$limit = 56; // int | Number of results included on a page. Used for pagination with query
$offset = 56; // int | Where to start the listing (the offset of the first result). Used for pagination with limit
$order = 'published_date'; // string | The field by which to order. Default varies by endpoint/resource.
$order_direction = 'desc'; // string

try {
    $result = $apiInstance->privateCollectionsList($page, $page_size, $limit, $offset, $order, $order_direction);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionsList: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **page** | **int**| Page number. Used for pagination with page_size | [optional] |
| **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to &#39;published_date&#39;] |
| **order_direction** | **string**|  | [optional] [default to &#39;desc&#39;] |

### Return type

[**\OpenAPI\Client\Model\Collection[]**](../Model/Collection.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `privateCollectionsSearch()`

```php
privateCollectionsSearch($search): \OpenAPI\Client\Model\Collection[]
```

Private Collections Search

Returns a list of private Collections

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\CollectionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$search = new \OpenAPI\Client\Model\PrivateCollectionSearch(); // \OpenAPI\Client\Model\PrivateCollectionSearch | Search Parameters

try {
    $result = $apiInstance->privateCollectionsSearch($search);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CollectionsApi->privateCollectionsSearch: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **search** | [**\OpenAPI\Client\Model\PrivateCollectionSearch**](../Model/PrivateCollectionSearch.md)| Search Parameters | |

### Return type

[**\OpenAPI\Client\Model\Collection[]**](../Model/Collection.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
