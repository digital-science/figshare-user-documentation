# OpenAPIClient-php

Figshare API v2 - Full REST API documentation for managing articles, collections, projects and more.

For more information, please visit [https://support.figshare.com/support/home](https://support.figshare.com/support/home).

## Installation & Usage

### Requirements

PHP 7.4 and later.
Should also work with PHP 8.0.

### Composer

To install the bindings via [Composer](https://getcomposer.org/), add the following to `composer.json`:

```json
{
  "repositories": [
    {
      "type": "vcs",
      "url": "https://github.com/GIT_USER_ID/GIT_REPO_ID.git"
    }
  ],
  "require": {
    "GIT_USER_ID/GIT_REPO_ID": "*@dev"
  }
}
```

Then run `composer install`

### Manual Installation

Download the files and include `autoload.php`:

```php
<?php
require_once('/path/to/OpenAPIClient-php/vendor/autoload.php');
```

## Getting Started

Please follow the [installation procedure](#installation--usage) and then run the following:

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



// Configure OAuth2 access token for authorization: OAuth2
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\ArticlesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$article_id = 56; // int | Article unique identifier

try {
    $result = $apiInstance->accountArticlePublish($article_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArticlesApi->accountArticlePublish: ', $e->getMessage(), PHP_EOL;
}

```

## API Endpoints

All URIs are relative to *https://api.figsh.com/v2*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*ArticlesApi* | [**accountArticlePublish**](docs/Api/ArticlesApi.md#accountarticlepublish) | **POST** /account/articles/{article_id}/publish | Private Article Publish
*ArticlesApi* | [**accountArticleReport**](docs/Api/ArticlesApi.md#accountarticlereport) | **GET** /account/articles/export | Account Article Report
*ArticlesApi* | [**accountArticleReportGenerate**](docs/Api/ArticlesApi.md#accountarticlereportgenerate) | **POST** /account/articles/export | Initiate a new Report
*ArticlesApi* | [**accountArticleUnpublish**](docs/Api/ArticlesApi.md#accountarticleunpublish) | **POST** /account/articles/{article_id}/unpublish | Public Article Unpublish
*ArticlesApi* | [**articleDetails**](docs/Api/ArticlesApi.md#articledetails) | **GET** /articles/{article_id} | View article details
*ArticlesApi* | [**articleFileDetails**](docs/Api/ArticlesApi.md#articlefiledetails) | **GET** /articles/{article_id}/files/{file_id} | Article file details
*ArticlesApi* | [**articleFiles**](docs/Api/ArticlesApi.md#articlefiles) | **GET** /articles/{article_id}/files | List article files
*ArticlesApi* | [**articleVersionConfidentiality**](docs/Api/ArticlesApi.md#articleversionconfidentiality) | **GET** /articles/{article_id}/versions/{version_id}/confidentiality | Public Article Confidentiality for article version
*ArticlesApi* | [**articleVersionDetails**](docs/Api/ArticlesApi.md#articleversiondetails) | **GET** /articles/{article_id}/versions/{version_id} | Article details for version
*ArticlesApi* | [**articleVersionEmbargo**](docs/Api/ArticlesApi.md#articleversionembargo) | **GET** /articles/{article_id}/versions/{version_id}/embargo | Public Article Embargo for article version
*ArticlesApi* | [**articleVersionFiles**](docs/Api/ArticlesApi.md#articleversionfiles) | **GET** /articles/{article_id}/versions/{version_id}/files | Public Article version files
*ArticlesApi* | [**articleVersionPartialUpdate**](docs/Api/ArticlesApi.md#articleversionpartialupdate) | **PATCH** /account/articles/{article_id}/versions/{version_id} | Partially update article version
*ArticlesApi* | [**articleVersionUpdate**](docs/Api/ArticlesApi.md#articleversionupdate) | **PUT** /account/articles/{article_id}/versions/{version_id} | Update article version
*ArticlesApi* | [**articleVersionUpdateThumb**](docs/Api/ArticlesApi.md#articleversionupdatethumb) | **PUT** /account/articles/{article_id}/versions/{version_id}/update_thumb | Update article version thumbnail
*ArticlesApi* | [**articleVersions**](docs/Api/ArticlesApi.md#articleversions) | **GET** /articles/{article_id}/versions | List article versions
*ArticlesApi* | [**articlesList**](docs/Api/ArticlesApi.md#articleslist) | **GET** /articles | Public Articles
*ArticlesApi* | [**articlesSearch**](docs/Api/ArticlesApi.md#articlessearch) | **POST** /articles/search | Public Articles Search
*ArticlesApi* | [**privateArticleAuthorDelete**](docs/Api/ArticlesApi.md#privatearticleauthordelete) | **DELETE** /account/articles/{article_id}/authors/{author_id} | Delete article author
*ArticlesApi* | [**privateArticleAuthorsAdd**](docs/Api/ArticlesApi.md#privatearticleauthorsadd) | **POST** /account/articles/{article_id}/authors | Add article authors
*ArticlesApi* | [**privateArticleAuthorsList**](docs/Api/ArticlesApi.md#privatearticleauthorslist) | **GET** /account/articles/{article_id}/authors | List article authors
*ArticlesApi* | [**privateArticleAuthorsReplace**](docs/Api/ArticlesApi.md#privatearticleauthorsreplace) | **PUT** /account/articles/{article_id}/authors | Replace article authors
*ArticlesApi* | [**privateArticleCategoriesAdd**](docs/Api/ArticlesApi.md#privatearticlecategoriesadd) | **POST** /account/articles/{article_id}/categories | Add article categories
*ArticlesApi* | [**privateArticleCategoriesList**](docs/Api/ArticlesApi.md#privatearticlecategorieslist) | **GET** /account/articles/{article_id}/categories | List article categories
*ArticlesApi* | [**privateArticleCategoriesReplace**](docs/Api/ArticlesApi.md#privatearticlecategoriesreplace) | **PUT** /account/articles/{article_id}/categories | Replace article categories
*ArticlesApi* | [**privateArticleCategoryDelete**](docs/Api/ArticlesApi.md#privatearticlecategorydelete) | **DELETE** /account/articles/{article_id}/categories/{category_id} | Delete article category
*ArticlesApi* | [**privateArticleConfidentialityDelete**](docs/Api/ArticlesApi.md#privatearticleconfidentialitydelete) | **DELETE** /account/articles/{article_id}/confidentiality | Delete article confidentiality
*ArticlesApi* | [**privateArticleConfidentialityDetails**](docs/Api/ArticlesApi.md#privatearticleconfidentialitydetails) | **GET** /account/articles/{article_id}/confidentiality | Article confidentiality details
*ArticlesApi* | [**privateArticleConfidentialityUpdate**](docs/Api/ArticlesApi.md#privatearticleconfidentialityupdate) | **PUT** /account/articles/{article_id}/confidentiality | Update article confidentiality
*ArticlesApi* | [**privateArticleCreate**](docs/Api/ArticlesApi.md#privatearticlecreate) | **POST** /account/articles | Create new Article
*ArticlesApi* | [**privateArticleDelete**](docs/Api/ArticlesApi.md#privatearticledelete) | **DELETE** /account/articles/{article_id} | Delete article
*ArticlesApi* | [**privateArticleDetails**](docs/Api/ArticlesApi.md#privatearticledetails) | **GET** /account/articles/{article_id} | Article details
*ArticlesApi* | [**privateArticleDownload**](docs/Api/ArticlesApi.md#privatearticledownload) | **GET** /account/articles/{article_id}/download | Private Article Download
*ArticlesApi* | [**privateArticleEmbargoDelete**](docs/Api/ArticlesApi.md#privatearticleembargodelete) | **DELETE** /account/articles/{article_id}/embargo | Delete Article Embargo
*ArticlesApi* | [**privateArticleEmbargoDetails**](docs/Api/ArticlesApi.md#privatearticleembargodetails) | **GET** /account/articles/{article_id}/embargo | Article Embargo Details
*ArticlesApi* | [**privateArticleEmbargoUpdate**](docs/Api/ArticlesApi.md#privatearticleembargoupdate) | **PUT** /account/articles/{article_id}/embargo | Update Article Embargo
*ArticlesApi* | [**privateArticleFile**](docs/Api/ArticlesApi.md#privatearticlefile) | **GET** /account/articles/{article_id}/files/{file_id} | Single File
*ArticlesApi* | [**privateArticleFileDelete**](docs/Api/ArticlesApi.md#privatearticlefiledelete) | **DELETE** /account/articles/{article_id}/files/{file_id} | File Delete
*ArticlesApi* | [**privateArticleFilesList**](docs/Api/ArticlesApi.md#privatearticlefileslist) | **GET** /account/articles/{article_id}/files | List article files
*ArticlesApi* | [**privateArticlePartialUpdate**](docs/Api/ArticlesApi.md#privatearticlepartialupdate) | **PATCH** /account/articles/{article_id} | Partially update article
*ArticlesApi* | [**privateArticlePrivateLink**](docs/Api/ArticlesApi.md#privatearticleprivatelink) | **GET** /account/articles/{article_id}/private_links | List private links
*ArticlesApi* | [**privateArticlePrivateLinkCreate**](docs/Api/ArticlesApi.md#privatearticleprivatelinkcreate) | **POST** /account/articles/{article_id}/private_links | Create private link
*ArticlesApi* | [**privateArticlePrivateLinkDelete**](docs/Api/ArticlesApi.md#privatearticleprivatelinkdelete) | **DELETE** /account/articles/{article_id}/private_links/{link_id} | Disable private link
*ArticlesApi* | [**privateArticlePrivateLinkUpdate**](docs/Api/ArticlesApi.md#privatearticleprivatelinkupdate) | **PUT** /account/articles/{article_id}/private_links/{link_id} | Update private link
*ArticlesApi* | [**privateArticleReserveDoi**](docs/Api/ArticlesApi.md#privatearticlereservedoi) | **POST** /account/articles/{article_id}/reserve_doi | Private Article Reserve DOI
*ArticlesApi* | [**privateArticleReserveHandle**](docs/Api/ArticlesApi.md#privatearticlereservehandle) | **POST** /account/articles/{article_id}/reserve_handle | Private Article Reserve Handle
*ArticlesApi* | [**privateArticleResource**](docs/Api/ArticlesApi.md#privatearticleresource) | **POST** /account/articles/{article_id}/resource | Private Article Resource
*ArticlesApi* | [**privateArticleUpdate**](docs/Api/ArticlesApi.md#privatearticleupdate) | **PUT** /account/articles/{article_id} | Update article
*ArticlesApi* | [**privateArticleUploadComplete**](docs/Api/ArticlesApi.md#privatearticleuploadcomplete) | **POST** /account/articles/{article_id}/files/{file_id} | Complete Upload
*ArticlesApi* | [**privateArticleUploadInitiate**](docs/Api/ArticlesApi.md#privatearticleuploadinitiate) | **POST** /account/articles/{article_id}/files | Initiate Upload
*ArticlesApi* | [**privateArticlesList**](docs/Api/ArticlesApi.md#privatearticleslist) | **GET** /account/articles | Private Articles
*ArticlesApi* | [**privateArticlesSearch**](docs/Api/ArticlesApi.md#privatearticlessearch) | **POST** /account/articles/search | Private Articles search
*ArticlesApi* | [**publicArticleDownload**](docs/Api/ArticlesApi.md#publicarticledownload) | **GET** /articles/{article_id}/download | Public Article Download
*ArticlesApi* | [**publicArticleVersionDownload**](docs/Api/ArticlesApi.md#publicarticleversiondownload) | **GET** /articles/{article_id}/versions/{version_id}/download | Public Article Version Download
*AuthorsApi* | [**privateAuthorDetails**](docs/Api/AuthorsApi.md#privateauthordetails) | **GET** /account/authors/{author_id} | Author details
*AuthorsApi* | [**privateAuthorsSearch**](docs/Api/AuthorsApi.md#privateauthorssearch) | **POST** /account/authors/search | Search Authors
*CollectionsApi* | [**collectionArticles**](docs/Api/CollectionsApi.md#collectionarticles) | **GET** /collections/{collection_id}/articles | Public Collection Articles
*CollectionsApi* | [**collectionDetails**](docs/Api/CollectionsApi.md#collectiondetails) | **GET** /collections/{collection_id} | Collection details
*CollectionsApi* | [**collectionVersionDetails**](docs/Api/CollectionsApi.md#collectionversiondetails) | **GET** /collections/{collection_id}/versions/{version_id} | Collection Version details
*CollectionsApi* | [**collectionVersions**](docs/Api/CollectionsApi.md#collectionversions) | **GET** /collections/{collection_id}/versions | Collection Versions list
*CollectionsApi* | [**collectionsList**](docs/Api/CollectionsApi.md#collectionslist) | **GET** /collections | Public Collections
*CollectionsApi* | [**collectionsSearch**](docs/Api/CollectionsApi.md#collectionssearch) | **POST** /collections/search | Public Collections Search
*CollectionsApi* | [**privateCollectionArticleDelete**](docs/Api/CollectionsApi.md#privatecollectionarticledelete) | **DELETE** /account/collections/{collection_id}/articles/{article_id} | Delete collection article
*CollectionsApi* | [**privateCollectionArticlesAdd**](docs/Api/CollectionsApi.md#privatecollectionarticlesadd) | **POST** /account/collections/{collection_id}/articles | Add collection articles
*CollectionsApi* | [**privateCollectionArticlesList**](docs/Api/CollectionsApi.md#privatecollectionarticleslist) | **GET** /account/collections/{collection_id}/articles | List collection articles
*CollectionsApi* | [**privateCollectionArticlesReplace**](docs/Api/CollectionsApi.md#privatecollectionarticlesreplace) | **PUT** /account/collections/{collection_id}/articles | Replace collection articles
*CollectionsApi* | [**privateCollectionAuthorDelete**](docs/Api/CollectionsApi.md#privatecollectionauthordelete) | **DELETE** /account/collections/{collection_id}/authors/{author_id} | Delete collection author
*CollectionsApi* | [**privateCollectionAuthorsAdd**](docs/Api/CollectionsApi.md#privatecollectionauthorsadd) | **POST** /account/collections/{collection_id}/authors | Add collection authors
*CollectionsApi* | [**privateCollectionAuthorsList**](docs/Api/CollectionsApi.md#privatecollectionauthorslist) | **GET** /account/collections/{collection_id}/authors | List collection authors
*CollectionsApi* | [**privateCollectionAuthorsReplace**](docs/Api/CollectionsApi.md#privatecollectionauthorsreplace) | **PUT** /account/collections/{collection_id}/authors | Replace collection authors
*CollectionsApi* | [**privateCollectionCategoriesAdd**](docs/Api/CollectionsApi.md#privatecollectioncategoriesadd) | **POST** /account/collections/{collection_id}/categories | Add collection categories
*CollectionsApi* | [**privateCollectionCategoriesList**](docs/Api/CollectionsApi.md#privatecollectioncategorieslist) | **GET** /account/collections/{collection_id}/categories | List collection categories
*CollectionsApi* | [**privateCollectionCategoriesReplace**](docs/Api/CollectionsApi.md#privatecollectioncategoriesreplace) | **PUT** /account/collections/{collection_id}/categories | Replace collection categories
*CollectionsApi* | [**privateCollectionCategoryDelete**](docs/Api/CollectionsApi.md#privatecollectioncategorydelete) | **DELETE** /account/collections/{collection_id}/categories/{category_id} | Delete collection category
*CollectionsApi* | [**privateCollectionCreate**](docs/Api/CollectionsApi.md#privatecollectioncreate) | **POST** /account/collections | Create collection
*CollectionsApi* | [**privateCollectionDelete**](docs/Api/CollectionsApi.md#privatecollectiondelete) | **DELETE** /account/collections/{collection_id} | Delete collection
*CollectionsApi* | [**privateCollectionDetails**](docs/Api/CollectionsApi.md#privatecollectiondetails) | **GET** /account/collections/{collection_id} | Collection details
*CollectionsApi* | [**privateCollectionPatch**](docs/Api/CollectionsApi.md#privatecollectionpatch) | **PATCH** /account/collections/{collection_id} | Partially update collection
*CollectionsApi* | [**privateCollectionPrivateLinkCreate**](docs/Api/CollectionsApi.md#privatecollectionprivatelinkcreate) | **POST** /account/collections/{collection_id}/private_links | Create collection private link
*CollectionsApi* | [**privateCollectionPrivateLinkDelete**](docs/Api/CollectionsApi.md#privatecollectionprivatelinkdelete) | **DELETE** /account/collections/{collection_id}/private_links/{link_id} | Disable private link
*CollectionsApi* | [**privateCollectionPrivateLinkDetails**](docs/Api/CollectionsApi.md#privatecollectionprivatelinkdetails) | **GET** /account/collections/{collection_id}/private_links/{link_id} | View collection private link
*CollectionsApi* | [**privateCollectionPrivateLinkUpdate**](docs/Api/CollectionsApi.md#privatecollectionprivatelinkupdate) | **PUT** /account/collections/{collection_id}/private_links/{link_id} | Update collection private link
*CollectionsApi* | [**privateCollectionPrivateLinksList**](docs/Api/CollectionsApi.md#privatecollectionprivatelinkslist) | **GET** /account/collections/{collection_id}/private_links | List collection private links
*CollectionsApi* | [**privateCollectionPublish**](docs/Api/CollectionsApi.md#privatecollectionpublish) | **POST** /account/collections/{collection_id}/publish | Private Collection Publish
*CollectionsApi* | [**privateCollectionReserveDoi**](docs/Api/CollectionsApi.md#privatecollectionreservedoi) | **POST** /account/collections/{collection_id}/reserve_doi | Private Collection Reserve DOI
*CollectionsApi* | [**privateCollectionReserveHandle**](docs/Api/CollectionsApi.md#privatecollectionreservehandle) | **POST** /account/collections/{collection_id}/reserve_handle | Private Collection Reserve Handle
*CollectionsApi* | [**privateCollectionResource**](docs/Api/CollectionsApi.md#privatecollectionresource) | **POST** /account/collections/{collection_id}/resource | Private Collection Resource
*CollectionsApi* | [**privateCollectionUpdate**](docs/Api/CollectionsApi.md#privatecollectionupdate) | **PUT** /account/collections/{collection_id} | Update collection
*CollectionsApi* | [**privateCollectionsList**](docs/Api/CollectionsApi.md#privatecollectionslist) | **GET** /account/collections | Private Collections List
*CollectionsApi* | [**privateCollectionsSearch**](docs/Api/CollectionsApi.md#privatecollectionssearch) | **POST** /account/collections/search | Private Collections Search
*InstitutionsApi* | [**accountInstitutionCuration**](docs/Api/InstitutionsApi.md#accountinstitutioncuration) | **GET** /account/institution/review/{curation_id} | Institution Curation Review
*InstitutionsApi* | [**accountInstitutionCurations**](docs/Api/InstitutionsApi.md#accountinstitutioncurations) | **GET** /account/institution/reviews | Institution Curation Reviews
*InstitutionsApi* | [**customFieldsList**](docs/Api/InstitutionsApi.md#customfieldslist) | **GET** /account/institution/custom_fields | Private account institution group custom fields
*InstitutionsApi* | [**customFieldsUpload**](docs/Api/InstitutionsApi.md#customfieldsupload) | **POST** /account/institution/custom_fields/{custom_field_id}/items/upload | Custom fields values files upload
*InstitutionsApi* | [**getAccountInstitutionCurationComments**](docs/Api/InstitutionsApi.md#getaccountinstitutioncurationcomments) | **GET** /account/institution/review/{curation_id}/comments | Institution Curation Review Comments
*InstitutionsApi* | [**institutionArticles**](docs/Api/InstitutionsApi.md#institutionarticles) | **GET** /institutions/{institution_string_id}/articles/filter-by | Public Institution Articles
*InstitutionsApi* | [**institutionHrfeedUpload**](docs/Api/InstitutionsApi.md#institutionhrfeedupload) | **POST** /institution/hrfeed/upload | Private Institution HRfeed Upload
*InstitutionsApi* | [**postAccountInstitutionCurationComments**](docs/Api/InstitutionsApi.md#postaccountinstitutioncurationcomments) | **POST** /account/institution/review/{curation_id}/comments | POST Institution Curation Review Comment
*InstitutionsApi* | [**privateAccountInstitutionUser**](docs/Api/InstitutionsApi.md#privateaccountinstitutionuser) | **GET** /account/institution/users/{account_id} | Private Account Institution User
*InstitutionsApi* | [**privateCategoriesList**](docs/Api/InstitutionsApi.md#privatecategorieslist) | **GET** /account/categories | Private Account Categories
*InstitutionsApi* | [**privateGroupEmbargoOptionsDetails**](docs/Api/InstitutionsApi.md#privategroupembargooptionsdetails) | **GET** /account/institution/groups/{group_id}/embargo_options | Private Account Institution Group Embargo Options
*InstitutionsApi* | [**privateInstitutionAccount**](docs/Api/InstitutionsApi.md#privateinstitutionaccount) | **GET** /account/institution/accounts/{account_id} | Private Institution Account information
*InstitutionsApi* | [**privateInstitutionAccountGroupRoleDelete**](docs/Api/InstitutionsApi.md#privateinstitutionaccountgrouproledelete) | **DELETE** /account/institution/roles/{account_id}/{group_id}/{role_id} | Delete Institution Account Group Role
*InstitutionsApi* | [**privateInstitutionAccountGroupRoles**](docs/Api/InstitutionsApi.md#privateinstitutionaccountgrouproles) | **GET** /account/institution/roles/{account_id} | List Institution Account Group Roles
*InstitutionsApi* | [**privateInstitutionAccountGroupRolesCreate**](docs/Api/InstitutionsApi.md#privateinstitutionaccountgrouprolescreate) | **POST** /account/institution/roles/{account_id} | Add Institution Account Group Roles
*InstitutionsApi* | [**privateInstitutionAccountsCreate**](docs/Api/InstitutionsApi.md#privateinstitutionaccountscreate) | **POST** /account/institution/accounts | Create new Institution Account
*InstitutionsApi* | [**privateInstitutionAccountsList**](docs/Api/InstitutionsApi.md#privateinstitutionaccountslist) | **GET** /account/institution/accounts | Private Account Institution Accounts
*InstitutionsApi* | [**privateInstitutionAccountsSearch**](docs/Api/InstitutionsApi.md#privateinstitutionaccountssearch) | **POST** /account/institution/accounts/search | Private Account Institution Accounts Search
*InstitutionsApi* | [**privateInstitutionAccountsUpdate**](docs/Api/InstitutionsApi.md#privateinstitutionaccountsupdate) | **PUT** /account/institution/accounts/{account_id} | Update Institution Account
*InstitutionsApi* | [**privateInstitutionArticles**](docs/Api/InstitutionsApi.md#privateinstitutionarticles) | **GET** /account/institution/articles | Private Institution Articles
*InstitutionsApi* | [**privateInstitutionDetails**](docs/Api/InstitutionsApi.md#privateinstitutiondetails) | **GET** /account/institution | Private Account Institutions
*InstitutionsApi* | [**privateInstitutionEmbargoOptionsDetails**](docs/Api/InstitutionsApi.md#privateinstitutionembargooptionsdetails) | **GET** /account/institution/embargo_options | Private Account Institution embargo options
*InstitutionsApi* | [**privateInstitutionGroupsList**](docs/Api/InstitutionsApi.md#privateinstitutiongroupslist) | **GET** /account/institution/groups | Private Account Institution Groups
*InstitutionsApi* | [**privateInstitutionRolesList**](docs/Api/InstitutionsApi.md#privateinstitutionroleslist) | **GET** /account/institution/roles | Private Account Institution Roles
*OauthApi* | [**createToken**](docs/Api/OauthApi.md#createtoken) | **POST** /token | Create OAuth token
*OauthApi* | [**getTokenInfo**](docs/Api/OauthApi.md#gettokeninfo) | **GET** /token | Get OAuth token information
*OtherApi* | [**categoriesList**](docs/Api/OtherApi.md#categorieslist) | **GET** /categories | Public Categories
*OtherApi* | [**fileDownload**](docs/Api/OtherApi.md#filedownload) | **GET** /file/download/{file_id} | Public File Download
*OtherApi* | [**itemTypesList**](docs/Api/OtherApi.md#itemtypeslist) | **GET** /item_types | Item Types
*OtherApi* | [**licensesList**](docs/Api/OtherApi.md#licenseslist) | **GET** /licenses | Public Licenses
*OtherApi* | [**privateAccount**](docs/Api/OtherApi.md#privateaccount) | **GET** /account | Private Account information
*OtherApi* | [**privateFundingSearch**](docs/Api/OtherApi.md#privatefundingsearch) | **POST** /account/funding/search | Search Funding
*OtherApi* | [**privateLicensesList**](docs/Api/OtherApi.md#privatelicenseslist) | **GET** /account/licenses | Private Account Licenses
*ProfilesApi* | [**updateUserProfile**](docs/Api/ProfilesApi.md#updateuserprofile) | **PUT** /account/profile | Update public profile
*ProfilesApi* | [**updateUserProfilePicture**](docs/Api/ProfilesApi.md#updateuserprofilepicture) | **POST** /account/profile/{user_id}/picture | Update public profile picture
*ProjectsApi* | [**privateProjectArticleDelete**](docs/Api/ProjectsApi.md#privateprojectarticledelete) | **DELETE** /account/projects/{project_id}/articles/{article_id} | Delete project article
*ProjectsApi* | [**privateProjectArticleDetails**](docs/Api/ProjectsApi.md#privateprojectarticledetails) | **GET** /account/projects/{project_id}/articles/{article_id} | Project article details
*ProjectsApi* | [**privateProjectArticleFile**](docs/Api/ProjectsApi.md#privateprojectarticlefile) | **GET** /account/projects/{project_id}/articles/{article_id}/files/{file_id} | Project article file details
*ProjectsApi* | [**privateProjectArticleFiles**](docs/Api/ProjectsApi.md#privateprojectarticlefiles) | **GET** /account/projects/{project_id}/articles/{article_id}/files | Project article list files
*ProjectsApi* | [**privateProjectArticlesCreate**](docs/Api/ProjectsApi.md#privateprojectarticlescreate) | **POST** /account/projects/{project_id}/articles | Create project article
*ProjectsApi* | [**privateProjectArticlesList**](docs/Api/ProjectsApi.md#privateprojectarticleslist) | **GET** /account/projects/{project_id}/articles | List project articles
*ProjectsApi* | [**privateProjectCollaboratorDelete**](docs/Api/ProjectsApi.md#privateprojectcollaboratordelete) | **DELETE** /account/projects/{project_id}/collaborators/{user_id} | Remove project collaborator
*ProjectsApi* | [**privateProjectCollaboratorsInvite**](docs/Api/ProjectsApi.md#privateprojectcollaboratorsinvite) | **POST** /account/projects/{project_id}/collaborators | Invite project collaborators
*ProjectsApi* | [**privateProjectCollaboratorsList**](docs/Api/ProjectsApi.md#privateprojectcollaboratorslist) | **GET** /account/projects/{project_id}/collaborators | List project collaborators
*ProjectsApi* | [**privateProjectCreate**](docs/Api/ProjectsApi.md#privateprojectcreate) | **POST** /account/projects | Create project
*ProjectsApi* | [**privateProjectDelete**](docs/Api/ProjectsApi.md#privateprojectdelete) | **DELETE** /account/projects/{project_id} | Delete project
*ProjectsApi* | [**privateProjectDetails**](docs/Api/ProjectsApi.md#privateprojectdetails) | **GET** /account/projects/{project_id} | View project details
*ProjectsApi* | [**privateProjectLeave**](docs/Api/ProjectsApi.md#privateprojectleave) | **POST** /account/projects/{project_id}/leave | Private Project Leave
*ProjectsApi* | [**privateProjectNote**](docs/Api/ProjectsApi.md#privateprojectnote) | **GET** /account/projects/{project_id}/notes/{note_id} | Project note details
*ProjectsApi* | [**privateProjectNoteDelete**](docs/Api/ProjectsApi.md#privateprojectnotedelete) | **DELETE** /account/projects/{project_id}/notes/{note_id} | Delete project note
*ProjectsApi* | [**privateProjectNoteUpdate**](docs/Api/ProjectsApi.md#privateprojectnoteupdate) | **PUT** /account/projects/{project_id}/notes/{note_id} | Update project note
*ProjectsApi* | [**privateProjectNotesCreate**](docs/Api/ProjectsApi.md#privateprojectnotescreate) | **POST** /account/projects/{project_id}/notes | Create project note
*ProjectsApi* | [**privateProjectNotesList**](docs/Api/ProjectsApi.md#privateprojectnoteslist) | **GET** /account/projects/{project_id}/notes | List project notes
*ProjectsApi* | [**privateProjectPartialUpdate**](docs/Api/ProjectsApi.md#privateprojectpartialupdate) | **PATCH** /account/projects/{project_id} | Partially update project
*ProjectsApi* | [**privateProjectPublish**](docs/Api/ProjectsApi.md#privateprojectpublish) | **POST** /account/projects/{project_id}/publish | Private Project Publish
*ProjectsApi* | [**privateProjectUpdate**](docs/Api/ProjectsApi.md#privateprojectupdate) | **PUT** /account/projects/{project_id} | Update project
*ProjectsApi* | [**privateProjectsList**](docs/Api/ProjectsApi.md#privateprojectslist) | **GET** /account/projects | Private Projects
*ProjectsApi* | [**privateProjectsSearch**](docs/Api/ProjectsApi.md#privateprojectssearch) | **POST** /account/projects/search | Private Projects search
*ProjectsApi* | [**projectArticles**](docs/Api/ProjectsApi.md#projectarticles) | **GET** /projects/{project_id}/articles | Public Project Articles
*ProjectsApi* | [**projectDetails**](docs/Api/ProjectsApi.md#projectdetails) | **GET** /projects/{project_id} | Public Project
*ProjectsApi* | [**projectsList**](docs/Api/ProjectsApi.md#projectslist) | **GET** /projects | Public Projects
*ProjectsApi* | [**projectsSearch**](docs/Api/ProjectsApi.md#projectssearch) | **POST** /projects/search | Public Projects Search

## Models

- [Account](docs/Model/Account.md)
- [AccountCreate](docs/Model/AccountCreate.md)
- [AccountCreateResponse](docs/Model/AccountCreateResponse.md)
- [AccountReport](docs/Model/AccountReport.md)
- [AccountUpdate](docs/Model/AccountUpdate.md)
- [Article](docs/Model/Article.md)
- [ArticleComplete](docs/Model/ArticleComplete.md)
- [ArticleCompletePrivate](docs/Model/ArticleCompletePrivate.md)
- [ArticleConfidentiality](docs/Model/ArticleConfidentiality.md)
- [ArticleCreate](docs/Model/ArticleCreate.md)
- [ArticleDOI](docs/Model/ArticleDOI.md)
- [ArticleEmbargo](docs/Model/ArticleEmbargo.md)
- [ArticleEmbargoUpdater](docs/Model/ArticleEmbargoUpdater.md)
- [ArticleHandle](docs/Model/ArticleHandle.md)
- [ArticleProjectCreate](docs/Model/ArticleProjectCreate.md)
- [ArticleSearch](docs/Model/ArticleSearch.md)
- [ArticleUnpublishData](docs/Model/ArticleUnpublishData.md)
- [ArticleUpdate](docs/Model/ArticleUpdate.md)
- [ArticleVersionUpdate](docs/Model/ArticleVersionUpdate.md)
- [ArticleVersions](docs/Model/ArticleVersions.md)
- [ArticleWithProject](docs/Model/ArticleWithProject.md)
- [ArticlesCreator](docs/Model/ArticlesCreator.md)
- [Author](docs/Model/Author.md)
- [AuthorComplete](docs/Model/AuthorComplete.md)
- [AuthorsCreator](docs/Model/AuthorsCreator.md)
- [CategoriesCreator](docs/Model/CategoriesCreator.md)
- [Category](docs/Model/Category.md)
- [CategoryList](docs/Model/CategoryList.md)
- [Collaborator](docs/Model/Collaborator.md)
- [Collection](docs/Model/Collection.md)
- [CollectionComplete](docs/Model/CollectionComplete.md)
- [CollectionCompletePrivate](docs/Model/CollectionCompletePrivate.md)
- [CollectionCreate](docs/Model/CollectionCreate.md)
- [CollectionDOI](docs/Model/CollectionDOI.md)
- [CollectionHandle](docs/Model/CollectionHandle.md)
- [CollectionPrivateLinkCreator](docs/Model/CollectionPrivateLinkCreator.md)
- [CollectionSearch](docs/Model/CollectionSearch.md)
- [CollectionUpdate](docs/Model/CollectionUpdate.md)
- [CollectionVersions](docs/Model/CollectionVersions.md)
- [CommonSearch](docs/Model/CommonSearch.md)
- [ConfidentialityCreator](docs/Model/ConfidentialityCreator.md)
- [CreateOAuthToken](docs/Model/CreateOAuthToken.md)
- [CreateProjectResponse](docs/Model/CreateProjectResponse.md)
- [Curation](docs/Model/Curation.md)
- [CurationComment](docs/Model/CurationComment.md)
- [CurationCommentCreate](docs/Model/CurationCommentCreate.md)
- [CurationDetail](docs/Model/CurationDetail.md)
- [CustomArticleField](docs/Model/CustomArticleField.md)
- [CustomArticleFieldAdd](docs/Model/CustomArticleFieldAdd.md)
- [ErrorMessage](docs/Model/ErrorMessage.md)
- [FileCreator](docs/Model/FileCreator.md)
- [FileId](docs/Model/FileId.md)
- [FundingCreate](docs/Model/FundingCreate.md)
- [FundingInformation](docs/Model/FundingInformation.md)
- [FundingSearch](docs/Model/FundingSearch.md)
- [Group](docs/Model/Group.md)
- [GroupEmbargoOptions](docs/Model/GroupEmbargoOptions.md)
- [Institution](docs/Model/Institution.md)
- [InstitutionAccountsSearch](docs/Model/InstitutionAccountsSearch.md)
- [ItemType](docs/Model/ItemType.md)
- [License](docs/Model/License.md)
- [Location](docs/Model/Location.md)
- [LocationWarnings](docs/Model/LocationWarnings.md)
- [LocationWarningsUpdate](docs/Model/LocationWarningsUpdate.md)
- [OAuthToken](docs/Model/OAuthToken.md)
- [PrivateArticleSearch](docs/Model/PrivateArticleSearch.md)
- [PrivateAuthorsSearch](docs/Model/PrivateAuthorsSearch.md)
- [PrivateCollectionSearch](docs/Model/PrivateCollectionSearch.md)
- [PrivateFile](docs/Model/PrivateFile.md)
- [PrivateLink](docs/Model/PrivateLink.md)
- [PrivateLinkCreator](docs/Model/PrivateLinkCreator.md)
- [PrivateLinkResponse](docs/Model/PrivateLinkResponse.md)
- [PrivateProjectArticle](docs/Model/PrivateProjectArticle.md)
- [ProfileUpdateData](docs/Model/ProfileUpdateData.md)
- [ProfileUpdateDataPersonalProfilesInner](docs/Model/ProfileUpdateDataPersonalProfilesInner.md)
- [Project](docs/Model/Project.md)
- [ProjectArticle](docs/Model/ProjectArticle.md)
- [ProjectCollaborator](docs/Model/ProjectCollaborator.md)
- [ProjectCollaboratorInvite](docs/Model/ProjectCollaboratorInvite.md)
- [ProjectComplete](docs/Model/ProjectComplete.md)
- [ProjectCompletePrivate](docs/Model/ProjectCompletePrivate.md)
- [ProjectCreate](docs/Model/ProjectCreate.md)
- [ProjectNote](docs/Model/ProjectNote.md)
- [ProjectNoteCreate](docs/Model/ProjectNoteCreate.md)
- [ProjectNotePrivate](docs/Model/ProjectNotePrivate.md)
- [ProjectPrivate](docs/Model/ProjectPrivate.md)
- [ProjectUpdate](docs/Model/ProjectUpdate.md)
- [ProjectsSearch](docs/Model/ProjectsSearch.md)
- [PublicFile](docs/Model/PublicFile.md)
- [RelatedMaterial](docs/Model/RelatedMaterial.md)
- [Resource](docs/Model/Resource.md)
- [ResponseMessage](docs/Model/ResponseMessage.md)
- [Role](docs/Model/Role.md)
- [ShortAccount](docs/Model/ShortAccount.md)
- [ShortCustomField](docs/Model/ShortCustomField.md)
- [Timeline](docs/Model/Timeline.md)
- [TimelineUpdate](docs/Model/TimelineUpdate.md)
- [UploadFilePart](docs/Model/UploadFilePart.md)
- [UploadInfo](docs/Model/UploadInfo.md)
- [User](docs/Model/User.md)

## Authorization

Authentication schemes defined for the API:
### OAuth2

- **Type**: `OAuth`
- **Flow**: `accessCode`
- **Authorization URL**: `https://figshare.com/account/applications/authorize`
- **Scopes**: 
    - **all**: Grants all access

## Tests

To run the tests, use:

```bash
composer install
vendor/bin/phpunit
```

## Author



## About this package

This PHP package is automatically generated by the [OpenAPI Generator](https://openapi-generator.tech) project:

- API version: `3.0.1`
    - Generator version: `7.9.0`
- Build package: `org.openapitools.codegen.languages.PhpClientCodegen`
