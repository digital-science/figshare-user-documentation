# OpenapiClient::ArticleVersions

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **version** | **Integer** | Version number |  |
| **url** | **String** | Api endpoint for the item version |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ArticleVersions.new(
  version: 1,
  url: https://api.figshare.com/v2/articles/2000005/versions/1
)
```

