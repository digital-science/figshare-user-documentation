# OpenapiClient::CurationComment

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | The ID of the comment. |  |
| **account_id** | **Integer** | The ID of the account which generated this comment. |  |
| **type** | **String** | The ID of the account which generated this comment. |  |
| **text** | **String** | The value/content of the comment. |  |
| **created_date** | **String** | The creation date of the comment. |  |
| **modified_date** | **String** | The date the comment has been modified. |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CurationComment.new(
  id: null,
  account_id: null,
  type: null,
  text: null,
  created_date: null,
  modified_date: null
)
```

