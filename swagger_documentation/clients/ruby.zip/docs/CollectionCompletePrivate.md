# OpenapiClient::CollectionCompletePrivate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **account_id** | **Integer** | ID of the account owning the collection |  |
| **funding** | [**Array&lt;FundingInformation&gt;**](FundingInformation.md) | Full Collection funding information |  |
| **resource_id** | **String** | Collection resource id |  |
| **resource_doi** | **String** | Collection resource doi |  |
| **resource_title** | **String** | Collection resource title |  |
| **resource_link** | **String** | Collection resource link |  |
| **resource_version** | **Integer** | Collection resource version |  |
| **version** | **Integer** | Collection version |  |
| **description** | **String** | Collection description |  |
| **categories** | [**Array&lt;Category&gt;**](Category.md) | List of collection categories |  |
| **references** | **Array&lt;String&gt;** | List of collection references |  |
| **related_materials** | [**Array&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] |
| **tags** | **Array&lt;String&gt;** | List of collection tags. Keywords can be used instead |  |
| **keywords** | **Array&lt;String&gt;** | List of collection keywords. Tags can be used instead |  |
| **authors** | [**Array&lt;Author&gt;**](Author.md) | List of collection authors |  |
| **institution_id** | **Integer** | Collection institution |  |
| **group_id** | **Integer** | Collection group |  |
| **articles_count** | **Integer** | Number of articles in collection |  |
| **public** | **Boolean** | True if collection is published |  |
| **citation** | **String** | Collection citation |  |
| **custom_fields** | [**Array&lt;CustomArticleField&gt;**](CustomArticleField.md) | Collection custom fields |  |
| **modified_date** | **String** | Date when collection was last modified |  |
| **created_date** | **String** | Date when collection was created |  |
| **timeline** | [**Timeline**](Timeline.md) |  |  |
| **id** | **Integer** | Collection id |  |
| **title** | **String** | Collection title |  |
| **doi** | **String** | Collection DOI |  |
| **handle** | **String** | Collection Handle |  |
| **url** | **String** | Api endpoint |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CollectionCompletePrivate.new(
  account_id: 1000001,
  funding: null,
  resource_id: ,
  resource_doi: 10.6084/m9.figshare.123,
  resource_title: test,
  resource_link: http://figshare.com,
  resource_version: 0,
  version: 1,
  description: description,
  categories: null,
  references: null,
  related_materials: [{&quot;id&quot;:10432,&quot;identifier&quot;:&quot;10.6084/m9.figshare.1407024&quot;,&quot;identifier_type&quot;:&quot;DOI&quot;,&quot;relation&quot;:&quot;IsSupplementTo&quot;,&quot;title&quot;:&quot;Figshare for institutions brochure&quot;,&quot;is_linkout&quot;:false}],
  tags: [&quot;t1&quot;,&quot;t2&quot;],
  keywords: [&quot;t1&quot;,&quot;t2&quot;],
  authors: null,
  institution_id: 1,
  group_id: 1,
  articles_count: 1,
  public: true,
  citation: citation,
  custom_fields: null,
  modified_date: 2017-05-15T15:12:26Z,
  created_date: 2017-05-15T15:12:26Z,
  timeline: null,
  id: 123,
  title: Sample collection,
  doi: 10.6084/m9.figshare.123,
  handle: 111184/figshare.1234,
  url: https://api.figshare.com/v2/collections/123
)
```

