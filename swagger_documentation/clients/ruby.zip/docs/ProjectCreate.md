# OpenapiClient::ProjectCreate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **title** | **String** | The title for this project - mandatory. 3 - 1000 characters. |  |
| **description** | **String** | Project description | [optional] |
| **funding** | **String** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional] |
| **funding_list** | [**Array&lt;FundingCreate&gt;**](FundingCreate.md) | Funding creation / update items | [optional] |
| **group_id** | **Integer** | Only if project type is group. | [optional] |
| **custom_fields** | **Object** | List of key, values pairs to be associated with the project | [optional] |
| **custom_fields_list** | [**Array&lt;CustomArticleFieldAdd&gt;**](CustomArticleFieldAdd.md) | List of custom fields values, supersedes custom_fields parameter | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ProjectCreate.new(
  title: project title,
  description: project description,
  funding: ,
  funding_list: null,
  group_id: 0,
  custom_fields: {&quot;defined_key&quot;:&quot;value for it&quot;},
  custom_fields_list: null
)
```

