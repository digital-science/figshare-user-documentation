# OpenapiClient::FundingCreate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | A funding ID as returned by the Funding Search endpoint | [optional] |
| **title** | **String** | The title of the new user created funding | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::FundingCreate.new(
  id: null,
  title: null
)
```

