# OpenapiClient::Article

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | Unique identifier for article |  |
| **title** | **String** | Title of article |  |
| **doi** | **String** | DOI |  |
| **handle** | **String** | Handle |  |
| **url** | **String** | Api endpoint for article |  |
| **url_public_html** | **String** | Public site endpoint for article |  |
| **url_public_api** | **String** | Public Api endpoint for article |  |
| **url_private_html** | **String** | Private site endpoint for article |  |
| **url_private_api** | **String** | Private Api endpoint for article |  |
| **timeline** | [**Timeline**](Timeline.md) |  |  |
| **thumb** | **String** | Thumbnail image |  |
| **defined_type** | **Integer** | Type of article identifier |  |
| **defined_type_name** | **String** | Name of the article type identifier |  |
| **resource_doi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to &#39;&#39;] |
| **resource_title** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to &#39;&#39;] |
| **created_date** | **String** | Date when article was created |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::Article.new(
  id: 1434614,
  title: Test article title,
  doi: 10.6084/m9.figshare.1434614,
  handle: 111184/figshare.1234,
  url: http://api.figshare.com/articles/1434614,
  url_public_html: https://figshare.com/articles/media/Test_article_title/1434614,
  url_public_api: https://api.figshare.com/articles/1434614,
  url_private_html: https://figshare.com/account/articles/1434614,
  url_private_api: https://api.figshare.com/account/articles/1434614,
  timeline: null,
  thumb: https://ndownloader.figshare.com/files/123456789/preview/12345678/thumb.png,
  defined_type: 3,
  defined_type_name: media,
  resource_doi: null,
  resource_title: null,
  created_date: 2017-05-18T11:49:03Z
)
```

