# OpenapiClient::SymplecticUserId200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **institution_user_id** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SymplecticUserId200Response.new(
  institution_user_id: null
)
```

