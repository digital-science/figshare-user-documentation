# OpenapiClient::AuthorsApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------ | ------------ | ----------- |
| [**private_author_details**](AuthorsApi.md#private_author_details) | **GET** /account/authors/{author_id} | Author details |
| [**private_authors_search**](AuthorsApi.md#private_authors_search) | **POST** /account/authors/search | Search Authors |


## private_author_details

> <AuthorComplete> private_author_details(author_id)

Author details

View author details

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::AuthorsApi.new
author_id = 789 # Integer | Author unique identifier

begin
  # Author details
  result = api_instance.private_author_details(author_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling AuthorsApi->private_author_details: #{e}"
end
```

#### Using the private_author_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<AuthorComplete>, Integer, Hash)> private_author_details_with_http_info(author_id)

```ruby
begin
  # Author details
  data, status_code, headers = api_instance.private_author_details_with_http_info(author_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <AuthorComplete>
rescue OpenapiClient::ApiError => e
  puts "Error when calling AuthorsApi->private_author_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **author_id** | **Integer** | Author unique identifier |  |

### Return type

[**AuthorComplete**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_authors_search

> <Array<AuthorComplete>> private_authors_search(opts)

Search Authors

Search for authors

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::AuthorsApi.new
opts = {
  search: OpenapiClient::PrivateAuthorsSearch.new # PrivateAuthorsSearch | Search Parameters
}

begin
  # Search Authors
  result = api_instance.private_authors_search(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling AuthorsApi->private_authors_search: #{e}"
end
```

#### Using the private_authors_search_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<AuthorComplete>>, Integer, Hash)> private_authors_search_with_http_info(opts)

```ruby
begin
  # Search Authors
  data, status_code, headers = api_instance.private_authors_search_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<AuthorComplete>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling AuthorsApi->private_authors_search_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **search** | [**PrivateAuthorsSearch**](PrivateAuthorsSearch.md) | Search Parameters | [optional] |

### Return type

[**Array&lt;AuthorComplete&gt;**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

