# OpenapiClient::CustomArticleField

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** | Custom  metadata name |  |
| **value** | **Object** | Custom metadata value (can be either a string or an array of strings) |  |
| **field_type** | **String** | Custom field type |  |
| **settings** | **Object** | Settings for the custom field |  |
| **order** | **Integer** | Order of the custom field |  |
| **is_mandatory** | **Boolean** | Whether the field is mandatory or not |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CustomArticleField.new(
  name: key,
  value: value,
  field_type: textarea,
  settings: {&quot;validations&quot;:{&quot;min_length&quot;:1,&quot;max_length&quot;:1000},&quot;placeholder&quot;:&quot;Enter your custom field here&quot;},
  order: 1,
  is_mandatory: false
)
```

