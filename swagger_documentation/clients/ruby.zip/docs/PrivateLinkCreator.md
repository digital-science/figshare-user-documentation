# OpenapiClient::PrivateLinkCreator

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **expires_date** | **String** | Date when this private link should expire - optional. By default private links expire in 365 days. | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::PrivateLinkCreator.new(
  expires_date: 2018-02-22 22:22:22
)
```

