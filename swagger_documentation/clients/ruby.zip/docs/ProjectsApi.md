# OpenapiClient::ProjectsApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
| ------ | ------------ | ----------- |
| [**private_project_article_delete**](ProjectsApi.md#private_project_article_delete) | **DELETE** /account/projects/{project_id}/articles/{article_id} | Delete project article |
| [**private_project_article_details**](ProjectsApi.md#private_project_article_details) | **GET** /account/projects/{project_id}/articles/{article_id} | Project article details |
| [**private_project_article_file**](ProjectsApi.md#private_project_article_file) | **GET** /account/projects/{project_id}/articles/{article_id}/files/{file_id} | Project article file details |
| [**private_project_article_files**](ProjectsApi.md#private_project_article_files) | **GET** /account/projects/{project_id}/articles/{article_id}/files | Project article list files |
| [**private_project_articles_create**](ProjectsApi.md#private_project_articles_create) | **POST** /account/projects/{project_id}/articles | Create project article |
| [**private_project_articles_list**](ProjectsApi.md#private_project_articles_list) | **GET** /account/projects/{project_id}/articles | List project articles |
| [**private_project_collaborator_delete**](ProjectsApi.md#private_project_collaborator_delete) | **DELETE** /account/projects/{project_id}/collaborators/{user_id} | Remove project collaborator |
| [**private_project_collaborators_invite**](ProjectsApi.md#private_project_collaborators_invite) | **POST** /account/projects/{project_id}/collaborators | Invite project collaborators |
| [**private_project_collaborators_list**](ProjectsApi.md#private_project_collaborators_list) | **GET** /account/projects/{project_id}/collaborators | List project collaborators |
| [**private_project_create**](ProjectsApi.md#private_project_create) | **POST** /account/projects | Create project |
| [**private_project_delete**](ProjectsApi.md#private_project_delete) | **DELETE** /account/projects/{project_id} | Delete project |
| [**private_project_details**](ProjectsApi.md#private_project_details) | **GET** /account/projects/{project_id} | View project details |
| [**private_project_leave**](ProjectsApi.md#private_project_leave) | **POST** /account/projects/{project_id}/leave | Private Project Leave |
| [**private_project_note**](ProjectsApi.md#private_project_note) | **GET** /account/projects/{project_id}/notes/{note_id} | Project note details |
| [**private_project_note_delete**](ProjectsApi.md#private_project_note_delete) | **DELETE** /account/projects/{project_id}/notes/{note_id} | Delete project note |
| [**private_project_note_update**](ProjectsApi.md#private_project_note_update) | **PUT** /account/projects/{project_id}/notes/{note_id} | Update project note |
| [**private_project_notes_create**](ProjectsApi.md#private_project_notes_create) | **POST** /account/projects/{project_id}/notes | Create project note |
| [**private_project_notes_list**](ProjectsApi.md#private_project_notes_list) | **GET** /account/projects/{project_id}/notes | List project notes |
| [**private_project_partial_update**](ProjectsApi.md#private_project_partial_update) | **PATCH** /account/projects/{project_id} | Partially update project |
| [**private_project_publish**](ProjectsApi.md#private_project_publish) | **POST** /account/projects/{project_id}/publish | Private Project Publish |
| [**private_project_update**](ProjectsApi.md#private_project_update) | **PUT** /account/projects/{project_id} | Update project |
| [**private_projects_list**](ProjectsApi.md#private_projects_list) | **GET** /account/projects | Private Projects |
| [**private_projects_search**](ProjectsApi.md#private_projects_search) | **POST** /account/projects/search | Private Projects search |
| [**project_articles**](ProjectsApi.md#project_articles) | **GET** /projects/{project_id}/articles | Public Project Articles |
| [**project_details**](ProjectsApi.md#project_details) | **GET** /projects/{project_id} | Public Project |
| [**projects_list**](ProjectsApi.md#projects_list) | **GET** /projects | Public Projects |
| [**projects_search**](ProjectsApi.md#projects_search) | **POST** /projects/search | Public Projects Search |


## private_project_article_delete

> private_project_article_delete(project_id, article_id)

Delete project article

Delete project article

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
article_id = 56 # Integer | Project Article unique identifier

begin
  # Delete project article
  api_instance.private_project_article_delete(project_id, article_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_article_delete: #{e}"
end
```

#### Using the private_project_article_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_project_article_delete_with_http_info(project_id, article_id)

```ruby
begin
  # Delete project article
  data, status_code, headers = api_instance.private_project_article_delete_with_http_info(project_id, article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_article_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **article_id** | **Integer** | Project Article unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_article_details

> <ArticleCompletePrivate> private_project_article_details(project_id, article_id)

Project article details

Project article details

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
article_id = 56 # Integer | Project Article unique identifier

begin
  # Project article details
  result = api_instance.private_project_article_details(project_id, article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_article_details: #{e}"
end
```

#### Using the private_project_article_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ArticleCompletePrivate>, Integer, Hash)> private_project_article_details_with_http_info(project_id, article_id)

```ruby
begin
  # Project article details
  data, status_code, headers = api_instance.private_project_article_details_with_http_info(project_id, article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ArticleCompletePrivate>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_article_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **article_id** | **Integer** | Project Article unique identifier |  |

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_article_file

> <PrivateFile> private_project_article_file(project_id, article_id, file_id)

Project article file details

Project article file details

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
article_id = 56 # Integer | Project Article unique identifier
file_id = 56 # Integer | File unique identifier

begin
  # Project article file details
  result = api_instance.private_project_article_file(project_id, article_id, file_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_article_file: #{e}"
end
```

#### Using the private_project_article_file_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<PrivateFile>, Integer, Hash)> private_project_article_file_with_http_info(project_id, article_id, file_id)

```ruby
begin
  # Project article file details
  data, status_code, headers = api_instance.private_project_article_file_with_http_info(project_id, article_id, file_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <PrivateFile>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_article_file_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **article_id** | **Integer** | Project Article unique identifier |  |
| **file_id** | **Integer** | File unique identifier |  |

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_article_files

> <Array<PrivateFile>> private_project_article_files(project_id, article_id)

Project article list files

List article files

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
article_id = 56 # Integer | Project Article unique identifier

begin
  # Project article list files
  result = api_instance.private_project_article_files(project_id, article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_article_files: #{e}"
end
```

#### Using the private_project_article_files_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<PrivateFile>>, Integer, Hash)> private_project_article_files_with_http_info(project_id, article_id)

```ruby
begin
  # Project article list files
  data, status_code, headers = api_instance.private_project_article_files_with_http_info(project_id, article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<PrivateFile>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_article_files_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **article_id** | **Integer** | Project Article unique identifier |  |

### Return type

[**Array&lt;PrivateFile&gt;**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_articles_create

> <Location> private_project_articles_create(project_id, article)

Create project article

Create a new Article and associate it with this project

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
article = OpenapiClient::ArticleProjectCreate.new({title: 'Test article title'}) # ArticleProjectCreate | Article description

begin
  # Create project article
  result = api_instance.private_project_articles_create(project_id, article)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_articles_create: #{e}"
end
```

#### Using the private_project_articles_create_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Location>, Integer, Hash)> private_project_articles_create_with_http_info(project_id, article)

```ruby
begin
  # Create project article
  data, status_code, headers = api_instance.private_project_articles_create_with_http_info(project_id, article)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Location>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_articles_create_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **article** | [**ArticleProjectCreate**](ArticleProjectCreate.md) | Article description |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_project_articles_list

> <Array<Article>> private_project_articles_list(project_id)

List project articles

List project articles

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier

begin
  # List project articles
  result = api_instance.private_project_articles_list(project_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_articles_list: #{e}"
end
```

#### Using the private_project_articles_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Article>>, Integer, Hash)> private_project_articles_list_with_http_info(project_id)

```ruby
begin
  # List project articles
  data, status_code, headers = api_instance.private_project_articles_list_with_http_info(project_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Article>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_articles_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |

### Return type

[**Array&lt;Article&gt;**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_collaborator_delete

> private_project_collaborator_delete(project_id, user_id)

Remove project collaborator

Remove project collaborator

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
user_id = 56 # Integer | User unique identifier

begin
  # Remove project collaborator
  api_instance.private_project_collaborator_delete(project_id, user_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_collaborator_delete: #{e}"
end
```

#### Using the private_project_collaborator_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_project_collaborator_delete_with_http_info(project_id, user_id)

```ruby
begin
  # Remove project collaborator
  data, status_code, headers = api_instance.private_project_collaborator_delete_with_http_info(project_id, user_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_collaborator_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **user_id** | **Integer** | User unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_collaborators_invite

> <ResponseMessage> private_project_collaborators_invite(project_id, collaborator)

Invite project collaborators

Invite users to collaborate on project or view the project

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
collaborator = OpenapiClient::ProjectCollaboratorInvite.new({role_name: 'viewer'}) # ProjectCollaboratorInvite | viewer or collaborator role. User user_id or email of user

begin
  # Invite project collaborators
  result = api_instance.private_project_collaborators_invite(project_id, collaborator)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_collaborators_invite: #{e}"
end
```

#### Using the private_project_collaborators_invite_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ResponseMessage>, Integer, Hash)> private_project_collaborators_invite_with_http_info(project_id, collaborator)

```ruby
begin
  # Invite project collaborators
  data, status_code, headers = api_instance.private_project_collaborators_invite_with_http_info(project_id, collaborator)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ResponseMessage>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_collaborators_invite_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **collaborator** | [**ProjectCollaboratorInvite**](ProjectCollaboratorInvite.md) | viewer or collaborator role. User user_id or email of user |  |

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_project_collaborators_list

> <Array<ProjectCollaborator>> private_project_collaborators_list(project_id)

List project collaborators

List Project collaborators and invited users

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier

begin
  # List project collaborators
  result = api_instance.private_project_collaborators_list(project_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_collaborators_list: #{e}"
end
```

#### Using the private_project_collaborators_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<ProjectCollaborator>>, Integer, Hash)> private_project_collaborators_list_with_http_info(project_id)

```ruby
begin
  # List project collaborators
  data, status_code, headers = api_instance.private_project_collaborators_list_with_http_info(project_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<ProjectCollaborator>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_collaborators_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |

### Return type

[**Array&lt;ProjectCollaborator&gt;**](ProjectCollaborator.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_create

> <CreateProjectResponse> private_project_create(project)

Create project

Create a new project

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project = OpenapiClient::ProjectCreate.new({title: 'project title'}) # ProjectCreate | Project  description

begin
  # Create project
  result = api_instance.private_project_create(project)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_create: #{e}"
end
```

#### Using the private_project_create_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<CreateProjectResponse>, Integer, Hash)> private_project_create_with_http_info(project)

```ruby
begin
  # Create project
  data, status_code, headers = api_instance.private_project_create_with_http_info(project)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <CreateProjectResponse>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_create_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project** | [**ProjectCreate**](ProjectCreate.md) | Project  description |  |

### Return type

[**CreateProjectResponse**](CreateProjectResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_project_delete

> private_project_delete(project_id)

Delete project

A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project. 

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier

begin
  # Delete project
  api_instance.private_project_delete(project_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_delete: #{e}"
end
```

#### Using the private_project_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_project_delete_with_http_info(project_id)

```ruby
begin
  # Delete project
  data, status_code, headers = api_instance.private_project_delete_with_http_info(project_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_details

> <ProjectCompletePrivate> private_project_details(project_id)

View project details

View a private project

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier

begin
  # View project details
  result = api_instance.private_project_details(project_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_details: #{e}"
end
```

#### Using the private_project_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ProjectCompletePrivate>, Integer, Hash)> private_project_details_with_http_info(project_id)

```ruby
begin
  # View project details
  data, status_code, headers = api_instance.private_project_details_with_http_info(project_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ProjectCompletePrivate>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |

### Return type

[**ProjectCompletePrivate**](ProjectCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_leave

> private_project_leave(project_id)

Private Project Leave

Please note: project's owner cannot leave the project.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier

begin
  # Private Project Leave
  api_instance.private_project_leave(project_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_leave: #{e}"
end
```

#### Using the private_project_leave_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_project_leave_with_http_info(project_id)

```ruby
begin
  # Private Project Leave
  data, status_code, headers = api_instance.private_project_leave_with_http_info(project_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_leave_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_note

> <ProjectNotePrivate> private_project_note(project_id, note_id)

Project note details

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
note_id = 56 # Integer | Note unique identifier

begin
  # Project note details
  result = api_instance.private_project_note(project_id, note_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_note: #{e}"
end
```

#### Using the private_project_note_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ProjectNotePrivate>, Integer, Hash)> private_project_note_with_http_info(project_id, note_id)

```ruby
begin
  # Project note details
  data, status_code, headers = api_instance.private_project_note_with_http_info(project_id, note_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ProjectNotePrivate>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_note_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **note_id** | **Integer** | Note unique identifier |  |

### Return type

[**ProjectNotePrivate**](ProjectNotePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_note_delete

> private_project_note_delete(project_id, note_id)

Delete project note

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
note_id = 56 # Integer | Note unique identifier

begin
  # Delete project note
  api_instance.private_project_note_delete(project_id, note_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_note_delete: #{e}"
end
```

#### Using the private_project_note_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_project_note_delete_with_http_info(project_id, note_id)

```ruby
begin
  # Delete project note
  data, status_code, headers = api_instance.private_project_note_delete_with_http_info(project_id, note_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_note_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **note_id** | **Integer** | Note unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_note_update

> private_project_note_update(project_id, note_id, note)

Update project note

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
note_id = 56 # Integer | Note unique identifier
note = OpenapiClient::ProjectNoteCreate.new({text: 'note to remember'}) # ProjectNoteCreate | Note message

begin
  # Update project note
  api_instance.private_project_note_update(project_id, note_id, note)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_note_update: #{e}"
end
```

#### Using the private_project_note_update_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_project_note_update_with_http_info(project_id, note_id, note)

```ruby
begin
  # Update project note
  data, status_code, headers = api_instance.private_project_note_update_with_http_info(project_id, note_id, note)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_note_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **note_id** | **Integer** | Note unique identifier |  |
| **note** | [**ProjectNoteCreate**](ProjectNoteCreate.md) | Note message |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_project_notes_create

> <Location> private_project_notes_create(project_id, note)

Create project note

Create a new project note

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
note = OpenapiClient::ProjectNoteCreate.new({text: 'note to remember'}) # ProjectNoteCreate | Note message

begin
  # Create project note
  result = api_instance.private_project_notes_create(project_id, note)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_notes_create: #{e}"
end
```

#### Using the private_project_notes_create_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Location>, Integer, Hash)> private_project_notes_create_with_http_info(project_id, note)

```ruby
begin
  # Create project note
  data, status_code, headers = api_instance.private_project_notes_create_with_http_info(project_id, note)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Location>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_notes_create_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **note** | [**ProjectNoteCreate**](ProjectNoteCreate.md) | Note message |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_project_notes_list

> <Array<ProjectNote>> private_project_notes_list(project_id, opts)

List project notes

List project notes

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
opts = {
  page: 56, # Integer | Page number. Used for pagination with page_size
  page_size: 56, # Integer | The number of results included on a page. Used for pagination with page
  limit: 56, # Integer | Number of results included on a page. Used for pagination with query
  offset: 56 # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
}

begin
  # List project notes
  result = api_instance.private_project_notes_list(project_id, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_notes_list: #{e}"
end
```

#### Using the private_project_notes_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<ProjectNote>>, Integer, Hash)> private_project_notes_list_with_http_info(project_id, opts)

```ruby
begin
  # List project notes
  data, status_code, headers = api_instance.private_project_notes_list_with_http_info(project_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<ProjectNote>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_notes_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**Array&lt;ProjectNote&gt;**](ProjectNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_partial_update

> private_project_partial_update(project_id, opts)

Partially update project

Partially update a project; only provided fields will be changed.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
opts = {
  project: OpenapiClient::ProjectUpdate.new # ProjectUpdate | Fields to update
}

begin
  # Partially update project
  api_instance.private_project_partial_update(project_id, opts)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_partial_update: #{e}"
end
```

#### Using the private_project_partial_update_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_project_partial_update_with_http_info(project_id, opts)

```ruby
begin
  # Partially update project
  data, status_code, headers = api_instance.private_project_partial_update_with_http_info(project_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_partial_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **project** | [**ProjectUpdate**](ProjectUpdate.md) | Fields to update | [optional] |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_project_publish

> <ResponseMessage> private_project_publish(project_id)

Private Project Publish

Publish a project. Possible after all items inside it are public

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier

begin
  # Private Project Publish
  result = api_instance.private_project_publish(project_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_publish: #{e}"
end
```

#### Using the private_project_publish_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ResponseMessage>, Integer, Hash)> private_project_publish_with_http_info(project_id)

```ruby
begin
  # Private Project Publish
  data, status_code, headers = api_instance.private_project_publish_with_http_info(project_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ResponseMessage>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_publish_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_project_update

> private_project_update(project_id, project)

Update project

Updating an project by passing body parameters.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project unique identifier
project = OpenapiClient::ProjectUpdate.new # ProjectUpdate | Project description

begin
  # Update project
  api_instance.private_project_update(project_id, project)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_update: #{e}"
end
```

#### Using the private_project_update_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_project_update_with_http_info(project_id, project)

```ruby
begin
  # Update project
  data, status_code, headers = api_instance.private_project_update_with_http_info(project_id, project)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_project_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project unique identifier |  |
| **project** | [**ProjectUpdate**](ProjectUpdate.md) | Project description |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_projects_list

> <Array<ProjectPrivate>> private_projects_list(opts)

Private Projects

List private projects

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProjectsApi.new
opts = {
  page: 56, # Integer | Page number. Used for pagination with page_size
  page_size: 56, # Integer | The number of results included on a page. Used for pagination with page
  limit: 56, # Integer | Number of results included on a page. Used for pagination with query
  offset: 56, # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
  order: 'published_date', # String | The field by which to order.
  order_direction: 'asc', # String | 
  storage: 'group', # String | only return collections from this institution
  roles: 'roles_example' # String | Any combination of owner, collaborator, viewer separated by comma. Examples: \"owner\" or \"owner,collaborator\".
}

begin
  # Private Projects
  result = api_instance.private_projects_list(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_projects_list: #{e}"
end
```

#### Using the private_projects_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<ProjectPrivate>>, Integer, Hash)> private_projects_list_with_http_info(opts)

```ruby
begin
  # Private Projects
  data, status_code, headers = api_instance.private_projects_list_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<ProjectPrivate>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_projects_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **String** | The field by which to order. | [optional][default to &#39;published_date&#39;] |
| **order_direction** | **String** |  | [optional][default to &#39;desc&#39;] |
| **storage** | **String** | only return collections from this institution | [optional] |
| **roles** | **String** | Any combination of owner, collaborator, viewer separated by comma. Examples: \&quot;owner\&quot; or \&quot;owner,collaborator\&quot;. | [optional] |

### Return type

[**Array&lt;ProjectPrivate&gt;**](ProjectPrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_projects_search

> <Array<ProjectPrivate>> private_projects_search(opts)

Private Projects search

Search inside the private projects

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ProjectsApi.new
opts = {
  search: OpenapiClient::ProjectsSearch.new # ProjectsSearch | Search Parameters
}

begin
  # Private Projects search
  result = api_instance.private_projects_search(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_projects_search: #{e}"
end
```

#### Using the private_projects_search_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<ProjectPrivate>>, Integer, Hash)> private_projects_search_with_http_info(opts)

```ruby
begin
  # Private Projects search
  data, status_code, headers = api_instance.private_projects_search_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<ProjectPrivate>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->private_projects_search_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **search** | [**ProjectsSearch**](ProjectsSearch.md) | Search Parameters | [optional] |

### Return type

[**Array&lt;ProjectPrivate&gt;**](ProjectPrivate.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## project_articles

> <Array<Article>> project_articles(project_id, opts)

Public Project Articles

List articles in project

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project Unique identifier
opts = {
  page: 56, # Integer | Page number. Used for pagination with page_size
  page_size: 56, # Integer | The number of results included on a page. Used for pagination with page
  limit: 56, # Integer | Number of results included on a page. Used for pagination with query
  offset: 56 # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
}

begin
  # Public Project Articles
  result = api_instance.project_articles(project_id, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->project_articles: #{e}"
end
```

#### Using the project_articles_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Article>>, Integer, Hash)> project_articles_with_http_info(project_id, opts)

```ruby
begin
  # Public Project Articles
  data, status_code, headers = api_instance.project_articles_with_http_info(project_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Article>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->project_articles_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project Unique identifier |  |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**Array&lt;Article&gt;**](Article.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## project_details

> <ProjectComplete> project_details(project_id)

Public Project

View a project

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ProjectsApi.new
project_id = 56 # Integer | Project Unique identifier

begin
  # Public Project
  result = api_instance.project_details(project_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->project_details: #{e}"
end
```

#### Using the project_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ProjectComplete>, Integer, Hash)> project_details_with_http_info(project_id)

```ruby
begin
  # Public Project
  data, status_code, headers = api_instance.project_details_with_http_info(project_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ProjectComplete>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->project_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **project_id** | **Integer** | Project Unique identifier |  |

### Return type

[**ProjectComplete**](ProjectComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## projects_list

> <Array<Project>> projects_list(opts)

Public Projects

Returns a list of public projects

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ProjectsApi.new
opts = {
  x_cursor: 'x_cursor_example', # String | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
  page: 56, # Integer | Page number. Used for pagination with page_size
  page_size: 56, # Integer | The number of results included on a page. Used for pagination with page
  limit: 56, # Integer | Number of results included on a page. Used for pagination with query
  offset: 56, # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
  order: 'published_date', # String | The field by which to order. Default varies by endpoint/resource.
  order_direction: 'asc', # String | 
  institution: 56, # Integer | only return collections from this institution
  published_since: 'published_since_example', # String | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD
  group: 56 # Integer | only return collections from this group
}

begin
  # Public Projects
  result = api_instance.projects_list(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->projects_list: #{e}"
end
```

#### Using the projects_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Project>>, Integer, Hash)> projects_list_with_http_info(opts)

```ruby
begin
  # Public Projects
  data, status_code, headers = api_instance.projects_list_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Project>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->projects_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **x_cursor** | **String** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **String** | The field by which to order. Default varies by endpoint/resource. | [optional][default to &#39;published_date&#39;] |
| **order_direction** | **String** |  | [optional][default to &#39;desc&#39;] |
| **institution** | **Integer** | only return collections from this institution | [optional] |
| **published_since** | **String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional] |
| **group** | **Integer** | only return collections from this group | [optional] |

### Return type

[**Array&lt;Project&gt;**](Project.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## projects_search

> <Array<Project>> projects_search(opts)

Public Projects Search

Returns a list of public articles

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ProjectsApi.new
opts = {
  x_cursor: 'x_cursor_example', # String | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
  search: OpenapiClient::ProjectsSearch.new # ProjectsSearch | Search Parameters
}

begin
  # Public Projects Search
  result = api_instance.projects_search(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->projects_search: #{e}"
end
```

#### Using the projects_search_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Project>>, Integer, Hash)> projects_search_with_http_info(opts)

```ruby
begin
  # Public Projects Search
  data, status_code, headers = api_instance.projects_search_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Project>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProjectsApi->projects_search_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **x_cursor** | **String** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **search** | [**ProjectsSearch**](ProjectsSearch.md) | Search Parameters | [optional] |

### Return type

[**Array&lt;Project&gt;**](Project.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

