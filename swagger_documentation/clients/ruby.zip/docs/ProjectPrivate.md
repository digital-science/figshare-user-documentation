# OpenapiClient::ProjectPrivate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **role** | **String** | Role inside this project |  |
| **storage** | **String** | Project storage type |  |
| **url** | **String** | Api endpoint |  |
| **id** | **Integer** | Project id |  |
| **title** | **String** | Project title |  |
| **created_date** | **String** | Date when project was created |  |
| **modified_date** | **String** | Date when project was last modified |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ProjectPrivate.new(
  role: Owner,
  storage: individual,
  url: http://api.figshare.com/v2/account/projects/1,
  id: 1,
  title: project,
  created_date: 2017-05-16T14:52:54Z,
  modified_date: 2017-05-16T14:52:54Z
)
```

