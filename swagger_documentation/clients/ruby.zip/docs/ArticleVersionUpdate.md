# OpenapiClient::ArticleVersionUpdate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **supplementary_fields** | **Array&lt;Object&gt;** | List of supplementary fields to be associated with the article version | [optional] |
| **internal_metadata** | **Object** | List of supplementary fields to be associated with the article version | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ArticleVersionUpdate.new(
  supplementary_fields: [{&quot;name&quot;:&quot;abc&quot;,&quot;value&quot;:&quot;def&quot;},{&quot;name&quot;:&quot;fname&quot;,&quot;value&quot;:&quot;fvalue&quot;}],
  internal_metadata: {&quot;curation_review_date&quot;:&quot;2021-11-16T13:03:38&quot;,&quot;export_pdf_download_url&quot;:null}
)
```

