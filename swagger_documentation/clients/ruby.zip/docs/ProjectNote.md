# SwaggerClient::ProjectNote

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Project note id | 
**user_id** | **Integer** | User who wrote the note | 
**abstract** | **String** | Note Abstract - short/truncated content | 
**user_name** | **String** | Username of the one who wrote the note | 
**created_date** | **String** | Date when note was created | 
**modified_date** | **String** | Date when note was last modified | 


