# OpenapiClient::UploadInfo

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **token** | **String** | token received after initializing a file upload | [optional] |
| **md5** | **String** | md5 provided on upload initialization | [optional] |
| **size** | **Integer** | size of file in bytes | [optional] |
| **name** | **String** | name of file on upload server | [optional] |
| **status** | **String** | Upload status | [optional] |
| **parts** | [**Array&lt;UploadFilePart&gt;**](UploadFilePart.md) | Uploads parts | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::UploadInfo.new(
  token: 693a2802-cd61-430d-b89f-507f0f6d8fd3,
  md5: 3a7f451c068f4e13260034c611378140,
  size: 70,
  name: 3000017/test.py,
  status: null,
  parts: null
)
```

