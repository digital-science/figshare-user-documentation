# OpenapiClient::ResponseMessage

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **message** | **String** | Response message text |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ResponseMessage.new(
  message: Project 1 has been published
)
```

