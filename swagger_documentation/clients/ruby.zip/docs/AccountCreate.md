# OpenapiClient::AccountCreate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **email** | **String** | Email of account |  |
| **first_name** | **String** | First Name | [optional][default to &#39;&#39;] |
| **last_name** | **String** | Last Name | [default to &#39;&#39;] |
| **group_id** | **Integer** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] |
| **institution_user_id** | **String** | Institution user id | [optional][default to &#39;&#39;] |
| **symplectic_user_id** | **String** | Symplectic user id | [optional][default to &#39;&#39;] |
| **quota** | **Integer** | Account quota | [optional] |
| **is_active** | **Boolean** | Is account active | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AccountCreate.new(
  email: johndoe@example.com,
  first_name: John,
  last_name: Doe,
  group_id: null,
  institution_user_id: johndoe,
  symplectic_user_id: johndoe,
  quota: 1000,
  is_active: null
)
```

