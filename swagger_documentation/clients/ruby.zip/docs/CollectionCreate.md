# OpenapiClient::CollectionCreate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **funding** | **String** | Grant number or funding authority | [optional][default to &#39;&#39;] |
| **funding_list** | [**Array&lt;FundingCreate&gt;**](FundingCreate.md) | Funding creation / update items | [optional] |
| **title** | **String** | Title of collection |  |
| **description** | **String** | The collection description. In a publisher case, usually this is the remote collection description | [optional][default to &#39;&#39;] |
| **articles** | **Array&lt;Integer&gt;** | List of articles to be associated with the collection | [optional] |
| **authors** | **Array&lt;Object&gt;** | List of authors to be associated with the collection. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint. | [optional] |
| **categories** | **Array&lt;Integer&gt;** | List of category ids to be associated with the collection(e.g [1, 23, 33, 66]) | [optional] |
| **categories_by_source_id** | **Array&lt;String&gt;** | List of category source ids to be associated with the collection, supersedes the categories property | [optional] |
| **tags** | **Array&lt;String&gt;** | List of tags to be associated with the collection. Keywords can be used instead | [optional] |
| **keywords** | **Array&lt;String&gt;** | List of tags to be associated with the collection. Tags can be used instead | [optional] |
| **references** | **Array&lt;String&gt;** | List of links to be associated with the collection (e.g [\&quot;http://link1\&quot;, \&quot;http://link2\&quot;, \&quot;http://link3\&quot;]) | [optional] |
| **related_materials** | [**Array&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] |
| **custom_fields** | **Object** | List of key, values pairs to be associated with the collection | [optional] |
| **custom_fields_list** | [**Array&lt;CustomArticleFieldAdd&gt;**](CustomArticleFieldAdd.md) | List of custom fields values, supersedes custom_fields parameter | [optional] |
| **doi** | **String** | Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional][default to &#39;&#39;] |
| **handle** | **String** | Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional][default to &#39;&#39;] |
| **resource_id** | **String** | Not applicable to regular users. In a publisher case, this is the publisher article id | [optional] |
| **resource_doi** | **String** | Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [optional][default to &#39;&#39;] |
| **resource_link** | **String** | Not applicable to regular users. In a publisher case, this is the publisher article link | [optional] |
| **resource_title** | **String** | Not applicable to regular users. In a publisher case, this is the publisher article title. | [optional][default to &#39;&#39;] |
| **resource_version** | **Integer** | Not applicable to regular users. In a publisher case, this is the publisher article version | [optional] |
| **group_id** | **Integer** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] |
| **timeline** | [**TimelineUpdate**](TimelineUpdate.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CollectionCreate.new(
  funding: null,
  funding_list: null,
  title: Test collection title,
  description: Test description of article,
  articles: [2000001,2000005],
  authors: [{&quot;name&quot;:&quot;John Doe&quot;},{&quot;id&quot;:20005}],
  categories: [1,10,11],
  categories_by_source_id: [&quot;300204&quot;,&quot;400207&quot;],
  tags: [&quot;tag1&quot;,&quot;tag2&quot;],
  keywords: [&quot;tag1&quot;,&quot;tag2&quot;],
  references: [&quot;http://figshare.com&quot;,&quot;http://api.figshare.com&quot;],
  related_materials: [{&quot;id&quot;:10432,&quot;identifier&quot;:&quot;10.6084/m9.figshare.1407024&quot;,&quot;identifier_type&quot;:&quot;DOI&quot;,&quot;relation&quot;:&quot;IsSupplementTo&quot;,&quot;title&quot;:&quot;Figshare for institutions brochure&quot;,&quot;is_linkout&quot;:false}],
  custom_fields: {&quot;defined_key&quot;:&quot;value for it&quot;},
  custom_fields_list: null,
  doi: null,
  handle: null,
  resource_id: null,
  resource_doi: null,
  resource_link: null,
  resource_title: null,
  resource_version: null,
  group_id: null,
  timeline: null
)
```

