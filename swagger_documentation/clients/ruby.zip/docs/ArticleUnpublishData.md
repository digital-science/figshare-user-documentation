# OpenapiClient::ArticleUnpublishData

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **reason** | **String** | Reason of article unpublishing |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ArticleUnpublishData.new(
  reason: Unpublish article reason
)
```

