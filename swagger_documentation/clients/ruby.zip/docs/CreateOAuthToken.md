# OpenapiClient::CreateOAuthToken

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **client_id** | **String** |  |  |
| **client_secret** | **String** |  |  |
| **grant_type** | **String** |  |  |
| **code** | **String** | Required if grant_type is &#39;authorization_code&#39; | [optional] |
| **refresh_token** | **String** | Required if grant_type is &#39;refresh_token&#39; | [optional] |
| **username** | **String** | Required if grant_type is &#39;password&#39; | [optional] |
| **password** | **String** | Required if grant_type is &#39;password&#39; | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CreateOAuthToken.new(
  client_id: null,
  client_secret: null,
  grant_type: null,
  code: null,
  refresh_token: null,
  username: null,
  password: null
)
```

