# OpenapiClient::PrivateLink

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **String** | Private link id |  |
| **is_active** | **Boolean** | True if private link is active |  |
| **expires_date** | **String** | Date when link will expire |  |
| **html_location** | **String** | HTML url for private link |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::PrivateLink.new(
  id: 0cfb0dbeac92df445df4aba45f63fdc85fa0b9a888b64e157ce3c93b576aa300fb3621ef3a219515dd482,
  is_active: true,
  expires_date: 2015-07-03T00:00:00,
  html_location: https://figshare.com/s/d5ec7a85bcd6dbe9d9b2
)
```

