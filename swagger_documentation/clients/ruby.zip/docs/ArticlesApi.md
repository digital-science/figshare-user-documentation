# OpenapiClient::ArticlesApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------ | ------------ | ----------- |
| [**account_article_publish**](ArticlesApi.md#account_article_publish) | **POST** /account/articles/{article_id}/publish | Private Article Publish |
| [**account_article_report**](ArticlesApi.md#account_article_report) | **GET** /account/articles/export | Account Article Report |
| [**account_article_report_generate**](ArticlesApi.md#account_article_report_generate) | **POST** /account/articles/export | Initiate a new Report |
| [**account_article_unpublish**](ArticlesApi.md#account_article_unpublish) | **POST** /account/articles/{article_id}/unpublish | Public Article Unpublish |
| [**article_details**](ArticlesApi.md#article_details) | **GET** /articles/{article_id} | View article details |
| [**article_file_details**](ArticlesApi.md#article_file_details) | **GET** /articles/{article_id}/files/{file_id} | Article file details |
| [**article_files**](ArticlesApi.md#article_files) | **GET** /articles/{article_id}/files | List article files |
| [**article_version_confidentiality**](ArticlesApi.md#article_version_confidentiality) | **GET** /articles/{article_id}/versions/{version_id}/confidentiality | Public Article Confidentiality for article version |
| [**article_version_details**](ArticlesApi.md#article_version_details) | **GET** /articles/{article_id}/versions/{version_id} | Article details for version |
| [**article_version_embargo**](ArticlesApi.md#article_version_embargo) | **GET** /articles/{article_id}/versions/{version_id}/embargo | Public Article Embargo for article version |
| [**article_version_files**](ArticlesApi.md#article_version_files) | **GET** /articles/{article_id}/versions/{version_id}/files | Public Article version files |
| [**article_version_partial_update**](ArticlesApi.md#article_version_partial_update) | **PATCH** /account/articles/{article_id}/versions/{version_id} | Partially update article version |
| [**article_version_update**](ArticlesApi.md#article_version_update) | **PUT** /account/articles/{article_id}/versions/{version_id} | Update article version |
| [**article_version_update_thumb**](ArticlesApi.md#article_version_update_thumb) | **PUT** /account/articles/{article_id}/versions/{version_id}/update_thumb | Update article version thumbnail |
| [**article_versions**](ArticlesApi.md#article_versions) | **GET** /articles/{article_id}/versions | List article versions |
| [**articles_list**](ArticlesApi.md#articles_list) | **GET** /articles | Public Articles |
| [**articles_search**](ArticlesApi.md#articles_search) | **POST** /articles/search | Public Articles Search |
| [**private_article_author_delete**](ArticlesApi.md#private_article_author_delete) | **DELETE** /account/articles/{article_id}/authors/{author_id} | Delete article author |
| [**private_article_authors_add**](ArticlesApi.md#private_article_authors_add) | **POST** /account/articles/{article_id}/authors | Add article authors |
| [**private_article_authors_list**](ArticlesApi.md#private_article_authors_list) | **GET** /account/articles/{article_id}/authors | List article authors |
| [**private_article_authors_replace**](ArticlesApi.md#private_article_authors_replace) | **PUT** /account/articles/{article_id}/authors | Replace article authors |
| [**private_article_categories_add**](ArticlesApi.md#private_article_categories_add) | **POST** /account/articles/{article_id}/categories | Add article categories |
| [**private_article_categories_list**](ArticlesApi.md#private_article_categories_list) | **GET** /account/articles/{article_id}/categories | List article categories |
| [**private_article_categories_replace**](ArticlesApi.md#private_article_categories_replace) | **PUT** /account/articles/{article_id}/categories | Replace article categories |
| [**private_article_category_delete**](ArticlesApi.md#private_article_category_delete) | **DELETE** /account/articles/{article_id}/categories/{category_id} | Delete article category |
| [**private_article_confidentiality_delete**](ArticlesApi.md#private_article_confidentiality_delete) | **DELETE** /account/articles/{article_id}/confidentiality | Delete article confidentiality |
| [**private_article_confidentiality_details**](ArticlesApi.md#private_article_confidentiality_details) | **GET** /account/articles/{article_id}/confidentiality | Article confidentiality details |
| [**private_article_confidentiality_update**](ArticlesApi.md#private_article_confidentiality_update) | **PUT** /account/articles/{article_id}/confidentiality | Update article confidentiality |
| [**private_article_create**](ArticlesApi.md#private_article_create) | **POST** /account/articles | Create new Article |
| [**private_article_delete**](ArticlesApi.md#private_article_delete) | **DELETE** /account/articles/{article_id} | Delete article |
| [**private_article_details**](ArticlesApi.md#private_article_details) | **GET** /account/articles/{article_id} | Article details |
| [**private_article_download**](ArticlesApi.md#private_article_download) | **GET** /account/articles/{article_id}/download | Private Article Download |
| [**private_article_embargo_delete**](ArticlesApi.md#private_article_embargo_delete) | **DELETE** /account/articles/{article_id}/embargo | Delete Article Embargo |
| [**private_article_embargo_details**](ArticlesApi.md#private_article_embargo_details) | **GET** /account/articles/{article_id}/embargo | Article Embargo Details |
| [**private_article_embargo_update**](ArticlesApi.md#private_article_embargo_update) | **PUT** /account/articles/{article_id}/embargo | Update Article Embargo |
| [**private_article_file**](ArticlesApi.md#private_article_file) | **GET** /account/articles/{article_id}/files/{file_id} | Single File |
| [**private_article_file_delete**](ArticlesApi.md#private_article_file_delete) | **DELETE** /account/articles/{article_id}/files/{file_id} | File Delete |
| [**private_article_files_list**](ArticlesApi.md#private_article_files_list) | **GET** /account/articles/{article_id}/files | List article files |
| [**private_article_partial_update**](ArticlesApi.md#private_article_partial_update) | **PATCH** /account/articles/{article_id} | Partially update article |
| [**private_article_private_link**](ArticlesApi.md#private_article_private_link) | **GET** /account/articles/{article_id}/private_links | List private links |
| [**private_article_private_link_create**](ArticlesApi.md#private_article_private_link_create) | **POST** /account/articles/{article_id}/private_links | Create private link |
| [**private_article_private_link_delete**](ArticlesApi.md#private_article_private_link_delete) | **DELETE** /account/articles/{article_id}/private_links/{link_id} | Disable private link |
| [**private_article_private_link_update**](ArticlesApi.md#private_article_private_link_update) | **PUT** /account/articles/{article_id}/private_links/{link_id} | Update private link |
| [**private_article_reserve_doi**](ArticlesApi.md#private_article_reserve_doi) | **POST** /account/articles/{article_id}/reserve_doi | Private Article Reserve DOI |
| [**private_article_reserve_handle**](ArticlesApi.md#private_article_reserve_handle) | **POST** /account/articles/{article_id}/reserve_handle | Private Article Reserve Handle |
| [**private_article_resource**](ArticlesApi.md#private_article_resource) | **POST** /account/articles/{article_id}/resource | Private Article Resource |
| [**private_article_update**](ArticlesApi.md#private_article_update) | **PUT** /account/articles/{article_id} | Update article |
| [**private_article_upload_complete**](ArticlesApi.md#private_article_upload_complete) | **POST** /account/articles/{article_id}/files/{file_id} | Complete Upload |
| [**private_article_upload_initiate**](ArticlesApi.md#private_article_upload_initiate) | **POST** /account/articles/{article_id}/files | Initiate Upload |
| [**private_articles_list**](ArticlesApi.md#private_articles_list) | **GET** /account/articles | Private Articles |
| [**private_articles_search**](ArticlesApi.md#private_articles_search) | **POST** /account/articles/search | Private Articles search |
| [**public_article_download**](ArticlesApi.md#public_article_download) | **GET** /articles/{article_id}/download | Public Article Download |
| [**public_article_version_download**](ArticlesApi.md#public_article_version_download) | **GET** /articles/{article_id}/versions/{version_id}/download | Public Article Version Download |


## account_article_publish

> <Location> account_article_publish(article_id)

Private Article Publish

- If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier

begin
  # Private Article Publish
  result = api_instance.account_article_publish(article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->account_article_publish: #{e}"
end
```

#### Using the account_article_publish_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Location>, Integer, Hash)> account_article_publish_with_http_info(article_id)

```ruby
begin
  # Private Article Publish
  data, status_code, headers = api_instance.account_article_publish_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Location>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->account_article_publish_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## account_article_report

> <Array<AccountReport>> account_article_report(opts)

Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
opts = {
  group_id: 789 # Integer | A group ID to filter by
}

begin
  # Account Article Report
  result = api_instance.account_article_report(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->account_article_report: #{e}"
end
```

#### Using the account_article_report_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<AccountReport>>, Integer, Hash)> account_article_report_with_http_info(opts)

```ruby
begin
  # Account Article Report
  data, status_code, headers = api_instance.account_article_report_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<AccountReport>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->account_article_report_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **group_id** | **Integer** | A group ID to filter by | [optional] |

### Return type

[**Array&lt;AccountReport&gt;**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## account_article_report_generate

> <AccountReport> account_article_report_generate

Initiate a new Report

Initiate a new Article Report for this Account. There is a limit of 1 report per day.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new

begin
  # Initiate a new Report
  result = api_instance.account_article_report_generate
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->account_article_report_generate: #{e}"
end
```

#### Using the account_article_report_generate_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<AccountReport>, Integer, Hash)> account_article_report_generate_with_http_info

```ruby
begin
  # Initiate a new Report
  data, status_code, headers = api_instance.account_article_report_generate_with_http_info
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <AccountReport>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->account_article_report_generate_with_http_info: #{e}"
end
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## account_article_unpublish

> account_article_unpublish(article_id, reason)

Public Article Unpublish

Allows authorized users to unpublish an article.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
reason = OpenapiClient::ArticleUnpublishData.new({reason: 'Unpublish article reason'}) # ArticleUnpublishData | Article unpublish data

begin
  # Public Article Unpublish
  api_instance.account_article_unpublish(article_id, reason)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->account_article_unpublish: #{e}"
end
```

#### Using the account_article_unpublish_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> account_article_unpublish_with_http_info(article_id, reason)

```ruby
begin
  # Public Article Unpublish
  data, status_code, headers = api_instance.account_article_unpublish_with_http_info(article_id, reason)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->account_article_unpublish_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **reason** | [**ArticleUnpublishData**](ArticleUnpublishData.md) | Article unpublish data |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## article_details

> <ArticleComplete> article_details(article_id)

View article details

View an article

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article Unique identifier

begin
  # View article details
  result = api_instance.article_details(article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_details: #{e}"
end
```

#### Using the article_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ArticleComplete>, Integer, Hash)> article_details_with_http_info(article_id)

```ruby
begin
  # View article details
  data, status_code, headers = api_instance.article_details_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ArticleComplete>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article Unique identifier |  |

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## article_file_details

> <PublicFile> article_file_details(article_id, file_id)

Article file details

File by id

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article Unique identifier
file_id = 789 # Integer | File Unique identifier

begin
  # Article file details
  result = api_instance.article_file_details(article_id, file_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_file_details: #{e}"
end
```

#### Using the article_file_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<PublicFile>, Integer, Hash)> article_file_details_with_http_info(article_id, file_id)

```ruby
begin
  # Article file details
  data, status_code, headers = api_instance.article_file_details_with_http_info(article_id, file_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <PublicFile>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_file_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article Unique identifier |  |
| **file_id** | **Integer** | File Unique identifier |  |

### Return type

[**PublicFile**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## article_files

> <Array<PublicFile>> article_files(article_id, opts)

List article files

Files list for article

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article Unique identifier
opts = {
  page: 789, # Integer | Page number. Used for pagination with page_size
  page_size: 789, # Integer | The number of results included on a page. Used for pagination with page
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789 # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
}

begin
  # List article files
  result = api_instance.article_files(article_id, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_files: #{e}"
end
```

#### Using the article_files_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<PublicFile>>, Integer, Hash)> article_files_with_http_info(article_id, opts)

```ruby
begin
  # List article files
  data, status_code, headers = api_instance.article_files_with_http_info(article_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<PublicFile>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_files_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article Unique identifier |  |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**Array&lt;PublicFile&gt;**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## article_version_confidentiality

> <ArticleConfidentiality> article_version_confidentiality(article_id, version_id)

Public Article Confidentiality for article version

Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article Unique identifier
version_id = 789 # Integer | Version Number

begin
  # Public Article Confidentiality for article version
  result = api_instance.article_version_confidentiality(article_id, version_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_confidentiality: #{e}"
end
```

#### Using the article_version_confidentiality_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ArticleConfidentiality>, Integer, Hash)> article_version_confidentiality_with_http_info(article_id, version_id)

```ruby
begin
  # Public Article Confidentiality for article version
  data, status_code, headers = api_instance.article_version_confidentiality_with_http_info(article_id, version_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ArticleConfidentiality>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_confidentiality_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article Unique identifier |  |
| **version_id** | **Integer** | Version Number |  |

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## article_version_details

> <ArticleComplete> article_version_details(article_id, version_id)

Article details for version

Article with specified version

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article Unique identifier
version_id = 789 # Integer | Article Version Number

begin
  # Article details for version
  result = api_instance.article_version_details(article_id, version_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_details: #{e}"
end
```

#### Using the article_version_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ArticleComplete>, Integer, Hash)> article_version_details_with_http_info(article_id, version_id)

```ruby
begin
  # Article details for version
  data, status_code, headers = api_instance.article_version_details_with_http_info(article_id, version_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ArticleComplete>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article Unique identifier |  |
| **version_id** | **Integer** | Article Version Number |  |

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## article_version_embargo

> <ArticleEmbargo> article_version_embargo(article_id, version_id)

Public Article Embargo for article version

Embargo for article version

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article Unique identifier
version_id = 789 # Integer | Version Number

begin
  # Public Article Embargo for article version
  result = api_instance.article_version_embargo(article_id, version_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_embargo: #{e}"
end
```

#### Using the article_version_embargo_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ArticleEmbargo>, Integer, Hash)> article_version_embargo_with_http_info(article_id, version_id)

```ruby
begin
  # Public Article Embargo for article version
  data, status_code, headers = api_instance.article_version_embargo_with_http_info(article_id, version_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ArticleEmbargo>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_embargo_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article Unique identifier |  |
| **version_id** | **Integer** | Version Number |  |

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## article_version_files

> <Array<PublicFile>> article_version_files(article_id, version_id, opts)

Public Article version files

Article version file details

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article Unique identifier
version_id = 789 # Integer | Article Version Unique identifier
opts = {
  page: 789, # Integer | Page number. Used for pagination with page_size
  page_size: 789, # Integer | The number of results included on a page. Used for pagination with page
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789 # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
}

begin
  # Public Article version files
  result = api_instance.article_version_files(article_id, version_id, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_files: #{e}"
end
```

#### Using the article_version_files_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<PublicFile>>, Integer, Hash)> article_version_files_with_http_info(article_id, version_id, opts)

```ruby
begin
  # Public Article version files
  data, status_code, headers = api_instance.article_version_files_with_http_info(article_id, version_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<PublicFile>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_files_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article Unique identifier |  |
| **version_id** | **Integer** | Article Version Unique identifier |  |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**Array&lt;PublicFile&gt;**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## article_version_partial_update

> <LocationWarningsUpdate> article_version_partial_update(article_id, version_id, article)

Partially update article version

Partially updating an article version by passing only the fields to change.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
version_id = 789 # Integer | Article version identifier
article = OpenapiClient::ArticleVersionUpdate.new # ArticleVersionUpdate | Subset of article version fields to update

begin
  # Partially update article version
  result = api_instance.article_version_partial_update(article_id, version_id, article)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_partial_update: #{e}"
end
```

#### Using the article_version_partial_update_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<LocationWarningsUpdate>, Integer, Hash)> article_version_partial_update_with_http_info(article_id, version_id, article)

```ruby
begin
  # Partially update article version
  data, status_code, headers = api_instance.article_version_partial_update_with_http_info(article_id, version_id, article)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <LocationWarningsUpdate>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_partial_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **version_id** | **Integer** | Article version identifier |  |
| **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md) | Subset of article version fields to update |  |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## article_version_update

> <LocationWarningsUpdate> article_version_update(article_id, version_id, article)

Update article version

Updating an article version by passing body parameters.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
version_id = 789 # Integer | Article version identifier
article = OpenapiClient::ArticleVersionUpdate.new # ArticleVersionUpdate | Article description

begin
  # Update article version
  result = api_instance.article_version_update(article_id, version_id, article)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_update: #{e}"
end
```

#### Using the article_version_update_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<LocationWarningsUpdate>, Integer, Hash)> article_version_update_with_http_info(article_id, version_id, article)

```ruby
begin
  # Update article version
  data, status_code, headers = api_instance.article_version_update_with_http_info(article_id, version_id, article)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <LocationWarningsUpdate>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **version_id** | **Integer** | Article version identifier |  |
| **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md) | Article description |  |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## article_version_update_thumb

> article_version_update_thumb(article_id, version_id, file_id)

Update article version thumbnail

For a given public article version update the article thumbnail by choosing one of the associated files

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
version_id = 789 # Integer | Article version identifier
file_id = OpenapiClient::FileId.new # FileId | File ID

begin
  # Update article version thumbnail
  api_instance.article_version_update_thumb(article_id, version_id, file_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_update_thumb: #{e}"
end
```

#### Using the article_version_update_thumb_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> article_version_update_thumb_with_http_info(article_id, version_id, file_id)

```ruby
begin
  # Update article version thumbnail
  data, status_code, headers = api_instance.article_version_update_thumb_with_http_info(article_id, version_id, file_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_version_update_thumb_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **version_id** | **Integer** | Article version identifier |  |
| **file_id** | [**FileId**](FileId.md) | File ID |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## article_versions

> <Array<ArticleVersions>> article_versions(article_id)

List article versions

List public article versions

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article Unique identifier

begin
  # List article versions
  result = api_instance.article_versions(article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_versions: #{e}"
end
```

#### Using the article_versions_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<ArticleVersions>>, Integer, Hash)> article_versions_with_http_info(article_id)

```ruby
begin
  # List article versions
  data, status_code, headers = api_instance.article_versions_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<ArticleVersions>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->article_versions_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article Unique identifier |  |

### Return type

[**Array&lt;ArticleVersions&gt;**](ArticleVersions.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## articles_list

> <Array<Article>> articles_list(opts)

Public Articles

Returns a list of public articles

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ArticlesApi.new
opts = {
  x_cursor: '38400000-8cf0-11bd-b23e-10b96e4ef00d', # String | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
  page: 789, # Integer | Page number. Used for pagination with page_size
  page_size: 789, # Integer | The number of results included on a page. Used for pagination with page
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789, # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
  order: 'published_date', # String | The field by which to order. Default varies by endpoint/resource.
  order_direction: 'asc', # String | 
  institution: 789, # Integer | only return articles from this institution
  published_since: 'published_since_example', # String | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
  modified_since: 'modified_since_example', # String | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
  group: 789, # Integer | only return articles from this group
  resource_doi: 'resource_doi_example', # String | Deprecated by related materials. Only return articles with this resource_doi
  item_type: 789, # Integer | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
  doi: 'doi_example', # String | only return articles with this doi
  handle: 'handle_example' # String | only return articles with this handle
}

begin
  # Public Articles
  result = api_instance.articles_list(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->articles_list: #{e}"
end
```

#### Using the articles_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Article>>, Integer, Hash)> articles_list_with_http_info(opts)

```ruby
begin
  # Public Articles
  data, status_code, headers = api_instance.articles_list_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Article>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->articles_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **x_cursor** | **String** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **String** | The field by which to order. Default varies by endpoint/resource. | [optional][default to &#39;published_date&#39;] |
| **order_direction** | **String** |  | [optional][default to &#39;desc&#39;] |
| **institution** | **Integer** | only return articles from this institution | [optional] |
| **published_since** | **String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **modified_since** | **String** | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **group** | **Integer** | only return articles from this group | [optional] |
| **resource_doi** | **String** | Deprecated by related materials. Only return articles with this resource_doi | [optional] |
| **item_type** | **Integer** | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] |
| **doi** | **String** | only return articles with this doi | [optional] |
| **handle** | **String** | only return articles with this handle | [optional] |

### Return type

[**Array&lt;Article&gt;**](Article.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## articles_search

> <Array<ArticleWithProject>> articles_search(opts)

Public Articles Search

Returns a list of public articles, filtered by the search parameters

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ArticlesApi.new
opts = {
  x_cursor: '38400000-8cf0-11bd-b23e-10b96e4ef00d', # String | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
  search: OpenapiClient::ArticleSearch.new # ArticleSearch | Search Parameters
}

begin
  # Public Articles Search
  result = api_instance.articles_search(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->articles_search: #{e}"
end
```

#### Using the articles_search_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<ArticleWithProject>>, Integer, Hash)> articles_search_with_http_info(opts)

```ruby
begin
  # Public Articles Search
  data, status_code, headers = api_instance.articles_search_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<ArticleWithProject>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->articles_search_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **x_cursor** | **String** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **search** | [**ArticleSearch**](ArticleSearch.md) | Search Parameters | [optional] |

### Return type

[**Array&lt;ArticleWithProject&gt;**](ArticleWithProject.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_author_delete

> private_article_author_delete(article_id, author_id)

Delete article author

De-associate author from article

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
author_id = 789 # Integer | Article Author unique identifier

begin
  # Delete article author
  api_instance.private_article_author_delete(article_id, author_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_author_delete: #{e}"
end
```

#### Using the private_article_author_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_author_delete_with_http_info(article_id, author_id)

```ruby
begin
  # Delete article author
  data, status_code, headers = api_instance.private_article_author_delete_with_http_info(article_id, author_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_author_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **author_id** | **Integer** | Article Author unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_authors_add

> private_article_authors_add(article_id, authors)

Add article authors

Associate new authors with the article. This will add new authors to the list of already associated authors

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
authors = OpenapiClient::AuthorsCreator.new({authors: [{"id": 12121}, {"id": 34345}, {"name": "John Doe"}]}) # AuthorsCreator | Authors description

begin
  # Add article authors
  api_instance.private_article_authors_add(article_id, authors)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_authors_add: #{e}"
end
```

#### Using the private_article_authors_add_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_authors_add_with_http_info(article_id, authors)

```ruby
begin
  # Add article authors
  data, status_code, headers = api_instance.private_article_authors_add_with_http_info(article_id, authors)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_authors_add_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **authors** | [**AuthorsCreator**](AuthorsCreator.md) | Authors description |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_authors_list

> <Array<Author>> private_article_authors_list(article_id)

List article authors

List article authors

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier

begin
  # List article authors
  result = api_instance.private_article_authors_list(article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_authors_list: #{e}"
end
```

#### Using the private_article_authors_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Author>>, Integer, Hash)> private_article_authors_list_with_http_info(article_id)

```ruby
begin
  # List article authors
  data, status_code, headers = api_instance.private_article_authors_list_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Author>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_authors_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |

### Return type

[**Array&lt;Author&gt;**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_authors_replace

> private_article_authors_replace(article_id, authors)

Replace article authors

Associate new authors with the article. This will remove all already associated authors and add these new ones

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
authors = OpenapiClient::AuthorsCreator.new({authors: [{"id": 12121}, {"id": 34345}, {"name": "John Doe"}]}) # AuthorsCreator | Authors description

begin
  # Replace article authors
  api_instance.private_article_authors_replace(article_id, authors)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_authors_replace: #{e}"
end
```

#### Using the private_article_authors_replace_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_authors_replace_with_http_info(article_id, authors)

```ruby
begin
  # Replace article authors
  data, status_code, headers = api_instance.private_article_authors_replace_with_http_info(article_id, authors)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_authors_replace_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **authors** | [**AuthorsCreator**](AuthorsCreator.md) | Authors description |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_categories_add

> private_article_categories_add(article_id, categories)

Add article categories

Associate new categories with the article. This will add new categories to the list of already associated categories

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
categories = OpenapiClient::CategoriesCreator.new({categories: [1, 10, 11]}) # CategoriesCreator | 

begin
  # Add article categories
  api_instance.private_article_categories_add(article_id, categories)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_categories_add: #{e}"
end
```

#### Using the private_article_categories_add_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_categories_add_with_http_info(article_id, categories)

```ruby
begin
  # Add article categories
  data, status_code, headers = api_instance.private_article_categories_add_with_http_info(article_id, categories)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_categories_add_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **categories** | [**CategoriesCreator**](CategoriesCreator.md) |  |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_categories_list

> <Array<Category>> private_article_categories_list(article_id)

List article categories

List article categories

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier

begin
  # List article categories
  result = api_instance.private_article_categories_list(article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_categories_list: #{e}"
end
```

#### Using the private_article_categories_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Category>>, Integer, Hash)> private_article_categories_list_with_http_info(article_id)

```ruby
begin
  # List article categories
  data, status_code, headers = api_instance.private_article_categories_list_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Category>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_categories_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |

### Return type

[**Array&lt;Category&gt;**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_categories_replace

> private_article_categories_replace(article_id, categories)

Replace article categories

Associate new categories with the article. This will remove all already associated categories and add these new ones

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
categories = OpenapiClient::CategoriesCreator.new({categories: [1, 10, 11]}) # CategoriesCreator | 

begin
  # Replace article categories
  api_instance.private_article_categories_replace(article_id, categories)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_categories_replace: #{e}"
end
```

#### Using the private_article_categories_replace_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_categories_replace_with_http_info(article_id, categories)

```ruby
begin
  # Replace article categories
  data, status_code, headers = api_instance.private_article_categories_replace_with_http_info(article_id, categories)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_categories_replace_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **categories** | [**CategoriesCreator**](CategoriesCreator.md) |  |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_category_delete

> private_article_category_delete(article_id, category_id)

Delete article category

De-associate category from article

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
category_id = 789 # Integer | Category unique identifier

begin
  # Delete article category
  api_instance.private_article_category_delete(article_id, category_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_category_delete: #{e}"
end
```

#### Using the private_article_category_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_category_delete_with_http_info(article_id, category_id)

```ruby
begin
  # Delete article category
  data, status_code, headers = api_instance.private_article_category_delete_with_http_info(article_id, category_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_category_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **category_id** | **Integer** | Category unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_confidentiality_delete

> private_article_confidentiality_delete(article_id)

Delete article confidentiality

Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier

begin
  # Delete article confidentiality
  api_instance.private_article_confidentiality_delete(article_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_confidentiality_delete: #{e}"
end
```

#### Using the private_article_confidentiality_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_confidentiality_delete_with_http_info(article_id)

```ruby
begin
  # Delete article confidentiality
  data, status_code, headers = api_instance.private_article_confidentiality_delete_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_confidentiality_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_confidentiality_details

> <ArticleConfidentiality> private_article_confidentiality_details(article_id)

Article confidentiality details

View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier

begin
  # Article confidentiality details
  result = api_instance.private_article_confidentiality_details(article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_confidentiality_details: #{e}"
end
```

#### Using the private_article_confidentiality_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ArticleConfidentiality>, Integer, Hash)> private_article_confidentiality_details_with_http_info(article_id)

```ruby
begin
  # Article confidentiality details
  data, status_code, headers = api_instance.private_article_confidentiality_details_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ArticleConfidentiality>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_confidentiality_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_confidentiality_update

> private_article_confidentiality_update(article_id, reason)

Update article confidentiality

Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
reason = OpenapiClient::ConfidentialityCreator.new({reason: 'reason_example'}) # ConfidentialityCreator | 

begin
  # Update article confidentiality
  api_instance.private_article_confidentiality_update(article_id, reason)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_confidentiality_update: #{e}"
end
```

#### Using the private_article_confidentiality_update_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_confidentiality_update_with_http_info(article_id, reason)

```ruby
begin
  # Update article confidentiality
  data, status_code, headers = api_instance.private_article_confidentiality_update_with_http_info(article_id, reason)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_confidentiality_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **reason** | [**ConfidentialityCreator**](ConfidentialityCreator.md) |  |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_create

> <LocationWarnings> private_article_create(article)

Create new Article

Create a new Article by sending article information

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article = OpenapiClient::ArticleCreate.new({title: 'Test article title'}) # ArticleCreate | Article description

begin
  # Create new Article
  result = api_instance.private_article_create(article)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_create: #{e}"
end
```

#### Using the private_article_create_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<LocationWarnings>, Integer, Hash)> private_article_create_with_http_info(article)

```ruby
begin
  # Create new Article
  data, status_code, headers = api_instance.private_article_create_with_http_info(article)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <LocationWarnings>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_create_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article** | [**ArticleCreate**](ArticleCreate.md) | Article description |  |

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_delete

> private_article_delete(article_id)

Delete article

Delete an article

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier

begin
  # Delete article
  api_instance.private_article_delete(article_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_delete: #{e}"
end
```

#### Using the private_article_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_delete_with_http_info(article_id)

```ruby
begin
  # Delete article
  data, status_code, headers = api_instance.private_article_delete_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_details

> <ArticleCompletePrivate> private_article_details(article_id)

Article details

View a private article

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier

begin
  # Article details
  result = api_instance.private_article_details(article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_details: #{e}"
end
```

#### Using the private_article_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ArticleCompletePrivate>, Integer, Hash)> private_article_details_with_http_info(article_id)

```ruby
begin
  # Article details
  data, status_code, headers = api_instance.private_article_details_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ArticleCompletePrivate>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_download

> private_article_download(article_id, opts)

Private Article Download

Download files from a private article preserving the folder structure

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
opts = {
  folder_path: 'folder_path_example' # String | Folder path to download. If not provided, all files from the article will be downloaded
}

begin
  # Private Article Download
  api_instance.private_article_download(article_id, opts)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_download: #{e}"
end
```

#### Using the private_article_download_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_download_with_http_info(article_id, opts)

```ruby
begin
  # Private Article Download
  data, status_code, headers = api_instance.private_article_download_with_http_info(article_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_download_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **folder_path** | **String** | Folder path to download. If not provided, all files from the article will be downloaded | [optional] |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined


## private_article_embargo_delete

> private_article_embargo_delete(article_id)

Delete Article Embargo

Will lift the embargo for the specified article

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier

begin
  # Delete Article Embargo
  api_instance.private_article_embargo_delete(article_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_embargo_delete: #{e}"
end
```

#### Using the private_article_embargo_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_embargo_delete_with_http_info(article_id)

```ruby
begin
  # Delete Article Embargo
  data, status_code, headers = api_instance.private_article_embargo_delete_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_embargo_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_embargo_details

> <ArticleEmbargo> private_article_embargo_details(article_id)

Article Embargo Details

View a private article embargo details

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier

begin
  # Article Embargo Details
  result = api_instance.private_article_embargo_details(article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_embargo_details: #{e}"
end
```

#### Using the private_article_embargo_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ArticleEmbargo>, Integer, Hash)> private_article_embargo_details_with_http_info(article_id)

```ruby
begin
  # Article Embargo Details
  data, status_code, headers = api_instance.private_article_embargo_details_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ArticleEmbargo>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_embargo_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_embargo_update

> private_article_embargo_update(article_id, embargo)

Update Article Embargo

Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
embargo = OpenapiClient::ArticleEmbargoUpdater.new({is_embargoed: true, embargo_date: '2018-05-22T04:04:04', embargo_type: 'article'}) # ArticleEmbargoUpdater | Embargo description

begin
  # Update Article Embargo
  api_instance.private_article_embargo_update(article_id, embargo)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_embargo_update: #{e}"
end
```

#### Using the private_article_embargo_update_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_embargo_update_with_http_info(article_id, embargo)

```ruby
begin
  # Update Article Embargo
  data, status_code, headers = api_instance.private_article_embargo_update_with_http_info(article_id, embargo)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_embargo_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **embargo** | [**ArticleEmbargoUpdater**](ArticleEmbargoUpdater.md) | Embargo description |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_file

> <PrivateFile> private_article_file(article_id, file_id)

Single File

View details of file for specified article

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
file_id = 789 # Integer | File unique identifier

begin
  # Single File
  result = api_instance.private_article_file(article_id, file_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_file: #{e}"
end
```

#### Using the private_article_file_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<PrivateFile>, Integer, Hash)> private_article_file_with_http_info(article_id, file_id)

```ruby
begin
  # Single File
  data, status_code, headers = api_instance.private_article_file_with_http_info(article_id, file_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <PrivateFile>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_file_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **file_id** | **Integer** | File unique identifier |  |

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_file_delete

> private_article_file_delete(article_id, file_id)

File Delete

Complete file upload

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
file_id = 789 # Integer | File unique identifier

begin
  # File Delete
  api_instance.private_article_file_delete(article_id, file_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_file_delete: #{e}"
end
```

#### Using the private_article_file_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_file_delete_with_http_info(article_id, file_id)

```ruby
begin
  # File Delete
  data, status_code, headers = api_instance.private_article_file_delete_with_http_info(article_id, file_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_file_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **file_id** | **Integer** | File unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_files_list

> <Array<PrivateFile>> private_article_files_list(article_id, opts)

List article files

List private files

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
opts = {
  page: 789, # Integer | Page number. Used for pagination with page_size
  page_size: 789, # Integer | The number of results included on a page. Used for pagination with page
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789 # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
}

begin
  # List article files
  result = api_instance.private_article_files_list(article_id, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_files_list: #{e}"
end
```

#### Using the private_article_files_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<PrivateFile>>, Integer, Hash)> private_article_files_list_with_http_info(article_id, opts)

```ruby
begin
  # List article files
  data, status_code, headers = api_instance.private_article_files_list_with_http_info(article_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<PrivateFile>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_files_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**Array&lt;PrivateFile&gt;**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_partial_update

> <LocationWarningsUpdate> private_article_partial_update(article_id, article)

Partially update article

Partially update an article by sending only the fields to change.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
article = OpenapiClient::ArticleUpdate.new # ArticleUpdate | Subset of article fields to update

begin
  # Partially update article
  result = api_instance.private_article_partial_update(article_id, article)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_partial_update: #{e}"
end
```

#### Using the private_article_partial_update_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<LocationWarningsUpdate>, Integer, Hash)> private_article_partial_update_with_http_info(article_id, article)

```ruby
begin
  # Partially update article
  data, status_code, headers = api_instance.private_article_partial_update_with_http_info(article_id, article)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <LocationWarningsUpdate>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_partial_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **article** | [**ArticleUpdate**](ArticleUpdate.md) | Subset of article fields to update |  |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_private_link

> <Array<PrivateLink>> private_article_private_link(article_id)

List private links

List private links

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier

begin
  # List private links
  result = api_instance.private_article_private_link(article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_private_link: #{e}"
end
```

#### Using the private_article_private_link_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<PrivateLink>>, Integer, Hash)> private_article_private_link_with_http_info(article_id)

```ruby
begin
  # List private links
  data, status_code, headers = api_instance.private_article_private_link_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<PrivateLink>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_private_link_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |

### Return type

[**Array&lt;PrivateLink&gt;**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_private_link_create

> <PrivateLinkResponse> private_article_private_link_create(article_id, opts)

Create private link

Create new private link for this article

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
opts = {
  private_link: OpenapiClient::PrivateLinkCreator.new # PrivateLinkCreator | 
}

begin
  # Create private link
  result = api_instance.private_article_private_link_create(article_id, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_private_link_create: #{e}"
end
```

#### Using the private_article_private_link_create_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<PrivateLinkResponse>, Integer, Hash)> private_article_private_link_create_with_http_info(article_id, opts)

```ruby
begin
  # Create private link
  data, status_code, headers = api_instance.private_article_private_link_create_with_http_info(article_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <PrivateLinkResponse>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_private_link_create_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **private_link** | [**PrivateLinkCreator**](PrivateLinkCreator.md) |  | [optional] |

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_private_link_delete

> private_article_private_link_delete(article_id, link_id)

Disable private link

Disable/delete private link for this article

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
link_id = 'link_id_example' # String | Private link token

begin
  # Disable private link
  api_instance.private_article_private_link_delete(article_id, link_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_private_link_delete: #{e}"
end
```

#### Using the private_article_private_link_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_private_link_delete_with_http_info(article_id, link_id)

```ruby
begin
  # Disable private link
  data, status_code, headers = api_instance.private_article_private_link_delete_with_http_info(article_id, link_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_private_link_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **link_id** | **String** | Private link token |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_private_link_update

> private_article_private_link_update(article_id, link_id, opts)

Update private link

Update existing private link for this article

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
link_id = 'link_id_example' # String | Private link token
opts = {
  private_link: OpenapiClient::PrivateLinkCreator.new # PrivateLinkCreator | 
}

begin
  # Update private link
  api_instance.private_article_private_link_update(article_id, link_id, opts)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_private_link_update: #{e}"
end
```

#### Using the private_article_private_link_update_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_private_link_update_with_http_info(article_id, link_id, opts)

```ruby
begin
  # Update private link
  data, status_code, headers = api_instance.private_article_private_link_update_with_http_info(article_id, link_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_private_link_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **link_id** | **String** | Private link token |  |
| **private_link** | [**PrivateLinkCreator**](PrivateLinkCreator.md) |  | [optional] |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_reserve_doi

> <ArticleDOI> private_article_reserve_doi(article_id)

Private Article Reserve DOI

Reserve DOI for article

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier

begin
  # Private Article Reserve DOI
  result = api_instance.private_article_reserve_doi(article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_reserve_doi: #{e}"
end
```

#### Using the private_article_reserve_doi_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ArticleDOI>, Integer, Hash)> private_article_reserve_doi_with_http_info(article_id)

```ruby
begin
  # Private Article Reserve DOI
  data, status_code, headers = api_instance.private_article_reserve_doi_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ArticleDOI>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_reserve_doi_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |

### Return type

[**ArticleDOI**](ArticleDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_reserve_handle

> <ArticleHandle> private_article_reserve_handle(article_id)

Private Article Reserve Handle

Reserve Handle for article

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier

begin
  # Private Article Reserve Handle
  result = api_instance.private_article_reserve_handle(article_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_reserve_handle: #{e}"
end
```

#### Using the private_article_reserve_handle_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ArticleHandle>, Integer, Hash)> private_article_reserve_handle_with_http_info(article_id)

```ruby
begin
  # Private Article Reserve Handle
  data, status_code, headers = api_instance.private_article_reserve_handle_with_http_info(article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ArticleHandle>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_reserve_handle_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |

### Return type

[**ArticleHandle**](ArticleHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_resource

> <Location> private_article_resource(article_id, resource)

Private Article Resource

Edit article resource data.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
resource = OpenapiClient::Resource.new # Resource | Resource data

begin
  # Private Article Resource
  result = api_instance.private_article_resource(article_id, resource)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_resource: #{e}"
end
```

#### Using the private_article_resource_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Location>, Integer, Hash)> private_article_resource_with_http_info(article_id, resource)

```ruby
begin
  # Private Article Resource
  data, status_code, headers = api_instance.private_article_resource_with_http_info(article_id, resource)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Location>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_resource_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **resource** | [**Resource**](Resource.md) | Resource data |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_update

> <LocationWarningsUpdate> private_article_update(article_id, article)

Update article

Update an article by passing full body parameters.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
article = OpenapiClient::ArticleUpdate.new # ArticleUpdate | Full article representation

begin
  # Update article
  result = api_instance.private_article_update(article_id, article)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_update: #{e}"
end
```

#### Using the private_article_update_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<LocationWarningsUpdate>, Integer, Hash)> private_article_update_with_http_info(article_id, article)

```ruby
begin
  # Update article
  data, status_code, headers = api_instance.private_article_update_with_http_info(article_id, article)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <LocationWarningsUpdate>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **article** | [**ArticleUpdate**](ArticleUpdate.md) | Full article representation |  |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_article_upload_complete

> private_article_upload_complete(article_id, file_id)

Complete Upload

Complete file upload

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
file_id = 789 # Integer | File unique identifier

begin
  # Complete Upload
  api_instance.private_article_upload_complete(article_id, file_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_upload_complete: #{e}"
end
```

#### Using the private_article_upload_complete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_article_upload_complete_with_http_info(article_id, file_id)

```ruby
begin
  # Complete Upload
  data, status_code, headers = api_instance.private_article_upload_complete_with_http_info(article_id, file_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_upload_complete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **file_id** | **Integer** | File unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_article_upload_initiate

> <Location> private_article_upload_initiate(article_id, file, opts)

Initiate Upload

Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
file = OpenapiClient::FileCreator.new # FileCreator | 
opts = {
  page: 789, # Integer | Page number. Used for pagination with page_size
  page_size: 789, # Integer | The number of results included on a page. Used for pagination with page
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789 # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
}

begin
  # Initiate Upload
  result = api_instance.private_article_upload_initiate(article_id, file, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_upload_initiate: #{e}"
end
```

#### Using the private_article_upload_initiate_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Location>, Integer, Hash)> private_article_upload_initiate_with_http_info(article_id, file, opts)

```ruby
begin
  # Initiate Upload
  data, status_code, headers = api_instance.private_article_upload_initiate_with_http_info(article_id, file, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Location>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_article_upload_initiate_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **file** | [**FileCreator**](FileCreator.md) |  |  |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_articles_list

> <Array<Article>> private_articles_list(opts)

Private Articles

Get Own Articles

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
opts = {
  page: 789, # Integer | Page number. Used for pagination with page_size
  page_size: 789, # Integer | The number of results included on a page. Used for pagination with page
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789 # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
}

begin
  # Private Articles
  result = api_instance.private_articles_list(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_articles_list: #{e}"
end
```

#### Using the private_articles_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Article>>, Integer, Hash)> private_articles_list_with_http_info(opts)

```ruby
begin
  # Private Articles
  data, status_code, headers = api_instance.private_articles_list_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Article>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_articles_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**Array&lt;Article&gt;**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_articles_search

> <Array<ArticleWithProject>> private_articles_search(search)

Private Articles search

Returns a list of private articles filtered by the search parameters

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ArticlesApi.new
search = OpenapiClient::PrivateArticleSearch.new # PrivateArticleSearch | Search Parameters

begin
  # Private Articles search
  result = api_instance.private_articles_search(search)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_articles_search: #{e}"
end
```

#### Using the private_articles_search_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<ArticleWithProject>>, Integer, Hash)> private_articles_search_with_http_info(search)

```ruby
begin
  # Private Articles search
  data, status_code, headers = api_instance.private_articles_search_with_http_info(search)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<ArticleWithProject>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->private_articles_search_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **search** | [**PrivateArticleSearch**](PrivateArticleSearch.md) | Search Parameters |  |

### Return type

[**Array&lt;ArticleWithProject&gt;**](ArticleWithProject.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## public_article_download

> public_article_download(article_id, opts)

Public Article Download

Download files from a public article preserving the folder structure

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
opts = {
  folder_path: 'folder_path_example' # String | Folder path to download. If not provided, all files from the article will be downloaded
}

begin
  # Public Article Download
  api_instance.public_article_download(article_id, opts)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->public_article_download: #{e}"
end
```

#### Using the public_article_download_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> public_article_download_with_http_info(article_id, opts)

```ruby
begin
  # Public Article Download
  data, status_code, headers = api_instance.public_article_download_with_http_info(article_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->public_article_download_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **folder_path** | **String** | Folder path to download. If not provided, all files from the article will be downloaded | [optional] |

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined


## public_article_version_download

> public_article_version_download(article_id, version_id, opts)

Public Article Version Download

Download files from a certain version of an public article preserving the folder structure

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::ArticlesApi.new
article_id = 789 # Integer | Article unique identifier
version_id = 789 # Integer | Version Number
opts = {
  folder_path: 'folder_path_example' # String | Folder path to download. If not provided, all files from the article will be downloaded
}

begin
  # Public Article Version Download
  api_instance.public_article_version_download(article_id, version_id, opts)
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->public_article_version_download: #{e}"
end
```

#### Using the public_article_version_download_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> public_article_version_download_with_http_info(article_id, version_id, opts)

```ruby
begin
  # Public Article Version Download
  data, status_code, headers = api_instance.public_article_version_download_with_http_info(article_id, version_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling ArticlesApi->public_article_version_download_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **article_id** | **Integer** | Article unique identifier |  |
| **version_id** | **Integer** | Version Number |  |
| **folder_path** | **String** | Folder path to download. If not provided, all files from the article will be downloaded | [optional] |

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

