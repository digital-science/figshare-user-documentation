# OpenapiClient::ItemType

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | The ID of the item type. |  |
| **name** | **String** | The name of the item type |  |
| **string_id** | **String** | The string identifier of the item type. |  |
| **icon** | **String** | The string identifying the icon of the item type. |  |
| **public_description** | **String** | The description of the item type. |  |
| **is_selectable** | **Boolean** | The selectable status |  |
| **url_name** | **String** | The URL name of the item type. |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ItemType.new(
  id: null,
  name: journal contribution,
  string_id: journal_contribution,
  icon: paper,
  public_description: This is the description of an item type,
  is_selectable: true,
  url_name: journal_contribution
)
```

