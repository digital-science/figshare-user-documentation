# OpenapiClient::CollectionsApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------ | ------------ | ----------- |
| [**collection_articles**](CollectionsApi.md#collection_articles) | **GET** /collections/{collection_id}/articles | Public Collection Articles |
| [**collection_details**](CollectionsApi.md#collection_details) | **GET** /collections/{collection_id} | Collection details |
| [**collection_version_details**](CollectionsApi.md#collection_version_details) | **GET** /collections/{collection_id}/versions/{version_id} | Collection Version details |
| [**collection_versions**](CollectionsApi.md#collection_versions) | **GET** /collections/{collection_id}/versions | Collection Versions list |
| [**collections_list**](CollectionsApi.md#collections_list) | **GET** /collections | Public Collections |
| [**collections_search**](CollectionsApi.md#collections_search) | **POST** /collections/search | Public Collections Search |
| [**private_collection_article_delete**](CollectionsApi.md#private_collection_article_delete) | **DELETE** /account/collections/{collection_id}/articles/{article_id} | Delete collection article |
| [**private_collection_articles_add**](CollectionsApi.md#private_collection_articles_add) | **POST** /account/collections/{collection_id}/articles | Add collection articles |
| [**private_collection_articles_list**](CollectionsApi.md#private_collection_articles_list) | **GET** /account/collections/{collection_id}/articles | List collection articles |
| [**private_collection_articles_replace**](CollectionsApi.md#private_collection_articles_replace) | **PUT** /account/collections/{collection_id}/articles | Replace collection articles |
| [**private_collection_author_delete**](CollectionsApi.md#private_collection_author_delete) | **DELETE** /account/collections/{collection_id}/authors/{author_id} | Delete collection author |
| [**private_collection_authors_add**](CollectionsApi.md#private_collection_authors_add) | **POST** /account/collections/{collection_id}/authors | Add collection authors |
| [**private_collection_authors_list**](CollectionsApi.md#private_collection_authors_list) | **GET** /account/collections/{collection_id}/authors | List collection authors |
| [**private_collection_authors_replace**](CollectionsApi.md#private_collection_authors_replace) | **PUT** /account/collections/{collection_id}/authors | Replace collection authors |
| [**private_collection_categories_add**](CollectionsApi.md#private_collection_categories_add) | **POST** /account/collections/{collection_id}/categories | Add collection categories |
| [**private_collection_categories_list**](CollectionsApi.md#private_collection_categories_list) | **GET** /account/collections/{collection_id}/categories | List collection categories |
| [**private_collection_categories_replace**](CollectionsApi.md#private_collection_categories_replace) | **PUT** /account/collections/{collection_id}/categories | Replace collection categories |
| [**private_collection_category_delete**](CollectionsApi.md#private_collection_category_delete) | **DELETE** /account/collections/{collection_id}/categories/{category_id} | Delete collection category |
| [**private_collection_create**](CollectionsApi.md#private_collection_create) | **POST** /account/collections | Create collection |
| [**private_collection_delete**](CollectionsApi.md#private_collection_delete) | **DELETE** /account/collections/{collection_id} | Delete collection |
| [**private_collection_details**](CollectionsApi.md#private_collection_details) | **GET** /account/collections/{collection_id} | Collection details |
| [**private_collection_patch**](CollectionsApi.md#private_collection_patch) | **PATCH** /account/collections/{collection_id} | Partially update collection |
| [**private_collection_private_link_create**](CollectionsApi.md#private_collection_private_link_create) | **POST** /account/collections/{collection_id}/private_links | Create collection private link |
| [**private_collection_private_link_delete**](CollectionsApi.md#private_collection_private_link_delete) | **DELETE** /account/collections/{collection_id}/private_links/{link_id} | Disable private link |
| [**private_collection_private_link_details**](CollectionsApi.md#private_collection_private_link_details) | **GET** /account/collections/{collection_id}/private_links/{link_id} | View collection private link |
| [**private_collection_private_link_update**](CollectionsApi.md#private_collection_private_link_update) | **PUT** /account/collections/{collection_id}/private_links/{link_id} | Update collection private link |
| [**private_collection_private_links_list**](CollectionsApi.md#private_collection_private_links_list) | **GET** /account/collections/{collection_id}/private_links | List collection private links |
| [**private_collection_publish**](CollectionsApi.md#private_collection_publish) | **POST** /account/collections/{collection_id}/publish | Private Collection Publish |
| [**private_collection_reserve_doi**](CollectionsApi.md#private_collection_reserve_doi) | **POST** /account/collections/{collection_id}/reserve_doi | Private Collection Reserve DOI |
| [**private_collection_reserve_handle**](CollectionsApi.md#private_collection_reserve_handle) | **POST** /account/collections/{collection_id}/reserve_handle | Private Collection Reserve Handle |
| [**private_collection_resource**](CollectionsApi.md#private_collection_resource) | **POST** /account/collections/{collection_id}/resource | Private Collection Resource |
| [**private_collection_update**](CollectionsApi.md#private_collection_update) | **PUT** /account/collections/{collection_id} | Update collection |
| [**private_collections_list**](CollectionsApi.md#private_collections_list) | **GET** /account/collections | Private Collections List |
| [**private_collections_search**](CollectionsApi.md#private_collections_search) | **POST** /account/collections/search | Private Collections Search |


## collection_articles

> <Array<Article>> collection_articles(collection_id, opts)

Public Collection Articles

Returns a list of public collection articles

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection Unique identifier
opts = {
  page: 789, # Integer | Page number. Used for pagination with page_size
  page_size: 789, # Integer | The number of results included on a page. Used for pagination with page
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789 # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
}

begin
  # Public Collection Articles
  result = api_instance.collection_articles(collection_id, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->collection_articles: #{e}"
end
```

#### Using the collection_articles_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Article>>, Integer, Hash)> collection_articles_with_http_info(collection_id, opts)

```ruby
begin
  # Public Collection Articles
  data, status_code, headers = api_instance.collection_articles_with_http_info(collection_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Article>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->collection_articles_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection Unique identifier |  |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**Array&lt;Article&gt;**](Article.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## collection_details

> <CollectionComplete> collection_details(collection_id)

Collection details

View a collection

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection Unique identifier

begin
  # Collection details
  result = api_instance.collection_details(collection_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->collection_details: #{e}"
end
```

#### Using the collection_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<CollectionComplete>, Integer, Hash)> collection_details_with_http_info(collection_id)

```ruby
begin
  # Collection details
  data, status_code, headers = api_instance.collection_details_with_http_info(collection_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <CollectionComplete>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->collection_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection Unique identifier |  |

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## collection_version_details

> <CollectionComplete> collection_version_details(collection_id, version_id)

Collection Version details

View details for a certain version of a collection

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection Unique identifier
version_id = 789 # Integer | Version Number

begin
  # Collection Version details
  result = api_instance.collection_version_details(collection_id, version_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->collection_version_details: #{e}"
end
```

#### Using the collection_version_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<CollectionComplete>, Integer, Hash)> collection_version_details_with_http_info(collection_id, version_id)

```ruby
begin
  # Collection Version details
  data, status_code, headers = api_instance.collection_version_details_with_http_info(collection_id, version_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <CollectionComplete>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->collection_version_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection Unique identifier |  |
| **version_id** | **Integer** | Version Number |  |

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## collection_versions

> <Array<CollectionVersions>> collection_versions(collection_id)

Collection Versions list

Returns a list of public collection Versions

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection Unique identifier

begin
  # Collection Versions list
  result = api_instance.collection_versions(collection_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->collection_versions: #{e}"
end
```

#### Using the collection_versions_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<CollectionVersions>>, Integer, Hash)> collection_versions_with_http_info(collection_id)

```ruby
begin
  # Collection Versions list
  data, status_code, headers = api_instance.collection_versions_with_http_info(collection_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<CollectionVersions>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->collection_versions_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection Unique identifier |  |

### Return type

[**Array&lt;CollectionVersions&gt;**](CollectionVersions.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## collections_list

> <Array<Collection>> collections_list(opts)

Public Collections

Returns a list of public collections

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::CollectionsApi.new
opts = {
  x_cursor: '38400000-8cf0-11bd-b23e-10b96e4ef00d', # String | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
  page: 789, # Integer | Page number. Used for pagination with page_size
  page_size: 789, # Integer | The number of results included on a page. Used for pagination with page
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789, # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
  order: 'published_date', # String | The field by which to order. Default varies by endpoint/resource.
  order_direction: 'asc', # String | 
  institution: 789, # Integer | only return collections from this institution
  published_since: 'published_since_example', # String | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD
  modified_since: 'modified_since_example', # String | Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD
  group: 789, # Integer | only return collections from this group
  resource_doi: 'resource_doi_example', # String | only return collections with this resource_doi
  doi: 'doi_example', # String | only return collections with this doi
  handle: 'handle_example' # String | only return collections with this handle
}

begin
  # Public Collections
  result = api_instance.collections_list(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->collections_list: #{e}"
end
```

#### Using the collections_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Collection>>, Integer, Hash)> collections_list_with_http_info(opts)

```ruby
begin
  # Public Collections
  data, status_code, headers = api_instance.collections_list_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Collection>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->collections_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **x_cursor** | **String** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **String** | The field by which to order. Default varies by endpoint/resource. | [optional][default to &#39;published_date&#39;] |
| **order_direction** | **String** |  | [optional][default to &#39;desc&#39;] |
| **institution** | **Integer** | only return collections from this institution | [optional] |
| **published_since** | **String** | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional] |
| **modified_since** | **String** | Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD | [optional] |
| **group** | **Integer** | only return collections from this group | [optional] |
| **resource_doi** | **String** | only return collections with this resource_doi | [optional] |
| **doi** | **String** | only return collections with this doi | [optional] |
| **handle** | **String** | only return collections with this handle | [optional] |

### Return type

[**Array&lt;Collection&gt;**](Collection.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## collections_search

> <Array<Collection>> collections_search(opts)

Public Collections Search

Returns a list of public collections

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::CollectionsApi.new
opts = {
  x_cursor: '38400000-8cf0-11bd-b23e-10b96e4ef00d', # String | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected.
  search: OpenapiClient::CollectionSearch.new # CollectionSearch | Search Parameters
}

begin
  # Public Collections Search
  result = api_instance.collections_search(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->collections_search: #{e}"
end
```

#### Using the collections_search_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Collection>>, Integer, Hash)> collections_search_with_http_info(opts)

```ruby
begin
  # Public Collections Search
  data, status_code, headers = api_instance.collections_search_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Collection>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->collections_search_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **x_cursor** | **String** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] |
| **search** | [**CollectionSearch**](CollectionSearch.md) | Search Parameters | [optional] |

### Return type

[**Array&lt;Collection&gt;**](Collection.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collection_article_delete

> private_collection_article_delete(collection_id, article_id)

Delete collection article

De-associate article from collection

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
article_id = 789 # Integer | Collection article unique identifier

begin
  # Delete collection article
  api_instance.private_collection_article_delete(collection_id, article_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_article_delete: #{e}"
end
```

#### Using the private_collection_article_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_collection_article_delete_with_http_info(collection_id, article_id)

```ruby
begin
  # Delete collection article
  data, status_code, headers = api_instance.private_collection_article_delete_with_http_info(collection_id, article_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_article_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **article_id** | **Integer** | Collection article unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_articles_add

> <Location> private_collection_articles_add(collection_id, articles)

Add collection articles

Associate new articles with the collection. This will add new articles to the list of already associated articles

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
articles = OpenapiClient::ArticlesCreator.new({articles: [2000003, 2000004]}) # ArticlesCreator | Articles list

begin
  # Add collection articles
  result = api_instance.private_collection_articles_add(collection_id, articles)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_articles_add: #{e}"
end
```

#### Using the private_collection_articles_add_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Location>, Integer, Hash)> private_collection_articles_add_with_http_info(collection_id, articles)

```ruby
begin
  # Add collection articles
  data, status_code, headers = api_instance.private_collection_articles_add_with_http_info(collection_id, articles)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Location>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_articles_add_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **articles** | [**ArticlesCreator**](ArticlesCreator.md) | Articles list |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collection_articles_list

> <Array<Article>> private_collection_articles_list(collection_id, opts)

List collection articles

List collection articles

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
opts = {
  page: 789, # Integer | Page number. Used for pagination with page_size
  page_size: 789, # Integer | The number of results included on a page. Used for pagination with page
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789 # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
}

begin
  # List collection articles
  result = api_instance.private_collection_articles_list(collection_id, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_articles_list: #{e}"
end
```

#### Using the private_collection_articles_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Article>>, Integer, Hash)> private_collection_articles_list_with_http_info(collection_id, opts)

```ruby
begin
  # List collection articles
  data, status_code, headers = api_instance.private_collection_articles_list_with_http_info(collection_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Article>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_articles_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**Array&lt;Article&gt;**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_articles_replace

> private_collection_articles_replace(collection_id, articles)

Replace collection articles

Associate new articles with the collection. This will remove all already associated articles and add these new ones

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
articles = OpenapiClient::ArticlesCreator.new({articles: [2000003, 2000004]}) # ArticlesCreator | Articles List

begin
  # Replace collection articles
  api_instance.private_collection_articles_replace(collection_id, articles)
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_articles_replace: #{e}"
end
```

#### Using the private_collection_articles_replace_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_collection_articles_replace_with_http_info(collection_id, articles)

```ruby
begin
  # Replace collection articles
  data, status_code, headers = api_instance.private_collection_articles_replace_with_http_info(collection_id, articles)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_articles_replace_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **articles** | [**ArticlesCreator**](ArticlesCreator.md) | Articles List |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collection_author_delete

> private_collection_author_delete(collection_id, author_id)

Delete collection author

Delete collection author

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
author_id = 789 # Integer | Collection Author unique identifier

begin
  # Delete collection author
  api_instance.private_collection_author_delete(collection_id, author_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_author_delete: #{e}"
end
```

#### Using the private_collection_author_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_collection_author_delete_with_http_info(collection_id, author_id)

```ruby
begin
  # Delete collection author
  data, status_code, headers = api_instance.private_collection_author_delete_with_http_info(collection_id, author_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_author_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **author_id** | **Integer** | Collection Author unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_authors_add

> <Location> private_collection_authors_add(collection_id, authors)

Add collection authors

Associate new authors with the collection. This will add new authors to the list of already associated authors

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
authors = OpenapiClient::AuthorsCreator.new({authors: [{"id": 12121}, {"id": 34345}, {"name": "John Doe"}]}) # AuthorsCreator | List of authors

begin
  # Add collection authors
  result = api_instance.private_collection_authors_add(collection_id, authors)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_authors_add: #{e}"
end
```

#### Using the private_collection_authors_add_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Location>, Integer, Hash)> private_collection_authors_add_with_http_info(collection_id, authors)

```ruby
begin
  # Add collection authors
  data, status_code, headers = api_instance.private_collection_authors_add_with_http_info(collection_id, authors)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Location>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_authors_add_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **authors** | [**AuthorsCreator**](AuthorsCreator.md) | List of authors |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collection_authors_list

> <Array<Author>> private_collection_authors_list(collection_id)

List collection authors

List collection authors

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier

begin
  # List collection authors
  result = api_instance.private_collection_authors_list(collection_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_authors_list: #{e}"
end
```

#### Using the private_collection_authors_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Author>>, Integer, Hash)> private_collection_authors_list_with_http_info(collection_id)

```ruby
begin
  # List collection authors
  data, status_code, headers = api_instance.private_collection_authors_list_with_http_info(collection_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Author>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_authors_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |

### Return type

[**Array&lt;Author&gt;**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_authors_replace

> private_collection_authors_replace(collection_id, authors)

Replace collection authors

Associate new authors with the collection. This will remove all already associated authors and add these new ones

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
authors = OpenapiClient::AuthorsCreator.new({authors: [{"id": 12121}, {"id": 34345}, {"name": "John Doe"}]}) # AuthorsCreator | List of authors

begin
  # Replace collection authors
  api_instance.private_collection_authors_replace(collection_id, authors)
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_authors_replace: #{e}"
end
```

#### Using the private_collection_authors_replace_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_collection_authors_replace_with_http_info(collection_id, authors)

```ruby
begin
  # Replace collection authors
  data, status_code, headers = api_instance.private_collection_authors_replace_with_http_info(collection_id, authors)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_authors_replace_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **authors** | [**AuthorsCreator**](AuthorsCreator.md) | List of authors |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collection_categories_add

> <Location> private_collection_categories_add(collection_id, categories)

Add collection categories

Associate new categories with the collection. This will add new categories to the list of already associated categories

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
categories = OpenapiClient::CategoriesCreator.new({categories: [1, 10, 11]}) # CategoriesCreator | Categories list

begin
  # Add collection categories
  result = api_instance.private_collection_categories_add(collection_id, categories)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_categories_add: #{e}"
end
```

#### Using the private_collection_categories_add_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Location>, Integer, Hash)> private_collection_categories_add_with_http_info(collection_id, categories)

```ruby
begin
  # Add collection categories
  data, status_code, headers = api_instance.private_collection_categories_add_with_http_info(collection_id, categories)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Location>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_categories_add_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **categories** | [**CategoriesCreator**](CategoriesCreator.md) | Categories list |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collection_categories_list

> <Array<Category>> private_collection_categories_list(collection_id)

List collection categories

List collection categories

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier

begin
  # List collection categories
  result = api_instance.private_collection_categories_list(collection_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_categories_list: #{e}"
end
```

#### Using the private_collection_categories_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Category>>, Integer, Hash)> private_collection_categories_list_with_http_info(collection_id)

```ruby
begin
  # List collection categories
  data, status_code, headers = api_instance.private_collection_categories_list_with_http_info(collection_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Category>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_categories_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |

### Return type

[**Array&lt;Category&gt;**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_categories_replace

> private_collection_categories_replace(collection_id, categories)

Replace collection categories

Associate new categories with the collection. This will remove all already associated categories and add these new ones

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
categories = OpenapiClient::CategoriesCreator.new({categories: [1, 10, 11]}) # CategoriesCreator | Categories list

begin
  # Replace collection categories
  api_instance.private_collection_categories_replace(collection_id, categories)
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_categories_replace: #{e}"
end
```

#### Using the private_collection_categories_replace_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_collection_categories_replace_with_http_info(collection_id, categories)

```ruby
begin
  # Replace collection categories
  data, status_code, headers = api_instance.private_collection_categories_replace_with_http_info(collection_id, categories)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_categories_replace_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **categories** | [**CategoriesCreator**](CategoriesCreator.md) | Categories list |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collection_category_delete

> private_collection_category_delete(collection_id, category_id)

Delete collection category

De-associate category from collection

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
category_id = 789 # Integer | Collection category unique identifier

begin
  # Delete collection category
  api_instance.private_collection_category_delete(collection_id, category_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_category_delete: #{e}"
end
```

#### Using the private_collection_category_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_collection_category_delete_with_http_info(collection_id, category_id)

```ruby
begin
  # Delete collection category
  data, status_code, headers = api_instance.private_collection_category_delete_with_http_info(collection_id, category_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_category_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **category_id** | **Integer** | Collection category unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_create

> <LocationWarnings> private_collection_create(collection)

Create collection

Create a new Collection by sending collection information

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection = OpenapiClient::CollectionCreate.new({title: 'Test collection title'}) # CollectionCreate | Collection description

begin
  # Create collection
  result = api_instance.private_collection_create(collection)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_create: #{e}"
end
```

#### Using the private_collection_create_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<LocationWarnings>, Integer, Hash)> private_collection_create_with_http_info(collection)

```ruby
begin
  # Create collection
  data, status_code, headers = api_instance.private_collection_create_with_http_info(collection)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <LocationWarnings>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_create_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection** | [**CollectionCreate**](CollectionCreate.md) | Collection description |  |

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collection_delete

> private_collection_delete(collection_id)

Delete collection

Delete n collection

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection Unique identifier

begin
  # Delete collection
  api_instance.private_collection_delete(collection_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_delete: #{e}"
end
```

#### Using the private_collection_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_collection_delete_with_http_info(collection_id)

```ruby
begin
  # Delete collection
  data, status_code, headers = api_instance.private_collection_delete_with_http_info(collection_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection Unique identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_details

> <CollectionCompletePrivate> private_collection_details(collection_id)

Collection details

View a collection

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection Unique identifier

begin
  # Collection details
  result = api_instance.private_collection_details(collection_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_details: #{e}"
end
```

#### Using the private_collection_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<CollectionCompletePrivate>, Integer, Hash)> private_collection_details_with_http_info(collection_id)

```ruby
begin
  # Collection details
  data, status_code, headers = api_instance.private_collection_details_with_http_info(collection_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <CollectionCompletePrivate>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection Unique identifier |  |

### Return type

[**CollectionCompletePrivate**](CollectionCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_patch

> <LocationWarningsUpdate> private_collection_patch(collection_id, collection)

Partially update collection

Partially update a collection by sending only the fields to change.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection Unique identifier
collection = OpenapiClient::CollectionUpdate.new # CollectionUpdate | Subset of collection fields to update

begin
  # Partially update collection
  result = api_instance.private_collection_patch(collection_id, collection)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_patch: #{e}"
end
```

#### Using the private_collection_patch_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<LocationWarningsUpdate>, Integer, Hash)> private_collection_patch_with_http_info(collection_id, collection)

```ruby
begin
  # Partially update collection
  data, status_code, headers = api_instance.private_collection_patch_with_http_info(collection_id, collection)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <LocationWarningsUpdate>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_patch_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection Unique identifier |  |
| **collection** | [**CollectionUpdate**](CollectionUpdate.md) | Subset of collection fields to update |  |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collection_private_link_create

> <PrivateLinkResponse> private_collection_private_link_create(collection_id, opts)

Create collection private link

Create new private link

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
opts = {
  private_link: OpenapiClient::CollectionPrivateLinkCreator.new # CollectionPrivateLinkCreator | 
}

begin
  # Create collection private link
  result = api_instance.private_collection_private_link_create(collection_id, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_private_link_create: #{e}"
end
```

#### Using the private_collection_private_link_create_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<PrivateLinkResponse>, Integer, Hash)> private_collection_private_link_create_with_http_info(collection_id, opts)

```ruby
begin
  # Create collection private link
  data, status_code, headers = api_instance.private_collection_private_link_create_with_http_info(collection_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <PrivateLinkResponse>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_private_link_create_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **private_link** | [**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md) |  | [optional] |

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collection_private_link_delete

> private_collection_private_link_delete(collection_id, link_id)

Disable private link

Disable/delete private link for this collection

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
link_id = 'link_id_example' # String | Private link token

begin
  # Disable private link
  api_instance.private_collection_private_link_delete(collection_id, link_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_private_link_delete: #{e}"
end
```

#### Using the private_collection_private_link_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_collection_private_link_delete_with_http_info(collection_id, link_id)

```ruby
begin
  # Disable private link
  data, status_code, headers = api_instance.private_collection_private_link_delete_with_http_info(collection_id, link_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_private_link_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **link_id** | **String** | Private link token |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_private_link_details

> <PrivateLink> private_collection_private_link_details(collection_id, link_id)

View collection private link

View existing private link for this collection

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
link_id = 'link_id_example' # String | Private link token

begin
  # View collection private link
  result = api_instance.private_collection_private_link_details(collection_id, link_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_private_link_details: #{e}"
end
```

#### Using the private_collection_private_link_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<PrivateLink>, Integer, Hash)> private_collection_private_link_details_with_http_info(collection_id, link_id)

```ruby
begin
  # View collection private link
  data, status_code, headers = api_instance.private_collection_private_link_details_with_http_info(collection_id, link_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <PrivateLink>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_private_link_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **link_id** | **String** | Private link token |  |

### Return type

[**PrivateLink**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_private_link_update

> private_collection_private_link_update(collection_id, link_id, opts)

Update collection private link

Update existing private link for this collection

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
link_id = 'link_id_example' # String | Private link token
opts = {
  private_link: OpenapiClient::CollectionPrivateLinkCreator.new # CollectionPrivateLinkCreator | 
}

begin
  # Update collection private link
  api_instance.private_collection_private_link_update(collection_id, link_id, opts)
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_private_link_update: #{e}"
end
```

#### Using the private_collection_private_link_update_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_collection_private_link_update_with_http_info(collection_id, link_id, opts)

```ruby
begin
  # Update collection private link
  data, status_code, headers = api_instance.private_collection_private_link_update_with_http_info(collection_id, link_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_private_link_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **link_id** | **String** | Private link token |  |
| **private_link** | [**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md) |  | [optional] |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collection_private_links_list

> <Array<PrivateLink>> private_collection_private_links_list(collection_id)

List collection private links

List article private links

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier

begin
  # List collection private links
  result = api_instance.private_collection_private_links_list(collection_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_private_links_list: #{e}"
end
```

#### Using the private_collection_private_links_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<PrivateLink>>, Integer, Hash)> private_collection_private_links_list_with_http_info(collection_id)

```ruby
begin
  # List collection private links
  data, status_code, headers = api_instance.private_collection_private_links_list_with_http_info(collection_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<PrivateLink>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_private_links_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |

### Return type

[**Array&lt;PrivateLink&gt;**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_publish

> <Location> private_collection_publish(collection_id)

Private Collection Publish

When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection Unique identifier

begin
  # Private Collection Publish
  result = api_instance.private_collection_publish(collection_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_publish: #{e}"
end
```

#### Using the private_collection_publish_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Location>, Integer, Hash)> private_collection_publish_with_http_info(collection_id)

```ruby
begin
  # Private Collection Publish
  data, status_code, headers = api_instance.private_collection_publish_with_http_info(collection_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Location>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_publish_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection Unique identifier |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_reserve_doi

> <CollectionDOI> private_collection_reserve_doi(collection_id)

Private Collection Reserve DOI

Reserve DOI for collection

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection Unique identifier

begin
  # Private Collection Reserve DOI
  result = api_instance.private_collection_reserve_doi(collection_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_reserve_doi: #{e}"
end
```

#### Using the private_collection_reserve_doi_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<CollectionDOI>, Integer, Hash)> private_collection_reserve_doi_with_http_info(collection_id)

```ruby
begin
  # Private Collection Reserve DOI
  data, status_code, headers = api_instance.private_collection_reserve_doi_with_http_info(collection_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <CollectionDOI>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_reserve_doi_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection Unique identifier |  |

### Return type

[**CollectionDOI**](CollectionDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_reserve_handle

> <CollectionHandle> private_collection_reserve_handle(collection_id)

Private Collection Reserve Handle

Reserve Handle for collection

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection Unique identifier

begin
  # Private Collection Reserve Handle
  result = api_instance.private_collection_reserve_handle(collection_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_reserve_handle: #{e}"
end
```

#### Using the private_collection_reserve_handle_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<CollectionHandle>, Integer, Hash)> private_collection_reserve_handle_with_http_info(collection_id)

```ruby
begin
  # Private Collection Reserve Handle
  data, status_code, headers = api_instance.private_collection_reserve_handle_with_http_info(collection_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <CollectionHandle>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_reserve_handle_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection Unique identifier |  |

### Return type

[**CollectionHandle**](CollectionHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collection_resource

> <Location> private_collection_resource(collection_id, resource)

Private Collection Resource

Edit collection resource data.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection unique identifier
resource = OpenapiClient::Resource.new # Resource | Resource data

begin
  # Private Collection Resource
  result = api_instance.private_collection_resource(collection_id, resource)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_resource: #{e}"
end
```

#### Using the private_collection_resource_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Location>, Integer, Hash)> private_collection_resource_with_http_info(collection_id, resource)

```ruby
begin
  # Private Collection Resource
  data, status_code, headers = api_instance.private_collection_resource_with_http_info(collection_id, resource)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Location>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_resource_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection unique identifier |  |
| **resource** | [**Resource**](Resource.md) | Resource data |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collection_update

> <LocationWarningsUpdate> private_collection_update(collection_id, collection)

Update collection

Update a collection by passing full body parameters.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
collection_id = 789 # Integer | Collection Unique identifier
collection = OpenapiClient::CollectionUpdate.new # CollectionUpdate | Collection description

begin
  # Update collection
  result = api_instance.private_collection_update(collection_id, collection)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_update: #{e}"
end
```

#### Using the private_collection_update_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<LocationWarningsUpdate>, Integer, Hash)> private_collection_update_with_http_info(collection_id, collection)

```ruby
begin
  # Update collection
  data, status_code, headers = api_instance.private_collection_update_with_http_info(collection_id, collection)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <LocationWarningsUpdate>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collection_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **collection_id** | **Integer** | Collection Unique identifier |  |
| **collection** | [**CollectionUpdate**](CollectionUpdate.md) | Collection description |  |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_collections_list

> <Array<Collection>> private_collections_list(opts)

Private Collections List

List private collections

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
opts = {
  page: 789, # Integer | Page number. Used for pagination with page_size
  page_size: 789, # Integer | The number of results included on a page. Used for pagination with page
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789, # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
  order: 'published_date', # String | The field by which to order. Default varies by endpoint/resource.
  order_direction: 'asc' # String | 
}

begin
  # Private Collections List
  result = api_instance.private_collections_list(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collections_list: #{e}"
end
```

#### Using the private_collections_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Collection>>, Integer, Hash)> private_collections_list_with_http_info(opts)

```ruby
begin
  # Private Collections List
  data, status_code, headers = api_instance.private_collections_list_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Collection>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collections_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **String** | The field by which to order. Default varies by endpoint/resource. | [optional][default to &#39;published_date&#39;] |
| **order_direction** | **String** |  | [optional][default to &#39;desc&#39;] |

### Return type

[**Array&lt;Collection&gt;**](Collection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_collections_search

> <Array<Collection>> private_collections_search(search)

Private Collections Search

Returns a list of private Collections

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::CollectionsApi.new
search = OpenapiClient::PrivateCollectionSearch.new # PrivateCollectionSearch | Search Parameters

begin
  # Private Collections Search
  result = api_instance.private_collections_search(search)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collections_search: #{e}"
end
```

#### Using the private_collections_search_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Collection>>, Integer, Hash)> private_collections_search_with_http_info(search)

```ruby
begin
  # Private Collections Search
  data, status_code, headers = api_instance.private_collections_search_with_http_info(search)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Collection>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling CollectionsApi->private_collections_search_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **search** | [**PrivateCollectionSearch**](PrivateCollectionSearch.md) | Search Parameters |  |

### Return type

[**Array&lt;Collection&gt;**](Collection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

