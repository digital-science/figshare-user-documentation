# OpenapiClient::CurationCommentCreate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **text** | **String** | The contents/value of the comment |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CurationCommentCreate.new(
  text: null
)
```

