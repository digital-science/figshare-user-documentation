# OpenapiClient::OauthApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------ | ------------ | ----------- |
| [**create_token**](OauthApi.md#create_token) | **POST** /token | Create OAuth token |
| [**get_token_info**](OauthApi.md#get_token_info) | **GET** /token | Get OAuth token information |


## create_token

> <OAuthToken> create_token(opts)

Create OAuth token

Creates OAuth token using various grant types

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::OauthApi.new
opts = {
  body: OpenapiClient::CreateOAuthToken.new({client_id: 'client_id_example', client_secret: 'client_secret_example', grant_type: 'authorization_code'}) # CreateOAuthToken | Create OAuth Token Parameters
}

begin
  # Create OAuth token
  result = api_instance.create_token(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling OauthApi->create_token: #{e}"
end
```

#### Using the create_token_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<OAuthToken>, Integer, Hash)> create_token_with_http_info(opts)

```ruby
begin
  # Create OAuth token
  data, status_code, headers = api_instance.create_token_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <OAuthToken>
rescue OpenapiClient::ApiError => e
  puts "Error when calling OauthApi->create_token_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **body** | [**CreateOAuthToken**](CreateOAuthToken.md) | Create OAuth Token Parameters | [optional] |

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## get_token_info

> <OAuthToken> get_token_info(opts)

Get OAuth token information

Returns information about the current OAuth token

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::OauthApi.new
opts = {
  access_token: 'access_token_example' # String | OAuth access token
}

begin
  # Get OAuth token information
  result = api_instance.get_token_info(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling OauthApi->get_token_info: #{e}"
end
```

#### Using the get_token_info_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<OAuthToken>, Integer, Hash)> get_token_info_with_http_info(opts)

```ruby
begin
  # Get OAuth token information
  data, status_code, headers = api_instance.get_token_info_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <OAuthToken>
rescue OpenapiClient::ApiError => e
  puts "Error when calling OauthApi->get_token_info_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **access_token** | **String** | OAuth access token | [optional] |

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

