# SwaggerClient::OauthApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_token**](OauthApi.md#create_token) | **POST** /token | Create OAuth token
[**get_token_info**](OauthApi.md#get_token_info) | **GET** /token | Get OAuth token information


# **create_token**
> OAuthToken create_token(opts)

Create OAuth token

Creates OAuth token using various grant types

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::OauthApi.new

opts = { 
  body: SwaggerClient::CreateOAuthToken.new # CreateOAuthToken | Create OAuth Token Parameters
}

begin
  #Create OAuth token
  result = api_instance.create_token(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OauthApi->create_token: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateOAuthToken**](CreateOAuthToken.md)| Create OAuth Token Parameters | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json



# **get_token_info**
> OAuthToken get_token_info(opts)

Get OAuth token information

Returns information about the current OAuth token

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::OauthApi.new

opts = { 
  access_token: 'access_token_example' # String | OAuth access token
}

begin
  #Get OAuth token information
  result = api_instance.get_token_info(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OauthApi->get_token_info: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **access_token** | **String**| OAuth access token | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json



