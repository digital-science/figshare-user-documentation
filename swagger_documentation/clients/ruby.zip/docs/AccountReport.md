# OpenapiClient::AccountReport

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | A unique ID for the AccountRecord |  |
| **account_id** | **Integer** | The ID of the account which generated this report. |  |
| **created_date** | **String** | Date when the AccountReport was requested |  |
| **status** | **String** | Status of the report |  |
| **download_url** | **String** | The download link for the generated XLSX |  |
| **group_id** | **Integer** | The group ID that was used to filter the report, if any. |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AccountReport.new(
  id: null,
  account_id: null,
  created_date: 2017-05-15T15:12:26Z,
  status: null,
  download_url: https://some.com/storage/path/123/report-456.xlsx,
  group_id: null
)
```

