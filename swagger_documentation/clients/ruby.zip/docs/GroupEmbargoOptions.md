# SwaggerClient::GroupEmbargoOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Embargo option id | 
**type** | **String** | Embargo permission type | 
**ip_name** | **String** | IP range name; value appears if type is ip_range | 


