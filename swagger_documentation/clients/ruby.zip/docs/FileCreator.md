# OpenapiClient::FileCreator

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **link** | **String** | Url for an existing file that will not be uploaded to Figshare | [optional] |
| **md5** | **String** | MD5 sum pre-computed on client side. | [optional] |
| **name** | **String** | File name including the extension; can be omitted only for linked files. | [optional] |
| **size** | **Integer** | File size in bytes; can be omitted only for linked files. | [optional] |
| **folder_path** | **String** | Unix-style directory path of the file; only available if the file was uploaded within a folder structure | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::FileCreator.new(
  link: http://figshare.com/file.txt,
  md5: 6c16e6e7d7587bd078e5117dda01d565,
  name: test.py,
  size: 70,
  folder_path: /level1/level2/level3
)
```

