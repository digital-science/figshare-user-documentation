# OpenapiClient::ArticleEmbargoUpdater

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **is_embargoed** | **Boolean** | Embargo status |  |
| **embargo_date** | **String** | Date when the embargo expires and the article gets published, &#39;0&#39; value will set up permanent embargo |  |
| **embargo_type** | **String** | Embargo can be enabled at the article or the file level. Possible values: article, file |  |
| **embargo_title** | **String** | Title for embargo | [optional] |
| **embargo_reason** | **String** | Reason for setting embargo | [optional] |
| **embargo_options** | **Array&lt;Object&gt;** | List of embargo permissions to be associated with the article. The list must contain &#x60;id&#x60; and can also contain &#x60;group_ids&#x60;(a field that only applies to &#39;logged_in&#39; permissions). The new list replaces old options in the database, and an empty list removes all permissions for this article. Administration permission has to be set up alone but logged in and IP range permissions can be set up together. | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ArticleEmbargoUpdater.new(
  is_embargoed: true,
  embargo_date: 2018-05-22T04:04:04,
  embargo_type: file,
  embargo_title: File(s) under embargo,
  embargo_reason: ,
  embargo_options: [{&quot;id&quot;:1321},{&quot;id&quot;:3345},{&quot;id&quot;:54621,&quot;group_ids&quot;:[4332,5433,678]}]
)
```

