# OpenapiClient::License

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **value** | **Integer** | License value |  |
| **name** | **String** | License name |  |
| **url** | **String** | License url |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::License.new(
  value: 1,
  name: CC BY,
  url: http://creativecommons.org/licenses/by/4.0/
)
```

