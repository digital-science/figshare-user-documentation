# OpenapiClient::ProjectComplete

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **funding** | **String** | Project funding |  |
| **funding_list** | [**Array&lt;FundingInformation&gt;**](FundingInformation.md) | Full Project funding information |  |
| **description** | **String** | Project description |  |
| **collaborators** | [**Array&lt;Collaborator&gt;**](Collaborator.md) | List of project collaborators |  |
| **custom_fields** | [**Array&lt;CustomArticleField&gt;**](CustomArticleField.md) | Project custom fields |  |
| **modified_date** | **String** | Date when project was last modified |  |
| **created_date** | **String** | Date when project was created |  |
| **url** | **String** | Api endpoint |  |
| **id** | **Integer** | Project id |  |
| **title** | **String** | Project title |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ProjectComplete.new(
  funding: ,
  funding_list: null,
  description: description,
  collaborators: null,
  custom_fields: null,
  modified_date: 2017-05-16T14:52:54Z,
  created_date: 2017-05-16T14:52:54Z,
  url: http://api.figshare.com/v2/account/projects/1,
  id: 1,
  title: project
)
```

