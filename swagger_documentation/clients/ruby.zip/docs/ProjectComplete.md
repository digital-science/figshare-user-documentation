# SwaggerClient::ProjectComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | Api endpoint | 
**id** | **Integer** | Project id | 
**title** | **String** | Project title | 
**created_date** | **String** | Date when project was created | 
**modified_date** | **String** | Date when project was last modified | 
**funding** | **String** | Project funding | 
**funding_list** | [**Array&lt;FundingInformation&gt;**](FundingInformation.md) | Full Project funding information | 
**description** | **String** | Project description | 
**collaborators** | [**Array&lt;Collaborator&gt;**](Collaborator.md) | List of project collaborators | 
**custom_fields** | [**Array&lt;CustomArticleField&gt;**](CustomArticleField.md) | Project custom fields | 


