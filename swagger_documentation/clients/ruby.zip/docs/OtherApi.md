# OpenapiClient::OtherApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------ | ------------ | ----------- |
| [**categories_list**](OtherApi.md#categories_list) | **GET** /categories | Public Categories |
| [**file_download**](OtherApi.md#file_download) | **GET** /file/download/{file_id} | Public File Download |
| [**item_types_list**](OtherApi.md#item_types_list) | **GET** /item_types | Item Types |
| [**licenses_list**](OtherApi.md#licenses_list) | **GET** /licenses | Public Licenses |
| [**private_account**](OtherApi.md#private_account) | **GET** /account | Private Account information |
| [**private_funding_search**](OtherApi.md#private_funding_search) | **POST** /account/funding/search | Search Funding |
| [**private_licenses_list**](OtherApi.md#private_licenses_list) | **GET** /account/licenses | Private Account Licenses |


## categories_list

> <Array<CategoryList>> categories_list

Public Categories

Returns a list of public categories

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::OtherApi.new

begin
  # Public Categories
  result = api_instance.categories_list
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->categories_list: #{e}"
end
```

#### Using the categories_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<CategoryList>>, Integer, Hash)> categories_list_with_http_info

```ruby
begin
  # Public Categories
  data, status_code, headers = api_instance.categories_list_with_http_info
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<CategoryList>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->categories_list_with_http_info: #{e}"
end
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**Array&lt;CategoryList&gt;**](CategoryList.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## file_download

> file_download(file_id)

Public File Download

Starts the download of a file

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::OtherApi.new
file_id = 789 # Integer | 

begin
  # Public File Download
  api_instance.file_download(file_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->file_download: #{e}"
end
```

#### Using the file_download_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> file_download_with_http_info(file_id)

```ruby
begin
  # Public File Download
  data, status_code, headers = api_instance.file_download_with_http_info(file_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->file_download_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **file_id** | **Integer** |  |  |

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined


## item_types_list

> <Array<ItemType>> item_types_list(opts)

Item Types

Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::OtherApi.new
opts = {
  group_id: 789 # Integer | Identifier of the group for which the item types are requested
}

begin
  # Item Types
  result = api_instance.item_types_list(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->item_types_list: #{e}"
end
```

#### Using the item_types_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<ItemType>>, Integer, Hash)> item_types_list_with_http_info(opts)

```ruby
begin
  # Item Types
  data, status_code, headers = api_instance.item_types_list_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<ItemType>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->item_types_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **group_id** | **Integer** | Identifier of the group for which the item types are requested | [optional][default to 0] |

### Return type

[**Array&lt;ItemType&gt;**](ItemType.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## licenses_list

> <Array<License>> licenses_list

Public Licenses

Returns a list of public licenses

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::OtherApi.new

begin
  # Public Licenses
  result = api_instance.licenses_list
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->licenses_list: #{e}"
end
```

#### Using the licenses_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<License>>, Integer, Hash)> licenses_list_with_http_info

```ruby
begin
  # Public Licenses
  data, status_code, headers = api_instance.licenses_list_with_http_info
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<License>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->licenses_list_with_http_info: #{e}"
end
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**Array&lt;License&gt;**](License.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_account

> <Account> private_account

Private Account information

Account information for token/personal token

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::OtherApi.new

begin
  # Private Account information
  result = api_instance.private_account
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->private_account: #{e}"
end
```

#### Using the private_account_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Account>, Integer, Hash)> private_account_with_http_info

```ruby
begin
  # Private Account information
  data, status_code, headers = api_instance.private_account_with_http_info
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Account>
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->private_account_with_http_info: #{e}"
end
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_funding_search

> <Array<FundingInformation>> private_funding_search(opts)

Search Funding

Search for fundings

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::OtherApi.new
opts = {
  search: OpenapiClient::FundingSearch.new # FundingSearch | Search Parameters
}

begin
  # Search Funding
  result = api_instance.private_funding_search(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->private_funding_search: #{e}"
end
```

#### Using the private_funding_search_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<FundingInformation>>, Integer, Hash)> private_funding_search_with_http_info(opts)

```ruby
begin
  # Search Funding
  data, status_code, headers = api_instance.private_funding_search_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<FundingInformation>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->private_funding_search_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **search** | [**FundingSearch**](FundingSearch.md) | Search Parameters | [optional] |

### Return type

[**Array&lt;FundingInformation&gt;**](FundingInformation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_licenses_list

> <Array<License>> private_licenses_list

Private Account Licenses

This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::OtherApi.new

begin
  # Private Account Licenses
  result = api_instance.private_licenses_list
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->private_licenses_list: #{e}"
end
```

#### Using the private_licenses_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<License>>, Integer, Hash)> private_licenses_list_with_http_info

```ruby
begin
  # Private Account Licenses
  data, status_code, headers = api_instance.private_licenses_list_with_http_info
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<License>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling OtherApi->private_licenses_list_with_http_info: #{e}"
end
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**Array&lt;License&gt;**](License.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

