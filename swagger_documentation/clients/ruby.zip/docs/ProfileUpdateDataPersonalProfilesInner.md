# OpenapiClient::ProfileUpdateDataPersonalProfilesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **label** | **String** | Label for the personal profile link | [optional] |
| **url** | **String** | URL for the personal profile link | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ProfileUpdateDataPersonalProfilesInner.new(
  label: ResearchGate,
  url: https://researchgate.net/profile/1
)
```

