# OpenapiClient::CollectionDOI

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **doi** | **String** | Reserved DOI |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CollectionDOI.new(
  doi: 10.5072/FK2.FIGSHARE.20345
)
```

