# OpenapiClient::ProjectCompletePrivate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **funding** | **String** | Project funding |  |
| **funding_list** | [**Array&lt;FundingInformation&gt;**](FundingInformation.md) | Full Project funding information |  |
| **description** | **String** | Project description |  |
| **collaborators** | [**Array&lt;Collaborator&gt;**](Collaborator.md) | List of project collaborators |  |
| **quota** | **Integer** | Project quota |  |
| **used_quota** | **Integer** | Project used quota |  |
| **created_date** | **String** | Date when project was created |  |
| **modified_date** | **String** | Date when project was last modified |  |
| **used_quota_private** | **Integer** | Project private quota used |  |
| **used_quota_public** | **Integer** | Project public quota used |  |
| **group_id** | **Integer** | Group of project if any |  |
| **account_id** | **Integer** | ID of the account owning the project |  |
| **custom_fields** | [**Array&lt;ShortCustomField&gt;**](ShortCustomField.md) | Collection custom fields |  |
| **role** | **String** | Role inside this project |  |
| **storage** | **String** | Project storage type |  |
| **url** | **String** | Api endpoint |  |
| **id** | **Integer** | Project id |  |
| **title** | **String** | Project title |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ProjectCompletePrivate.new(
  funding: none,
  funding_list: null,
  description: description,
  collaborators: null,
  quota: 0,
  used_quota: 0,
  created_date: 2017-05-16T14:52:54Z,
  modified_date: 2017-05-16T14:52:54Z,
  used_quota_private: 0,
  used_quota_public: 0,
  group_id: 0,
  account_id: 1000001,
  custom_fields: null,
  role: Owner,
  storage: individual,
  url: http://api.figshare.com/v2/account/projects/1,
  id: 1,
  title: project
)
```

