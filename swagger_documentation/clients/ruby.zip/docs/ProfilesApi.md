# OpenapiClient::ProfilesApi

All URIs are relative to *https://api.figinternal.dev*

| Method | HTTP request | Description |
| ------ | ------------ | ----------- |
| [**update_user_profile**](ProfilesApi.md#update_user_profile) | **PUT** /account/profile | Update public profile |
| [**update_user_profile_picture**](ProfilesApi.md#update_user_profile_picture) | **POST** /account/profile/{user_id}/picture | Update public profile picture |


## update_user_profile

> Object update_user_profile(user_profile_data, opts)

Update public profile

Updates the fields of the user's public profile.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProfilesApi.new
user_profile_data = OpenapiClient::ProfileUpdateData.new # ProfileUpdateData | 
opts = {
  user_id: 789, # Integer | User ID
  institution_user_id: 'institution_user_id_example' # String | Institutional user ID
}

begin
  # Update public profile
  result = api_instance.update_user_profile(user_profile_data, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProfilesApi->update_user_profile: #{e}"
end
```

#### Using the update_user_profile_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(Object, Integer, Hash)> update_user_profile_with_http_info(user_profile_data, opts)

```ruby
begin
  # Update public profile
  data, status_code, headers = api_instance.update_user_profile_with_http_info(user_profile_data, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => Object
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProfilesApi->update_user_profile_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **user_profile_data** | [**ProfileUpdateData**](ProfileUpdateData.md) |  |  |
| **user_id** | **Integer** | User ID | [optional] |
| **institution_user_id** | **String** | Institutional user ID | [optional] |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## update_user_profile_picture

> Object update_user_profile_picture(user_id, profile_picture)

Update public profile picture

Updates the profile picture of the user's public profile.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::ProfilesApi.new
user_id = 789 # Integer | User ID
profile_picture = File.new('/path/to/some/file') # File | User profile picture

begin
  # Update public profile picture
  result = api_instance.update_user_profile_picture(user_id, profile_picture)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProfilesApi->update_user_profile_picture: #{e}"
end
```

#### Using the update_user_profile_picture_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(Object, Integer, Hash)> update_user_profile_picture_with_http_info(user_id, profile_picture)

```ruby
begin
  # Update public profile picture
  data, status_code, headers = api_instance.update_user_profile_picture_with_http_info(user_id, profile_picture)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => Object
rescue OpenapiClient::ApiError => e
  puts "Error when calling ProfilesApi->update_user_profile_picture_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **user_id** | **Integer** | User ID |  |
| **profile_picture** | **File** | User profile picture |  |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: multipart/form-data
- **Accept**: application/json

