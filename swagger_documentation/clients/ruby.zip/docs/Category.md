# OpenapiClient::Category

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **parent_id** | **Integer** | Parent category |  |
| **id** | **Integer** | Category id |  |
| **title** | **String** | Category title |  |
| **path** | **String** | Path to all ancestor ids |  |
| **source_id** | **String** | ID in original standard taxonomy |  |
| **taxonomy_id** | **Integer** | Internal id of taxonomy the category is part of |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::Category.new(
  parent_id: 1,
  id: 11,
  title: Anatomy,
  path: /450/1024/6532,
  source_id: 300204,
  taxonomy_id: 4
)
```

