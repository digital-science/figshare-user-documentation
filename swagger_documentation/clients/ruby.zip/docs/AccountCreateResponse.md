# OpenapiClient::AccountCreateResponse

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **account_id** | **Integer** | ID of created account |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AccountCreateResponse.new(
  account_id: 33334444
)
```

