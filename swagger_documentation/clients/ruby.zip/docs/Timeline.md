# OpenapiClient::Timeline

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **first_online** | **String** | Online posted date | [optional] |
| **publisher_publication** | **String** | Publish date | [optional] |
| **publisher_acceptance** | **String** | Date when the item was accepted for publication | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::Timeline.new(
  first_online: 2015-12-31,
  publisher_publication: 2015-12-31,
  publisher_acceptance: 2015-12-31
)
```

