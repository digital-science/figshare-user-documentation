# OpenapiClient::LocationWarningsUpdate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **location** | **String** | Url for entity |  |
| **warnings** | **Array&lt;String&gt;** | Issues encountered during the operation |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::LocationWarningsUpdate.new(
  location: null,
  warnings: null
)
```

