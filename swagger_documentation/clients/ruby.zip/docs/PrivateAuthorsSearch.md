# OpenapiClient::PrivateAuthorsSearch

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **search_for** | **String** | Search term | [optional] |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **institution_id** | **Integer** | Return only authors associated to this institution | [optional] |
| **orcid** | **String** | Orcid of author | [optional] |
| **group_id** | **Integer** | Return only authors in this group or subgroups of the group | [optional] |
| **is_active** | **Boolean** | Return only active authors if True | [optional] |
| **is_public** | **Boolean** | Return only authors that have published items if True | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::PrivateAuthorsSearch.new(
  search_for: figshare,
  page: 1,
  page_size: 10,
  limit: 10,
  offset: 0,
  institution_id: 1,
  orcid: null,
  group_id: null,
  is_active: null,
  is_public: null
)
```

