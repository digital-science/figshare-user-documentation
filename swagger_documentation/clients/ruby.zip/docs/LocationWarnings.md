# OpenapiClient::LocationWarnings

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **entity_id** | **Integer** | Figshare ID of the entity |  |
| **location** | **String** | Url for entity |  |
| **warnings** | **Array&lt;String&gt;** | Issues encountered during the operation |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::LocationWarnings.new(
  entity_id: 33334444,
  location: null,
  warnings: null
)
```

