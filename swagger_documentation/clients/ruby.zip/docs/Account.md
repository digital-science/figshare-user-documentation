# OpenapiClient::Account

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | Account id |  |
| **first_name** | **String** | First Name |  |
| **last_name** | **String** | Last Name |  |
| **used_quota_private** | **Integer** | Account used private quota |  |
| **modified_date** | **String** | Date of last account modification |  |
| **used_quota** | **Integer** | Account total used quota |  |
| **created_date** | **String** | Date when account was created |  |
| **quota** | **Integer** | Account quota |  |
| **group_id** | **Integer** | Account group id |  |
| **institution_user_id** | **String** | Account institution user id |  |
| **institution_id** | **Integer** | Account institution |  |
| **email** | **String** | User email |  |
| **used_quota_public** | **Integer** | Account public used quota |  |
| **pending_quota_request** | **Boolean** | True if a quota request is pending |  |
| **active** | **Integer** | Account activity status |  |
| **maximum_file_size** | **Integer** | Maximum upload size for account |  |
| **user_id** | **Integer** | User id associated with account, useful for example for adding the account as an author to an item |  |
| **orcid_id** | **String** | ORCID iD associated to account |  |
| **symplectic_user_id** | **String** | Symplectic ID associated to account |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::Account.new(
  id: 1495682,
  first_name: Doe,
  last_name: John,
  used_quota_private: 0,
  modified_date: 2018-05-22T04:04:04,
  used_quota: 0,
  created_date: 2018-05-22T04:04:04,
  quota: 0,
  group_id: 0,
  institution_user_id: djohn42,
  institution_id: 1,
  email: user@domain.com,
  used_quota_public: 0,
  pending_quota_request: true,
  active: 0,
  maximum_file_size: 0,
  user_id: 1000001,
  orcid_id: 0000-0001-2345-6789,
  symplectic_user_id: djohn42
)
```

