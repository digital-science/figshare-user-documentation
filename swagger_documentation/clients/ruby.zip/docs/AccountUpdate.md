# OpenapiClient::AccountUpdate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **group_id** | **Integer** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups |  |
| **is_active** | **Boolean** | Is account active |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AccountUpdate.new(
  group_id: null,
  is_active: null
)
```

