# OpenapiClient::CategoriesCreator

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **categories** | **Array&lt;Integer&gt;** | List of category ids |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CategoriesCreator.new(
  categories: [1,10,11]
)
```

