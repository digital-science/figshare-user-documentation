# OpenapiClient::FundingSearch

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **search_for** | **String** | Search term | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::FundingSearch.new(
  search_for: null
)
```

