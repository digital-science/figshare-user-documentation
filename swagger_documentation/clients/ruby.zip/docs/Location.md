# OpenapiClient::Location

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **location** | **String** | Url for item |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::Location.new(
  location: null
)
```

