# OpenapiClient::ArticleSearch

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **resource_doi** | **String** | Only return articles with this resource_doi | [optional] |
| **item_type** | **Integer** | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] |
| **doi** | **String** | Only return articles with this doi | [optional] |
| **handle** | **String** | Only return articles with this handle | [optional] |
| **project_id** | **Integer** | Only return articles in this project | [optional] |
| **order** | **String** | The field by which to order | [optional][default to &#39;created_date&#39;] |
| **search_for** | **String** | Search term | [optional] |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order_direction** | **String** | Direction of ordering | [optional][default to &#39;desc&#39;] |
| **institution** | **Integer** | only return collections from this institution | [optional] |
| **published_since** | **String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **modified_since** | **String** | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **group** | **Integer** | only return collections from this group | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ArticleSearch.new(
  resource_doi: 10.6084/m9.figshare.1407024,
  item_type: 1,
  doi: 10.6084/m9.figshare.1407024,
  handle: 111084/m9.figshare.14074,
  project_id: 1,
  order: published_date,
  search_for: figshare,
  page: 1,
  page_size: 10,
  limit: 10,
  offset: 0,
  order_direction: desc,
  institution: 2000013,
  published_since: 2017-12-22,
  modified_since: 2017-12-22,
  group: 2000013
)
```

