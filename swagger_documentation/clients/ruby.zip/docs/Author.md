# OpenapiClient::Author

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | Author id |  |
| **full_name** | **String** | Author full name |  |
| **first_name** | **String** | Author first name |  |
| **last_name** | **String** | Author last name |  |
| **is_active** | **Boolean** | True if author has published items |  |
| **url_name** | **String** | Author url name |  |
| **orcid_id** | **String** | Author Orcid |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::Author.new(
  id: 97657,
  full_name: John Doe,
  first_name: John,
  last_name: Doe,
  is_active: false,
  url_name: John_Doe,
  orcid_id: 1234-5678-9123-1234
)
```

