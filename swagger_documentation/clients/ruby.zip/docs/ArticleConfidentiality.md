# OpenapiClient::ArticleConfidentiality

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **is_confidential** | **Boolean** | True if article is confidential |  |
| **reason** | **String** | Reason for confidentiality |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ArticleConfidentiality.new(
  is_confidential: true,
  reason: need to
)
```

