# OpenapiClient::ArticleHandle

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **handle** | **String** | Reserved Handle |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ArticleHandle.new(
  handle: 11172/FK2.FIGSHARE.20345
)
```

