# SwaggerClient::ShortAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Account id | 
**first_name** | **String** | First Name | 
**last_name** | **String** | Last Name | 
**institution_id** | **Integer** | Account institution | 
**email** | **String** | User email | 
**active** | **Integer** | Account activity status | 
**institution_user_id** | **String** | Account institution user id | 
**quota** | **Integer** | Total storage available to account, in bytes | 
**used_quota** | **Integer** | Storage used by the account, in bytes | 
**user_id** | **Integer** | User id associated with account, useful for example for adding the account as an author to an item | 
**orcid_id** | **String** | ORCID iD associated to account | 


