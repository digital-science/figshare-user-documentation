# OpenapiClient::PrivateFile

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **viewer_type** | **String** | File viewer type |  |
| **preview_state** | **String** | File preview state |  |
| **upload_url** | **String** | Upload url for file |  |
| **upload_token** | **String** | Token for file upload |  |
| **is_attached_to_public_version** | **Boolean** | True if the file is attached to a public item version |  |
| **id** | **Integer** | File id |  |
| **name** | **String** | File name |  |
| **size** | **Integer** | File size |  |
| **is_link_only** | **Boolean** | True if file is hosted somewhere else |  |
| **download_url** | **String** | Url for file download |  |
| **supplied_md5** | **String** | File supplied md5 |  |
| **computed_md5** | **String** | File computed md5 |  |
| **mimetype** | **String** | MIME Type of the file, it defaults to an empty string | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::PrivateFile.new(
  viewer_type: null,
  preview_state: preview not available,
  upload_url: https://uploads.figshare.com,
  upload_token: 9dfc5fe3-d617-4d93-ac11-8afe7e984a4b,
  is_attached_to_public_version: true,
  id: 3000002,
  name: test.xls,
  size: 14848,
  is_link_only: false,
  download_url: https://ndownloader.figshare.com/files/3000002,
  supplied_md5: 043a51806d646e88cafbf19e7b82846f,
  computed_md5: 043a51806d646e88cafbf19e7b82846f,
  mimetype: application/pdf
)
```

