# OpenapiClient::InstitutionsApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
| ------ | ------------ | ----------- |
| [**account_institution_curation**](InstitutionsApi.md#account_institution_curation) | **GET** /account/institution/review/{curation_id} | Institution Curation Review |
| [**account_institution_curations**](InstitutionsApi.md#account_institution_curations) | **GET** /account/institution/reviews | Institution Curation Reviews |
| [**custom_fields_list**](InstitutionsApi.md#custom_fields_list) | **GET** /account/institution/custom_fields | Private account institution group custom fields |
| [**custom_fields_upload**](InstitutionsApi.md#custom_fields_upload) | **POST** /account/institution/custom_fields/{custom_field_id}/items/upload | Custom fields values files upload |
| [**get_account_institution_curation_comments**](InstitutionsApi.md#get_account_institution_curation_comments) | **GET** /account/institution/review/{curation_id}/comments | Institution Curation Review Comments |
| [**institution_articles**](InstitutionsApi.md#institution_articles) | **GET** /institutions/{institution_string_id}/articles/filter-by | Public Institution Articles |
| [**institution_hrfeed_upload**](InstitutionsApi.md#institution_hrfeed_upload) | **POST** /institution/hrfeed/upload | Private Institution HRfeed Upload |
| [**post_account_institution_curation_comments**](InstitutionsApi.md#post_account_institution_curation_comments) | **POST** /account/institution/review/{curation_id}/comments | POST Institution Curation Review Comment |
| [**private_account_institution_user**](InstitutionsApi.md#private_account_institution_user) | **GET** /account/institution/users/{account_id} | Private Account Institution User |
| [**private_categories_list**](InstitutionsApi.md#private_categories_list) | **GET** /account/categories | Private Account Categories |
| [**private_group_embargo_options_details**](InstitutionsApi.md#private_group_embargo_options_details) | **GET** /account/institution/groups/{group_id}/embargo_options | Private Account Institution Group Embargo Options |
| [**private_institution_account**](InstitutionsApi.md#private_institution_account) | **GET** /account/institution/accounts/{account_id} | Private Institution Account information |
| [**private_institution_account_group_role_delete**](InstitutionsApi.md#private_institution_account_group_role_delete) | **DELETE** /account/institution/roles/{account_id}/{group_id}/{role_id} | Delete Institution Account Group Role |
| [**private_institution_account_group_roles**](InstitutionsApi.md#private_institution_account_group_roles) | **GET** /account/institution/roles/{account_id} | List Institution Account Group Roles |
| [**private_institution_account_group_roles_create**](InstitutionsApi.md#private_institution_account_group_roles_create) | **POST** /account/institution/roles/{account_id} | Add Institution Account Group Roles |
| [**private_institution_accounts_create**](InstitutionsApi.md#private_institution_accounts_create) | **POST** /account/institution/accounts | Create new Institution Account |
| [**private_institution_accounts_list**](InstitutionsApi.md#private_institution_accounts_list) | **GET** /account/institution/accounts | Private Account Institution Accounts |
| [**private_institution_accounts_search**](InstitutionsApi.md#private_institution_accounts_search) | **POST** /account/institution/accounts/search | Private Account Institution Accounts Search |
| [**private_institution_accounts_update**](InstitutionsApi.md#private_institution_accounts_update) | **PUT** /account/institution/accounts/{account_id} | Update Institution Account |
| [**private_institution_articles**](InstitutionsApi.md#private_institution_articles) | **GET** /account/institution/articles | Private Institution Articles |
| [**private_institution_details**](InstitutionsApi.md#private_institution_details) | **GET** /account/institution | Private Account Institutions |
| [**private_institution_embargo_options_details**](InstitutionsApi.md#private_institution_embargo_options_details) | **GET** /account/institution/embargo_options | Private Account Institution embargo options |
| [**private_institution_groups_list**](InstitutionsApi.md#private_institution_groups_list) | **GET** /account/institution/groups | Private Account Institution Groups |
| [**private_institution_roles_list**](InstitutionsApi.md#private_institution_roles_list) | **GET** /account/institution/roles | Private Account Institution Roles |


## account_institution_curation

> <CurationDetail> account_institution_curation(curation_id)

Institution Curation Review

Retrieve a certain curation review by its ID

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
curation_id = 789 # Integer | ID of the curation

begin
  # Institution Curation Review
  result = api_instance.account_institution_curation(curation_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->account_institution_curation: #{e}"
end
```

#### Using the account_institution_curation_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<CurationDetail>, Integer, Hash)> account_institution_curation_with_http_info(curation_id)

```ruby
begin
  # Institution Curation Review
  data, status_code, headers = api_instance.account_institution_curation_with_http_info(curation_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <CurationDetail>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->account_institution_curation_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **curation_id** | **Integer** | ID of the curation |  |

### Return type

[**CurationDetail**](CurationDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## account_institution_curations

> <Curation> account_institution_curations(opts)

Institution Curation Reviews

Retrieve a list of curation reviews for this institution

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
opts = {
  group_id: 789, # Integer | Filter by the group ID
  article_id: 789, # Integer | Retrieve the reviews for this article
  status: 'pending', # String | Filter by the status of the review
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789 # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
}

begin
  # Institution Curation Reviews
  result = api_instance.account_institution_curations(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->account_institution_curations: #{e}"
end
```

#### Using the account_institution_curations_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Curation>, Integer, Hash)> account_institution_curations_with_http_info(opts)

```ruby
begin
  # Institution Curation Reviews
  data, status_code, headers = api_instance.account_institution_curations_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Curation>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->account_institution_curations_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **group_id** | **Integer** | Filter by the group ID | [optional] |
| **article_id** | **Integer** | Retrieve the reviews for this article | [optional] |
| **status** | **String** | Filter by the status of the review | [optional] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**Curation**](Curation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## custom_fields_list

> <Array<ShortCustomField>> custom_fields_list(opts)

Private account institution group custom fields

Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
opts = {
  group_id: 789 # Integer | Group_id
}

begin
  # Private account institution group custom fields
  result = api_instance.custom_fields_list(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->custom_fields_list: #{e}"
end
```

#### Using the custom_fields_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<ShortCustomField>>, Integer, Hash)> custom_fields_list_with_http_info(opts)

```ruby
begin
  # Private account institution group custom fields
  data, status_code, headers = api_instance.custom_fields_list_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<ShortCustomField>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->custom_fields_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **group_id** | **Integer** | Group_id | [optional] |

### Return type

[**Array&lt;ShortCustomField&gt;**](ShortCustomField.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## custom_fields_upload

> Object custom_fields_upload(custom_field_id, opts)

Custom fields values files upload

Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. More details in the <a href=\"#custom_fields\">Custom Fields section</a>

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
custom_field_id = 789 # Integer | Custom field identifier
opts = {
  external_file: File.new('/path/to/some/file') # File | CSV file to be uploaded
}

begin
  # Custom fields values files upload
  result = api_instance.custom_fields_upload(custom_field_id, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->custom_fields_upload: #{e}"
end
```

#### Using the custom_fields_upload_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(Object, Integer, Hash)> custom_fields_upload_with_http_info(custom_field_id, opts)

```ruby
begin
  # Custom fields values files upload
  data, status_code, headers = api_instance.custom_fields_upload_with_http_info(custom_field_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => Object
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->custom_fields_upload_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **custom_field_id** | **Integer** | Custom field identifier |  |
| **external_file** | **File** | CSV file to be uploaded | [optional] |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: multipart/form-data
- **Accept**: application/json


## get_account_institution_curation_comments

> <CurationComment> get_account_institution_curation_comments(curation_id, opts)

Institution Curation Review Comments

Retrieve a certain curation review's comments.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
curation_id = 789 # Integer | ID of the curation
opts = {
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789 # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
}

begin
  # Institution Curation Review Comments
  result = api_instance.get_account_institution_curation_comments(curation_id, opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->get_account_institution_curation_comments: #{e}"
end
```

#### Using the get_account_institution_curation_comments_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<CurationComment>, Integer, Hash)> get_account_institution_curation_comments_with_http_info(curation_id, opts)

```ruby
begin
  # Institution Curation Review Comments
  data, status_code, headers = api_instance.get_account_institution_curation_comments_with_http_info(curation_id, opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <CurationComment>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->get_account_institution_curation_comments_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **curation_id** | **Integer** | ID of the curation |  |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |

### Return type

[**CurationComment**](CurationComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## institution_articles

> <Array<Article>> institution_articles(institution_string_id, resource_id, filename)

Public Institution Articles

Returns a list of articles belonging to the institution

### Examples

```ruby
require 'time'
require 'openapi_client'

api_instance = OpenapiClient::InstitutionsApi.new
institution_string_id = 'institution_string_id_example' # String | 
resource_id = 'resource_id_example' # String | 
filename = 'filename_example' # String | 

begin
  # Public Institution Articles
  result = api_instance.institution_articles(institution_string_id, resource_id, filename)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->institution_articles: #{e}"
end
```

#### Using the institution_articles_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Article>>, Integer, Hash)> institution_articles_with_http_info(institution_string_id, resource_id, filename)

```ruby
begin
  # Public Institution Articles
  data, status_code, headers = api_instance.institution_articles_with_http_info(institution_string_id, resource_id, filename)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Article>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->institution_articles_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **institution_string_id** | **String** |  |  |
| **resource_id** | **String** |  |  |
| **filename** | **String** |  |  |

### Return type

[**Array&lt;Article&gt;**](Article.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## institution_hrfeed_upload

> <ResponseMessage> institution_hrfeed_upload(opts)

Private Institution HRfeed Upload

More info in the <a href=\"#hr_feed\">HR Feed section</a>

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
opts = {
  hrfeed: File.new('/path/to/some/file') # File | You can find an example in the Hr Feed section
}

begin
  # Private Institution HRfeed Upload
  result = api_instance.institution_hrfeed_upload(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->institution_hrfeed_upload: #{e}"
end
```

#### Using the institution_hrfeed_upload_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<ResponseMessage>, Integer, Hash)> institution_hrfeed_upload_with_http_info(opts)

```ruby
begin
  # Private Institution HRfeed Upload
  data, status_code, headers = api_instance.institution_hrfeed_upload_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <ResponseMessage>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->institution_hrfeed_upload_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **hrfeed** | **File** | You can find an example in the Hr Feed section | [optional] |

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: multipart/form-data
- **Accept**: application/json


## post_account_institution_curation_comments

> post_account_institution_curation_comments(curation_id, curation_comment)

POST Institution Curation Review Comment

Add a new comment to the review.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
curation_id = 789 # Integer | ID of the curation
curation_comment = OpenapiClient::CurationCommentCreate.new({text: 'text_example'}) # CurationCommentCreate | The content/value of the comment.

begin
  # POST Institution Curation Review Comment
  api_instance.post_account_institution_curation_comments(curation_id, curation_comment)
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->post_account_institution_curation_comments: #{e}"
end
```

#### Using the post_account_institution_curation_comments_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> post_account_institution_curation_comments_with_http_info(curation_id, curation_comment)

```ruby
begin
  # POST Institution Curation Review Comment
  data, status_code, headers = api_instance.post_account_institution_curation_comments_with_http_info(curation_id, curation_comment)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->post_account_institution_curation_comments_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **curation_id** | **Integer** | ID of the curation |  |
| **curation_comment** | [**CurationCommentCreate**](CurationCommentCreate.md) | The content/value of the comment. |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_account_institution_user

> <User> private_account_institution_user(account_id)

Private Account Institution User

Retrieve institution user information using the account_id

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
account_id = 789 # Integer | Account identifier the user is associated to

begin
  # Private Account Institution User
  result = api_instance.private_account_institution_user(account_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_account_institution_user: #{e}"
end
```

#### Using the private_account_institution_user_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<User>, Integer, Hash)> private_account_institution_user_with_http_info(account_id)

```ruby
begin
  # Private Account Institution User
  data, status_code, headers = api_instance.private_account_institution_user_with_http_info(account_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <User>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_account_institution_user_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **account_id** | **Integer** | Account identifier the user is associated to |  |

### Return type

[**User**](User.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_categories_list

> <Array<CategoryList>> private_categories_list

Private Account Categories

List institution categories (including parent Categories)

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new

begin
  # Private Account Categories
  result = api_instance.private_categories_list
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_categories_list: #{e}"
end
```

#### Using the private_categories_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<CategoryList>>, Integer, Hash)> private_categories_list_with_http_info

```ruby
begin
  # Private Account Categories
  data, status_code, headers = api_instance.private_categories_list_with_http_info
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<CategoryList>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_categories_list_with_http_info: #{e}"
end
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**Array&lt;CategoryList&gt;**](CategoryList.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_group_embargo_options_details

> <Array<GroupEmbargoOptions>> private_group_embargo_options_details(group_id)

Private Account Institution Group Embargo Options

Account institution group embargo options details

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
group_id = 789 # Integer | Group identifier

begin
  # Private Account Institution Group Embargo Options
  result = api_instance.private_group_embargo_options_details(group_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_group_embargo_options_details: #{e}"
end
```

#### Using the private_group_embargo_options_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<GroupEmbargoOptions>>, Integer, Hash)> private_group_embargo_options_details_with_http_info(group_id)

```ruby
begin
  # Private Account Institution Group Embargo Options
  data, status_code, headers = api_instance.private_group_embargo_options_details_with_http_info(group_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<GroupEmbargoOptions>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_group_embargo_options_details_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **group_id** | **Integer** | Group identifier |  |

### Return type

[**Array&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_institution_account

> <Account> private_institution_account(account_id)

Private Institution Account information

Private Institution Account information

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
account_id = 789 # Integer | Account identifier the user is associated to

begin
  # Private Institution Account information
  result = api_instance.private_institution_account(account_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_account: #{e}"
end
```

#### Using the private_institution_account_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Account>, Integer, Hash)> private_institution_account_with_http_info(account_id)

```ruby
begin
  # Private Institution Account information
  data, status_code, headers = api_instance.private_institution_account_with_http_info(account_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Account>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_account_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **account_id** | **Integer** | Account identifier the user is associated to |  |

### Return type

[**Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_institution_account_group_role_delete

> private_institution_account_group_role_delete(account_id, group_id, role_id)

Delete Institution Account Group Role

Delete Institution Account Group Role

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
account_id = 789 # Integer | Account identifier for which to remove the role
group_id = 789 # Integer | Group identifier for which to remove the role
role_id = 789 # Integer | Role identifier

begin
  # Delete Institution Account Group Role
  api_instance.private_institution_account_group_role_delete(account_id, group_id, role_id)
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_account_group_role_delete: #{e}"
end
```

#### Using the private_institution_account_group_role_delete_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_institution_account_group_role_delete_with_http_info(account_id, group_id, role_id)

```ruby
begin
  # Delete Institution Account Group Role
  data, status_code, headers = api_instance.private_institution_account_group_role_delete_with_http_info(account_id, group_id, role_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_account_group_role_delete_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **account_id** | **Integer** | Account identifier for which to remove the role |  |
| **group_id** | **Integer** | Group identifier for which to remove the role |  |
| **role_id** | **Integer** | Role identifier |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_institution_account_group_roles

> Object private_institution_account_group_roles(account_id)

List Institution Account Group Roles

List Institution Account Group Roles

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
account_id = 789 # Integer | Account identifier the user is associated to

begin
  # List Institution Account Group Roles
  result = api_instance.private_institution_account_group_roles(account_id)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_account_group_roles: #{e}"
end
```

#### Using the private_institution_account_group_roles_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(Object, Integer, Hash)> private_institution_account_group_roles_with_http_info(account_id)

```ruby
begin
  # List Institution Account Group Roles
  data, status_code, headers = api_instance.private_institution_account_group_roles_with_http_info(account_id)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => Object
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_account_group_roles_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **account_id** | **Integer** | Account identifier the user is associated to |  |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_institution_account_group_roles_create

> private_institution_account_group_roles_create(account_id, account)

Add Institution Account Group Roles

Add Institution Account Group Roles

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
account_id = 789 # Integer | Account identifier the user is associated to
account = { ... } # Object | Account description

begin
  # Add Institution Account Group Roles
  api_instance.private_institution_account_group_roles_create(account_id, account)
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_account_group_roles_create: #{e}"
end
```

#### Using the private_institution_account_group_roles_create_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_institution_account_group_roles_create_with_http_info(account_id, account)

```ruby
begin
  # Add Institution Account Group Roles
  data, status_code, headers = api_instance.private_institution_account_group_roles_create_with_http_info(account_id, account)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_account_group_roles_create_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **account_id** | **Integer** | Account identifier the user is associated to |  |
| **account** | **Object** | Account description |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_institution_accounts_create

> <AccountCreateResponse> private_institution_accounts_create(account)

Create new Institution Account

Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
account = OpenapiClient::AccountCreate.new({email: 'johndoe@example.com', last_name: 'Doe'}) # AccountCreate | Account description

begin
  # Create new Institution Account
  result = api_instance.private_institution_accounts_create(account)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_accounts_create: #{e}"
end
```

#### Using the private_institution_accounts_create_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<AccountCreateResponse>, Integer, Hash)> private_institution_accounts_create_with_http_info(account)

```ruby
begin
  # Create new Institution Account
  data, status_code, headers = api_instance.private_institution_accounts_create_with_http_info(account)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <AccountCreateResponse>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_accounts_create_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **account** | [**AccountCreate**](AccountCreate.md) | Account description |  |

### Return type

[**AccountCreateResponse**](AccountCreateResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_institution_accounts_list

> <Array<ShortAccount>> private_institution_accounts_list(opts)

Private Account Institution Accounts

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
opts = {
  page: 789, # Integer | Page number. Used for pagination with page_size
  page_size: 789, # Integer | The number of results included on a page. Used for pagination with page
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789, # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
  is_active: 789, # Integer | Filter by active status
  institution_user_id: 'institution_user_id_example', # String | Filter by institution_user_id
  email: 'email_example', # String | Filter by email
  id_lte: 789, # Integer | Retrieve accounts with an ID lower or equal to the specified value
  id_gte: 789 # Integer | Retrieve accounts with an ID greater or equal to the specified value
}

begin
  # Private Account Institution Accounts
  result = api_instance.private_institution_accounts_list(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_accounts_list: #{e}"
end
```

#### Using the private_institution_accounts_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<ShortAccount>>, Integer, Hash)> private_institution_accounts_list_with_http_info(opts)

```ruby
begin
  # Private Account Institution Accounts
  data, status_code, headers = api_instance.private_institution_accounts_list_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<ShortAccount>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_accounts_list_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **is_active** | **Integer** | Filter by active status | [optional] |
| **institution_user_id** | **String** | Filter by institution_user_id | [optional] |
| **email** | **String** | Filter by email | [optional] |
| **id_lte** | **Integer** | Retrieve accounts with an ID lower or equal to the specified value | [optional] |
| **id_gte** | **Integer** | Retrieve accounts with an ID greater or equal to the specified value | [optional] |

### Return type

[**Array&lt;ShortAccount&gt;**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_institution_accounts_search

> <Array<ShortAccount>> private_institution_accounts_search(search)

Private Account Institution Accounts Search

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
search = OpenapiClient::InstitutionAccountsSearch.new # InstitutionAccountsSearch | Search Parameters

begin
  # Private Account Institution Accounts Search
  result = api_instance.private_institution_accounts_search(search)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_accounts_search: #{e}"
end
```

#### Using the private_institution_accounts_search_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<ShortAccount>>, Integer, Hash)> private_institution_accounts_search_with_http_info(search)

```ruby
begin
  # Private Account Institution Accounts Search
  data, status_code, headers = api_instance.private_institution_accounts_search_with_http_info(search)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<ShortAccount>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_accounts_search_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **search** | [**InstitutionAccountsSearch**](InstitutionAccountsSearch.md) | Search Parameters |  |

### Return type

[**Array&lt;ShortAccount&gt;**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_institution_accounts_update

> private_institution_accounts_update(account_id, account)

Update Institution Account

Update Institution Account

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
account_id = 789 # Integer | Account identifier the user is associated to
account = OpenapiClient::AccountUpdate.new({group_id: 3.56, is_active: false}) # AccountUpdate | Account description

begin
  # Update Institution Account
  api_instance.private_institution_accounts_update(account_id, account)
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_accounts_update: #{e}"
end
```

#### Using the private_institution_accounts_update_with_http_info variant

This returns an Array which contains the response data (`nil` in this case), status code and headers.

> <Array(nil, Integer, Hash)> private_institution_accounts_update_with_http_info(account_id, account)

```ruby
begin
  # Update Institution Account
  data, status_code, headers = api_instance.private_institution_accounts_update_with_http_info(account_id, account)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => nil
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_accounts_update_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **account_id** | **Integer** | Account identifier the user is associated to |  |
| **account** | [**AccountUpdate**](AccountUpdate.md) | Account description |  |

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


## private_institution_articles

> <Array<Article>> private_institution_articles(opts)

Private Institution Articles

Get Articles from own institution. User must be administrator of the institution

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new
opts = {
  page: 789, # Integer | Page number. Used for pagination with page_size
  page_size: 789, # Integer | The number of results included on a page. Used for pagination with page
  limit: 789, # Integer | Number of results included on a page. Used for pagination with query
  offset: 789, # Integer | Where to start the listing (the offset of the first result). Used for pagination with limit
  order: 'published_date', # String | The field by which to order. Default varies by endpoint/resource.
  order_direction: 'asc', # String | 
  published_since: 'published_since_example', # String | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
  modified_since: 'modified_since_example', # String | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ
  status: 789, # Integer | only return collections with this status
  resource_doi: 'resource_doi_example', # String | only return collections with this resource_doi
  item_type: 789, # Integer | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model
  group: 789 # Integer | only return articles from this group
}

begin
  # Private Institution Articles
  result = api_instance.private_institution_articles(opts)
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_articles: #{e}"
end
```

#### Using the private_institution_articles_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Article>>, Integer, Hash)> private_institution_articles_with_http_info(opts)

```ruby
begin
  # Private Institution Articles
  data, status_code, headers = api_instance.private_institution_articles_with_http_info(opts)
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Article>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_articles_with_http_info: #{e}"
end
```

### Parameters

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **page** | **Integer** | Page number. Used for pagination with page_size | [optional] |
| **page_size** | **Integer** | The number of results included on a page. Used for pagination with page | [optional][default to 10] |
| **limit** | **Integer** | Number of results included on a page. Used for pagination with query | [optional] |
| **offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] |
| **order** | **String** | The field by which to order. Default varies by endpoint/resource. | [optional][default to &#39;published_date&#39;] |
| **order_direction** | **String** |  | [optional][default to &#39;desc&#39;] |
| **published_since** | **String** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **modified_since** | **String** | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] |
| **status** | **Integer** | only return collections with this status | [optional] |
| **resource_doi** | **String** | only return collections with this resource_doi | [optional] |
| **item_type** | **Integer** | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] |
| **group** | **Integer** | only return articles from this group | [optional] |

### Return type

[**Array&lt;Article&gt;**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_institution_details

> <Institution> private_institution_details

Private Account Institutions

Account institution details

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new

begin
  # Private Account Institutions
  result = api_instance.private_institution_details
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_details: #{e}"
end
```

#### Using the private_institution_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Institution>, Integer, Hash)> private_institution_details_with_http_info

```ruby
begin
  # Private Account Institutions
  data, status_code, headers = api_instance.private_institution_details_with_http_info
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Institution>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_details_with_http_info: #{e}"
end
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**Institution**](Institution.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_institution_embargo_options_details

> <Array<GroupEmbargoOptions>> private_institution_embargo_options_details

Private Account Institution embargo options

Account institution embargo options details

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new

begin
  # Private Account Institution embargo options
  result = api_instance.private_institution_embargo_options_details
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_embargo_options_details: #{e}"
end
```

#### Using the private_institution_embargo_options_details_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<GroupEmbargoOptions>>, Integer, Hash)> private_institution_embargo_options_details_with_http_info

```ruby
begin
  # Private Account Institution embargo options
  data, status_code, headers = api_instance.private_institution_embargo_options_details_with_http_info
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<GroupEmbargoOptions>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_embargo_options_details_with_http_info: #{e}"
end
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**Array&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_institution_groups_list

> <Array<Group>> private_institution_groups_list

Private Account Institution Groups

Returns the groups for which the account has administrative privileges (assigned and inherited).

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new

begin
  # Private Account Institution Groups
  result = api_instance.private_institution_groups_list
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_groups_list: #{e}"
end
```

#### Using the private_institution_groups_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Group>>, Integer, Hash)> private_institution_groups_list_with_http_info

```ruby
begin
  # Private Account Institution Groups
  data, status_code, headers = api_instance.private_institution_groups_list_with_http_info
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Group>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_groups_list_with_http_info: #{e}"
end
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**Array&lt;Group&gt;**](Group.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


## private_institution_roles_list

> <Array<Role>> private_institution_roles_list

Private Account Institution Roles

Returns the roles available for groups and the institution group.

### Examples

```ruby
require 'time'
require 'openapi_client'
# setup authorization
OpenapiClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = OpenapiClient::InstitutionsApi.new

begin
  # Private Account Institution Roles
  result = api_instance.private_institution_roles_list
  p result
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_roles_list: #{e}"
end
```

#### Using the private_institution_roles_list_with_http_info variant

This returns an Array which contains the response data, status code and headers.

> <Array(<Array<Role>>, Integer, Hash)> private_institution_roles_list_with_http_info

```ruby
begin
  # Private Account Institution Roles
  data, status_code, headers = api_instance.private_institution_roles_list_with_http_info
  p status_code # => 2xx
  p headers # => { ... }
  p data # => <Array<Role>>
rescue OpenapiClient::ApiError => e
  puts "Error when calling InstitutionsApi->private_institution_roles_list_with_http_info: #{e}"
end
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**Array&lt;Role&gt;**](Role.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

