# OpenapiClient::Group

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | Group id |  |
| **name** | **String** | Group name |  |
| **resource_id** | **String** | Group resource id |  |
| **parent_id** | **Integer** | Parent group if any |  |
| **association_criteria** | **String** | HR code associated with group, if code exists |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::Group.new(
  id: 1,
  name: Materials,
  resource_id: ,
  parent_id: 0,
  association_criteria: IT
)
```

