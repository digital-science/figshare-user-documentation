# OpenapiClient::AltmetricInstitution

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | Institution id |  |
| **name** | **String** | Institution name |  |
| **custom_domain** | **String** | Custom domain for the institution | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AltmetricInstitution.new(
  id: 1,
  name: My Institution,
  custom_domain: myinstitution.figshare.com
)
```

