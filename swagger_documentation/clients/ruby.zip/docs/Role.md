# OpenapiClient::Role

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | Role id |  |
| **name** | **String** | Role name |  |
| **category** | **String** | Role category |  |
| **description** | **String** | Role description |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::Role.new(
  id: 1,
  name: Curator,
  category: group,
  description: null
)
```

