# OpenapiClient::ProjectNoteCreate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **text** | **String** | Text of the note |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ProjectNoteCreate.new(
  text: note to remember
)
```

