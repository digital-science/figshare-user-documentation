# SwaggerClient::Institution

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Institution id | 
**name** | **String** | Institution name | 


