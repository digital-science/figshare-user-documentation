# OpenapiClient::ArticleProjectCreate

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **title** | **String** | Title of article |  |
| **description** | **String** | The article description. In a publisher case, usually this is the remote article description | [optional][default to &#39;&#39;] |
| **tags** | **Array&lt;String&gt;** | List of tags to be associated with the article. Keywords can be used instead | [optional] |
| **keywords** | **Array&lt;String&gt;** | List of tags to be associated with the article. Tags can be used instead | [optional] |
| **references** | **Array&lt;String&gt;** | List of links to be associated with the article (e.g [\&quot;http://link1\&quot;, \&quot;http://link2\&quot;, \&quot;http://link3\&quot;]) | [optional] |
| **related_materials** | [**Array&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] |
| **categories** | **Array&lt;Integer&gt;** | List of category ids to be associated with the article(e.g [1, 23, 33, 66]) | [optional] |
| **categories_by_source_id** | **Array&lt;String&gt;** | List of category source ids to be associated with the article, supersedes the categories property | [optional] |
| **authors** | **Array&lt;Object&gt;** | List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint. | [optional] |
| **custom_fields** | **Object** | List of key, values pairs to be associated with the article | [optional] |
| **custom_fields_list** | [**Array&lt;CustomArticleFieldAdd&gt;**](CustomArticleFieldAdd.md) | List of custom fields values, supersedes custom_fields parameter | [optional] |
| **defined_type** | **String** | &lt;b&gt;One of:&lt;/b&gt; &lt;code&gt;figure&lt;/code&gt; &lt;code&gt;online resource&lt;/code&gt; &lt;code&gt;preprint&lt;/code&gt; &lt;code&gt;book&lt;/code&gt; &lt;code&gt;conference contribution&lt;/code&gt; &lt;code&gt;media&lt;/code&gt; &lt;code&gt;dataset&lt;/code&gt; &lt;code&gt;poster&lt;/code&gt; &lt;code&gt;journal contribution&lt;/code&gt; &lt;code&gt;presentation&lt;/code&gt; &lt;code&gt;thesis&lt;/code&gt; &lt;code&gt;software&lt;/code&gt; | [optional] |
| **funding** | **String** | Grant number or funding authority | [optional][default to &#39;&#39;] |
| **funding_list** | [**Array&lt;FundingCreate&gt;**](FundingCreate.md) | Funding creation / update items | [optional] |
| **license** | **Integer** | License id for this article. | [optional][default to 0] |
| **doi** | **String** | Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional][default to &#39;&#39;] |
| **handle** | **String** | Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional][default to &#39;&#39;] |
| **resource_doi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [optional][default to &#39;&#39;] |
| **resource_title** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [optional][default to &#39;&#39;] |
| **timeline** | [**TimelineUpdate**](TimelineUpdate.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ArticleProjectCreate.new(
  title: Test article title,
  description: Test description of article,
  tags: [&quot;tag1&quot;,&quot;tag2&quot;],
  keywords: [&quot;tag1&quot;,&quot;tag2&quot;],
  references: [&quot;http://figshare.com&quot;,&quot;http://api.figshare.com&quot;],
  related_materials: [{&quot;id&quot;:10432,&quot;identifier&quot;:&quot;10.6084/m9.figshare.1407024&quot;,&quot;identifier_type&quot;:&quot;DOI&quot;,&quot;relation&quot;:&quot;IsSupplementTo&quot;,&quot;title&quot;:&quot;Figshare for institutions brochure&quot;,&quot;is_linkout&quot;:false}],
  categories: [1,10,11],
  categories_by_source_id: [&quot;300204&quot;,&quot;400207&quot;],
  authors: [{&quot;name&quot;:&quot;John Doe&quot;},{&quot;id&quot;:1000008}],
  custom_fields: {&quot;defined_key&quot;:&quot;value for it&quot;},
  custom_fields_list: null,
  defined_type: media,
  funding: null,
  funding_list: null,
  license: 1,
  doi: null,
  handle: null,
  resource_doi: null,
  resource_title: null,
  timeline: null
)
```

