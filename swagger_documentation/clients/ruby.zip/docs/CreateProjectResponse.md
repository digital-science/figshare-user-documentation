# OpenapiClient::CreateProjectResponse

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **entity_id** | **Integer** | Figshare ID of the entity |  |
| **location** | **String** | Url for entity |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CreateProjectResponse.new(
  entity_id: 33334444,
  location: null
)
```

