# SwaggerClient::TimelineUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_online** | **String** | Online posted date | [optional] 
**publisher_publication** | **String** | Publish date | [optional] 
**publisher_acceptance** | **String** | Date when the item was accepted for publication | [optional] 


