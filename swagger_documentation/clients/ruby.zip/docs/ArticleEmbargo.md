# OpenapiClient::ArticleEmbargo

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **is_embargoed** | **Boolean** | True if embargoed |  |
| **embargo_title** | **String** | Title for embargo |  |
| **embargo_reason** | **String** | Reason for embargo |  |
| **embargo_options** | **Array&lt;Object&gt;** | List of embargo permissions that are associated with the article. If the type is logged_in and the group_ids list is empty, then the whole institution can see the article; if there are multiple group_ids, then only users that are under those groups can see the article. |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ArticleEmbargo.new(
  is_embargoed: true,
  embargo_title: File(s) under embargo,
  embargo_reason: ,
  embargo_options: [{&quot;id&quot;:13,&quot;type&quot;:&quot;ip_range&quot;,&quot;group_ids&quot;:[],&quot;ip_name&quot;:&quot;bacau&quot;},{&quot;id&quot;:12,&quot;type&quot;:&quot;logged_in&quot;,&quot;ip_name&quot;:&quot;&quot;,&quot;group_ids&quot;:[550,9448]}]
)
```

