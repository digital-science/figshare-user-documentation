# OpenapiClient::ProjectCollaborator

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **status** | **String** | Status of collaborator invitation |  |
| **role_name** | **String** | Collaborator role |  |
| **user_id** | **Integer** | Collaborator id |  |
| **name** | **String** | Collaborator name |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ProjectCollaborator.new(
  status: invited,
  role_name: Owner,
  user_id: 1,
  name: name
)
```

