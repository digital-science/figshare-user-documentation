# OpenapiClient::User

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | User id |  |
| **first_name** | **String** | First Name |  |
| **last_name** | **String** | Last Name |  |
| **name** | **String** | Full Name |  |
| **is_active** | **Boolean** | Account activity status |  |
| **url_name** | **String** | Name that appears in website url |  |
| **is_public** | **Boolean** | Account public status |  |
| **job_title** | **String** | User Job title |  |
| **orcid_id** | **String** | Orcid associated to this User |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::User.new(
  id: 1495682,
  first_name: Doe,
  last_name: John,
  name: John Doe,
  is_active: true,
  url_name: John_Doe,
  is_public: true,
  job_title: programmer,
  orcid_id: 1234-5678-9123-1234
)
```

