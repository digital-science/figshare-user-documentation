# SwaggerClient::User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | User id | 
**first_name** | **String** | First Name | 
**last_name** | **String** | Last Name | 
**name** | **String** | Full Name | 
**is_active** | **BOOLEAN** | Account activity status | 
**url_name** | **String** | Name that appears in website url | 
**is_public** | **BOOLEAN** | Account public status | 
**job_title** | **String** | User Job title | 
**orcid_id** | **String** | Orcid associated to this User | 


