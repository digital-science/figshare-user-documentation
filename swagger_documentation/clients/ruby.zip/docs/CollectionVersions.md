# OpenapiClient::CollectionVersions

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **version** | **Integer** | Version number |  |
| **url** | **String** | Api endpoint for the collection version |  |
| **funding** | [**Array&lt;FundingInformation&gt;**](FundingInformation.md) | Full Collection funding information |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CollectionVersions.new(
  version: 1,
  url: https://api.figshare.com/v2/collections/2000005/versions/1,
  funding: null
)
```

