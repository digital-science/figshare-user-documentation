# SwaggerClient::CollectionVersions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **Integer** | Version number | 
**url** | **String** | Api endpoint for the collection version | 
**funding** | [**Array&lt;FundingInformation&gt;**](FundingInformation.md) | Full Collection funding information | 


