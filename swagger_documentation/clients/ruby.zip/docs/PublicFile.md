# OpenapiClient::PublicFile

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | File id |  |
| **name** | **String** | File name |  |
| **size** | **Integer** | File size |  |
| **is_link_only** | **Boolean** | True if file is hosted somewhere else |  |
| **download_url** | **String** | Url for file download |  |
| **supplied_md5** | **String** | File supplied md5 |  |
| **computed_md5** | **String** | File computed md5 |  |
| **mimetype** | **String** | MIME Type of the file, it defaults to an empty string | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::PublicFile.new(
  id: 3000002,
  name: test.xls,
  size: 14848,
  is_link_only: false,
  download_url: https://ndownloader.figshare.com/files/3000002,
  supplied_md5: 043a51806d646e88cafbf19e7b82846f,
  computed_md5: 043a51806d646e88cafbf19e7b82846f,
  mimetype: application/pdf
)
```

