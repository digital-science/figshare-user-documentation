# OpenapiClient::FileId

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **file_id** | **Integer** | File ID | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::FileId.new(
  file_id: 123
)
```

