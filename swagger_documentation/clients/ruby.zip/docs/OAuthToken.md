# OpenapiClient::OAuthToken

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **access_token** | **String** | The OAuth access token |  |
| **token** | **String** | The OAuth access token | [optional] |
| **token_type** | **String** | The type of token issued |  |
| **expires_in** | **Integer** | Token expiration time in seconds |  |
| **refresh_token** | **String** | The refresh token (only provided for certain grant types) | [optional] |
| **scope** | **String** | The scope of the access token | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::OAuthToken.new(
  access_token: abcd1234567890efgh,
  token: abcd1234567890efgh,
  token_type: bearer,
  expires_in: 3600,
  refresh_token: refresh_abcd1234567890efgh,
  scope: all
)
```

