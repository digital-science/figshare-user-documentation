# SwaggerClient::OAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_token** | **String** | The OAuth access token | 
**token** | **String** | The OAuth access token | [optional] 
**token_type** | **String** | The type of token issued | 
**expires_in** | **Integer** | Token expiration time in seconds | 
**refresh_token** | **String** | The refresh token (only provided for certain grant types) | [optional] 
**scope** | **String** | The scope of the access token | [optional] 


