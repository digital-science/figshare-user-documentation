# OpenapiClient::PrivateProjectArticle

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **files** | [**Array&lt;PublicFile&gt;**](PublicFile.md) | List of up to 10 article files. |  |
| **embargo_options** | [**Array&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md) | List of embargo options |  |
| **custom_fields** | [**Array&lt;CustomArticleField&gt;**](CustomArticleField.md) | List of custom fields values |  |
| **account_id** | **Integer** | ID of the account owning the article |  |
| **download_disabled** | **Boolean** | If true, downloading of files for this article is disabled |  |
| **authors** | [**Array&lt;Author&gt;**](Author.md) | List of authors |  |
| **figshare_url** | **String** | Article public url |  |
| **curation_status** | **String** | Curation status of the article |  |
| **citation** | **String** | Article citation |  |
| **confidential_reason** | **String** | Confidentiality reason |  |
| **is_confidential** | **Boolean** | Article Confidentiality |  |
| **size** | **Integer** | Article size |  |
| **funding** | **String** | Article funding |  |
| **funding_list** | [**Array&lt;FundingInformation&gt;**](FundingInformation.md) | Full Article funding information |  |
| **tags** | **Array&lt;String&gt;** | List of article tags. Keywords can be used instead |  |
| **keywords** | **Array&lt;String&gt;** | List of article keywords. Tags can be used instead |  |
| **version** | **Integer** | Article version |  |
| **is_metadata_record** | **Boolean** | True if article has no files |  |
| **metadata_reason** | **String** | Article metadata reason |  |
| **status** | **String** | Article status |  |
| **description** | **String** | Article description |  |
| **is_embargoed** | **Boolean** | True if article is embargoed |  |
| **is_public** | **Boolean** | True if article is published |  |
| **created_date** | **String** | Date when article was created |  |
| **has_linked_file** | **Boolean** | True if any files are linked to the article |  |
| **categories** | [**Array&lt;Category&gt;**](Category.md) | List of categories selected for the article |  |
| **license** | [**License**](License.md) |  |  |
| **embargo_title** | **String** | Title for embargo |  |
| **embargo_reason** | **String** | Reason for embargo |  |
| **references** | **Array&lt;String&gt;** | List of references |  |
| **related_materials** | [**Array&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] |
| **id** | **Integer** | Unique identifier for article |  |
| **title** | **String** | Title of article |  |
| **doi** | **String** | DOI |  |
| **handle** | **String** | Handle |  |
| **url** | **String** | Api endpoint for article |  |
| **url_public_html** | **String** | Public site endpoint for article |  |
| **url_public_api** | **String** | Public Api endpoint for article |  |
| **url_private_html** | **String** | Private site endpoint for article |  |
| **url_private_api** | **String** | Private Api endpoint for article |  |
| **timeline** | [**Timeline**](Timeline.md) |  |  |
| **thumb** | **String** | Thumbnail image |  |
| **defined_type** | **Integer** | Type of article identifier |  |
| **defined_type_name** | **String** | Name of the article type identifier |  |
| **resource_doi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to &#39;&#39;] |
| **resource_title** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to &#39;&#39;] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::PrivateProjectArticle.new(
  files: null,
  embargo_options: null,
  custom_fields: null,
  account_id: 1000001,
  download_disabled: false,
  authors: null,
  figshare_url: http://figshare.com/articles/media/article_name/2000005,
  curation_status: approved,
  citation: lilliput, figshare admin (2017): first project item. figshare.
 
 Retrieved: 14 01, May 22, 2017 (GMT),
  confidential_reason: none,
  is_confidential: true,
  size: 69939,
  funding: none,
  funding_list: null,
  tags: [t1, t2, t3],
  keywords: [t1, t2, t3],
  version: 1,
  is_metadata_record: false,
  metadata_reason: hosted somewhere else,
  status: public,
  description: article description,
  is_embargoed: true,
  is_public: true,
  created_date: 2017-05-18T11:49:03Z,
  has_linked_file: true,
  categories: null,
  license: null,
  embargo_title: File(s) under embargo,
  embargo_reason: not complete,
  references: [http://figshare.com, http://figshare.com/api],
  related_materials: [{id&#x3D;10432, identifier&#x3D;10.6084/m9.figshare.1407024, identifier_type&#x3D;DOI, relation&#x3D;IsSupplementTo, title&#x3D;Figshare for institutions brochure, is_linkout&#x3D;false}],
  id: 1434614,
  title: Test article title,
  doi: 10.6084/m9.figshare.1434614,
  handle: 111184/figshare.1234,
  url: http://api.figshare.com/articles/1434614,
  url_public_html: https://figshare.com/articles/media/Test_article_title/1434614,
  url_public_api: https://api.figshare.com/articles/1434614,
  url_private_html: https://figshare.com/account/articles/1434614,
  url_private_api: https://api.figshare.com/account/articles/1434614,
  timeline: null,
  thumb: https://ndownloader.figshare.com/files/123456789/preview/12345678/thumb.png,
  defined_type: 3,
  defined_type_name: media,
  resource_doi: null,
  resource_title: null
)
```

