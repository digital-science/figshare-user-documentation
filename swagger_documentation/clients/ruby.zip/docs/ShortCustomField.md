# OpenapiClient::ShortCustomField

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | Custom field id |  |
| **name** | **String** | Custom field name |  |
| **field_type** | **String** | Custom field type |  |
| **settings** | **Object** | Settings for the custom field | [optional] |
| **order** | **Integer** | Order of the field in the group | [optional] |
| **is_mandatory** | **Boolean** | Whether the field is mandatory or not | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ShortCustomField.new(
  id: 365,
  name: my custom field,
  field_type: textarea,
  settings: {&quot;validations&quot;:{&quot;min_length&quot;:1,&quot;max_length&quot;:1000},&quot;placeholder&quot;:&quot;Enter your custom field here&quot;},
  order: 1,
  is_mandatory: false
)
```

