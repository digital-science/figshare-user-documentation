# SwaggerClient::ShortCustomField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Custom field id | 
**name** | **String** | Custom field name | 
**field_type** | **String** | Custom field type | 
**settings** | **Object** | Settings for the custom field | [optional] 
**order** | **Integer** | Order of the field in the group | [optional] 


