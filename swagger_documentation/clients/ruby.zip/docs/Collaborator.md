# OpenapiClient::Collaborator

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **role_name** | **String** | Collaborator role |  |
| **user_id** | **Integer** | Collaborator id |  |
| **name** | **String** | Collaborator name |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::Collaborator.new(
  role_name: Owner,
  user_id: 1,
  name: name
)
```

