# OpenapiClient::ArticlesCreator

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **articles** | **Array&lt;Integer&gt;** | List of article ids |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ArticlesCreator.new(
  articles: [2000003,2000004]
)
```

