# OpenapiClient::AuthorComplete

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **institution_id** | **Integer** | Institution id |  |
| **group_id** | **Integer** | Group id |  |
| **first_name** | **String** | First Name |  |
| **last_name** | **String** | Last Name |  |
| **is_public** | **Integer** | if 1 then the author has published items |  |
| **job_title** | **String** | Job title |  |
| **id** | **Integer** | Author id |  |
| **full_name** | **String** | Author full name |  |
| **is_active** | **Boolean** | True if author has published items |  |
| **url_name** | **String** | Author url name |  |
| **orcid_id** | **String** | Author Orcid |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::AuthorComplete.new(
  institution_id: null,
  group_id: null,
  first_name: null,
  last_name: null,
  is_public: null,
  job_title: null,
  id: 97657,
  full_name: John Doe,
  is_active: false,
  url_name: John_Doe,
  orcid_id: 1234-5678-9123-1234
)
```

