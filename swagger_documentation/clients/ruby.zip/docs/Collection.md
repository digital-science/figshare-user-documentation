# OpenapiClient::Collection

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | Collection id |  |
| **title** | **String** | Collection title |  |
| **doi** | **String** | Collection DOI |  |
| **handle** | **String** | Collection Handle |  |
| **url** | **String** | Api endpoint |  |
| **timeline** | [**Timeline**](Timeline.md) |  |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::Collection.new(
  id: 123,
  title: Sample collection,
  doi: 10.6084/m9.figshare.123,
  handle: 111184/figshare.1234,
  url: https://api.figshare.com/v2/collections/123,
  timeline: null
)
```

