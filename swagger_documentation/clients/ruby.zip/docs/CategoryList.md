# SwaggerClient::CategoryList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent_id** | **Integer** | Parent category | 
**id** | **Integer** | Category id | 
**title** | **String** | Category title | 
**path** | **String** | Path to all ancestor ids | 
**source_id** | **String** | ID in original standard taxonomy | 
**taxonomy_id** | **Integer** | Internal id of taxonomy the category is part of | 
**is_selectable** | **BOOLEAN** | The selectable status | 
**has_children** | **BOOLEAN** | True if category has children | 


