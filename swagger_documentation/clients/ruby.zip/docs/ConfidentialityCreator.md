# OpenapiClient::ConfidentialityCreator

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **reason** | **String** | Reason for confidentiality |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ConfidentialityCreator.new(
  reason: null
)
```

