# OpenapiClient::UploadFilePart

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **part_no** | **Integer** | File part id | [optional] |
| **start_offset** | **Integer** | Indexes on byte range. zero-based and inclusive | [optional] |
| **end_offset** | **Integer** | Indexes on byte range. zero-based and inclusive | [optional] |
| **status** | **String** | part status | [optional] |
| **locked** | **Boolean** | When a part is being uploaded it is being locked, by setting the locked flag to true. No changes/uploads can happen on this part from other requests. | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::UploadFilePart.new(
  part_no: 1,
  start_offset: 0,
  end_offset: 69,
  status: null,
  locked: null
)
```

