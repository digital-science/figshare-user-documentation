# OpenapiClient::PrivateLinkResponse

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **location** | **String** | Url for private link |  |
| **html_location** | **String** | HTML url for private link |  |
| **token** | **String** | Token for private link |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::PrivateLinkResponse.new(
  location: null,
  html_location: https://figshare.com/s/d5ec7a85bcd6dbe9d9b2,
  token: d5ec7a85bcd6dbe9d9b2
)
```

