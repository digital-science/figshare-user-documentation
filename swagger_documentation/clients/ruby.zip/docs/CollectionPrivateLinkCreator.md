# SwaggerClient::CollectionPrivateLinkCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expires_date** | **String** | Date when this private link should expire - optional. By default private links expire in 365 days. | [optional] 
**read_only** | **BOOLEAN** | Optional, default true. Set to false to give private link users editing rights for this collection. | [optional] 


