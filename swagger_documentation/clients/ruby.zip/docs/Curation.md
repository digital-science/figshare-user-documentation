# OpenapiClient::Curation

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **id** | **Integer** | The review id |  |
| **group_id** | **Integer** | The group in which the article is present. |  |
| **account_id** | **Integer** | The ID of the account of the owner of the article of this review. |  |
| **assigned_to** | **Integer** | The ID of the account to which this review is assigned. |  |
| **article_id** | **Integer** | The ID of the article of this review. |  |
| **version** | **Integer** | The Version number of the article in review. |  |
| **comments_count** | **Integer** | The number of comments in the review. |  |
| **status** | **String** | The status of the review. |  |
| **created_date** | **String** | The creation date of the review. |  |
| **modified_date** | **String** | The date the review has been modified. |  |
| **request_number** | **Integer** | The request number of the review. |  |
| **resolution_comment** | **String** | The resolution comment of the review. |  |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::Curation.new(
  id: null,
  group_id: null,
  account_id: null,
  assigned_to: null,
  article_id: null,
  version: null,
  comments_count: null,
  status: null,
  created_date: null,
  modified_date: null,
  request_number: null,
  resolution_comment: null
)
```

