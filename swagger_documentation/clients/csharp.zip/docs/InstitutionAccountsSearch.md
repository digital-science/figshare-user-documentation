# Org.OpenAPITools.Model.InstitutionAccountsSearch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SearchFor** | **string** | Search term | [optional] 
**IsActive** | **long** | Filter by active status | [optional] 
**Page** | **long** | Page number. Used for pagination with page_size | [optional] 
**PageSize** | **long** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**Limit** | **long** | Number of results included on a page. Used for pagination with query | [optional] 
**Offset** | **long** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
**InstitutionUserId** | **string** | filter by institution_user_id | [optional] 
**Email** | **string** | filter by email | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

