# IO.Swagger.Model.User
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | User id | 
**FirstName** | **string** | First Name | 
**LastName** | **string** | Last Name | 
**Name** | **string** | Full Name | 
**IsActive** | **bool?** | Account activity status | 
**UrlName** | **string** | Name that appears in website url | 
**IsPublic** | **bool?** | Account public status | 
**JobTitle** | **string** | User Job title | 
**OrcidId** | **string** | Orcid associated to this User | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

