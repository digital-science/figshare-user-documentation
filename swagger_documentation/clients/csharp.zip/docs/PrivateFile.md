# Org.OpenAPITools.Model.PrivateFile

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ViewerType** | **string** | File viewer type | 
**PreviewState** | **string** | File preview state | 
**UploadUrl** | **string** | Upload url for file | 
**UploadToken** | **string** | Token for file upload | 
**IsAttachedToPublicVersion** | **bool** | True if the file is attached to a public item version | 
**Id** | **int** | File id | 
**Name** | **string** | File name | 
**Size** | **int** | File size | 
**IsLinkOnly** | **bool** | True if file is hosted somewhere else | 
**DownloadUrl** | **string** | Url for file download | 
**SuppliedMd5** | **string** | File supplied md5 | 
**ComputedMd5** | **string** | File computed md5 | 
**Mimetype** | **string** | MIME Type of the file, it defaults to an empty string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

