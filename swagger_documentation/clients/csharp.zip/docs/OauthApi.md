# Org.OpenAPITools.Api.OauthApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**CreateToken**](OauthApi.md#createtoken) | **POST** /token | Create OAuth token |
| [**GetTokenInfo**](OauthApi.md#gettokeninfo) | **GET** /token | Get OAuth token information |

<a id="createtoken"></a>
# **CreateToken**
> OAuthToken CreateToken (CreateOAuthToken? body = null)

Create OAuth token

Creates OAuth token using various grant types

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class CreateTokenExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new OauthApi(config);
            var body = new CreateOAuthToken?(); // CreateOAuthToken? | Create OAuth Token Parameters (optional) 

            try
            {
                // Create OAuth token
                OAuthToken result = apiInstance.CreateToken(body);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling OauthApi.CreateToken: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the CreateTokenWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create OAuth token
    ApiResponse<OAuthToken> response = apiInstance.CreateTokenWithHttpInfo(body);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling OauthApi.CreateTokenWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **body** | [**CreateOAuthToken?**](CreateOAuthToken?.md) | Create OAuth Token Parameters | [optional]  |

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Token created successfully &lt;a href&#x3D;&#39;http://tools.ietf.org/html/rfc6749#section-5.1&#39; target&#x3D;&#39;_blank&#39;&gt;RFC 6749 Section 5.1&lt;/a&gt;. |  -  |
| **400** | Bad Request &lt;a href&#x3D;&#39;http://tools.ietf.org/html/rfc6749#section-5.2&#39; target&#x3D;&#39;_blank&#39;&gt;RFC 6749 Section 5.2&lt;/a&gt;. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="gettokeninfo"></a>
# **GetTokenInfo**
> OAuthToken GetTokenInfo (string? accessToken = null)

Get OAuth token information

Returns information about the current OAuth token

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class GetTokenInfoExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new OauthApi(config);
            var accessToken = "accessToken_example";  // string? | OAuth access token (optional) 

            try
            {
                // Get OAuth token information
                OAuthToken result = apiInstance.GetTokenInfo(accessToken);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling OauthApi.GetTokenInfo: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the GetTokenInfoWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Get OAuth token information
    ApiResponse<OAuthToken> response = apiInstance.GetTokenInfoWithHttpInfo(accessToken);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling OauthApi.GetTokenInfoWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **accessToken** | **string?** | OAuth access token | [optional]  |

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Token information |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

