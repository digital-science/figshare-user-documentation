# IO.Swagger.Model.AuthorComplete
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Author id | 
**FullName** | **string** | Author full name | 
**FirstName** | **string** | First Name | 
**LastName** | **string** | Last Name | 
**IsActive** | **bool?** | True if author has published items | 
**UrlName** | **string** | Author url name | 
**OrcidId** | **string** | Author Orcid | 
**InstitutionId** | **long?** | Institution id | 
**GroupId** | **long?** | Group id | 
**IsPublic** | **long?** | if 1 then the author has published items | 
**JobTitle** | **string** | Job title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

