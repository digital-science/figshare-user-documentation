# Org.OpenAPITools.Model.AuthorComplete

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstitutionId** | **int** | Institution id | 
**GroupId** | **int** | Group id | 
**FirstName** | **string** | First Name | 
**LastName** | **string** | Last Name | 
**IsPublic** | **int** | if 1 then the author has published items | 
**JobTitle** | **string** | Job title | 
**Id** | **int** | Author id | 
**FullName** | **string** | Author full name | 
**IsActive** | **bool** | True if author has published items | 
**UrlName** | **string** | Author url name | 
**OrcidId** | **string** | Author Orcid | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

