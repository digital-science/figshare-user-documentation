# IO.Swagger.Model.ArticleComplete
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Citation** | **string** | Article citation | [optional] 
**ConfidentialReason** | **string** | Confidentiality reason | [optional] 
**IsConfidential** | **bool?** | Article Confidentiality | [optional] 
**Size** | **long?** | Article size | [optional] 
**Funding** | **string** | Article funding | [optional] 
**FundingList** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Article funding information | [optional] 
**Tags** | **List&lt;string&gt;** | List of article tags. Keywords can be used instead | [optional] 
**Keywords** | **List&lt;string&gt;** | List of article keywords. Tags can be used instead | [optional] 
**Version** | **long?** | Article version | [optional] 
**IsMetadataRecord** | **bool?** | True if article has no files | [optional] 
**MetadataReason** | **string** | Article metadata reason | [optional] 
**Status** | **string** | Article status | [optional] 
**Description** | **string** | Article description | [optional] 
**IsEmbargoed** | **bool?** | True if article is embargoed | [optional] 
**IsPublic** | **bool?** | True if article is published | [optional] 
**CreatedDate** | **string** | Date when article was created | 
**HasLinkedFile** | **bool?** | True if any files are linked to the article | [optional] 
**Categories** | [**List&lt;Category&gt;**](Category.md) | List of categories selected for the article | [optional] 
**License** | [**License**](License.md) | Article selected license | [optional] 
**EmbargoTitle** | **string** | Title for embargo | [optional] 
**EmbargoReason** | **string** | Reason for embargo | [optional] 
**References** | **List&lt;string&gt;** | List of references | [optional] 
**RelatedMaterials** | [**List&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 
**Id** | **long?** | Unique identifier for article | 
**Title** | **string** | Title of article | 
**Doi** | **string** | DOI | 
**Handle** | **string** | Handle | 
**Url** | **string** | Api endpoint for article | 
**UrlPublicHtml** | **string** | Public site endpoint for article | 
**UrlPublicApi** | **string** | Public Api endpoint for article | 
**UrlPrivateHtml** | **string** | Private site endpoint for article | 
**UrlPrivateApi** | **string** | Private Api endpoint for article | 
**Timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**Thumb** | **string** | Thumbnail image | 
**DefinedType** | **long?** | Type of article identifier | 
**DefinedTypeName** | **string** | Name of the article type identifier | 
**ResourceDoi** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to ""]
**ResourceTitle** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to ""]
**FigshareUrl** | **string** | Article public url | 
**DownloadDisabled** | **bool?** | If true, downloading of files for this article is disabled | 
**Files** | [**List&lt;PublicFile&gt;**](PublicFile.md) | List of article files | 
**FolderStructure** | **Object** | Mapping of file ids to folder paths, if folders are used | 
**Authors** | [**List&lt;Author&gt;**](Author.md) | List of article authors | 
**CustomFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | List of custom fields values | 
**EmbargoOptions** | [**List&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md) | List of embargo options | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

