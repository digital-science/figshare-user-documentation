# Org.OpenAPITools.Model.CollectionSearch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ResourceDoi** | **string** | Only return collections with this resource_doi | [optional] 
**Doi** | **string** | Only return collections with this doi | [optional] 
**Handle** | **string** | Only return collections with this handle | [optional] 
**Order** | **string** | The field by which to order. | [optional] [default to OrderEnum.CreatedDate]
**SearchFor** | **string** | Search term | [optional] 
**Page** | **long** | Page number. Used for pagination with page_size | [optional] 
**PageSize** | **long** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**Limit** | **long** | Number of results included on a page. Used for pagination with query | [optional] 
**Offset** | **long** | Where to start the listing(the offset of the first result). Used for pagination with limit | [optional] 
**OrderDirection** | **string** | Direction of ordering | [optional] [default to OrderDirectionEnum.Desc]
**Institution** | **int** | only return collections from this institution | [optional] 
**PublishedSince** | **string** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
**ModifiedSince** | **string** | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
**Group** | **int** | only return collections from this group | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

