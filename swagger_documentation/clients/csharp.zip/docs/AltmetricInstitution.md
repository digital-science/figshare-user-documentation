# Org.OpenAPITools.Model.AltmetricInstitution

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** | Institution id | 
**Name** | **string** | Institution name | 
**CustomDomain** | **string** | Custom domain for the institution | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

