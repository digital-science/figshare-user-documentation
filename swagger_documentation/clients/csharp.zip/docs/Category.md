# IO.Swagger.Model.Category
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ParentId** | **long?** | Parent category | 
**Id** | **long?** | Category id | 
**Title** | **string** | Category title | 
**Path** | **string** | Path to all ancestor ids | 
**SourceId** | **string** | ID in original standard taxonomy | 
**TaxonomyId** | **long?** | Internal id of taxonomy the category is part of | 
**HasChildren** | **bool?** | True if category has children | 
**IsSelectable** | **bool?** | The selectable status | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

