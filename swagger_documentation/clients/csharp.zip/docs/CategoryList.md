# Org.OpenAPITools.Model.CategoryList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IsSelectable** | **bool** | The selectable status | 
**HasChildren** | **bool** | True if category has children | 
**ParentId** | **int** | Parent category | 
**Id** | **int** | Category id | 
**Title** | **string** | Category title | 
**Path** | **string** | Path to all ancestor ids | 
**SourceId** | **string** | ID in original standard taxonomy | 
**TaxonomyId** | **int** | Internal id of taxonomy the category is part of | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

