# Org.OpenAPITools.Model.SymplecticUserId200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstitutionUserId** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

