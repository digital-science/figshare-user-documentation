# Org.OpenAPITools.Api.ProjectsApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**PrivateProjectArticleDelete**](ProjectsApi.md#privateprojectarticledelete) | **DELETE** /account/projects/{project_id}/articles/{article_id} | Delete project article |
| [**PrivateProjectArticleDetails**](ProjectsApi.md#privateprojectarticledetails) | **GET** /account/projects/{project_id}/articles/{article_id} | Project article details |
| [**PrivateProjectArticleFile**](ProjectsApi.md#privateprojectarticlefile) | **GET** /account/projects/{project_id}/articles/{article_id}/files/{file_id} | Project article file details |
| [**PrivateProjectArticleFiles**](ProjectsApi.md#privateprojectarticlefiles) | **GET** /account/projects/{project_id}/articles/{article_id}/files | Project article list files |
| [**PrivateProjectArticlesCreate**](ProjectsApi.md#privateprojectarticlescreate) | **POST** /account/projects/{project_id}/articles | Create project article |
| [**PrivateProjectArticlesList**](ProjectsApi.md#privateprojectarticleslist) | **GET** /account/projects/{project_id}/articles | List project articles |
| [**PrivateProjectCollaboratorDelete**](ProjectsApi.md#privateprojectcollaboratordelete) | **DELETE** /account/projects/{project_id}/collaborators/{user_id} | Remove project collaborator |
| [**PrivateProjectCollaboratorsInvite**](ProjectsApi.md#privateprojectcollaboratorsinvite) | **POST** /account/projects/{project_id}/collaborators | Invite project collaborators |
| [**PrivateProjectCollaboratorsList**](ProjectsApi.md#privateprojectcollaboratorslist) | **GET** /account/projects/{project_id}/collaborators | List project collaborators |
| [**PrivateProjectCreate**](ProjectsApi.md#privateprojectcreate) | **POST** /account/projects | Create project |
| [**PrivateProjectDelete**](ProjectsApi.md#privateprojectdelete) | **DELETE** /account/projects/{project_id} | Delete project |
| [**PrivateProjectDetails**](ProjectsApi.md#privateprojectdetails) | **GET** /account/projects/{project_id} | View project details |
| [**PrivateProjectLeave**](ProjectsApi.md#privateprojectleave) | **POST** /account/projects/{project_id}/leave | Private Project Leave |
| [**PrivateProjectNote**](ProjectsApi.md#privateprojectnote) | **GET** /account/projects/{project_id}/notes/{note_id} | Project note details |
| [**PrivateProjectNoteDelete**](ProjectsApi.md#privateprojectnotedelete) | **DELETE** /account/projects/{project_id}/notes/{note_id} | Delete project note |
| [**PrivateProjectNoteUpdate**](ProjectsApi.md#privateprojectnoteupdate) | **PUT** /account/projects/{project_id}/notes/{note_id} | Update project note |
| [**PrivateProjectNotesCreate**](ProjectsApi.md#privateprojectnotescreate) | **POST** /account/projects/{project_id}/notes | Create project note |
| [**PrivateProjectNotesList**](ProjectsApi.md#privateprojectnoteslist) | **GET** /account/projects/{project_id}/notes | List project notes |
| [**PrivateProjectPartialUpdate**](ProjectsApi.md#privateprojectpartialupdate) | **PATCH** /account/projects/{project_id} | Partially update project |
| [**PrivateProjectPublish**](ProjectsApi.md#privateprojectpublish) | **POST** /account/projects/{project_id}/publish | Private Project Publish |
| [**PrivateProjectUpdate**](ProjectsApi.md#privateprojectupdate) | **PUT** /account/projects/{project_id} | Update project |
| [**PrivateProjectsList**](ProjectsApi.md#privateprojectslist) | **GET** /account/projects | Private Projects |
| [**PrivateProjectsSearch**](ProjectsApi.md#privateprojectssearch) | **POST** /account/projects/search | Private Projects search |
| [**ProjectArticles**](ProjectsApi.md#projectarticles) | **GET** /projects/{project_id}/articles | Public Project Articles |
| [**ProjectDetails**](ProjectsApi.md#projectdetails) | **GET** /projects/{project_id} | Public Project |
| [**ProjectsList**](ProjectsApi.md#projectslist) | **GET** /projects | Public Projects |
| [**ProjectsSearch**](ProjectsApi.md#projectssearch) | **POST** /projects/search | Public Projects Search |

<a id="privateprojectarticledelete"></a>
# **PrivateProjectArticleDelete**
> void PrivateProjectArticleDelete (long projectId, long articleId)

Delete project article

Delete project article

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectArticleDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var articleId = 789L;  // long | Project Article unique identifier

            try
            {
                // Delete project article
                apiInstance.PrivateProjectArticleDelete(projectId, articleId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticleDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectArticleDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete project article
    apiInstance.PrivateProjectArticleDeleteWithHttpInfo(projectId, articleId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticleDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **articleId** | **long** | Project Article unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectarticledetails"></a>
# **PrivateProjectArticleDetails**
> ArticleCompletePrivate PrivateProjectArticleDetails (long projectId, long articleId)

Project article details

Project article details

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectArticleDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var articleId = 789L;  // long | Project Article unique identifier

            try
            {
                // Project article details
                ArticleCompletePrivate result = apiInstance.PrivateProjectArticleDetails(projectId, articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticleDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectArticleDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Project article details
    ApiResponse<ArticleCompletePrivate> response = apiInstance.PrivateProjectArticleDetailsWithHttpInfo(projectId, articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticleDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **articleId** | **long** | Project Article unique identifier |  |

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Article representation |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectarticlefile"></a>
# **PrivateProjectArticleFile**
> PrivateFile PrivateProjectArticleFile (long projectId, long articleId, long fileId)

Project article file details

Project article file details

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectArticleFileExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var articleId = 789L;  // long | Project Article unique identifier
            var fileId = 789L;  // long | File unique identifier

            try
            {
                // Project article file details
                PrivateFile result = apiInstance.PrivateProjectArticleFile(projectId, articleId, fileId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticleFile: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectArticleFileWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Project article file details
    ApiResponse<PrivateFile> response = apiInstance.PrivateProjectArticleFileWithHttpInfo(projectId, articleId, fileId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticleFileWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **articleId** | **long** | Project Article unique identifier |  |
| **fileId** | **long** | File unique identifier |  |

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. File representation |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectarticlefiles"></a>
# **PrivateProjectArticleFiles**
> List&lt;PrivateFile&gt; PrivateProjectArticleFiles (long projectId, long articleId)

Project article list files

List article files

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectArticleFilesExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var articleId = 789L;  // long | Project Article unique identifier

            try
            {
                // Project article list files
                List<PrivateFile> result = apiInstance.PrivateProjectArticleFiles(projectId, articleId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticleFiles: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectArticleFilesWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Project article list files
    ApiResponse<List<PrivateFile>> response = apiInstance.PrivateProjectArticleFilesWithHttpInfo(projectId, articleId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticleFilesWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **articleId** | **long** | Project Article unique identifier |  |

### Return type

[**List&lt;PrivateFile&gt;**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. List of files |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectarticlescreate"></a>
# **PrivateProjectArticlesCreate**
> Location PrivateProjectArticlesCreate (long projectId, ArticleProjectCreate article)

Create project article

Create a new Article and associate it with this project

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectArticlesCreateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var article = new ArticleProjectCreate(); // ArticleProjectCreate | Article description

            try
            {
                // Create project article
                Location result = apiInstance.PrivateProjectArticlesCreate(projectId, article);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticlesCreate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectArticlesCreateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create project article
    ApiResponse<Location> response = apiInstance.PrivateProjectArticlesCreateWithHttpInfo(projectId, article);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticlesCreateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **article** | [**ArticleProjectCreate**](ArticleProjectCreate.md) | Article description |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectarticleslist"></a>
# **PrivateProjectArticlesList**
> List&lt;Article&gt; PrivateProjectArticlesList (long projectId)

List project articles

List project articles

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectArticlesListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier

            try
            {
                // List project articles
                List<Article> result = apiInstance.PrivateProjectArticlesList(projectId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticlesList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectArticlesListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List project articles
    ApiResponse<List<Article>> response = apiInstance.PrivateProjectArticlesListWithHttpInfo(projectId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectArticlesListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |

### Return type

[**List&lt;Article&gt;**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. List of articles |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectcollaboratordelete"></a>
# **PrivateProjectCollaboratorDelete**
> void PrivateProjectCollaboratorDelete (long projectId, long userId)

Remove project collaborator

Remove project collaborator

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectCollaboratorDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var userId = 789L;  // long | User unique identifier

            try
            {
                // Remove project collaborator
                apiInstance.PrivateProjectCollaboratorDelete(projectId, userId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectCollaboratorDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectCollaboratorDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Remove project collaborator
    apiInstance.PrivateProjectCollaboratorDeleteWithHttpInfo(projectId, userId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectCollaboratorDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **userId** | **long** | User unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | OK |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectcollaboratorsinvite"></a>
# **PrivateProjectCollaboratorsInvite**
> ResponseMessage PrivateProjectCollaboratorsInvite (long projectId, ProjectCollaboratorInvite collaborator)

Invite project collaborators

Invite users to collaborate on project or view the project

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectCollaboratorsInviteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var collaborator = new ProjectCollaboratorInvite(); // ProjectCollaboratorInvite | viewer or collaborator role. User user_id or email of user

            try
            {
                // Invite project collaborators
                ResponseMessage result = apiInstance.PrivateProjectCollaboratorsInvite(projectId, collaborator);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectCollaboratorsInvite: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectCollaboratorsInviteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Invite project collaborators
    ApiResponse<ResponseMessage> response = apiInstance.PrivateProjectCollaboratorsInviteWithHttpInfo(projectId, collaborator);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectCollaboratorsInviteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **collaborator** | [**ProjectCollaboratorInvite**](ProjectCollaboratorInvite.md) | viewer or collaborator role. User user_id or email of user |  |

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectcollaboratorslist"></a>
# **PrivateProjectCollaboratorsList**
> List&lt;ProjectCollaborator&gt; PrivateProjectCollaboratorsList (long projectId)

List project collaborators

List Project collaborators and invited users

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectCollaboratorsListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier

            try
            {
                // List project collaborators
                List<ProjectCollaborator> result = apiInstance.PrivateProjectCollaboratorsList(projectId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectCollaboratorsList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectCollaboratorsListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List project collaborators
    ApiResponse<List<ProjectCollaborator>> response = apiInstance.PrivateProjectCollaboratorsListWithHttpInfo(projectId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectCollaboratorsListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |

### Return type

[**List&lt;ProjectCollaborator&gt;**](ProjectCollaborator.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. List of Collaborators |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectcreate"></a>
# **PrivateProjectCreate**
> CreateProjectResponse PrivateProjectCreate (ProjectCreate project)

Create project

Create a new project

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectCreateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var project = new ProjectCreate(); // ProjectCreate | Project  description

            try
            {
                // Create project
                CreateProjectResponse result = apiInstance.PrivateProjectCreate(project);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectCreate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectCreateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create project
    ApiResponse<CreateProjectResponse> response = apiInstance.PrivateProjectCreateWithHttpInfo(project);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectCreateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **project** | [**ProjectCreate**](ProjectCreate.md) | Project  description |  |

### Return type

[**CreateProjectResponse**](CreateProjectResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectdelete"></a>
# **PrivateProjectDelete**
> void PrivateProjectDelete (long projectId)

Delete project

A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project. 

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier

            try
            {
                // Delete project
                apiInstance.PrivateProjectDelete(projectId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete project
    apiInstance.PrivateProjectDeleteWithHttpInfo(projectId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectdetails"></a>
# **PrivateProjectDetails**
> ProjectCompletePrivate PrivateProjectDetails (long projectId)

View project details

View a private project

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier

            try
            {
                // View project details
                ProjectCompletePrivate result = apiInstance.PrivateProjectDetails(projectId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // View project details
    ApiResponse<ProjectCompletePrivate> response = apiInstance.PrivateProjectDetailsWithHttpInfo(projectId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |

### Return type

[**ProjectCompletePrivate**](ProjectCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Project representation |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectleave"></a>
# **PrivateProjectLeave**
> void PrivateProjectLeave (long projectId)

Private Project Leave

Please note: project's owner cannot leave the project.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectLeaveExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier

            try
            {
                // Private Project Leave
                apiInstance.PrivateProjectLeave(projectId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectLeave: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectLeaveWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Project Leave
    apiInstance.PrivateProjectLeaveWithHttpInfo(projectId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectLeaveWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectnote"></a>
# **PrivateProjectNote**
> ProjectNotePrivate PrivateProjectNote (long projectId, long noteId)

Project note details

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectNoteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var noteId = 789L;  // long | Note unique identifier

            try
            {
                // Project note details
                ProjectNotePrivate result = apiInstance.PrivateProjectNote(projectId, noteId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectNote: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectNoteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Project note details
    ApiResponse<ProjectNotePrivate> response = apiInstance.PrivateProjectNoteWithHttpInfo(projectId, noteId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectNoteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **noteId** | **long** | Note unique identifier |  |

### Return type

[**ProjectNotePrivate**](ProjectNotePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Note representation |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectnotedelete"></a>
# **PrivateProjectNoteDelete**
> void PrivateProjectNoteDelete (long projectId, long noteId)

Delete project note

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectNoteDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var noteId = 789L;  // long | Note unique identifier

            try
            {
                // Delete project note
                apiInstance.PrivateProjectNoteDelete(projectId, noteId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectNoteDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectNoteDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete project note
    apiInstance.PrivateProjectNoteDeleteWithHttpInfo(projectId, noteId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectNoteDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **noteId** | **long** | Note unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectnoteupdate"></a>
# **PrivateProjectNoteUpdate**
> void PrivateProjectNoteUpdate (long projectId, long noteId, ProjectNoteCreate note)

Update project note

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectNoteUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var noteId = 789L;  // long | Note unique identifier
            var note = new ProjectNoteCreate(); // ProjectNoteCreate | Note message

            try
            {
                // Update project note
                apiInstance.PrivateProjectNoteUpdate(projectId, noteId, note);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectNoteUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectNoteUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update project note
    apiInstance.PrivateProjectNoteUpdateWithHttpInfo(projectId, noteId, note);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectNoteUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **noteId** | **long** | Note unique identifier |  |
| **note** | [**ProjectNoteCreate**](ProjectNoteCreate.md) | Note message |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectnotescreate"></a>
# **PrivateProjectNotesCreate**
> Location PrivateProjectNotesCreate (long projectId, ProjectNoteCreate note)

Create project note

Create a new project note

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectNotesCreateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var note = new ProjectNoteCreate(); // ProjectNoteCreate | Note message

            try
            {
                // Create project note
                Location result = apiInstance.PrivateProjectNotesCreate(projectId, note);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectNotesCreate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectNotesCreateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create project note
    ApiResponse<Location> response = apiInstance.PrivateProjectNotesCreateWithHttpInfo(projectId, note);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectNotesCreateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **note** | [**ProjectNoteCreate**](ProjectNoteCreate.md) | Note message |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectnoteslist"></a>
# **PrivateProjectNotesList**
> List&lt;ProjectNote&gt; PrivateProjectNotesList (long projectId, long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

List project notes

List project notes

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectNotesListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var page = 789L;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10L;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789L;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789L;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // List project notes
                List<ProjectNote> result = apiInstance.PrivateProjectNotesList(projectId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectNotesList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectNotesListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List project notes
    ApiResponse<List<ProjectNote>> response = apiInstance.PrivateProjectNotesListWithHttpInfo(projectId, page, pageSize, limit, offset);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectNotesListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **page** | **long?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **long?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **long?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |

### Return type

[**List&lt;ProjectNote&gt;**](ProjectNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. List of project notes |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectpartialupdate"></a>
# **PrivateProjectPartialUpdate**
> void PrivateProjectPartialUpdate (long projectId, ProjectUpdate? project = null)

Partially update project

Partially update a project; only provided fields will be changed.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectPartialUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var project = new ProjectUpdate?(); // ProjectUpdate? | Fields to update (optional) 

            try
            {
                // Partially update project
                apiInstance.PrivateProjectPartialUpdate(projectId, project);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectPartialUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectPartialUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Partially update project
    apiInstance.PrivateProjectPartialUpdateWithHttpInfo(projectId, project);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectPartialUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **project** | [**ProjectUpdate?**](ProjectUpdate?.md) | Fields to update | [optional]  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectpublish"></a>
# **PrivateProjectPublish**
> ResponseMessage PrivateProjectPublish (long projectId)

Private Project Publish

Publish a project. Possible after all items inside it are public

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectPublishExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier

            try
            {
                // Private Project Publish
                ResponseMessage result = apiInstance.PrivateProjectPublish(projectId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectPublish: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectPublishWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Project Publish
    ApiResponse<ResponseMessage> response = apiInstance.PrivateProjectPublishWithHttpInfo(projectId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectPublishWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectupdate"></a>
# **PrivateProjectUpdate**
> void PrivateProjectUpdate (long projectId, ProjectUpdate project)

Update project

Updating an project by passing body parameters.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project unique identifier
            var project = new ProjectUpdate(); // ProjectUpdate | Project description

            try
            {
                // Update project
                apiInstance.PrivateProjectUpdate(projectId, project);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update project
    apiInstance.PrivateProjectUpdateWithHttpInfo(projectId, project);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project unique identifier |  |
| **project** | [**ProjectUpdate**](ProjectUpdate.md) | Project description |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectslist"></a>
# **PrivateProjectsList**
> List&lt;ProjectPrivate&gt; PrivateProjectsList (long? page = null, long? pageSize = null, long? limit = null, long? offset = null, string? order = null, string? orderDirection = null, string? storage = null, string? roles = null)

Private Projects

List private projects

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectsListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProjectsApi(config);
            var page = 789L;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10L;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789L;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789L;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 
            var order = "published_date";  // string? | The field by which to order. (optional)  (default to published_date)
            var orderDirection = "asc";  // string? |  (optional)  (default to desc)
            var storage = "group";  // string? | only return collections from this institution (optional) 
            var roles = "roles_example";  // string? | Any combination of owner, collaborator, viewer separated by comma. Examples: \"owner\" or \"owner,collaborator\". (optional) 

            try
            {
                // Private Projects
                List<ProjectPrivate> result = apiInstance.PrivateProjectsList(page, pageSize, limit, offset, order, orderDirection, storage, roles);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectsList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectsListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Projects
    ApiResponse<List<ProjectPrivate>> response = apiInstance.PrivateProjectsListWithHttpInfo(page, pageSize, limit, offset, order, orderDirection, storage, roles);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectsListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **page** | **long?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **long?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **long?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |
| **order** | **string?** | The field by which to order. | [optional] [default to published_date] |
| **orderDirection** | **string?** |  | [optional] [default to desc] |
| **storage** | **string?** | only return collections from this institution | [optional]  |
| **roles** | **string?** | Any combination of owner, collaborator, viewer separated by comma. Examples: \&quot;owner\&quot; or \&quot;owner,collaborator\&quot;. | [optional]  |

### Return type

[**List&lt;ProjectPrivate&gt;**](ProjectPrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of projects |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateprojectssearch"></a>
# **PrivateProjectsSearch**
> List&lt;ProjectPrivate&gt; PrivateProjectsSearch (ProjectsSearch? search = null)

Private Projects search

Search inside the private projects

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateProjectsSearchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new ProjectsApi(config);
            var search = new ProjectsSearch?(); // ProjectsSearch? | Search Parameters (optional) 

            try
            {
                // Private Projects search
                List<ProjectPrivate> result = apiInstance.PrivateProjectsSearch(search);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.PrivateProjectsSearch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateProjectsSearchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Projects search
    ApiResponse<List<ProjectPrivate>> response = apiInstance.PrivateProjectsSearchWithHttpInfo(search);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.PrivateProjectsSearchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **search** | [**ProjectsSearch?**](ProjectsSearch?.md) | Search Parameters | [optional]  |

### Return type

[**List&lt;ProjectPrivate&gt;**](ProjectPrivate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of projects |  -  |
| **400** | Bad Request |  -  |
| **422** | Bad Request |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="projectarticles"></a>
# **ProjectArticles**
> List&lt;Article&gt; ProjectArticles (long projectId, long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

Public Project Articles

List articles in project

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ProjectArticlesExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project Unique identifier
            var page = 789L;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10L;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789L;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789L;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Public Project Articles
                List<Article> result = apiInstance.ProjectArticles(projectId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.ProjectArticles: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ProjectArticlesWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Project Articles
    ApiResponse<List<Article>> response = apiInstance.ProjectArticlesWithHttpInfo(projectId, page, pageSize, limit, offset);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.ProjectArticlesWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project Unique identifier |  |
| **page** | **long?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **long?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **long?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |

### Return type

[**List&lt;Article&gt;**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Project articles list |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="projectdetails"></a>
# **ProjectDetails**
> ProjectComplete ProjectDetails (long projectId)

Public Project

View a project

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ProjectDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new ProjectsApi(config);
            var projectId = 789L;  // long | Project Unique identifier

            try
            {
                // Public Project
                ProjectComplete result = apiInstance.ProjectDetails(projectId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.ProjectDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ProjectDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Project
    ApiResponse<ProjectComplete> response = apiInstance.ProjectDetailsWithHttpInfo(projectId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.ProjectDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **projectId** | **long** | Project Unique identifier |  |

### Return type

[**ProjectComplete**](ProjectComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Project representation |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="projectslist"></a>
# **ProjectsList**
> List&lt;Project&gt; ProjectsList (Guid? xCursor = null, long? page = null, long? pageSize = null, long? limit = null, long? offset = null, string? order = null, string? orderDirection = null, long? institution = null, string? publishedSince = null, long? group = null)

Public Projects

Returns a list of public projects

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ProjectsListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new ProjectsApi(config);
            var xCursor = "xCursor_example";  // Guid? | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional) 
            var page = 789L;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10L;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789L;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789L;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 
            var order = "published_date";  // string? | The field by which to order. Default varies by endpoint/resource. (optional)  (default to published_date)
            var orderDirection = "asc";  // string? |  (optional)  (default to desc)
            var institution = 789L;  // long? | only return collections from this institution (optional) 
            var publishedSince = "publishedSince_example";  // string? | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD (optional) 
            var group = 789L;  // long? | only return collections from this group (optional) 

            try
            {
                // Public Projects
                List<Project> result = apiInstance.ProjectsList(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, group);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.ProjectsList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ProjectsListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Projects
    ApiResponse<List<Project>> response = apiInstance.ProjectsListWithHttpInfo(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, group);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.ProjectsListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **xCursor** | **Guid?** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional]  |
| **page** | **long?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **long?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **long?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |
| **order** | **string?** | The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date] |
| **orderDirection** | **string?** |  | [optional] [default to desc] |
| **institution** | **long?** | only return collections from this institution | [optional]  |
| **publishedSince** | **string?** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD | [optional]  |
| **group** | **long?** | only return collections from this group | [optional]  |

### Return type

[**List&lt;Project&gt;**](Project.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of projects |  * X-Cursor - Unique hash used for bypassing the item retrieval limit of 9,000 entities. <br>  |
| **400** | Bad Request |  -  |
| **422** | Bad Request |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="projectssearch"></a>
# **ProjectsSearch**
> List&lt;Project&gt; ProjectsSearch (Guid? xCursor = null, ProjectsSearch? search = null)

Public Projects Search

Returns a list of public articles

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ProjectsSearchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new ProjectsApi(config);
            var xCursor = "xCursor_example";  // Guid? | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional) 
            var search = new ProjectsSearch?(); // ProjectsSearch? | Search Parameters (optional) 

            try
            {
                // Public Projects Search
                List<Project> result = apiInstance.ProjectsSearch(xCursor, search);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProjectsApi.ProjectsSearch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the ProjectsSearchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Projects Search
    ApiResponse<List<Project>> response = apiInstance.ProjectsSearchWithHttpInfo(xCursor, search);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProjectsApi.ProjectsSearchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **xCursor** | **Guid?** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional]  |
| **search** | [**ProjectsSearch?**](ProjectsSearch?.md) | Search Parameters | [optional]  |

### Return type

[**List&lt;Project&gt;**](Project.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of projects |  * X-Cursor - Unique hash used for bypassing the item retrieval limit of 9,000 entities. <br>  |
| **400** | Bad Request |  -  |
| **422** | Bad Request |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

