# Org.OpenAPITools.Model.CustomArticleField

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Custom  metadata name | 
**Value** | **Object** | Custom metadata value (can be either a string or an array of strings) | 
**FieldType** | **string** | Custom field type | 
**Settings** | **Object** | Settings for the custom field | 
**Order** | **int** | Order of the custom field | 
**IsMandatory** | **bool** | Whether the field is mandatory or not | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

