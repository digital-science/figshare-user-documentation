# Org.OpenAPITools.Model.ProjectCollaboratorInvite

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RoleName** | **string** | Role of the the collaborator inside the project | 
**UserId** | **long** | User id of the collaborator | [optional] 
**Email** | **string** | Collaborator email | [optional] 
**Comment** | **string** | Text sent when inviting the user to the project | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

