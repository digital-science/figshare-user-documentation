# Org.OpenAPITools.Api.AltmetricApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**AltmetricInstitutionsList**](AltmetricApi.md#altmetricinstitutionslist) | **GET** /altmetric/institutions | List Altmetric Institutions |

<a id="altmetricinstitutionslist"></a>
# **AltmetricInstitutionsList**
> List&lt;AltmetricInstitution&gt; AltmetricInstitutionsList (int? offset = null)

List Altmetric Institutions

Returns a list of institutions available for Altmetric reporting

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AltmetricInstitutionsListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "http://localhost";
            var apiInstance = new AltmetricApi(config);
            var offset = 0;  // int? | Where to start the listing. The offset of the first item. (optional)  (default to 0)

            try
            {
                // List Altmetric Institutions
                List<AltmetricInstitution> result = apiInstance.AltmetricInstitutionsList(offset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AltmetricApi.AltmetricInstitutionsList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the AltmetricInstitutionsListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List Altmetric Institutions
    ApiResponse<List<AltmetricInstitution>> response = apiInstance.AltmetricInstitutionsListWithHttpInfo(offset);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AltmetricApi.AltmetricInstitutionsListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **offset** | **int?** | Where to start the listing. The offset of the first item. | [optional] [default to 0] |

### Return type

[**List&lt;AltmetricInstitution&gt;**](AltmetricInstitution.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of Altmetric institutions |  -  |
| **400** | Bad Request |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

