# Org.OpenAPITools.Model.OAuthToken

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessToken** | **string** | The OAuth access token | 
**Token** | **string** | The OAuth access token | [optional] 
**TokenType** | **string** | The type of token issued | 
**ExpiresIn** | **long** | Token expiration time in seconds | 
**RefreshToken** | **string** | The refresh token (only provided for certain grant types) | [optional] 
**Scope** | **string** | The scope of the access token | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

