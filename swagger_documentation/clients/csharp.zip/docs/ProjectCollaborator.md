# Org.OpenAPITools.Model.ProjectCollaborator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Status** | **string** | Status of collaborator invitation | 
**RoleName** | **string** | Collaborator role | 
**UserId** | **int** | Collaborator id | 
**Name** | **string** | Collaborator name | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

