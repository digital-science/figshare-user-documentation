# Org.OpenAPITools.Model.ItemType

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long** | The ID of the item type. | 
**Name** | **string** | The name of the item type | 
**StringId** | **string** | The string identifier of the item type. | 
**Icon** | **string** | The string identifying the icon of the item type. | 
**PublicDescription** | **string** | The description of the item type. | 
**IsSelectable** | **bool** | The selectable status | 
**UrlName** | **string** | The URL name of the item type. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

