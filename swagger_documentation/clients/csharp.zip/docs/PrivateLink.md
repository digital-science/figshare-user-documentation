# Org.OpenAPITools.Model.PrivateLink

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | Private link id | 
**IsActive** | **bool** | True if private link is active | 
**ExpiresDate** | **string** | Date when link will expire | 
**HtmlLocation** | **string** | HTML url for private link | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

