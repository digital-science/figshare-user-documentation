# Org.OpenAPITools.Api.ProfilesApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**UpdateUserProfile**](ProfilesApi.md#updateuserprofile) | **PUT** /account/profile | Update public profile |
| [**UpdateUserProfilePicture**](ProfilesApi.md#updateuserprofilepicture) | **POST** /account/profile/{user_id}/picture | Update public profile picture |

<a id="updateuserprofile"></a>
# **UpdateUserProfile**
> Object UpdateUserProfile (ProfileUpdateData userProfileData, long? userId = null, string? institutionUserId = null)

Update public profile

Updates the fields of the user's public profile.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class UpdateUserProfileExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProfilesApi(config);
            var userProfileData = new ProfileUpdateData(); // ProfileUpdateData | 
            var userId = 789L;  // long? | User ID (optional) 
            var institutionUserId = "institutionUserId_example";  // string? | Institutional user ID (optional) 

            try
            {
                // Update public profile
                Object result = apiInstance.UpdateUserProfile(userProfileData, userId, institutionUserId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProfilesApi.UpdateUserProfile: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the UpdateUserProfileWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update public profile
    ApiResponse<Object> response = apiInstance.UpdateUserProfileWithHttpInfo(userProfileData, userId, institutionUserId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProfilesApi.UpdateUserProfileWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **userProfileData** | [**ProfileUpdateData**](ProfileUpdateData.md) |  |  |
| **userId** | **long?** | User ID | [optional]  |
| **institutionUserId** | **string?** | Institutional user ID | [optional]  |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="updateuserprofilepicture"></a>
# **UpdateUserProfilePicture**
> Object UpdateUserProfilePicture (long userId, System.IO.Stream profilePicture)

Update public profile picture

Updates the profile picture of the user's public profile.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class UpdateUserProfilePictureExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProfilesApi(config);
            var userId = 789L;  // long | User ID
            var profilePicture = new System.IO.MemoryStream(System.IO.File.ReadAllBytes("/path/to/file.txt"));  // System.IO.Stream | User profile picture

            try
            {
                // Update public profile picture
                Object result = apiInstance.UpdateUserProfilePicture(userId, profilePicture);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling ProfilesApi.UpdateUserProfilePicture: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the UpdateUserProfilePictureWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update public profile picture
    ApiResponse<Object> response = apiInstance.UpdateUserProfilePictureWithHttpInfo(userId, profilePicture);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling ProfilesApi.UpdateUserProfilePictureWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **userId** | **long** | User ID |  |
| **profilePicture** | **System.IO.Stream****System.IO.Stream** | User profile picture |  |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

