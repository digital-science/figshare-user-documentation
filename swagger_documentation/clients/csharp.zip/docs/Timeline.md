# Org.OpenAPITools.Model.Timeline

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstOnline** | **string** | Online posted date | [optional] 
**PublisherPublication** | **string** | Publish date | [optional] 
**PublisherAcceptance** | **string** | Date when the item was accepted for publication | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

