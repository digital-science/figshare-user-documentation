# IO.Swagger.Model.ShortAccount
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Account id | 
**FirstName** | **string** | First Name | 
**LastName** | **string** | Last Name | 
**InstitutionId** | **long?** | Account institution | 
**Email** | **string** | User email | 
**Active** | **long?** | Account activity status | 
**InstitutionUserId** | **string** | Account institution user id | 
**Quota** | **long?** | Total storage available to account, in bytes | 
**UsedQuota** | **long?** | Storage used by the account, in bytes | 
**UserId** | **long?** | User id associated with account, useful for example for adding the account as an author to an item | 
**OrcidId** | **string** | ORCID iD associated to account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

