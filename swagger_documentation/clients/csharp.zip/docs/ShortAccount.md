# Org.OpenAPITools.Model.ShortAccount

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** | Account id | 
**FirstName** | **string** | First Name | 
**LastName** | **string** | Last Name | 
**InstitutionId** | **int** | Account institution | 
**Email** | **string** | User email | 
**Active** | **int** | Account activity status | 
**InstitutionUserId** | **string** | Account institution user id | 
**Quota** | **int** | Total storage available to account, in bytes | 
**UsedQuota** | **int** | Storage used by the account, in bytes | 
**UserId** | **int** | User id associated with account, useful for example for adding the account as an author to an item | 
**OrcidId** | **string** | ORCID iD associated to account | 
**SymplecticUserId** | **string** | Symplectic ID associated to account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

