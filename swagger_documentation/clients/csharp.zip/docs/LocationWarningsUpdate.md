# Org.OpenAPITools.Model.LocationWarningsUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Location** | **string** | Url for entity | 
**Warnings** | **List&lt;string&gt;** | Issues encountered during the operation | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

