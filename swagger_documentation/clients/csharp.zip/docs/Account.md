# IO.Swagger.Model.Account
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Account id | 
**FirstName** | **string** | First Name | 
**LastName** | **string** | Last Name | 
**UsedQuotaPrivate** | **long?** | Account used private quota | 
**ModifiedDate** | **string** | Date of last account modification | 
**UsedQuota** | **long?** | Account total used quota | 
**CreatedDate** | **string** | Date when account was created | 
**Quota** | **long?** | Account quota | 
**GroupId** | **long?** | Account group id | 
**InstitutionUserId** | **string** | Account institution user id | 
**InstitutionId** | **long?** | Account institution | 
**Email** | **string** | User email | 
**UsedQuotaPublic** | **long?** | Account public used quota | 
**PendingQuotaRequest** | **bool?** | True if a quota request is pending | 
**Active** | **long?** | Account activity status | 
**MaximumFileSize** | **long?** | Maximum upload size for account | 
**UserId** | **long?** | User id associated with account, useful for example for adding the account as an author to an item | 
**OrcidId** | **string** | ORCID iD associated to account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

