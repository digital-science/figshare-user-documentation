# Org.OpenAPITools.Model.CustomArticleFieldAddValue
Custom metadata value (can be either a string, an array of strings, or empty)

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

