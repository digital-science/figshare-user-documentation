# Org.OpenAPITools.Model.ProjectNotePrivate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Text** | **string** | Full text of note | 
**Id** | **long** | Project note id | 
**UserId** | **long** | User who wrote the note | 
**Abstract** | **string** | Note Abstract - short/truncated content | 
**UserName** | **string** | Username of the one who wrote the note | 
**CreatedDate** | **string** | Date when note was created | 
**ModifiedDate** | **string** | Date when note was last modified | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

