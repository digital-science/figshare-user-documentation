# IO.Swagger.Model.Role
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** | Role id | 
**Name** | **string** | Role name | 
**Category** | **string** | Role category | 
**Description** | **string** | Role description | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

