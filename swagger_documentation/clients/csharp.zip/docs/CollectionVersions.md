# Org.OpenAPITools.Model.CollectionVersions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VarVersion** | **long** | Version number | 
**Url** | **string** | Api endpoint for the collection version | 
**Funding** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Collection funding information | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

