# Org.OpenAPITools.Model.UploadInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Token** | **string** | token received after initializing a file upload | [optional] 
**Md5** | **string** | md5 provided on upload initialization | [optional] 
**Size** | **long** | size of file in bytes | [optional] 
**Name** | **string** | name of file on upload server | [optional] 
**Status** | **string** | Upload status | [optional] 
**Parts** | [**List&lt;UploadFilePart&gt;**](UploadFilePart.md) | Uploads parts | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

