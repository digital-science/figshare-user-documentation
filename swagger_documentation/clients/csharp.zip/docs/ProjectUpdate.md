# Org.OpenAPITools.Model.ProjectUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** | The title for this project - mandatory. 3 - 1000 characters. | [optional] 
**Description** | **string** | Project description | [optional] 
**Funding** | **string** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional] 
**FundingList** | [**List&lt;FundingCreate&gt;**](FundingCreate.md) | Funding creation / update items | [optional] 
**CustomFields** | **Object** | List of key, values pairs to be associated with the project | [optional] 
**CustomFieldsList** | [**List&lt;CustomArticleFieldAdd&gt;**](CustomArticleFieldAdd.md) | List of custom fields values, supersedes custom_fields parameter | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

