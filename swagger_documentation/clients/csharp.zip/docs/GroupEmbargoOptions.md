# Org.OpenAPITools.Model.GroupEmbargoOptions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long** | Embargo option id | 
**Type** | **string** | Embargo permission type | 
**IpName** | **string** | IP range name; value appears if type is ip_range | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

