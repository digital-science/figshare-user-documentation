# Org.OpenAPITools.Model.ArticleConfidentiality

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IsConfidential** | **bool** | True if article is confidential | 
**Reason** | **string** | Reason for confidentiality | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

