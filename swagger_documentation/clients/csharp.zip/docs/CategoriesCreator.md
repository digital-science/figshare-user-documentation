# Org.OpenAPITools.Model.CategoriesCreator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Categories** | **List&lt;long&gt;** | List of category ids | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

