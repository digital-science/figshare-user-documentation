# Org.OpenAPITools.Model.CollectionDOI

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Doi** | **string** | Reserved DOI | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

