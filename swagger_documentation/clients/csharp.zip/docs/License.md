# Org.OpenAPITools.Model.License

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Value** | **long** | License value | 
**Name** | **string** | License name | 
**Url** | **string** | License url | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

