# IO.Swagger.Model.Collaborator
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RoleName** | **string** | Collaborator role | 
**UserId** | **int?** | Collaborator id | 
**Name** | **string** | Collaborator name | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

