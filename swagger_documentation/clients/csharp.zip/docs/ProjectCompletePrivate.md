# IO.Swagger.Model.ProjectCompletePrivate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Role** | **string** | Role inside this project | [optional] 
**Storage** | **string** | Project storage type | [optional] 
**Url** | **string** | Api endpoint | 
**Id** | **long?** | Project id | 
**Title** | **string** | Project title | 
**CreatedDate** | **string** | Date when project was created | 
**ModifiedDate** | **string** | Date when project was last modified | 
**Funding** | **string** | Project funding | 
**FundingList** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Project funding information | 
**Description** | **string** | Project description | 
**Collaborators** | [**List&lt;Collaborator&gt;**](Collaborator.md) | List of project collaborators | 
**Quota** | **long?** | Project quota | 
**UsedQuota** | **long?** | Project used quota | 
**UsedQuotaPrivate** | **long?** | Project private quota used | 
**UsedQuotaPublic** | **long?** | Project public quota used | 
**GroupId** | **long?** | Group of project if any | 
**AccountId** | **long?** | ID of the account owning the project | 
**CustomFields** | [**List&lt;ShortCustomField&gt;**](ShortCustomField.md) | Collection custom fields | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

