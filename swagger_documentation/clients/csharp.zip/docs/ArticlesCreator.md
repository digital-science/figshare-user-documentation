# Org.OpenAPITools.Model.ArticlesCreator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Articles** | **List&lt;int&gt;** | List of article ids | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

