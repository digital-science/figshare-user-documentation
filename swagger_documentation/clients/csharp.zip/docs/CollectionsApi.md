# Org.OpenAPITools.Api.CollectionsApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**CollectionArticles**](CollectionsApi.md#collectionarticles) | **GET** /collections/{collection_id}/articles | Public Collection Articles |
| [**CollectionDetails**](CollectionsApi.md#collectiondetails) | **GET** /collections/{collection_id} | Collection details |
| [**CollectionVersionDetails**](CollectionsApi.md#collectionversiondetails) | **GET** /collections/{collection_id}/versions/{version_id} | Collection Version details |
| [**CollectionVersions**](CollectionsApi.md#collectionversions) | **GET** /collections/{collection_id}/versions | Collection Versions list |
| [**CollectionsList**](CollectionsApi.md#collectionslist) | **GET** /collections | Public Collections |
| [**CollectionsSearch**](CollectionsApi.md#collectionssearch) | **POST** /collections/search | Public Collections Search |
| [**PrivateCollectionArticleDelete**](CollectionsApi.md#privatecollectionarticledelete) | **DELETE** /account/collections/{collection_id}/articles/{article_id} | Delete collection article |
| [**PrivateCollectionArticlesAdd**](CollectionsApi.md#privatecollectionarticlesadd) | **POST** /account/collections/{collection_id}/articles | Add collection articles |
| [**PrivateCollectionArticlesList**](CollectionsApi.md#privatecollectionarticleslist) | **GET** /account/collections/{collection_id}/articles | List collection articles |
| [**PrivateCollectionArticlesReplace**](CollectionsApi.md#privatecollectionarticlesreplace) | **PUT** /account/collections/{collection_id}/articles | Replace collection articles |
| [**PrivateCollectionAuthorDelete**](CollectionsApi.md#privatecollectionauthordelete) | **DELETE** /account/collections/{collection_id}/authors/{author_id} | Delete collection author |
| [**PrivateCollectionAuthorsAdd**](CollectionsApi.md#privatecollectionauthorsadd) | **POST** /account/collections/{collection_id}/authors | Add collection authors |
| [**PrivateCollectionAuthorsList**](CollectionsApi.md#privatecollectionauthorslist) | **GET** /account/collections/{collection_id}/authors | List collection authors |
| [**PrivateCollectionAuthorsReplace**](CollectionsApi.md#privatecollectionauthorsreplace) | **PUT** /account/collections/{collection_id}/authors | Replace collection authors |
| [**PrivateCollectionCategoriesAdd**](CollectionsApi.md#privatecollectioncategoriesadd) | **POST** /account/collections/{collection_id}/categories | Add collection categories |
| [**PrivateCollectionCategoriesList**](CollectionsApi.md#privatecollectioncategorieslist) | **GET** /account/collections/{collection_id}/categories | List collection categories |
| [**PrivateCollectionCategoriesReplace**](CollectionsApi.md#privatecollectioncategoriesreplace) | **PUT** /account/collections/{collection_id}/categories | Replace collection categories |
| [**PrivateCollectionCategoryDelete**](CollectionsApi.md#privatecollectioncategorydelete) | **DELETE** /account/collections/{collection_id}/categories/{category_id} | Delete collection category |
| [**PrivateCollectionCreate**](CollectionsApi.md#privatecollectioncreate) | **POST** /account/collections | Create collection |
| [**PrivateCollectionDelete**](CollectionsApi.md#privatecollectiondelete) | **DELETE** /account/collections/{collection_id} | Delete collection |
| [**PrivateCollectionDetails**](CollectionsApi.md#privatecollectiondetails) | **GET** /account/collections/{collection_id} | Collection details |
| [**PrivateCollectionPatch**](CollectionsApi.md#privatecollectionpatch) | **PATCH** /account/collections/{collection_id} | Partially update collection |
| [**PrivateCollectionPrivateLinkCreate**](CollectionsApi.md#privatecollectionprivatelinkcreate) | **POST** /account/collections/{collection_id}/private_links | Create collection private link |
| [**PrivateCollectionPrivateLinkDelete**](CollectionsApi.md#privatecollectionprivatelinkdelete) | **DELETE** /account/collections/{collection_id}/private_links/{link_id} | Disable private link |
| [**PrivateCollectionPrivateLinkDetails**](CollectionsApi.md#privatecollectionprivatelinkdetails) | **GET** /account/collections/{collection_id}/private_links/{link_id} | View collection private link |
| [**PrivateCollectionPrivateLinkUpdate**](CollectionsApi.md#privatecollectionprivatelinkupdate) | **PUT** /account/collections/{collection_id}/private_links/{link_id} | Update collection private link |
| [**PrivateCollectionPrivateLinksList**](CollectionsApi.md#privatecollectionprivatelinkslist) | **GET** /account/collections/{collection_id}/private_links | List collection private links |
| [**PrivateCollectionPublish**](CollectionsApi.md#privatecollectionpublish) | **POST** /account/collections/{collection_id}/publish | Private Collection Publish |
| [**PrivateCollectionReserveDoi**](CollectionsApi.md#privatecollectionreservedoi) | **POST** /account/collections/{collection_id}/reserve_doi | Private Collection Reserve DOI |
| [**PrivateCollectionReserveHandle**](CollectionsApi.md#privatecollectionreservehandle) | **POST** /account/collections/{collection_id}/reserve_handle | Private Collection Reserve Handle |
| [**PrivateCollectionResource**](CollectionsApi.md#privatecollectionresource) | **POST** /account/collections/{collection_id}/resource | Private Collection Resource |
| [**PrivateCollectionUpdate**](CollectionsApi.md#privatecollectionupdate) | **PUT** /account/collections/{collection_id} | Update collection |
| [**PrivateCollectionsList**](CollectionsApi.md#privatecollectionslist) | **GET** /account/collections | Private Collections List |
| [**PrivateCollectionsSearch**](CollectionsApi.md#privatecollectionssearch) | **POST** /account/collections/search | Private Collections Search |

<a id="collectionarticles"></a>
# **CollectionArticles**
> List&lt;Article&gt; CollectionArticles (long collectionId, long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

Public Collection Articles

Returns a list of public collection articles

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class CollectionArticlesExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection Unique identifier
            var page = 789L;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10L;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789L;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789L;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Public Collection Articles
                List<Article> result = apiInstance.CollectionArticles(collectionId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.CollectionArticles: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the CollectionArticlesWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Collection Articles
    ApiResponse<List<Article>> response = apiInstance.CollectionArticlesWithHttpInfo(collectionId, page, pageSize, limit, offset);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.CollectionArticlesWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection Unique identifier |  |
| **page** | **long?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **long?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **long?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |

### Return type

[**List&lt;Article&gt;**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of articles belonging to the collection |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **422** | Bad Request |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="collectiondetails"></a>
# **CollectionDetails**
> CollectionComplete CollectionDetails (long collectionId)

Collection details

View a collection

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class CollectionDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection Unique identifier

            try
            {
                // Collection details
                CollectionComplete result = apiInstance.CollectionDetails(collectionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.CollectionDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the CollectionDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Collection details
    ApiResponse<CollectionComplete> response = apiInstance.CollectionDetailsWithHttpInfo(collectionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.CollectionDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection Unique identifier |  |

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Collection representation |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="collectionversiondetails"></a>
# **CollectionVersionDetails**
> CollectionComplete CollectionVersionDetails (long collectionId, long versionId)

Collection Version details

View details for a certain version of a collection

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class CollectionVersionDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection Unique identifier
            var versionId = 789L;  // long | Version Number

            try
            {
                // Collection Version details
                CollectionComplete result = apiInstance.CollectionVersionDetails(collectionId, versionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.CollectionVersionDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the CollectionVersionDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Collection Version details
    ApiResponse<CollectionComplete> response = apiInstance.CollectionVersionDetailsWithHttpInfo(collectionId, versionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.CollectionVersionDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection Unique identifier |  |
| **versionId** | **long** | Version Number |  |

### Return type

[**CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Collection for that version |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="collectionversions"></a>
# **CollectionVersions**
> List&lt;CollectionVersions&gt; CollectionVersions (long collectionId)

Collection Versions list

Returns a list of public collection Versions

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class CollectionVersionsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection Unique identifier

            try
            {
                // Collection Versions list
                List<CollectionVersions> result = apiInstance.CollectionVersions(collectionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.CollectionVersions: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the CollectionVersionsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Collection Versions list
    ApiResponse<List<CollectionVersions>> response = apiInstance.CollectionVersionsWithHttpInfo(collectionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.CollectionVersionsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection Unique identifier |  |

### Return type

[**List&lt;CollectionVersions&gt;**](CollectionVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of versions |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="collectionslist"></a>
# **CollectionsList**
> List&lt;Collection&gt; CollectionsList (Guid? xCursor = null, long? page = null, long? pageSize = null, long? limit = null, long? offset = null, string? order = null, string? orderDirection = null, long? institution = null, string? publishedSince = null, string? modifiedSince = null, long? group = null, string? resourceDoi = null, string? doi = null, string? handle = null)

Public Collections

Returns a list of public collections

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class CollectionsListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new CollectionsApi(config);
            var xCursor = "xCursor_example";  // Guid? | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional) 
            var page = 789L;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10L;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789L;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789L;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 
            var order = "published_date";  // string? | The field by which to order. Default varies by endpoint/resource. (optional)  (default to published_date)
            var orderDirection = "asc";  // string? |  (optional)  (default to desc)
            var institution = 789L;  // long? | only return collections from this institution (optional) 
            var publishedSince = "publishedSince_example";  // string? | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD (optional) 
            var modifiedSince = "modifiedSince_example";  // string? | Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD (optional) 
            var group = 789L;  // long? | only return collections from this group (optional) 
            var resourceDoi = "resourceDoi_example";  // string? | only return collections with this resource_doi (optional) 
            var doi = "doi_example";  // string? | only return collections with this doi (optional) 
            var handle = "handle_example";  // string? | only return collections with this handle (optional) 

            try
            {
                // Public Collections
                List<Collection> result = apiInstance.CollectionsList(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, modifiedSince, group, resourceDoi, doi, handle);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.CollectionsList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the CollectionsListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Collections
    ApiResponse<List<Collection>> response = apiInstance.CollectionsListWithHttpInfo(xCursor, page, pageSize, limit, offset, order, orderDirection, institution, publishedSince, modifiedSince, group, resourceDoi, doi, handle);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.CollectionsListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **xCursor** | **Guid?** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional]  |
| **page** | **long?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **long?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **long?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |
| **order** | **string?** | The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date] |
| **orderDirection** | **string?** |  | [optional] [default to desc] |
| **institution** | **long?** | only return collections from this institution | [optional]  |
| **publishedSince** | **string?** | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD | [optional]  |
| **modifiedSince** | **string?** | Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD | [optional]  |
| **group** | **long?** | only return collections from this group | [optional]  |
| **resourceDoi** | **string?** | only return collections with this resource_doi | [optional]  |
| **doi** | **string?** | only return collections with this doi | [optional]  |
| **handle** | **string?** | only return collections with this handle | [optional]  |

### Return type

**List<Collection>**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of collections |  * X-Cursor - Unique hash used for bypassing the item retrieval limit of 9,000 entities. <br>  |
| **400** | Bad Request |  -  |
| **422** | Bad Request |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="collectionssearch"></a>
# **CollectionsSearch**
> List&lt;Collection&gt; CollectionsSearch (Guid? xCursor = null, CollectionSearch? search = null)

Public Collections Search

Returns a list of public collections

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class CollectionsSearchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new CollectionsApi(config);
            var xCursor = "xCursor_example";  // Guid? | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional) 
            var search = new CollectionSearch?(); // CollectionSearch? | Search Parameters (optional) 

            try
            {
                // Public Collections Search
                List<Collection> result = apiInstance.CollectionsSearch(xCursor, search);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.CollectionsSearch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the CollectionsSearchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Collections Search
    ApiResponse<List<Collection>> response = apiInstance.CollectionsSearchWithHttpInfo(xCursor, search);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.CollectionsSearchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **xCursor** | **Guid?** | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional]  |
| **search** | [**CollectionSearch?**](CollectionSearch?.md) | Search Parameters | [optional]  |

### Return type

**List<Collection>**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of collections |  * X-Cursor - Unique hash used for bypassing the item retrieval limit of 9,000 entities. <br>  |
| **400** | Bad Request |  -  |
| **422** | Bad Request |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionarticledelete"></a>
# **PrivateCollectionArticleDelete**
> void PrivateCollectionArticleDelete (long collectionId, long articleId)

Delete collection article

De-associate article from collection

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionArticleDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var articleId = 789L;  // long | Collection article unique identifier

            try
            {
                // Delete collection article
                apiInstance.PrivateCollectionArticleDelete(collectionId, articleId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionArticleDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionArticleDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete collection article
    apiInstance.PrivateCollectionArticleDeleteWithHttpInfo(collectionId, articleId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionArticleDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **articleId** | **long** | Collection article unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionarticlesadd"></a>
# **PrivateCollectionArticlesAdd**
> Location PrivateCollectionArticlesAdd (long collectionId, ArticlesCreator articles)

Add collection articles

Associate new articles with the collection. This will add new articles to the list of already associated articles

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionArticlesAddExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var articles = new ArticlesCreator(); // ArticlesCreator | Articles list

            try
            {
                // Add collection articles
                Location result = apiInstance.PrivateCollectionArticlesAdd(collectionId, articles);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionArticlesAdd: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionArticlesAddWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Add collection articles
    ApiResponse<Location> response = apiInstance.PrivateCollectionArticlesAddWithHttpInfo(collectionId, articles);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionArticlesAddWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **articles** | [**ArticlesCreator**](ArticlesCreator.md) | Articles list |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Reset Content |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionarticleslist"></a>
# **PrivateCollectionArticlesList**
> List&lt;Article&gt; PrivateCollectionArticlesList (long collectionId, long? page = null, long? pageSize = null, long? limit = null, long? offset = null)

List collection articles

List collection articles

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionArticlesListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var page = 789L;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10L;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789L;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789L;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // List collection articles
                List<Article> result = apiInstance.PrivateCollectionArticlesList(collectionId, page, pageSize, limit, offset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionArticlesList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionArticlesListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List collection articles
    ApiResponse<List<Article>> response = apiInstance.PrivateCollectionArticlesListWithHttpInfo(collectionId, page, pageSize, limit, offset);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionArticlesListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **page** | **long?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **long?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **long?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |

### Return type

[**List&lt;Article&gt;**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Articles List |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionarticlesreplace"></a>
# **PrivateCollectionArticlesReplace**
> void PrivateCollectionArticlesReplace (long collectionId, ArticlesCreator articles)

Replace collection articles

Associate new articles with the collection. This will remove all already associated articles and add these new ones

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionArticlesReplaceExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var articles = new ArticlesCreator(); // ArticlesCreator | Articles List

            try
            {
                // Replace collection articles
                apiInstance.PrivateCollectionArticlesReplace(collectionId, articles);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionArticlesReplace: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionArticlesReplaceWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Replace collection articles
    apiInstance.PrivateCollectionArticlesReplaceWithHttpInfo(collectionId, articles);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionArticlesReplaceWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **articles** | [**ArticlesCreator**](ArticlesCreator.md) | Articles List |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionauthordelete"></a>
# **PrivateCollectionAuthorDelete**
> void PrivateCollectionAuthorDelete (long collectionId, long authorId)

Delete collection author

Delete collection author

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionAuthorDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var authorId = 789L;  // long | Collection Author unique identifier

            try
            {
                // Delete collection author
                apiInstance.PrivateCollectionAuthorDelete(collectionId, authorId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionAuthorDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionAuthorDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete collection author
    apiInstance.PrivateCollectionAuthorDeleteWithHttpInfo(collectionId, authorId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionAuthorDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **authorId** | **long** | Collection Author unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionauthorsadd"></a>
# **PrivateCollectionAuthorsAdd**
> Location PrivateCollectionAuthorsAdd (long collectionId, AuthorsCreator authors)

Add collection authors

Associate new authors with the collection. This will add new authors to the list of already associated authors

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionAuthorsAddExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var authors = new AuthorsCreator(); // AuthorsCreator | List of authors

            try
            {
                // Add collection authors
                Location result = apiInstance.PrivateCollectionAuthorsAdd(collectionId, authors);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionAuthorsAdd: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionAuthorsAddWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Add collection authors
    ApiResponse<Location> response = apiInstance.PrivateCollectionAuthorsAddWithHttpInfo(collectionId, authors);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionAuthorsAddWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **authors** | [**AuthorsCreator**](AuthorsCreator.md) | List of authors |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Reset Content |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionauthorslist"></a>
# **PrivateCollectionAuthorsList**
> List&lt;Author&gt; PrivateCollectionAuthorsList (long collectionId)

List collection authors

List collection authors

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionAuthorsListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier

            try
            {
                // List collection authors
                List<Author> result = apiInstance.PrivateCollectionAuthorsList(collectionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionAuthorsList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionAuthorsListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List collection authors
    ApiResponse<List<Author>> response = apiInstance.PrivateCollectionAuthorsListWithHttpInfo(collectionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionAuthorsListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |

### Return type

[**List&lt;Author&gt;**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Embargo for article |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionauthorsreplace"></a>
# **PrivateCollectionAuthorsReplace**
> void PrivateCollectionAuthorsReplace (long collectionId, AuthorsCreator authors)

Replace collection authors

Associate new authors with the collection. This will remove all already associated authors and add these new ones

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionAuthorsReplaceExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var authors = new AuthorsCreator(); // AuthorsCreator | List of authors

            try
            {
                // Replace collection authors
                apiInstance.PrivateCollectionAuthorsReplace(collectionId, authors);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionAuthorsReplace: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionAuthorsReplaceWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Replace collection authors
    apiInstance.PrivateCollectionAuthorsReplaceWithHttpInfo(collectionId, authors);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionAuthorsReplaceWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **authors** | [**AuthorsCreator**](AuthorsCreator.md) | List of authors |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectioncategoriesadd"></a>
# **PrivateCollectionCategoriesAdd**
> Location PrivateCollectionCategoriesAdd (long collectionId, CategoriesCreator categories)

Add collection categories

Associate new categories with the collection. This will add new categories to the list of already associated categories

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionCategoriesAddExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var categories = new CategoriesCreator(); // CategoriesCreator | Categories list

            try
            {
                // Add collection categories
                Location result = apiInstance.PrivateCollectionCategoriesAdd(collectionId, categories);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCategoriesAdd: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionCategoriesAddWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Add collection categories
    ApiResponse<Location> response = apiInstance.PrivateCollectionCategoriesAddWithHttpInfo(collectionId, categories);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCategoriesAddWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **categories** | [**CategoriesCreator**](CategoriesCreator.md) | Categories list |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Reset Content |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectioncategorieslist"></a>
# **PrivateCollectionCategoriesList**
> List&lt;Category&gt; PrivateCollectionCategoriesList (long collectionId)

List collection categories

List collection categories

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionCategoriesListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier

            try
            {
                // List collection categories
                List<Category> result = apiInstance.PrivateCollectionCategoriesList(collectionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCategoriesList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionCategoriesListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List collection categories
    ApiResponse<List<Category>> response = apiInstance.PrivateCollectionCategoriesListWithHttpInfo(collectionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCategoriesListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |

### Return type

[**List&lt;Category&gt;**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Categories list |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectioncategoriesreplace"></a>
# **PrivateCollectionCategoriesReplace**
> void PrivateCollectionCategoriesReplace (long collectionId, CategoriesCreator categories)

Replace collection categories

Associate new categories with the collection. This will remove all already associated categories and add these new ones

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionCategoriesReplaceExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var categories = new CategoriesCreator(); // CategoriesCreator | Categories list

            try
            {
                // Replace collection categories
                apiInstance.PrivateCollectionCategoriesReplace(collectionId, categories);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCategoriesReplace: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionCategoriesReplaceWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Replace collection categories
    apiInstance.PrivateCollectionCategoriesReplaceWithHttpInfo(collectionId, categories);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCategoriesReplaceWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **categories** | [**CategoriesCreator**](CategoriesCreator.md) | Categories list |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectioncategorydelete"></a>
# **PrivateCollectionCategoryDelete**
> void PrivateCollectionCategoryDelete (long collectionId, long categoryId)

Delete collection category

De-associate category from collection

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionCategoryDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var categoryId = 789L;  // long | Collection category unique identifier

            try
            {
                // Delete collection category
                apiInstance.PrivateCollectionCategoryDelete(collectionId, categoryId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCategoryDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionCategoryDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete collection category
    apiInstance.PrivateCollectionCategoryDeleteWithHttpInfo(collectionId, categoryId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCategoryDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **categoryId** | **long** | Collection category unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectioncreate"></a>
# **PrivateCollectionCreate**
> LocationWarnings PrivateCollectionCreate (CollectionCreate collection)

Create collection

Create a new Collection by sending collection information

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionCreateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collection = new CollectionCreate(); // CollectionCreate | Collection description

            try
            {
                // Create collection
                LocationWarnings result = apiInstance.PrivateCollectionCreate(collection);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCreate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionCreateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create collection
    ApiResponse<LocationWarnings> response = apiInstance.PrivateCollectionCreateWithHttpInfo(collection);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionCreateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collection** | [**CollectionCreate**](CollectionCreate.md) | Collection description |  |

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectiondelete"></a>
# **PrivateCollectionDelete**
> void PrivateCollectionDelete (long collectionId)

Delete collection

Delete n collection

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection Unique identifier

            try
            {
                // Delete collection
                apiInstance.PrivateCollectionDelete(collectionId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete collection
    apiInstance.PrivateCollectionDeleteWithHttpInfo(collectionId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection Unique identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectiondetails"></a>
# **PrivateCollectionDetails**
> CollectionCompletePrivate PrivateCollectionDetails (long collectionId)

Collection details

View a collection

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection Unique identifier

            try
            {
                // Collection details
                CollectionCompletePrivate result = apiInstance.PrivateCollectionDetails(collectionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Collection details
    ApiResponse<CollectionCompletePrivate> response = apiInstance.PrivateCollectionDetailsWithHttpInfo(collectionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection Unique identifier |  |

### Return type

[**CollectionCompletePrivate**](CollectionCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Collection representation |  -  |
| **400** | Bad Request |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionpatch"></a>
# **PrivateCollectionPatch**
> LocationWarningsUpdate PrivateCollectionPatch (long collectionId, CollectionUpdate collection)

Partially update collection

Partially update a collection by sending only the fields to change.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionPatchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection Unique identifier
            var collection = new CollectionUpdate(); // CollectionUpdate | Subset of collection fields to update

            try
            {
                // Partially update collection
                LocationWarningsUpdate result = apiInstance.PrivateCollectionPatch(collectionId, collection);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPatch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionPatchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Partially update collection
    ApiResponse<LocationWarningsUpdate> response = apiInstance.PrivateCollectionPatchWithHttpInfo(collectionId, collection);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPatchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection Unique identifier |  |
| **collection** | [**CollectionUpdate**](CollectionUpdate.md) | Subset of collection fields to update |  |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionprivatelinkcreate"></a>
# **PrivateCollectionPrivateLinkCreate**
> PrivateLinkResponse PrivateCollectionPrivateLinkCreate (long collectionId, CollectionPrivateLinkCreator? privateLink = null)

Create collection private link

Create new private link

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionPrivateLinkCreateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var privateLink = new CollectionPrivateLinkCreator?(); // CollectionPrivateLinkCreator? |  (optional) 

            try
            {
                // Create collection private link
                PrivateLinkResponse result = apiInstance.PrivateCollectionPrivateLinkCreate(collectionId, privateLink);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinkCreate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionPrivateLinkCreateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create collection private link
    ApiResponse<PrivateLinkResponse> response = apiInstance.PrivateCollectionPrivateLinkCreateWithHttpInfo(collectionId, privateLink);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinkCreateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **privateLink** | [**CollectionPrivateLinkCreator?**](CollectionPrivateLinkCreator?.md) |  | [optional]  |

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionprivatelinkdelete"></a>
# **PrivateCollectionPrivateLinkDelete**
> void PrivateCollectionPrivateLinkDelete (long collectionId, string linkId)

Disable private link

Disable/delete private link for this collection

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionPrivateLinkDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var linkId = "linkId_example";  // string | Private link token

            try
            {
                // Disable private link
                apiInstance.PrivateCollectionPrivateLinkDelete(collectionId, linkId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinkDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionPrivateLinkDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Disable private link
    apiInstance.PrivateCollectionPrivateLinkDeleteWithHttpInfo(collectionId, linkId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinkDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **linkId** | **string** | Private link token |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionprivatelinkdetails"></a>
# **PrivateCollectionPrivateLinkDetails**
> PrivateLink PrivateCollectionPrivateLinkDetails (long collectionId, string linkId)

View collection private link

View existing private link for this collection

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionPrivateLinkDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var linkId = "linkId_example";  // string | Private link token

            try
            {
                // View collection private link
                PrivateLink result = apiInstance.PrivateCollectionPrivateLinkDetails(collectionId, linkId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinkDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionPrivateLinkDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // View collection private link
    ApiResponse<PrivateLink> response = apiInstance.PrivateCollectionPrivateLinkDetailsWithHttpInfo(collectionId, linkId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinkDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **linkId** | **string** | Private link token |  |

### Return type

[**PrivateLink**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Collection private link |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionprivatelinkupdate"></a>
# **PrivateCollectionPrivateLinkUpdate**
> void PrivateCollectionPrivateLinkUpdate (long collectionId, string linkId, CollectionPrivateLinkCreator? privateLink = null)

Update collection private link

Update existing private link for this collection

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionPrivateLinkUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var linkId = "linkId_example";  // string | Private link token
            var privateLink = new CollectionPrivateLinkCreator?(); // CollectionPrivateLinkCreator? |  (optional) 

            try
            {
                // Update collection private link
                apiInstance.PrivateCollectionPrivateLinkUpdate(collectionId, linkId, privateLink);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinkUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionPrivateLinkUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update collection private link
    apiInstance.PrivateCollectionPrivateLinkUpdateWithHttpInfo(collectionId, linkId, privateLink);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinkUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **linkId** | **string** | Private link token |  |
| **privateLink** | [**CollectionPrivateLinkCreator?**](CollectionPrivateLinkCreator?.md) |  | [optional]  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of article <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **422** | Unprocessable Entity |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionprivatelinkslist"></a>
# **PrivateCollectionPrivateLinksList**
> List&lt;PrivateLink&gt; PrivateCollectionPrivateLinksList (long collectionId)

List collection private links

List article private links

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionPrivateLinksListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier

            try
            {
                // List collection private links
                List<PrivateLink> result = apiInstance.PrivateCollectionPrivateLinksList(collectionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinksList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionPrivateLinksListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List collection private links
    ApiResponse<List<PrivateLink>> response = apiInstance.PrivateCollectionPrivateLinksListWithHttpInfo(collectionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPrivateLinksListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |

### Return type

[**List&lt;PrivateLink&gt;**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Collection private links |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionpublish"></a>
# **PrivateCollectionPublish**
> Location PrivateCollectionPublish (long collectionId)

Private Collection Publish

When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionPublishExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection Unique identifier

            try
            {
                // Private Collection Publish
                Location result = apiInstance.PrivateCollectionPublish(collectionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPublish: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionPublishWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Collection Publish
    ApiResponse<Location> response = apiInstance.PrivateCollectionPublishWithHttpInfo(collectionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionPublishWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection Unique identifier |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  * Location - Location of project <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionreservedoi"></a>
# **PrivateCollectionReserveDoi**
> CollectionDOI PrivateCollectionReserveDoi (long collectionId)

Private Collection Reserve DOI

Reserve DOI for collection

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionReserveDoiExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection Unique identifier

            try
            {
                // Private Collection Reserve DOI
                CollectionDOI result = apiInstance.PrivateCollectionReserveDoi(collectionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionReserveDoi: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionReserveDoiWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Collection Reserve DOI
    ApiResponse<CollectionDOI> response = apiInstance.PrivateCollectionReserveDoiWithHttpInfo(collectionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionReserveDoiWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection Unique identifier |  |

### Return type

[**CollectionDOI**](CollectionDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionreservehandle"></a>
# **PrivateCollectionReserveHandle**
> CollectionHandle PrivateCollectionReserveHandle (long collectionId)

Private Collection Reserve Handle

Reserve Handle for collection

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionReserveHandleExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection Unique identifier

            try
            {
                // Private Collection Reserve Handle
                CollectionHandle result = apiInstance.PrivateCollectionReserveHandle(collectionId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionReserveHandle: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionReserveHandleWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Collection Reserve Handle
    ApiResponse<CollectionHandle> response = apiInstance.PrivateCollectionReserveHandleWithHttpInfo(collectionId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionReserveHandleWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection Unique identifier |  |

### Return type

[**CollectionHandle**](CollectionHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionresource"></a>
# **PrivateCollectionResource**
> Location PrivateCollectionResource (long collectionId, Resource resource)

Private Collection Resource

Edit collection resource data.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionResourceExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection unique identifier
            var resource = new Resource(); // Resource | Resource data

            try
            {
                // Private Collection Resource
                Location result = apiInstance.PrivateCollectionResource(collectionId, resource);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionResource: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionResourceWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Collection Resource
    ApiResponse<Location> response = apiInstance.PrivateCollectionResourceWithHttpInfo(collectionId, resource);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionResourceWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection unique identifier |  |
| **resource** | [**Resource**](Resource.md) | Resource data |  |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **422** | Unprocessable Entity |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionupdate"></a>
# **PrivateCollectionUpdate**
> LocationWarningsUpdate PrivateCollectionUpdate (long collectionId, CollectionUpdate collection)

Update collection

Update a collection by passing full body parameters.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var collectionId = 789L;  // long | Collection Unique identifier
            var collection = new CollectionUpdate(); // CollectionUpdate | Collection description

            try
            {
                // Update collection
                LocationWarningsUpdate result = apiInstance.PrivateCollectionUpdate(collectionId, collection);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update collection
    ApiResponse<LocationWarningsUpdate> response = apiInstance.PrivateCollectionUpdateWithHttpInfo(collectionId, collection);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **collectionId** | **long** | Collection Unique identifier |  |
| **collection** | [**CollectionUpdate**](CollectionUpdate.md) | Collection description |  |

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionslist"></a>
# **PrivateCollectionsList**
> List&lt;Collection&gt; PrivateCollectionsList (long? page = null, long? pageSize = null, long? limit = null, long? offset = null, string? order = null, string? orderDirection = null)

Private Collections List

List private collections

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionsListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var page = 789L;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10L;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789L;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789L;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 
            var order = "published_date";  // string? | The field by which to order. Default varies by endpoint/resource. (optional)  (default to published_date)
            var orderDirection = "asc";  // string? |  (optional)  (default to desc)

            try
            {
                // Private Collections List
                List<Collection> result = apiInstance.PrivateCollectionsList(page, pageSize, limit, offset, order, orderDirection);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionsList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionsListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Collections List
    ApiResponse<List<Collection>> response = apiInstance.PrivateCollectionsListWithHttpInfo(page, pageSize, limit, offset, order, orderDirection);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionsListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **page** | **long?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **long?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **long?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |
| **order** | **string?** | The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date] |
| **orderDirection** | **string?** |  | [optional] [default to desc] |

### Return type

**List<Collection>**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of collections |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecollectionssearch"></a>
# **PrivateCollectionsSearch**
> List&lt;Collection&gt; PrivateCollectionsSearch (PrivateCollectionSearch search)

Private Collections Search

Returns a list of private Collections

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCollectionsSearchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CollectionsApi(config);
            var search = new PrivateCollectionSearch(); // PrivateCollectionSearch | Search Parameters

            try
            {
                // Private Collections Search
                List<Collection> result = apiInstance.PrivateCollectionsSearch(search);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CollectionsApi.PrivateCollectionsSearch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCollectionsSearchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Collections Search
    ApiResponse<List<Collection>> response = apiInstance.PrivateCollectionsSearchWithHttpInfo(search);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling CollectionsApi.PrivateCollectionsSearchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **search** | [**PrivateCollectionSearch**](PrivateCollectionSearch.md) | Search Parameters |  |

### Return type

**List<Collection>**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of collections |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

