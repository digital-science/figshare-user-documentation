# Org.OpenAPITools.Model.Location

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VarLocation** | **string** | Url for item | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

