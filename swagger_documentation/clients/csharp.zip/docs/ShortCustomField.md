# Org.OpenAPITools.Model.ShortCustomField

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long** | Custom field id | 
**Name** | **string** | Custom field name | 
**FieldType** | **string** | Custom field type | 
**Settings** | **Object** | Settings for the custom field | [optional] 
**Order** | **long** | Order of the field in the group | [optional] 
**IsMandatory** | **bool** | Whether the field is mandatory or not | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

