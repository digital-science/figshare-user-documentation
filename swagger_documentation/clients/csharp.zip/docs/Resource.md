# Org.OpenAPITools.Model.Resource

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | ID of resource item | [optional] [default to ""]
**Title** | **string** | Title of resource item | [optional] [default to ""]
**Doi** | **string** | DOI of resource item | [optional] [default to ""]
**Link** | **string** | Link of resource item | [optional] [default to ""]
**Status** | **string** | Status of resource item | [optional] [default to ""]
**VarVersion** | **long** | Version of resource item | [optional] [default to 0]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

