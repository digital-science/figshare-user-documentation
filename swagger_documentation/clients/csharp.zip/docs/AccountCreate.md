# Org.OpenAPITools.Model.AccountCreate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Email** | **string** | Email of account | 
**FirstName** | **string** | First Name | [optional] [default to ""]
**LastName** | **string** | Last Name | [default to ""]
**GroupId** | **int** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] 
**InstitutionUserId** | **string** | Institution user id | [optional] [default to ""]
**SymplecticUserId** | **string** | Symplectic user id | [optional] [default to ""]
**Quota** | **int** | Account quota | [optional] 
**IsActive** | **bool** | Is account active | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

