# IO.Swagger.Api.InstitutionsApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AccountInstitutionCuration**](InstitutionsApi.md#accountinstitutioncuration) | **GET** /account/institution/review/{curation_id} | Institution Curation Review
[**AccountInstitutionCurations**](InstitutionsApi.md#accountinstitutioncurations) | **GET** /account/institution/reviews | Institution Curation Reviews
[**CustomFieldsList**](InstitutionsApi.md#customfieldslist) | **GET** /account/institution/custom_fields | Private account institution group custom fields
[**CustomFieldsUpload**](InstitutionsApi.md#customfieldsupload) | **POST** /account/institution/custom_fields/{custom_field_id}/items/upload | Custom fields values files upload
[**GetAccountInstitutionCurationComments**](InstitutionsApi.md#getaccountinstitutioncurationcomments) | **GET** /account/institution/review/{curation_id}/comments | Institution Curation Review Comments
[**InstitutionArticles**](InstitutionsApi.md#institutionarticles) | **GET** /institutions/{institution_string_id}/articles/filter-by | Public Institution Articles
[**InstitutionHrfeedUpload**](InstitutionsApi.md#institutionhrfeedupload) | **POST** /institution/hrfeed/upload | Private Institution HRfeed Upload
[**PostAccountInstitutionCurationComments**](InstitutionsApi.md#postaccountinstitutioncurationcomments) | **POST** /account/institution/review/{curation_id}/comments | POST Institution Curation Review Comment
[**PrivateAccountInstitutionUser**](InstitutionsApi.md#privateaccountinstitutionuser) | **GET** /account/institution/users/{account_id} | Private Account Institution User
[**PrivateCategoriesList**](InstitutionsApi.md#privatecategorieslist) | **GET** /account/categories | Private Account Categories
[**PrivateGroupEmbargoOptionsDetails**](InstitutionsApi.md#privategroupembargooptionsdetails) | **GET** /account/institution/groups/{group_id}/embargo_options | Private Account Institution Group Embargo Options
[**PrivateInstitutionAccount**](InstitutionsApi.md#privateinstitutionaccount) | **GET** /account/institution/accounts/{account_id} | Private Institution Account information
[**PrivateInstitutionAccountGroupRoleDelete**](InstitutionsApi.md#privateinstitutionaccountgrouproledelete) | **DELETE** /account/institution/roles/{account_id}/{group_id}/{role_id} | Delete Institution Account Group Role
[**PrivateInstitutionAccountGroupRoles**](InstitutionsApi.md#privateinstitutionaccountgrouproles) | **GET** /account/institution/roles/{account_id} | List Institution Account Group Roles
[**PrivateInstitutionAccountGroupRolesCreate**](InstitutionsApi.md#privateinstitutionaccountgrouprolescreate) | **POST** /account/institution/roles/{account_id} | Add Institution Account Group Roles
[**PrivateInstitutionAccountsCreate**](InstitutionsApi.md#privateinstitutionaccountscreate) | **POST** /account/institution/accounts | Create new Institution Account
[**PrivateInstitutionAccountsList**](InstitutionsApi.md#privateinstitutionaccountslist) | **GET** /account/institution/accounts | Private Account Institution Accounts
[**PrivateInstitutionAccountsSearch**](InstitutionsApi.md#privateinstitutionaccountssearch) | **POST** /account/institution/accounts/search | Private Account Institution Accounts Search
[**PrivateInstitutionAccountsUpdate**](InstitutionsApi.md#privateinstitutionaccountsupdate) | **PUT** /account/institution/accounts/{account_id} | Update Institution Account
[**PrivateInstitutionArticles**](InstitutionsApi.md#privateinstitutionarticles) | **GET** /account/institution/articles | Private Institution Articles
[**PrivateInstitutionDetails**](InstitutionsApi.md#privateinstitutiondetails) | **GET** /account/institution | Private Account Institutions
[**PrivateInstitutionEmbargoOptionsDetails**](InstitutionsApi.md#privateinstitutionembargooptionsdetails) | **GET** /account/institution/embargo_options | Private Account Institution embargo options
[**PrivateInstitutionGroupsList**](InstitutionsApi.md#privateinstitutiongroupslist) | **GET** /account/institution/groups | Private Account Institution Groups
[**PrivateInstitutionRolesList**](InstitutionsApi.md#privateinstitutionroleslist) | **GET** /account/institution/roles | Private Account Institution Roles


<a name="accountinstitutioncuration"></a>
# **AccountInstitutionCuration**
> CurationDetail AccountInstitutionCuration (long? curationId)

Institution Curation Review

Retrieve a certain curation review by its ID

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AccountInstitutionCurationExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var curationId = 789;  // long? | ID of the curation

            try
            {
                // Institution Curation Review
                CurationDetail result = apiInstance.AccountInstitutionCuration(curationId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.AccountInstitutionCuration: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curationId** | **long?**| ID of the curation | 

### Return type

[**CurationDetail**](CurationDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="accountinstitutioncurations"></a>
# **AccountInstitutionCurations**
> Curation AccountInstitutionCurations (long? groupId = null, long? articleId = null, string status = null, long? limit = null, long? offset = null)

Institution Curation Reviews

Retrieve a list of curation reviews for this institution

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AccountInstitutionCurationsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var groupId = 789;  // long? | Filter by the group ID (optional) 
            var articleId = 789;  // long? | Retrieve the reviews for this article (optional) 
            var status = status_example;  // string | Filter by the status of the review (optional) 
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Institution Curation Reviews
                Curation result = apiInstance.AccountInstitutionCurations(groupId, articleId, status, limit, offset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.AccountInstitutionCurations: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **long?**| Filter by the group ID | [optional] 
 **articleId** | **long?**| Retrieve the reviews for this article | [optional] 
 **status** | **string**| Filter by the status of the review | [optional] 
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**Curation**](Curation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="customfieldslist"></a>
# **CustomFieldsList**
> List<ShortCustomField> CustomFieldsList (long? groupId = null)

Private account institution group custom fields

Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CustomFieldsListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var groupId = 789;  // long? | Group_id (optional) 

            try
            {
                // Private account institution group custom fields
                List&lt;ShortCustomField&gt; result = apiInstance.CustomFieldsList(groupId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.CustomFieldsList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **long?**| Group_id | [optional] 

### Return type

[**List<ShortCustomField>**](ShortCustomField.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="customfieldsupload"></a>
# **CustomFieldsUpload**
> Object CustomFieldsUpload (long? customFieldId, System.IO.Stream externalFile = null)

Custom fields values files upload

Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. More details in the <a href=\"#custom_fields\">Custom Fields section</a>

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CustomFieldsUploadExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var customFieldId = 789;  // long? | Custom field identifier
            var externalFile = new System.IO.Stream(); // System.IO.Stream | CSV file to be uploaded (optional) 

            try
            {
                // Custom fields values files upload
                Object result = apiInstance.CustomFieldsUpload(customFieldId, externalFile);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.CustomFieldsUpload: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customFieldId** | **long?**| Custom field identifier | 
 **externalFile** | **System.IO.Stream**| CSV file to be uploaded | [optional] 

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getaccountinstitutioncurationcomments"></a>
# **GetAccountInstitutionCurationComments**
> CurationComment GetAccountInstitutionCurationComments (long? curationId, long? limit = null, long? offset = null)

Institution Curation Review Comments

Retrieve a certain curation review's comments.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAccountInstitutionCurationCommentsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var curationId = 789;  // long? | ID of the curation
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Institution Curation Review Comments
                CurationComment result = apiInstance.GetAccountInstitutionCurationComments(curationId, limit, offset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.GetAccountInstitutionCurationComments: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curationId** | **long?**| ID of the curation | 
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**CurationComment**](CurationComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="institutionarticles"></a>
# **InstitutionArticles**
> List<Article> InstitutionArticles (string institutionStringId, string resourceId, string filename)

Public Institution Articles

Returns a list of articles belonging to the institution

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class InstitutionArticlesExample
    {
        public void main()
        {
            var apiInstance = new InstitutionsApi();
            var institutionStringId = institutionStringId_example;  // string | 
            var resourceId = resourceId_example;  // string | 
            var filename = filename_example;  // string | 

            try
            {
                // Public Institution Articles
                List&lt;Article&gt; result = apiInstance.InstitutionArticles(institutionStringId, resourceId, filename);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.InstitutionArticles: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **institutionStringId** | **string**|  | 
 **resourceId** | **string**|  | 
 **filename** | **string**|  | 

### Return type

[**List<Article>**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="institutionhrfeedupload"></a>
# **InstitutionHrfeedUpload**
> ResponseMessage InstitutionHrfeedUpload (System.IO.Stream hrfeed = null)

Private Institution HRfeed Upload

More info in the <a href=\"#hr_feed\">HR Feed section</a>

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class InstitutionHrfeedUploadExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var hrfeed = new System.IO.Stream(); // System.IO.Stream | You can find an example in the Hr Feed section (optional) 

            try
            {
                // Private Institution HRfeed Upload
                ResponseMessage result = apiInstance.InstitutionHrfeedUpload(hrfeed);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.InstitutionHrfeedUpload: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hrfeed** | **System.IO.Stream**| You can find an example in the Hr Feed section | [optional] 

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="postaccountinstitutioncurationcomments"></a>
# **PostAccountInstitutionCurationComments**
> void PostAccountInstitutionCurationComments (long? curationId, CurationCommentCreate curationComment)

POST Institution Curation Review Comment

Add a new comment to the review.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PostAccountInstitutionCurationCommentsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var curationId = 789;  // long? | ID of the curation
            var curationComment = new CurationCommentCreate(); // CurationCommentCreate | The content/value of the comment.

            try
            {
                // POST Institution Curation Review Comment
                apiInstance.PostAccountInstitutionCurationComments(curationId, curationComment);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PostAccountInstitutionCurationComments: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curationId** | **long?**| ID of the curation | 
 **curationComment** | [**CurationCommentCreate**](CurationCommentCreate.md)| The content/value of the comment. | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateaccountinstitutionuser"></a>
# **PrivateAccountInstitutionUser**
> User PrivateAccountInstitutionUser (long? accountId)

Private Account Institution User

Retrieve institution user information using the account_id

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateAccountInstitutionUserExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var accountId = 789;  // long? | Account identifier the user is associated to

            try
            {
                // Private Account Institution User
                User result = apiInstance.PrivateAccountInstitutionUser(accountId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateAccountInstitutionUser: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountId** | **long?**| Account identifier the user is associated to | 

### Return type

[**User**](User.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privatecategorieslist"></a>
# **PrivateCategoriesList**
> List<CategoryList> PrivateCategoriesList ()

Private Account Categories

List institution categories (including parent Categories)

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateCategoriesListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();

            try
            {
                // Private Account Categories
                List&lt;CategoryList&gt; result = apiInstance.PrivateCategoriesList();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateCategoriesList: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<CategoryList>**](CategoryList.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privategroupembargooptionsdetails"></a>
# **PrivateGroupEmbargoOptionsDetails**
> List<GroupEmbargoOptions> PrivateGroupEmbargoOptionsDetails (long? groupId)

Private Account Institution Group Embargo Options

Account institution group embargo options details

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateGroupEmbargoOptionsDetailsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var groupId = 789;  // long? | Group identifier

            try
            {
                // Private Account Institution Group Embargo Options
                List&lt;GroupEmbargoOptions&gt; result = apiInstance.PrivateGroupEmbargoOptionsDetails(groupId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateGroupEmbargoOptionsDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupId** | **long?**| Group identifier | 

### Return type

[**List<GroupEmbargoOptions>**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutionaccount"></a>
# **PrivateInstitutionAccount**
> Account PrivateInstitutionAccount (long? accountId)

Private Institution Account information

Private Institution Account information

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionAccountExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var accountId = 789;  // long? | Account identifier the user is associated to

            try
            {
                // Private Institution Account information
                Account result = apiInstance.PrivateInstitutionAccount(accountId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccount: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountId** | **long?**| Account identifier the user is associated to | 

### Return type

[**Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutionaccountgrouproledelete"></a>
# **PrivateInstitutionAccountGroupRoleDelete**
> void PrivateInstitutionAccountGroupRoleDelete (long? accountId, long? groupId, long? roleId)

Delete Institution Account Group Role

Delete Institution Account Group Role

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionAccountGroupRoleDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var accountId = 789;  // long? | Account identifier for which to remove the role
            var groupId = 789;  // long? | Group identifier for which to remove the role
            var roleId = 789;  // long? | Role identifier

            try
            {
                // Delete Institution Account Group Role
                apiInstance.PrivateInstitutionAccountGroupRoleDelete(accountId, groupId, roleId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountGroupRoleDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountId** | **long?**| Account identifier for which to remove the role | 
 **groupId** | **long?**| Group identifier for which to remove the role | 
 **roleId** | **long?**| Role identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutionaccountgrouproles"></a>
# **PrivateInstitutionAccountGroupRoles**
> AccountGroupRoles PrivateInstitutionAccountGroupRoles (long? accountId)

List Institution Account Group Roles

List Institution Account Group Roles

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionAccountGroupRolesExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var accountId = 789;  // long? | Account identifier the user is associated to

            try
            {
                // List Institution Account Group Roles
                AccountGroupRoles result = apiInstance.PrivateInstitutionAccountGroupRoles(accountId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountGroupRoles: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountId** | **long?**| Account identifier the user is associated to | 

### Return type

[**AccountGroupRoles**](AccountGroupRoles.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutionaccountgrouprolescreate"></a>
# **PrivateInstitutionAccountGroupRolesCreate**
> void PrivateInstitutionAccountGroupRolesCreate (long? accountId, AccountGroupRolesCreate account)

Add Institution Account Group Roles

Add Institution Account Group Roles

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionAccountGroupRolesCreateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var accountId = 789;  // long? | Account identifier the user is associated to
            var account = new AccountGroupRolesCreate(); // AccountGroupRolesCreate | Account description

            try
            {
                // Add Institution Account Group Roles
                apiInstance.PrivateInstitutionAccountGroupRolesCreate(accountId, account);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountGroupRolesCreate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountId** | **long?**| Account identifier the user is associated to | 
 **account** | [**AccountGroupRolesCreate**](AccountGroupRolesCreate.md)| Account description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutionaccountscreate"></a>
# **PrivateInstitutionAccountsCreate**
> AccountCreateResponse PrivateInstitutionAccountsCreate (AccountCreate account)

Create new Institution Account

Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionAccountsCreateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var account = new AccountCreate(); // AccountCreate | Account description

            try
            {
                // Create new Institution Account
                AccountCreateResponse result = apiInstance.PrivateInstitutionAccountsCreate(account);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountsCreate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account** | [**AccountCreate**](AccountCreate.md)| Account description | 

### Return type

[**AccountCreateResponse**](AccountCreateResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutionaccountslist"></a>
# **PrivateInstitutionAccountsList**
> List<ShortAccount> PrivateInstitutionAccountsList (long? page = null, long? pageSize = null, long? limit = null, long? offset = null, long? isActive = null, string institutionUserId = null, string email = null, long? idLte = null, long? idGte = null)

Private Account Institution Accounts

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionAccountsListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 
            var isActive = 789;  // long? | Filter by active status (optional) 
            var institutionUserId = institutionUserId_example;  // string | Filter by institution_user_id (optional) 
            var email = email_example;  // string | Filter by email (optional) 
            var idLte = 789;  // long? | Retrieve accounts with an ID lower or equal to the specified value (optional) 
            var idGte = 789;  // long? | Retrieve accounts with an ID greater or equal to the specified value (optional) 

            try
            {
                // Private Account Institution Accounts
                List&lt;ShortAccount&gt; result = apiInstance.PrivateInstitutionAccountsList(page, pageSize, limit, offset, isActive, institutionUserId, email, idLte, idGte);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountsList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **isActive** | **long?**| Filter by active status | [optional] 
 **institutionUserId** | **string**| Filter by institution_user_id | [optional] 
 **email** | **string**| Filter by email | [optional] 
 **idLte** | **long?**| Retrieve accounts with an ID lower or equal to the specified value | [optional] 
 **idGte** | **long?**| Retrieve accounts with an ID greater or equal to the specified value | [optional] 

### Return type

[**List<ShortAccount>**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutionaccountssearch"></a>
# **PrivateInstitutionAccountsSearch**
> List<ShortAccount> PrivateInstitutionAccountsSearch (InstitutionAccountsSearch search)

Private Account Institution Accounts Search

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionAccountsSearchExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var search = new InstitutionAccountsSearch(); // InstitutionAccountsSearch | Search Parameters

            try
            {
                // Private Account Institution Accounts Search
                List&lt;ShortAccount&gt; result = apiInstance.PrivateInstitutionAccountsSearch(search);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountsSearch: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**InstitutionAccountsSearch**](InstitutionAccountsSearch.md)| Search Parameters | 

### Return type

[**List<ShortAccount>**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutionaccountsupdate"></a>
# **PrivateInstitutionAccountsUpdate**
> void PrivateInstitutionAccountsUpdate (long? accountId, AccountUpdate account)

Update Institution Account

Update Institution Account

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionAccountsUpdateExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var accountId = 789;  // long? | Account identifier the user is associated to
            var account = new AccountUpdate(); // AccountUpdate | Account description

            try
            {
                // Update Institution Account
                apiInstance.PrivateInstitutionAccountsUpdate(accountId, account);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountsUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accountId** | **long?**| Account identifier the user is associated to | 
 **account** | [**AccountUpdate**](AccountUpdate.md)| Account description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutionarticles"></a>
# **PrivateInstitutionArticles**
> List<Article> PrivateInstitutionArticles (long? page = null, long? pageSize = null, long? limit = null, long? offset = null, string order = null, string orderDirection = null, string publishedSince = null, string modifiedSince = null, long? status = null, string resourceDoi = null, long? itemType = null, long? group = null)

Private Institution Articles

Get Articles from own institution. User must be administrator of the institution

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionArticlesExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();
            var page = 789;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 789;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 
            var order = order_example;  // string | The field by which to order. Default varies by endpoint/resource. (optional)  (default to published_date)
            var orderDirection = orderDirection_example;  // string |  (optional)  (default to desc)
            var publishedSince = publishedSince_example;  // string | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional) 
            var modifiedSince = modifiedSince_example;  // string | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional) 
            var status = 789;  // long? | only return collections with this status (optional) 
            var resourceDoi = resourceDoi_example;  // string | only return collections with this resource_doi (optional) 
            var itemType = 789;  // long? | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional) 
            var group = 789;  // long? | only return articles from this group (optional) 

            try
            {
                // Private Institution Articles
                List&lt;Article&gt; result = apiInstance.PrivateInstitutionArticles(page, pageSize, limit, offset, order, orderDirection, publishedSince, modifiedSince, status, resourceDoi, itemType, group);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionArticles: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **long?**| Page number. Used for pagination with page_size | [optional] 
 **pageSize** | **long?**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **long?**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **long?**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **string**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **orderDirection** | **string**|  | [optional] [default to desc]
 **publishedSince** | **string**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **modifiedSince** | **string**| Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **status** | **long?**| only return collections with this status | [optional] 
 **resourceDoi** | **string**| only return collections with this resource_doi | [optional] 
 **itemType** | **long?**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
 **group** | **long?**| only return articles from this group | [optional] 

### Return type

[**List<Article>**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutiondetails"></a>
# **PrivateInstitutionDetails**
> Institution PrivateInstitutionDetails ()

Private Account Institutions

Account institution details

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionDetailsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();

            try
            {
                // Private Account Institutions
                Institution result = apiInstance.PrivateInstitutionDetails();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Institution**](Institution.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutionembargooptionsdetails"></a>
# **PrivateInstitutionEmbargoOptionsDetails**
> List<GroupEmbargoOptions> PrivateInstitutionEmbargoOptionsDetails ()

Private Account Institution embargo options

Account institution embargo options details

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionEmbargoOptionsDetailsExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();

            try
            {
                // Private Account Institution embargo options
                List&lt;GroupEmbargoOptions&gt; result = apiInstance.PrivateInstitutionEmbargoOptionsDetails();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionEmbargoOptionsDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<GroupEmbargoOptions>**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutiongroupslist"></a>
# **PrivateInstitutionGroupsList**
> List<Group> PrivateInstitutionGroupsList ()

Private Account Institution Groups

Returns the groups for which the account has administrative privileges (assigned and inherited).

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionGroupsListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();

            try
            {
                // Private Account Institution Groups
                List&lt;Group&gt; result = apiInstance.PrivateInstitutionGroupsList();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionGroupsList: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<Group>**](Group.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="privateinstitutionroleslist"></a>
# **PrivateInstitutionRolesList**
> List<Role> PrivateInstitutionRolesList ()

Private Account Institution Roles

Returns the roles available for groups and the institution group.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PrivateInstitutionRolesListExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi();

            try
            {
                // Private Account Institution Roles
                List&lt;Role&gt; result = apiInstance.PrivateInstitutionRolesList();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionRolesList: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<Role>**](Role.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

