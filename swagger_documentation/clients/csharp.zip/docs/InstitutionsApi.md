# Org.OpenAPITools.Api.InstitutionsApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**AccountInstitutionCuration**](InstitutionsApi.md#accountinstitutioncuration) | **GET** /account/institution/review/{curation_id} | Institution Curation Review |
| [**AccountInstitutionCurations**](InstitutionsApi.md#accountinstitutioncurations) | **GET** /account/institution/reviews | Institution Curation Reviews |
| [**CustomFieldsList**](InstitutionsApi.md#customfieldslist) | **GET** /account/institution/custom_fields | Private account institution group custom fields |
| [**CustomFieldsUpload**](InstitutionsApi.md#customfieldsupload) | **POST** /account/institution/custom_fields/{custom_field_id}/items/upload | Custom fields values files upload |
| [**GetAccountInstitutionCurationComments**](InstitutionsApi.md#getaccountinstitutioncurationcomments) | **GET** /account/institution/review/{curation_id}/comments | Institution Curation Review Comments |
| [**InstitutionArticles**](InstitutionsApi.md#institutionarticles) | **GET** /institutions/{institution_string_id}/articles/filter-by | Public Institution Articles |
| [**InstitutionHrfeedUpload**](InstitutionsApi.md#institutionhrfeedupload) | **POST** /institution/hrfeed/upload | Private Institution HRfeed Upload |
| [**PostAccountInstitutionCurationComments**](InstitutionsApi.md#postaccountinstitutioncurationcomments) | **POST** /account/institution/review/{curation_id}/comments | POST Institution Curation Review Comment |
| [**PrivateAccountInstitutionUser**](InstitutionsApi.md#privateaccountinstitutionuser) | **GET** /account/institution/users/{account_id} | Private Account Institution User |
| [**PrivateCategoriesList**](InstitutionsApi.md#privatecategorieslist) | **GET** /account/categories | Private Account Categories |
| [**PrivateGroupEmbargoOptionsDetails**](InstitutionsApi.md#privategroupembargooptionsdetails) | **GET** /account/institution/groups/{group_id}/embargo_options | Private Account Institution Group Embargo Options |
| [**PrivateInstitutionAccount**](InstitutionsApi.md#privateinstitutionaccount) | **GET** /account/institution/accounts/{account_id} | Private Institution Account information |
| [**PrivateInstitutionAccountGroupRoleDelete**](InstitutionsApi.md#privateinstitutionaccountgrouproledelete) | **DELETE** /account/institution/roles/{account_id}/{group_id}/{role_id} | Delete Institution Account Group Role |
| [**PrivateInstitutionAccountGroupRoles**](InstitutionsApi.md#privateinstitutionaccountgrouproles) | **GET** /account/institution/roles/{account_id} | List Institution Account Group Roles |
| [**PrivateInstitutionAccountGroupRolesCreate**](InstitutionsApi.md#privateinstitutionaccountgrouprolescreate) | **POST** /account/institution/roles/{account_id} | Add Institution Account Group Roles |
| [**PrivateInstitutionAccountsCreate**](InstitutionsApi.md#privateinstitutionaccountscreate) | **POST** /account/institution/accounts | Create new Institution Account |
| [**PrivateInstitutionAccountsList**](InstitutionsApi.md#privateinstitutionaccountslist) | **GET** /account/institution/accounts | Private Account Institution Accounts |
| [**PrivateInstitutionAccountsSearch**](InstitutionsApi.md#privateinstitutionaccountssearch) | **POST** /account/institution/accounts/search | Private Account Institution Accounts Search |
| [**PrivateInstitutionAccountsUpdate**](InstitutionsApi.md#privateinstitutionaccountsupdate) | **PUT** /account/institution/accounts/{account_id} | Update Institution Account |
| [**PrivateInstitutionArticles**](InstitutionsApi.md#privateinstitutionarticles) | **GET** /account/institution/articles | Private Institution Articles |
| [**PrivateInstitutionDetails**](InstitutionsApi.md#privateinstitutiondetails) | **GET** /account/institution | Private Account Institutions |
| [**PrivateInstitutionEmbargoOptionsDetails**](InstitutionsApi.md#privateinstitutionembargooptionsdetails) | **GET** /account/institution/embargo_options | Private Account Institution embargo options |
| [**PrivateInstitutionGroupsList**](InstitutionsApi.md#privateinstitutiongroupslist) | **GET** /account/institution/groups | Private Account Institution Groups |
| [**PrivateInstitutionRolesList**](InstitutionsApi.md#privateinstitutionroleslist) | **GET** /account/institution/roles | Private Account Institution Roles |

<a id="accountinstitutioncuration"></a>
# **AccountInstitutionCuration**
> CurationDetail AccountInstitutionCuration (long curationId)

Institution Curation Review

Retrieve a certain curation review by its ID

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AccountInstitutionCurationExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var curationId = 789L;  // long | ID of the curation

            try
            {
                // Institution Curation Review
                CurationDetail result = apiInstance.AccountInstitutionCuration(curationId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.AccountInstitutionCuration: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the AccountInstitutionCurationWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Institution Curation Review
    ApiResponse<CurationDetail> response = apiInstance.AccountInstitutionCurationWithHttpInfo(curationId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.AccountInstitutionCurationWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **curationId** | **long** | ID of the curation |  |

### Return type

[**CurationDetail**](CurationDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. A curation review. |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="accountinstitutioncurations"></a>
# **AccountInstitutionCurations**
> Curation AccountInstitutionCurations (long? groupId = null, long? articleId = null, string? status = null, long? limit = null, long? offset = null)

Institution Curation Reviews

Retrieve a list of curation reviews for this institution

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AccountInstitutionCurationsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var groupId = 789L;  // long? | Filter by the group ID (optional) 
            var articleId = 789L;  // long? | Retrieve the reviews for this article (optional) 
            var status = "pending";  // string? | Filter by the status of the review (optional) 
            var limit = 789L;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789L;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Institution Curation Reviews
                Curation result = apiInstance.AccountInstitutionCurations(groupId, articleId, status, limit, offset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.AccountInstitutionCurations: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the AccountInstitutionCurationsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Institution Curation Reviews
    ApiResponse<Curation> response = apiInstance.AccountInstitutionCurationsWithHttpInfo(groupId, articleId, status, limit, offset);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.AccountInstitutionCurationsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **groupId** | **long?** | Filter by the group ID | [optional]  |
| **articleId** | **long?** | Retrieve the reviews for this article | [optional]  |
| **status** | **string?** | Filter by the status of the review | [optional]  |
| **limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **long?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |

### Return type

[**Curation**](Curation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. A list of curation reviews. |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="customfieldslist"></a>
# **CustomFieldsList**
> List&lt;ShortCustomField&gt; CustomFieldsList (long? groupId = null)

Private account institution group custom fields

Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class CustomFieldsListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var groupId = 789L;  // long? | Group_id (optional) 

            try
            {
                // Private account institution group custom fields
                List<ShortCustomField> result = apiInstance.CustomFieldsList(groupId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.CustomFieldsList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the CustomFieldsListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private account institution group custom fields
    ApiResponse<List<ShortCustomField>> response = apiInstance.CustomFieldsListWithHttpInfo(groupId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.CustomFieldsListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **groupId** | **long?** | Group_id | [optional]  |

### Return type

[**List&lt;ShortCustomField&gt;**](ShortCustomField.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of custom fields |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="customfieldsupload"></a>
# **CustomFieldsUpload**
> Object CustomFieldsUpload (long customFieldId, System.IO.Stream? externalFile = null)

Custom fields values files upload

Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. More details in the <a href=\"#custom_fields\">Custom Fields section</a>

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class CustomFieldsUploadExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var customFieldId = 789L;  // long | Custom field identifier
            var externalFile = new System.IO.MemoryStream(System.IO.File.ReadAllBytes("/path/to/file.txt"));  // System.IO.Stream? | CSV file to be uploaded (optional) 

            try
            {
                // Custom fields values files upload
                Object result = apiInstance.CustomFieldsUpload(customFieldId, externalFile);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.CustomFieldsUpload: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the CustomFieldsUploadWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Custom fields values files upload
    ApiResponse<Object> response = apiInstance.CustomFieldsUploadWithHttpInfo(customFieldId, externalFile);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.CustomFieldsUploadWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **customFieldId** | **long** | Custom field identifier |  |
| **externalFile** | **System.IO.Stream?****System.IO.Stream?** | CSV file to be uploaded | [optional]  |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **409** | Conflict |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="getaccountinstitutioncurationcomments"></a>
# **GetAccountInstitutionCurationComments**
> CurationComment GetAccountInstitutionCurationComments (long curationId, long? limit = null, long? offset = null)

Institution Curation Review Comments

Retrieve a certain curation review's comments.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class GetAccountInstitutionCurationCommentsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var curationId = 789L;  // long | ID of the curation
            var limit = 789L;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789L;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 

            try
            {
                // Institution Curation Review Comments
                CurationComment result = apiInstance.GetAccountInstitutionCurationComments(curationId, limit, offset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.GetAccountInstitutionCurationComments: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the GetAccountInstitutionCurationCommentsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Institution Curation Review Comments
    ApiResponse<CurationComment> response = apiInstance.GetAccountInstitutionCurationCommentsWithHttpInfo(curationId, limit, offset);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.GetAccountInstitutionCurationCommentsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **curationId** | **long** | ID of the curation |  |
| **limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **long?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |

### Return type

[**CurationComment**](CurationComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. A curation review&#39;s comments. |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="institutionarticles"></a>
# **InstitutionArticles**
> List&lt;Article&gt; InstitutionArticles (string institutionStringId, string resourceId, string filename)

Public Institution Articles

Returns a list of articles belonging to the institution

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class InstitutionArticlesExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            var apiInstance = new InstitutionsApi(config);
            var institutionStringId = "institutionStringId_example";  // string | 
            var resourceId = "resourceId_example";  // string | 
            var filename = "filename_example";  // string | 

            try
            {
                // Public Institution Articles
                List<Article> result = apiInstance.InstitutionArticles(institutionStringId, resourceId, filename);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.InstitutionArticles: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the InstitutionArticlesWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Public Institution Articles
    ApiResponse<List<Article>> response = apiInstance.InstitutionArticlesWithHttpInfo(institutionStringId, resourceId, filename);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.InstitutionArticlesWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **institutionStringId** | **string** |  |  |
| **resourceId** | **string** |  |  |
| **filename** | **string** |  |  |

### Return type

[**List&lt;Article&gt;**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of articles |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="institutionhrfeedupload"></a>
# **InstitutionHrfeedUpload**
> ResponseMessage InstitutionHrfeedUpload (System.IO.Stream? hrfeed = null)

Private Institution HRfeed Upload

More info in the <a href=\"#hr_feed\">HR Feed section</a>

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class InstitutionHrfeedUploadExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var hrfeed = new System.IO.MemoryStream(System.IO.File.ReadAllBytes("/path/to/file.txt"));  // System.IO.Stream? | You can find an example in the Hr Feed section (optional) 

            try
            {
                // Private Institution HRfeed Upload
                ResponseMessage result = apiInstance.InstitutionHrfeedUpload(hrfeed);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.InstitutionHrfeedUpload: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the InstitutionHrfeedUploadWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Institution HRfeed Upload
    ApiResponse<ResponseMessage> response = apiInstance.InstitutionHrfeedUploadWithHttpInfo(hrfeed);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.InstitutionHrfeedUploadWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **hrfeed** | **System.IO.Stream?****System.IO.Stream?** | You can find an example in the Hr Feed section | [optional]  |

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="postaccountinstitutioncurationcomments"></a>
# **PostAccountInstitutionCurationComments**
> void PostAccountInstitutionCurationComments (long curationId, CurationCommentCreate curationComment)

POST Institution Curation Review Comment

Add a new comment to the review.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PostAccountInstitutionCurationCommentsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var curationId = 789L;  // long | ID of the curation
            var curationComment = new CurationCommentCreate(); // CurationCommentCreate | The content/value of the comment.

            try
            {
                // POST Institution Curation Review Comment
                apiInstance.PostAccountInstitutionCurationComments(curationId, curationComment);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PostAccountInstitutionCurationComments: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PostAccountInstitutionCurationCommentsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // POST Institution Curation Review Comment
    apiInstance.PostAccountInstitutionCurationCommentsWithHttpInfo(curationId, curationComment);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PostAccountInstitutionCurationCommentsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **curationId** | **long** | ID of the curation |  |
| **curationComment** | [**CurationCommentCreate**](CurationCommentCreate.md) | The content/value of the comment. |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateaccountinstitutionuser"></a>
# **PrivateAccountInstitutionUser**
> User PrivateAccountInstitutionUser (long accountId)

Private Account Institution User

Retrieve institution user information using the account_id

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateAccountInstitutionUserExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var accountId = 789L;  // long | Account identifier the user is associated to

            try
            {
                // Private Account Institution User
                User result = apiInstance.PrivateAccountInstitutionUser(accountId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateAccountInstitutionUser: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateAccountInstitutionUserWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Account Institution User
    ApiResponse<User> response = apiInstance.PrivateAccountInstitutionUserWithHttpInfo(accountId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateAccountInstitutionUserWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **accountId** | **long** | Account identifier the user is associated to |  |

### Return type

[**User**](User.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. User representation |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privatecategorieslist"></a>
# **PrivateCategoriesList**
> List&lt;CategoryList&gt; PrivateCategoriesList ()

Private Account Categories

List institution categories (including parent Categories)

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateCategoriesListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);

            try
            {
                // Private Account Categories
                List<CategoryList> result = apiInstance.PrivateCategoriesList();
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateCategoriesList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateCategoriesListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Account Categories
    ApiResponse<List<CategoryList>> response = apiInstance.PrivateCategoriesListWithHttpInfo();
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateCategoriesListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters
This endpoint does not need any parameter.
### Return type

[**List&lt;CategoryList&gt;**](CategoryList.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of categories |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privategroupembargooptionsdetails"></a>
# **PrivateGroupEmbargoOptionsDetails**
> List&lt;GroupEmbargoOptions&gt; PrivateGroupEmbargoOptionsDetails (long groupId)

Private Account Institution Group Embargo Options

Account institution group embargo options details

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateGroupEmbargoOptionsDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var groupId = 789L;  // long | Group identifier

            try
            {
                // Private Account Institution Group Embargo Options
                List<GroupEmbargoOptions> result = apiInstance.PrivateGroupEmbargoOptionsDetails(groupId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateGroupEmbargoOptionsDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateGroupEmbargoOptionsDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Account Institution Group Embargo Options
    ApiResponse<List<GroupEmbargoOptions>> response = apiInstance.PrivateGroupEmbargoOptionsDetailsWithHttpInfo(groupId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateGroupEmbargoOptionsDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **groupId** | **long** | Group identifier |  |

### Return type

[**List&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of embargo options |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutionaccount"></a>
# **PrivateInstitutionAccount**
> Account PrivateInstitutionAccount (long accountId)

Private Institution Account information

Private Institution Account information

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionAccountExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var accountId = 789L;  // long | Account identifier the user is associated to

            try
            {
                // Private Institution Account information
                Account result = apiInstance.PrivateInstitutionAccount(accountId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccount: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionAccountWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Institution Account information
    ApiResponse<Account> response = apiInstance.PrivateInstitutionAccountWithHttpInfo(accountId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **accountId** | **long** | Account identifier the user is associated to |  |

### Return type

[**Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Account |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutionaccountgrouproledelete"></a>
# **PrivateInstitutionAccountGroupRoleDelete**
> void PrivateInstitutionAccountGroupRoleDelete (long accountId, long groupId, long roleId)

Delete Institution Account Group Role

Delete Institution Account Group Role

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionAccountGroupRoleDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var accountId = 789L;  // long | Account identifier for which to remove the role
            var groupId = 789L;  // long | Group identifier for which to remove the role
            var roleId = 789L;  // long | Role identifier

            try
            {
                // Delete Institution Account Group Role
                apiInstance.PrivateInstitutionAccountGroupRoleDelete(accountId, groupId, roleId);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountGroupRoleDelete: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionAccountGroupRoleDeleteWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Delete Institution Account Group Role
    apiInstance.PrivateInstitutionAccountGroupRoleDeleteWithHttpInfo(accountId, groupId, roleId);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountGroupRoleDeleteWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **accountId** | **long** | Account identifier for which to remove the role |  |
| **groupId** | **long** | Group identifier for which to remove the role |  |
| **roleId** | **long** | Role identifier |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **204** | No Content |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutionaccountgrouproles"></a>
# **PrivateInstitutionAccountGroupRoles**
> Object PrivateInstitutionAccountGroupRoles (long accountId)

List Institution Account Group Roles

List Institution Account Group Roles

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionAccountGroupRolesExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var accountId = 789L;  // long | Account identifier the user is associated to

            try
            {
                // List Institution Account Group Roles
                Object result = apiInstance.PrivateInstitutionAccountGroupRoles(accountId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountGroupRoles: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionAccountGroupRolesWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // List Institution Account Group Roles
    ApiResponse<Object> response = apiInstance.PrivateInstitutionAccountGroupRolesWithHttpInfo(accountId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountGroupRolesWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **accountId** | **long** | Account identifier the user is associated to |  |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Account Group Roles |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutionaccountgrouprolescreate"></a>
# **PrivateInstitutionAccountGroupRolesCreate**
> void PrivateInstitutionAccountGroupRolesCreate (long accountId, Object account)

Add Institution Account Group Roles

Add Institution Account Group Roles

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionAccountGroupRolesCreateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var accountId = 789L;  // long | Account identifier the user is associated to
            var account = null;  // Object | Account description

            try
            {
                // Add Institution Account Group Roles
                apiInstance.PrivateInstitutionAccountGroupRolesCreate(accountId, account);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountGroupRolesCreate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionAccountGroupRolesCreateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Add Institution Account Group Roles
    apiInstance.PrivateInstitutionAccountGroupRolesCreateWithHttpInfo(accountId, account);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountGroupRolesCreateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **accountId** | **long** | Account identifier the user is associated to |  |
| **account** | **Object** | Account description |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutionaccountscreate"></a>
# **PrivateInstitutionAccountsCreate**
> AccountCreateResponse PrivateInstitutionAccountsCreate (AccountCreate account)

Create new Institution Account

Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionAccountsCreateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var account = new AccountCreate(); // AccountCreate | Account description

            try
            {
                // Create new Institution Account
                AccountCreateResponse result = apiInstance.PrivateInstitutionAccountsCreate(account);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountsCreate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionAccountsCreateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Create new Institution Account
    ApiResponse<AccountCreateResponse> response = apiInstance.PrivateInstitutionAccountsCreateWithHttpInfo(account);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountsCreateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **account** | [**AccountCreate**](AccountCreate.md) | Account description |  |

### Return type

[**AccountCreateResponse**](AccountCreateResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **201** | Created |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutionaccountslist"></a>
# **PrivateInstitutionAccountsList**
> List&lt;ShortAccount&gt; PrivateInstitutionAccountsList (long? page = null, long? pageSize = null, long? limit = null, long? offset = null, long? isActive = null, string? institutionUserId = null, string? email = null, long? idLte = null, long? idGte = null)

Private Account Institution Accounts

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionAccountsListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var page = 789L;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10L;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789L;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789L;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 
            var isActive = 789L;  // long? | Filter by active status (optional) 
            var institutionUserId = "institutionUserId_example";  // string? | Filter by institution_user_id (optional) 
            var email = "email_example";  // string? | Filter by email (optional) 
            var idLte = 789L;  // long? | Retrieve accounts with an ID lower or equal to the specified value (optional) 
            var idGte = 789L;  // long? | Retrieve accounts with an ID greater or equal to the specified value (optional) 

            try
            {
                // Private Account Institution Accounts
                List<ShortAccount> result = apiInstance.PrivateInstitutionAccountsList(page, pageSize, limit, offset, isActive, institutionUserId, email, idLte, idGte);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountsList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionAccountsListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Account Institution Accounts
    ApiResponse<List<ShortAccount>> response = apiInstance.PrivateInstitutionAccountsListWithHttpInfo(page, pageSize, limit, offset, isActive, institutionUserId, email, idLte, idGte);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountsListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **page** | **long?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **long?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **long?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |
| **isActive** | **long?** | Filter by active status | [optional]  |
| **institutionUserId** | **string?** | Filter by institution_user_id | [optional]  |
| **email** | **string?** | Filter by email | [optional]  |
| **idLte** | **long?** | Retrieve accounts with an ID lower or equal to the specified value | [optional]  |
| **idGte** | **long?** | Retrieve accounts with an ID greater or equal to the specified value | [optional]  |

### Return type

[**List&lt;ShortAccount&gt;**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of Accounts |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutionaccountssearch"></a>
# **PrivateInstitutionAccountsSearch**
> List&lt;ShortAccount&gt; PrivateInstitutionAccountsSearch (InstitutionAccountsSearch search)

Private Account Institution Accounts Search

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionAccountsSearchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var search = new InstitutionAccountsSearch(); // InstitutionAccountsSearch | Search Parameters

            try
            {
                // Private Account Institution Accounts Search
                List<ShortAccount> result = apiInstance.PrivateInstitutionAccountsSearch(search);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountsSearch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionAccountsSearchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Account Institution Accounts Search
    ApiResponse<List<ShortAccount>> response = apiInstance.PrivateInstitutionAccountsSearchWithHttpInfo(search);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountsSearchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **search** | [**InstitutionAccountsSearch**](InstitutionAccountsSearch.md) | Search Parameters |  |

### Return type

[**List&lt;ShortAccount&gt;**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of Accounts |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutionaccountsupdate"></a>
# **PrivateInstitutionAccountsUpdate**
> void PrivateInstitutionAccountsUpdate (long accountId, AccountUpdate account)

Update Institution Account

Update Institution Account

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionAccountsUpdateExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var accountId = 789L;  // long | Account identifier the user is associated to
            var account = new AccountUpdate(); // AccountUpdate | Account description

            try
            {
                // Update Institution Account
                apiInstance.PrivateInstitutionAccountsUpdate(accountId, account);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountsUpdate: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionAccountsUpdateWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Update Institution Account
    apiInstance.PrivateInstitutionAccountsUpdateWithHttpInfo(accountId, account);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionAccountsUpdateWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **accountId** | **long** | Account identifier the user is associated to |  |
| **account** | [**AccountUpdate**](AccountUpdate.md) | Account description |  |

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **205** | Reset Content |  * Location - Location of project <br>  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutionarticles"></a>
# **PrivateInstitutionArticles**
> List&lt;Article&gt; PrivateInstitutionArticles (long? page = null, long? pageSize = null, long? limit = null, long? offset = null, string? order = null, string? orderDirection = null, string? publishedSince = null, string? modifiedSince = null, long? status = null, string? resourceDoi = null, long? itemType = null, long? group = null)

Private Institution Articles

Get Articles from own institution. User must be administrator of the institution

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionArticlesExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);
            var page = 789L;  // long? | Page number. Used for pagination with page_size (optional) 
            var pageSize = 10L;  // long? | The number of results included on a page. Used for pagination with page (optional)  (default to 10)
            var limit = 789L;  // long? | Number of results included on a page. Used for pagination with query (optional) 
            var offset = 789L;  // long? | Where to start the listing (the offset of the first result). Used for pagination with limit (optional) 
            var order = "published_date";  // string? | The field by which to order. Default varies by endpoint/resource. (optional)  (default to published_date)
            var orderDirection = "asc";  // string? |  (optional)  (default to desc)
            var publishedSince = "publishedSince_example";  // string? | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional) 
            var modifiedSince = "modifiedSince_example";  // string? | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional) 
            var status = 789L;  // long? | only return collections with this status (optional) 
            var resourceDoi = "resourceDoi_example";  // string? | only return collections with this resource_doi (optional) 
            var itemType = 789L;  // long? | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional) 
            var group = 789L;  // long? | only return articles from this group (optional) 

            try
            {
                // Private Institution Articles
                List<Article> result = apiInstance.PrivateInstitutionArticles(page, pageSize, limit, offset, order, orderDirection, publishedSince, modifiedSince, status, resourceDoi, itemType, group);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionArticles: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionArticlesWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Institution Articles
    ApiResponse<List<Article>> response = apiInstance.PrivateInstitutionArticlesWithHttpInfo(page, pageSize, limit, offset, order, orderDirection, publishedSince, modifiedSince, status, resourceDoi, itemType, group);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionArticlesWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **page** | **long?** | Page number. Used for pagination with page_size | [optional]  |
| **pageSize** | **long?** | The number of results included on a page. Used for pagination with page | [optional] [default to 10] |
| **limit** | **long?** | Number of results included on a page. Used for pagination with query | [optional]  |
| **offset** | **long?** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]  |
| **order** | **string?** | The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date] |
| **orderDirection** | **string?** |  | [optional] [default to desc] |
| **publishedSince** | **string?** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional]  |
| **modifiedSince** | **string?** | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional]  |
| **status** | **long?** | only return collections with this status | [optional]  |
| **resourceDoi** | **string?** | only return collections with this resource_doi | [optional]  |
| **itemType** | **long?** | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional]  |
| **group** | **long?** | only return articles from this group | [optional]  |

### Return type

[**List&lt;Article&gt;**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of articles belonging to the institution |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutiondetails"></a>
# **PrivateInstitutionDetails**
> Institution PrivateInstitutionDetails ()

Private Account Institutions

Account institution details

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);

            try
            {
                // Private Account Institutions
                Institution result = apiInstance.PrivateInstitutionDetails();
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Account Institutions
    ApiResponse<Institution> response = apiInstance.PrivateInstitutionDetailsWithHttpInfo();
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters
This endpoint does not need any parameter.
### Return type

[**Institution**](Institution.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of institutions |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutionembargooptionsdetails"></a>
# **PrivateInstitutionEmbargoOptionsDetails**
> List&lt;GroupEmbargoOptions&gt; PrivateInstitutionEmbargoOptionsDetails ()

Private Account Institution embargo options

Account institution embargo options details

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionEmbargoOptionsDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);

            try
            {
                // Private Account Institution embargo options
                List<GroupEmbargoOptions> result = apiInstance.PrivateInstitutionEmbargoOptionsDetails();
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionEmbargoOptionsDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionEmbargoOptionsDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Account Institution embargo options
    ApiResponse<List<GroupEmbargoOptions>> response = apiInstance.PrivateInstitutionEmbargoOptionsDetailsWithHttpInfo();
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionEmbargoOptionsDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters
This endpoint does not need any parameter.
### Return type

[**List&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of embargo options |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutiongroupslist"></a>
# **PrivateInstitutionGroupsList**
> List&lt;Group&gt; PrivateInstitutionGroupsList ()

Private Account Institution Groups

Returns the groups for which the account has administrative privileges (assigned and inherited).

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionGroupsListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);

            try
            {
                // Private Account Institution Groups
                List<Group> result = apiInstance.PrivateInstitutionGroupsList();
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionGroupsList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionGroupsListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Account Institution Groups
    ApiResponse<List<Group>> response = apiInstance.PrivateInstitutionGroupsListWithHttpInfo();
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionGroupsListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters
This endpoint does not need any parameter.
### Return type

[**List&lt;Group&gt;**](Group.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of Groups |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateinstitutionroleslist"></a>
# **PrivateInstitutionRolesList**
> List&lt;Role&gt; PrivateInstitutionRolesList ()

Private Account Institution Roles

Returns the roles available for groups and the institution group.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateInstitutionRolesListExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstitutionsApi(config);

            try
            {
                // Private Account Institution Roles
                List<Role> result = apiInstance.PrivateInstitutionRolesList();
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionRolesList: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateInstitutionRolesListWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Private Account Institution Roles
    ApiResponse<List<Role>> response = apiInstance.PrivateInstitutionRolesListWithHttpInfo();
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling InstitutionsApi.PrivateInstitutionRolesListWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters
This endpoint does not need any parameter.
### Return type

[**List&lt;Role&gt;**](Role.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of Roles |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

