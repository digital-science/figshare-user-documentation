# Org.OpenAPITools.Model.CollectionCreate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Funding** | **string** | Grant number or funding authority | [optional] [default to ""]
**FundingList** | [**List&lt;FundingCreate&gt;**](FundingCreate.md) | Funding creation / update items | [optional] 
**Title** | **string** | Title of collection | 
**Description** | **string** | The collection description. In a publisher case, usually this is the remote collection description | [optional] [default to ""]
**Articles** | **List&lt;int&gt;** | List of articles to be associated with the collection | [optional] 
**Authors** | **List&lt;Object&gt;** | List of authors to be associated with the collection. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint. | [optional] 
**Categories** | **List&lt;long&gt;** | List of category ids to be associated with the collection(e.g [1, 23, 33, 66]) | [optional] 
**CategoriesBySourceId** | **List&lt;string&gt;** | List of category source ids to be associated with the collection, supersedes the categories property | [optional] 
**Tags** | **List&lt;string&gt;** | List of tags to be associated with the collection. Keywords can be used instead | [optional] 
**Keywords** | **List&lt;string&gt;** | List of tags to be associated with the collection. Tags can be used instead | [optional] 
**References** | **List&lt;string&gt;** | List of links to be associated with the collection (e.g [\&quot;http://link1\&quot;, \&quot;http://link2\&quot;, \&quot;http://link3\&quot;]) | [optional] 
**RelatedMaterials** | [**List&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 
**CustomFields** | **Object** | List of key, values pairs to be associated with the collection | [optional] 
**CustomFieldsList** | [**List&lt;CustomArticleFieldAdd&gt;**](CustomArticleFieldAdd.md) | List of custom fields values, supersedes custom_fields parameter | [optional] 
**Doi** | **string** | Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional] [default to ""]
**Handle** | **string** | Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional] [default to ""]
**ResourceId** | **string** | Not applicable to regular users. In a publisher case, this is the publisher article id | [optional] 
**ResourceDoi** | **string** | Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [optional] [default to ""]
**ResourceLink** | **string** | Not applicable to regular users. In a publisher case, this is the publisher article link | [optional] 
**ResourceTitle** | **string** | Not applicable to regular users. In a publisher case, this is the publisher article title. | [optional] [default to ""]
**ResourceVersion** | **int** | Not applicable to regular users. In a publisher case, this is the publisher article version | [optional] 
**GroupId** | **long** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] 
**Timeline** | [**TimelineUpdate**](TimelineUpdate.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

