# Org.OpenAPITools.Model.PrivateProjectArticle

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Files** | [**List&lt;PublicFile&gt;**](PublicFile.md) | List of up to 10 article files. | 
**EmbargoOptions** | [**List&lt;GroupEmbargoOptions&gt;**](GroupEmbargoOptions.md) | List of embargo options | 
**CustomFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | List of custom fields values | 
**AccountId** | **long** | ID of the account owning the article | 
**DownloadDisabled** | **bool** | If true, downloading of files for this article is disabled | 
**Authors** | [**List&lt;Author&gt;**](Author.md) | List of authors | 
**FigshareUrl** | **string** | Article public url | 
**CurationStatus** | **string** | Curation status of the article | 
**Citation** | **string** | Article citation | 
**ConfidentialReason** | **string** | Confidentiality reason | 
**IsConfidential** | **bool** | Article Confidentiality | 
**Size** | **long** | Article size | 
**Funding** | **string** | Article funding | 
**FundingList** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Article funding information | 
**Tags** | **List&lt;string&gt;** | List of article tags. Keywords can be used instead | 
**Keywords** | **List&lt;string&gt;** | List of article keywords. Tags can be used instead | 
**VarVersion** | **long** | Article version | 
**IsMetadataRecord** | **bool** | True if article has no files | 
**MetadataReason** | **string** | Article metadata reason | 
**Status** | **string** | Article status | 
**Description** | **string** | Article description | 
**IsEmbargoed** | **bool** | True if article is embargoed | 
**IsPublic** | **bool** | True if article is published | 
**CreatedDate** | **string** | Date when article was created | 
**HasLinkedFile** | **bool** | True if any files are linked to the article | 
**Categories** | [**List&lt;Category&gt;**](Category.md) | List of categories selected for the article | 
**License** | [**License**](License.md) |  | 
**EmbargoTitle** | **string** | Title for embargo | 
**EmbargoReason** | **string** | Reason for embargo | 
**References** | **List&lt;string&gt;** | List of references | 
**RelatedMaterials** | [**List&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 
**Id** | **long** | Unique identifier for article | 
**Title** | **string** | Title of article | 
**Doi** | **string** | DOI | 
**Handle** | **string** | Handle | 
**Url** | **string** | Api endpoint for article | 
**UrlPublicHtml** | **string** | Public site endpoint for article | 
**UrlPublicApi** | **string** | Public Api endpoint for article | 
**UrlPrivateHtml** | **string** | Private site endpoint for article | 
**UrlPrivateApi** | **string** | Private Api endpoint for article | 
**Timeline** | [**Timeline**](Timeline.md) |  | 
**Thumb** | **string** | Thumbnail image | 
**DefinedType** | **long** | Type of article identifier | 
**DefinedTypeName** | **string** | Name of the article type identifier | 
**ResourceDoi** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to ""]
**ResourceTitle** | **string** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to ""]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

