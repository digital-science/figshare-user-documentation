# Org.OpenAPITools.Model.Group

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** | Group id | 
**Name** | **string** | Group name | 
**ResourceId** | **string** | Group resource id | 
**ParentId** | **int** | Parent group if any | 
**AssociationCriteria** | **string** | HR code associated with group, if code exists | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

