# Org.OpenAPITools.Api.AuthorsApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
|--------|--------------|-------------|
| [**PrivateAuthorDetails**](AuthorsApi.md#privateauthordetails) | **GET** /account/authors/{author_id} | Author details |
| [**PrivateAuthorsSearch**](AuthorsApi.md#privateauthorssearch) | **POST** /account/authors/search | Search Authors |

<a id="privateauthordetails"></a>
# **PrivateAuthorDetails**
> AuthorComplete PrivateAuthorDetails (long authorId)

Author details

View author details

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateAuthorDetailsExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new AuthorsApi(config);
            var authorId = 789L;  // long | Author unique identifier

            try
            {
                // Author details
                AuthorComplete result = apiInstance.PrivateAuthorDetails(authorId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AuthorsApi.PrivateAuthorDetails: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateAuthorDetailsWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Author details
    ApiResponse<AuthorComplete> response = apiInstance.PrivateAuthorDetailsWithHttpInfo(authorId);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AuthorsApi.PrivateAuthorDetailsWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **authorId** | **long** | Author unique identifier |  |

### Return type

[**AuthorComplete**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Article representation |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a id="privateauthorssearch"></a>
# **PrivateAuthorsSearch**
> List&lt;AuthorComplete&gt; PrivateAuthorsSearch (PrivateAuthorsSearch? search = null)

Search Authors

Search for authors

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class PrivateAuthorsSearchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.figsh.com/v2";
            // Configure OAuth2 access token for authorization: OAuth2
            config.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new AuthorsApi(config);
            var search = new PrivateAuthorsSearch?(); // PrivateAuthorsSearch? | Search Parameters (optional) 

            try
            {
                // Search Authors
                List<AuthorComplete> result = apiInstance.PrivateAuthorsSearch(search);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling AuthorsApi.PrivateAuthorsSearch: " + e.Message);
                Debug.Print("Status Code: " + e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

#### Using the PrivateAuthorsSearchWithHttpInfo variant
This returns an ApiResponse object which contains the response data, status code and headers.

```csharp
try
{
    // Search Authors
    ApiResponse<List<AuthorComplete>> response = apiInstance.PrivateAuthorsSearchWithHttpInfo(search);
    Debug.Write("Status Code: " + response.StatusCode);
    Debug.Write("Response Headers: " + response.Headers);
    Debug.Write("Response Body: " + response.Data);
}
catch (ApiException e)
{
    Debug.Print("Exception when calling AuthorsApi.PrivateAuthorsSearchWithHttpInfo: " + e.Message);
    Debug.Print("Status Code: " + e.ErrorCode);
    Debug.Print(e.StackTrace);
}
```

### Parameters

| Name | Type | Description | Notes |
|------|------|-------------|-------|
| **search** | [**PrivateAuthorsSearch?**](PrivateAuthorsSearch?.md) | Search Parameters | [optional]  |

### Return type

[**List&lt;AuthorComplete&gt;**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of authors |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

