# Org.OpenAPITools.Model.ArticleVersionUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SupplementaryFields** | **List&lt;Object&gt;** | List of supplementary fields to be associated with the article version | [optional] 
**InternalMetadata** | **Object** | List of supplementary fields to be associated with the article version | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

