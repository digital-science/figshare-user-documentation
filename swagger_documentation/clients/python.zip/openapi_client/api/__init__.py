# flake8: noqa

# import apis into api package
from openapi_client.api.articles_api import ArticlesApi
from openapi_client.api.authors_api import AuthorsApi
from openapi_client.api.collections_api import CollectionsApi
from openapi_client.api.institutions_api import InstitutionsApi
from openapi_client.api.oauth_api import OauthApi
from openapi_client.api.other_api import OtherApi
from openapi_client.api.profiles_api import ProfilesApi
from openapi_client.api.projects_api import ProjectsApi

