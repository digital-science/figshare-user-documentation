# PrivateLinkCreator


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expires_date** | **str** | Date when this private link should expire - optional. By default private links expire in 365 days. | [optional] 

## Example

```python
from openapi_client.models.private_link_creator import PrivateLinkCreator

# TODO update the JSON string below
json = "{}"
# create an instance of PrivateLinkCreator from a JSON string
private_link_creator_instance = PrivateLinkCreator.from_json(json)
# print the JSON string representation of the object
print(PrivateLinkCreator.to_json())

# convert the object into a dict
private_link_creator_dict = private_link_creator_instance.to_dict()
# create an instance of PrivateLinkCreator from a dict
private_link_creator_from_dict = PrivateLinkCreator.from_dict(private_link_creator_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


