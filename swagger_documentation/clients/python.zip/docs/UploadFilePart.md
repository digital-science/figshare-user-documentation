# UploadFilePart


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**part_no** | **int** | File part id | [optional] 
**start_offset** | **int** | Indexes on byte range. zero-based and inclusive | [optional] 
**end_offset** | **int** | Indexes on byte range. zero-based and inclusive | [optional] 
**status** | **str** | part status | [optional] 
**locked** | **bool** | When a part is being uploaded it is being locked, by setting the locked flag to true. No changes/uploads can happen on this part from other requests. | [optional] 

## Example

```python
from openapi_client.models.upload_file_part import UploadFilePart

# TODO update the JSON string below
json = "{}"
# create an instance of UploadFilePart from a JSON string
upload_file_part_instance = UploadFilePart.from_json(json)
# print the JSON string representation of the object
print(UploadFilePart.to_json())

# convert the object into a dict
upload_file_part_dict = upload_file_part_instance.to_dict()
# create an instance of UploadFilePart from a dict
upload_file_part_from_dict = UploadFilePart.from_dict(upload_file_part_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


