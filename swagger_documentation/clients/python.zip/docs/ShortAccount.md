# ShortAccount


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Account id | 
**first_name** | **str** | First Name | 
**last_name** | **str** | Last Name | 
**institution_id** | **int** | Account institution | 
**email** | **str** | User email | 
**active** | **int** | Account activity status | 
**institution_user_id** | **str** | Account institution user id | 
**quota** | **int** | Total storage available to account, in bytes | 
**used_quota** | **int** | Storage used by the account, in bytes | 
**user_id** | **int** | User id associated with account, useful for example for adding the account as an author to an item | 
**orcid_id** | **str** | ORCID iD associated to account | 
**symplectic_user_id** | **str** | Symplectic ID associated to account | 

## Example

```python
from openapi_client.models.short_account import ShortAccount

# TODO update the JSON string below
json = "{}"
# create an instance of ShortAccount from a JSON string
short_account_instance = ShortAccount.from_json(json)
# print the JSON string representation of the object
print(ShortAccount.to_json())

# convert the object into a dict
short_account_dict = short_account_instance.to_dict()
# create an instance of ShortAccount from a dict
short_account_from_dict = ShortAccount.from_dict(short_account_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


