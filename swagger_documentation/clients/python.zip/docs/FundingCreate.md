# FundingCreate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | A funding ID as returned by the Funding Search endpoint | [optional] 
**title** | **str** | The title of the new user created funding | [optional] 

## Example

```python
from openapi_client.models.funding_create import FundingCreate

# TODO update the JSON string below
json = "{}"
# create an instance of FundingCreate from a JSON string
funding_create_instance = FundingCreate.from_json(json)
# print the JSON string representation of the object
print(FundingCreate.to_json())

# convert the object into a dict
funding_create_dict = funding_create_instance.to_dict()
# create an instance of FundingCreate from a dict
funding_create_from_dict = FundingCreate.from_dict(funding_create_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


