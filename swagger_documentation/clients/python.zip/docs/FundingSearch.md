# FundingSearch


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_for** | **str** | Search term | [optional] 

## Example

```python
from openapi_client.models.funding_search import FundingSearch

# TODO update the JSON string below
json = "{}"
# create an instance of FundingSearch from a JSON string
funding_search_instance = FundingSearch.from_json(json)
# print the JSON string representation of the object
print(FundingSearch.to_json())

# convert the object into a dict
funding_search_dict = funding_search_instance.to_dict()
# create an instance of FundingSearch from a dict
funding_search_from_dict = FundingSearch.from_dict(funding_search_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


