# openapi_client.OtherApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categories_list**](OtherApi.md#categories_list) | **GET** /categories | Public Categories
[**file_download**](OtherApi.md#file_download) | **GET** /file/download/{file_id} | Public File Download
[**item_types_list**](OtherApi.md#item_types_list) | **GET** /item_types | Item Types
[**licenses_list**](OtherApi.md#licenses_list) | **GET** /licenses | Public Licenses
[**private_account**](OtherApi.md#private_account) | **GET** /account | Private Account information
[**private_funding_search**](OtherApi.md#private_funding_search) | **POST** /account/funding/search | Search Funding
[**private_licenses_list**](OtherApi.md#private_licenses_list) | **GET** /account/licenses | Private Account Licenses


# **categories_list**
> List[CategoryList] categories_list()

Public Categories

Returns a list of public categories

### Example


```python
import openapi_client
from openapi_client.models.category_list import CategoryList
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.OtherApi(api_client)

    try:
        # Public Categories
        api_response = api_instance.categories_list()
        print("The response of OtherApi->categories_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling OtherApi->categories_list: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**List[CategoryList]**](CategoryList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of categories |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **file_download**
> file_download(file_id)

Public File Download

Starts the download of a file

### Example


```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.OtherApi(api_client)
    file_id = 56 # int | 

    try:
        # Public File Download
        api_instance.file_download(file_id)
    except Exception as e:
        print("Exception when calling OtherApi->file_download: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **file_id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **item_types_list**
> List[ItemType] item_types_list(group_id=group_id)

Item Types

Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.item_type import ItemType
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.OtherApi(api_client)
    group_id = 0 # int | Identifier of the group for which the item types are requested (optional) (default to 0)

    try:
        # Item Types
        api_response = api_instance.item_types_list(group_id=group_id)
        print("The response of OtherApi->item_types_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling OtherApi->item_types_list: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| Identifier of the group for which the item types are requested | [optional] [default to 0]

### Return type

[**List[ItemType]**](ItemType.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of item types |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **licenses_list**
> List[License] licenses_list()

Public Licenses

Returns a list of public licenses

### Example


```python
import openapi_client
from openapi_client.models.license import License
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.OtherApi(api_client)

    try:
        # Public Licenses
        api_response = api_instance.licenses_list()
        print("The response of OtherApi->licenses_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling OtherApi->licenses_list: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**List[License]**](License.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of licenses |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_account**
> Account private_account()

Private Account information

Account information for token/personal token

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.account import Account
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.OtherApi(api_client)

    try:
        # Private Account information
        api_response = api_instance.private_account()
        print("The response of OtherApi->private_account:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling OtherApi->private_account: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Account representation |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_funding_search**
> List[FundingInformation] private_funding_search(search=search)

Search Funding

Search for fundings

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.funding_information import FundingInformation
from openapi_client.models.funding_search import FundingSearch
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.OtherApi(api_client)
    search = openapi_client.FundingSearch() # FundingSearch | Search Parameters (optional)

    try:
        # Search Funding
        api_response = api_instance.private_funding_search(search=search)
        print("The response of OtherApi->private_funding_search:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling OtherApi->private_funding_search: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**FundingSearch**](FundingSearch.md)| Search Parameters | [optional] 

### Return type

[**List[FundingInformation]**](FundingInformation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of funding information |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_licenses_list**
> List[License] private_licenses_list()

Private Account Licenses

This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.license import License
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.OtherApi(api_client)

    try:
        # Private Account Licenses
        api_response = api_instance.private_licenses_list()
        print("The response of OtherApi->private_licenses_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling OtherApi->private_licenses_list: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**List[License]**](License.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of personal licenses |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

