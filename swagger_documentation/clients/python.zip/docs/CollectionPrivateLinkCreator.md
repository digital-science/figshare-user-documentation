# CollectionPrivateLinkCreator


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expires_date** | **str** | Date when this private link should expire - optional. By default private links expire in 365 days. | [optional] 

## Example

```python
from openapi_client.models.collection_private_link_creator import CollectionPrivateLinkCreator

# TODO update the JSON string below
json = "{}"
# create an instance of CollectionPrivateLinkCreator from a JSON string
collection_private_link_creator_instance = CollectionPrivateLinkCreator.from_json(json)
# print the JSON string representation of the object
print(CollectionPrivateLinkCreator.to_json())

# convert the object into a dict
collection_private_link_creator_dict = collection_private_link_creator_instance.to_dict()
# create an instance of CollectionPrivateLinkCreator from a dict
collection_private_link_creator_from_dict = CollectionPrivateLinkCreator.from_dict(collection_private_link_creator_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


