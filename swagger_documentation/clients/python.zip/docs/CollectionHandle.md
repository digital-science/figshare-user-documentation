# CollectionHandle


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**handle** | **str** | Reserved Handle | 

## Example

```python
from openapi_client.models.collection_handle import CollectionHandle

# TODO update the JSON string below
json = "{}"
# create an instance of CollectionHandle from a JSON string
collection_handle_instance = CollectionHandle.from_json(json)
# print the JSON string representation of the object
print(CollectionHandle.to_json())

# convert the object into a dict
collection_handle_dict = collection_handle_instance.to_dict()
# create an instance of CollectionHandle from a dict
collection_handle_from_dict = CollectionHandle.from_dict(collection_handle_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


