# openapi_client.InstitutionsApi

All URIs are relative to *https://api.figinternal.dev*

Method | HTTP request | Description
------------- | ------------- | -------------
[**account_institution_curation**](InstitutionsApi.md#account_institution_curation) | **GET** /account/institution/review/{curation_id} | Institution Curation Review
[**account_institution_curations**](InstitutionsApi.md#account_institution_curations) | **GET** /account/institution/reviews | Institution Curation Reviews
[**custom_fields_list**](InstitutionsApi.md#custom_fields_list) | **GET** /account/institution/custom_fields | Private account institution group custom fields
[**custom_fields_upload**](InstitutionsApi.md#custom_fields_upload) | **POST** /account/institution/custom_fields/{custom_field_id}/items/upload | Custom fields values files upload
[**get_account_institution_curation_comments**](InstitutionsApi.md#get_account_institution_curation_comments) | **GET** /account/institution/review/{curation_id}/comments | Institution Curation Review Comments
[**institution_articles**](InstitutionsApi.md#institution_articles) | **GET** /institutions/{institution_string_id}/articles/filter-by | Public Institution Articles
[**institution_hrfeed_upload**](InstitutionsApi.md#institution_hrfeed_upload) | **POST** /institution/hrfeed/upload | Private Institution HRfeed Upload
[**post_account_institution_curation_comments**](InstitutionsApi.md#post_account_institution_curation_comments) | **POST** /account/institution/review/{curation_id}/comments | POST Institution Curation Review Comment
[**private_account_institution_user**](InstitutionsApi.md#private_account_institution_user) | **GET** /account/institution/users/{account_id} | Private Account Institution User
[**private_categories_list**](InstitutionsApi.md#private_categories_list) | **GET** /account/categories | Private Account Categories
[**private_group_embargo_options_details**](InstitutionsApi.md#private_group_embargo_options_details) | **GET** /account/institution/groups/{group_id}/embargo_options | Private Account Institution Group Embargo Options
[**private_institution_account**](InstitutionsApi.md#private_institution_account) | **GET** /account/institution/accounts/{account_id} | Private Institution Account information
[**private_institution_account_group_role_delete**](InstitutionsApi.md#private_institution_account_group_role_delete) | **DELETE** /account/institution/roles/{account_id}/{group_id}/{role_id} | Delete Institution Account Group Role
[**private_institution_account_group_roles**](InstitutionsApi.md#private_institution_account_group_roles) | **GET** /account/institution/roles/{account_id} | List Institution Account Group Roles
[**private_institution_account_group_roles_create**](InstitutionsApi.md#private_institution_account_group_roles_create) | **POST** /account/institution/roles/{account_id} | Add Institution Account Group Roles
[**private_institution_accounts_create**](InstitutionsApi.md#private_institution_accounts_create) | **POST** /account/institution/accounts | Create new Institution Account
[**private_institution_accounts_list**](InstitutionsApi.md#private_institution_accounts_list) | **GET** /account/institution/accounts | Private Account Institution Accounts
[**private_institution_accounts_search**](InstitutionsApi.md#private_institution_accounts_search) | **POST** /account/institution/accounts/search | Private Account Institution Accounts Search
[**private_institution_accounts_update**](InstitutionsApi.md#private_institution_accounts_update) | **PUT** /account/institution/accounts/{account_id} | Update Institution Account
[**private_institution_articles**](InstitutionsApi.md#private_institution_articles) | **GET** /account/institution/articles | Private Institution Articles
[**private_institution_details**](InstitutionsApi.md#private_institution_details) | **GET** /account/institution | Private Account Institutions
[**private_institution_embargo_options_details**](InstitutionsApi.md#private_institution_embargo_options_details) | **GET** /account/institution/embargo_options | Private Account Institution embargo options
[**private_institution_groups_list**](InstitutionsApi.md#private_institution_groups_list) | **GET** /account/institution/groups | Private Account Institution Groups
[**private_institution_roles_list**](InstitutionsApi.md#private_institution_roles_list) | **GET** /account/institution/roles | Private Account Institution Roles


# **account_institution_curation**
> CurationDetail account_institution_curation(curation_id)

Institution Curation Review

Retrieve a certain curation review by its ID

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.curation_detail import CurationDetail
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    curation_id = 56 # int | ID of the curation

    try:
        # Institution Curation Review
        api_response = api_instance.account_institution_curation(curation_id)
        print("The response of InstitutionsApi->account_institution_curation:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->account_institution_curation: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curation_id** | **int**| ID of the curation | 

### Return type

[**CurationDetail**](CurationDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. A curation review. |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **account_institution_curations**
> Curation account_institution_curations(group_id=group_id, article_id=article_id, status=status, limit=limit, offset=offset)

Institution Curation Reviews

Retrieve a list of curation reviews for this institution

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.curation import Curation
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    group_id = 56 # int | Filter by the group ID (optional)
    article_id = 56 # int | Retrieve the reviews for this article (optional)
    status = 'status_example' # str | Filter by the status of the review (optional)
    limit = 56 # int | Number of results included on a page. Used for pagination with query (optional)
    offset = 56 # int | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

    try:
        # Institution Curation Reviews
        api_response = api_instance.account_institution_curations(group_id=group_id, article_id=article_id, status=status, limit=limit, offset=offset)
        print("The response of InstitutionsApi->account_institution_curations:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->account_institution_curations: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| Filter by the group ID | [optional] 
 **article_id** | **int**| Retrieve the reviews for this article | [optional] 
 **status** | **str**| Filter by the status of the review | [optional] 
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**Curation**](Curation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. A list of curation reviews. |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **custom_fields_list**
> List[ShortCustomField] custom_fields_list(group_id=group_id)

Private account institution group custom fields

Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.short_custom_field import ShortCustomField
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    group_id = 56 # int | Group_id (optional)

    try:
        # Private account institution group custom fields
        api_response = api_instance.custom_fields_list(group_id=group_id)
        print("The response of InstitutionsApi->custom_fields_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->custom_fields_list: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| Group_id | [optional] 

### Return type

[**List[ShortCustomField]**](ShortCustomField.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of custom fields |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **custom_fields_upload**
> object custom_fields_upload(custom_field_id, external_file=external_file)

Custom fields values files upload

Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. More details in the <a href=\"#custom_fields\">Custom Fields section</a>

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    custom_field_id = 56 # int | Custom field identifier
    external_file = None # bytearray | CSV file to be uploaded (optional)

    try:
        # Custom fields values files upload
        api_response = api_instance.custom_fields_upload(custom_field_id, external_file=external_file)
        print("The response of InstitutionsApi->custom_fields_upload:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->custom_fields_upload: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **custom_field_id** | **int**| Custom field identifier | 
 **external_file** | **bytearray**| CSV file to be uploaded | [optional] 

### Return type

**object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_account_institution_curation_comments**
> CurationComment get_account_institution_curation_comments(curation_id, limit=limit, offset=offset)

Institution Curation Review Comments

Retrieve a certain curation review's comments.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.curation_comment import CurationComment
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    curation_id = 56 # int | ID of the curation
    limit = 56 # int | Number of results included on a page. Used for pagination with query (optional)
    offset = 56 # int | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

    try:
        # Institution Curation Review Comments
        api_response = api_instance.get_account_institution_curation_comments(curation_id, limit=limit, offset=offset)
        print("The response of InstitutionsApi->get_account_institution_curation_comments:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->get_account_institution_curation_comments: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curation_id** | **int**| ID of the curation | 
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**CurationComment**](CurationComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. A curation review&#39;s comments. |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **institution_articles**
> List[Article] institution_articles(institution_string_id, resource_id, filename)

Public Institution Articles

Returns a list of articles belonging to the institution

### Example


```python
import openapi_client
from openapi_client.models.article import Article
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    institution_string_id = 'institution_string_id_example' # str | 
    resource_id = 'resource_id_example' # str | 
    filename = 'filename_example' # str | 

    try:
        # Public Institution Articles
        api_response = api_instance.institution_articles(institution_string_id, resource_id, filename)
        print("The response of InstitutionsApi->institution_articles:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->institution_articles: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **institution_string_id** | **str**|  | 
 **resource_id** | **str**|  | 
 **filename** | **str**|  | 

### Return type

[**List[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of articles |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **institution_hrfeed_upload**
> ResponseMessage institution_hrfeed_upload(hrfeed=hrfeed)

Private Institution HRfeed Upload

More info in the <a href=\"#hr_feed\">HR Feed section</a>

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.response_message import ResponseMessage
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    hrfeed = None # bytearray | You can find an example in the Hr Feed section (optional)

    try:
        # Private Institution HRfeed Upload
        api_response = api_instance.institution_hrfeed_upload(hrfeed=hrfeed)
        print("The response of InstitutionsApi->institution_hrfeed_upload:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->institution_hrfeed_upload: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hrfeed** | **bytearray**| You can find an example in the Hr Feed section | [optional] 

### Return type

[**ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_account_institution_curation_comments**
> post_account_institution_curation_comments(curation_id, curation_comment)

POST Institution Curation Review Comment

Add a new comment to the review.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.curation_comment_create import CurationCommentCreate
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    curation_id = 56 # int | ID of the curation
    curation_comment = openapi_client.CurationCommentCreate() # CurationCommentCreate | The content/value of the comment.

    try:
        # POST Institution Curation Review Comment
        api_instance.post_account_institution_curation_comments(curation_id, curation_comment)
    except Exception as e:
        print("Exception when calling InstitutionsApi->post_account_institution_curation_comments: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **curation_id** | **int**| ID of the curation | 
 **curation_comment** | [**CurationCommentCreate**](CurationCommentCreate.md)| The content/value of the comment. | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_account_institution_user**
> User private_account_institution_user(account_id)

Private Account Institution User

Retrieve institution user information using the account_id

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.user import User
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    account_id = 56 # int | Account identifier the user is associated to

    try:
        # Private Account Institution User
        api_response = api_instance.private_account_institution_user(account_id)
        print("The response of InstitutionsApi->private_account_institution_user:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_account_institution_user: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to | 

### Return type

[**User**](User.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. User representation |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_categories_list**
> List[CategoryList] private_categories_list()

Private Account Categories

List institution categories (including parent Categories)

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.category_list import CategoryList
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)

    try:
        # Private Account Categories
        api_response = api_instance.private_categories_list()
        print("The response of InstitutionsApi->private_categories_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_categories_list: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**List[CategoryList]**](CategoryList.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of categories |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_group_embargo_options_details**
> List[GroupEmbargoOptions] private_group_embargo_options_details(group_id)

Private Account Institution Group Embargo Options

Account institution group embargo options details

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.group_embargo_options import GroupEmbargoOptions
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    group_id = 56 # int | Group identifier

    try:
        # Private Account Institution Group Embargo Options
        api_response = api_instance.private_group_embargo_options_details(group_id)
        print("The response of InstitutionsApi->private_group_embargo_options_details:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_group_embargo_options_details: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| Group identifier | 

### Return type

[**List[GroupEmbargoOptions]**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of embargo options |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_account**
> Account private_institution_account(account_id)

Private Institution Account information

Private Institution Account information

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.account import Account
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    account_id = 56 # int | Account identifier the user is associated to

    try:
        # Private Institution Account information
        api_response = api_instance.private_institution_account(account_id)
        print("The response of InstitutionsApi->private_institution_account:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_account: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to | 

### Return type

[**Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Account |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_account_group_role_delete**
> private_institution_account_group_role_delete(account_id, group_id, role_id)

Delete Institution Account Group Role

Delete Institution Account Group Role

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    account_id = 56 # int | Account identifier for which to remove the role
    group_id = 56 # int | Group identifier for which to remove the role
    role_id = 56 # int | Role identifier

    try:
        # Delete Institution Account Group Role
        api_instance.private_institution_account_group_role_delete(account_id, group_id, role_id)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_account_group_role_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier for which to remove the role | 
 **group_id** | **int**| Group identifier for which to remove the role | 
 **role_id** | **int**| Role identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_account_group_roles**
> object private_institution_account_group_roles(account_id)

List Institution Account Group Roles

List Institution Account Group Roles

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    account_id = 56 # int | Account identifier the user is associated to

    try:
        # List Institution Account Group Roles
        api_response = api_instance.private_institution_account_group_roles(account_id)
        print("The response of InstitutionsApi->private_institution_account_group_roles:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_account_group_roles: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to | 

### Return type

**object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Account Group Roles |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_account_group_roles_create**
> private_institution_account_group_roles_create(account_id, account)

Add Institution Account Group Roles

Add Institution Account Group Roles

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    account_id = 56 # int | Account identifier the user is associated to
    account = None # object | Account description

    try:
        # Add Institution Account Group Roles
        api_instance.private_institution_account_group_roles_create(account_id, account)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_account_group_roles_create: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to | 
 **account** | **object**| Account description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_accounts_create**
> AccountCreateResponse private_institution_accounts_create(account)

Create new Institution Account

Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.account_create import AccountCreate
from openapi_client.models.account_create_response import AccountCreateResponse
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    account = openapi_client.AccountCreate() # AccountCreate | Account description

    try:
        # Create new Institution Account
        api_response = api_instance.private_institution_accounts_create(account)
        print("The response of InstitutionsApi->private_institution_accounts_create:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_accounts_create: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account** | [**AccountCreate**](AccountCreate.md)| Account description | 

### Return type

[**AccountCreateResponse**](AccountCreateResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_accounts_list**
> List[ShortAccount] private_institution_accounts_list(page=page, page_size=page_size, limit=limit, offset=offset, is_active=is_active, institution_user_id=institution_user_id, email=email, id_lte=id_lte, id_gte=id_gte)

Private Account Institution Accounts

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.short_account import ShortAccount
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    page = 56 # int | Page number. Used for pagination with page_size (optional)
    page_size = 10 # int | The number of results included on a page. Used for pagination with page (optional) (default to 10)
    limit = 56 # int | Number of results included on a page. Used for pagination with query (optional)
    offset = 56 # int | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
    is_active = 56 # int | Filter by active status (optional)
    institution_user_id = 'institution_user_id_example' # str | Filter by institution_user_id (optional)
    email = 'email_example' # str | Filter by email (optional)
    id_lte = 56 # int | Retrieve accounts with an ID lower or equal to the specified value (optional)
    id_gte = 56 # int | Retrieve accounts with an ID greater or equal to the specified value (optional)

    try:
        # Private Account Institution Accounts
        api_response = api_instance.private_institution_accounts_list(page=page, page_size=page_size, limit=limit, offset=offset, is_active=is_active, institution_user_id=institution_user_id, email=email, id_lte=id_lte, id_gte=id_gte)
        print("The response of InstitutionsApi->private_institution_accounts_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_accounts_list: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **is_active** | **int**| Filter by active status | [optional] 
 **institution_user_id** | **str**| Filter by institution_user_id | [optional] 
 **email** | **str**| Filter by email | [optional] 
 **id_lte** | **int**| Retrieve accounts with an ID lower or equal to the specified value | [optional] 
 **id_gte** | **int**| Retrieve accounts with an ID greater or equal to the specified value | [optional] 

### Return type

[**List[ShortAccount]**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of Accounts |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_accounts_search**
> List[ShortAccount] private_institution_accounts_search(search)

Private Account Institution Accounts Search

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.institution_accounts_search import InstitutionAccountsSearch
from openapi_client.models.short_account import ShortAccount
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    search = openapi_client.InstitutionAccountsSearch() # InstitutionAccountsSearch | Search Parameters

    try:
        # Private Account Institution Accounts Search
        api_response = api_instance.private_institution_accounts_search(search)
        print("The response of InstitutionsApi->private_institution_accounts_search:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_accounts_search: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**InstitutionAccountsSearch**](InstitutionAccountsSearch.md)| Search Parameters | 

### Return type

[**List[ShortAccount]**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of Accounts |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_accounts_update**
> private_institution_accounts_update(account_id, account)

Update Institution Account

Update Institution Account

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.account_update import AccountUpdate
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    account_id = 56 # int | Account identifier the user is associated to
    account = openapi_client.AccountUpdate() # AccountUpdate | Account description

    try:
        # Update Institution Account
        api_instance.private_institution_accounts_update(account_id, account)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_accounts_update: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **int**| Account identifier the user is associated to | 
 **account** | [**AccountUpdate**](AccountUpdate.md)| Account description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  * Location - Location of newly created article <br>  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_articles**
> List[Article] private_institution_articles(page=page, page_size=page_size, limit=limit, offset=offset, order=order, order_direction=order_direction, published_since=published_since, modified_since=modified_since, status=status, resource_doi=resource_doi, item_type=item_type, group=group)

Private Institution Articles

Get Articles from own institution. User must be administrator of the institution

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article import Article
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)
    page = 56 # int | Page number. Used for pagination with page_size (optional)
    page_size = 10 # int | The number of results included on a page. Used for pagination with page (optional) (default to 10)
    limit = 56 # int | Number of results included on a page. Used for pagination with query (optional)
    offset = 56 # int | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
    order = published_date # str | The field by which to order. Default varies by endpoint/resource. (optional) (default to published_date)
    order_direction = desc # str |  (optional) (default to desc)
    published_since = 'published_since_example' # str | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
    modified_since = 'modified_since_example' # str | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
    status = 56 # int | only return collections with this status (optional)
    resource_doi = 'resource_doi_example' # str | only return collections with this resource_doi (optional)
    item_type = 56 # int | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional)
    group = 56 # int | only return articles from this group (optional)

    try:
        # Private Institution Articles
        api_response = api_instance.private_institution_articles(page=page, page_size=page_size, limit=limit, offset=offset, order=order, order_direction=order_direction, published_since=published_since, modified_since=modified_since, status=status, resource_doi=resource_doi, item_type=item_type, group=group)
        print("The response of InstitutionsApi->private_institution_articles:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_articles: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **str**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **order_direction** | **str**|  | [optional] [default to desc]
 **published_since** | **str**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **modified_since** | **str**| Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **status** | **int**| only return collections with this status | [optional] 
 **resource_doi** | **str**| only return collections with this resource_doi | [optional] 
 **item_type** | **int**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
 **group** | **int**| only return articles from this group | [optional] 

### Return type

[**List[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of articles belonging to the institution |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_details**
> Institution private_institution_details()

Private Account Institutions

Account institution details

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.institution import Institution
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)

    try:
        # Private Account Institutions
        api_response = api_instance.private_institution_details()
        print("The response of InstitutionsApi->private_institution_details:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_details: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**Institution**](Institution.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of institutions |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_embargo_options_details**
> List[GroupEmbargoOptions] private_institution_embargo_options_details()

Private Account Institution embargo options

Account institution embargo options details

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.group_embargo_options import GroupEmbargoOptions
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)

    try:
        # Private Account Institution embargo options
        api_response = api_instance.private_institution_embargo_options_details()
        print("The response of InstitutionsApi->private_institution_embargo_options_details:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_embargo_options_details: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**List[GroupEmbargoOptions]**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of embargo options |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_groups_list**
> List[Group] private_institution_groups_list()

Private Account Institution Groups

Returns the groups for which the account has administrative privileges (assigned and inherited).

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.group import Group
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)

    try:
        # Private Account Institution Groups
        api_response = api_instance.private_institution_groups_list()
        print("The response of InstitutionsApi->private_institution_groups_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_groups_list: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**List[Group]**](Group.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of Groups |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_institution_roles_list**
> List[Role] private_institution_roles_list()

Private Account Institution Roles

Returns the roles available for groups and the institution group.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.role import Role
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figinternal.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figinternal.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.InstitutionsApi(api_client)

    try:
        # Private Account Institution Roles
        api_response = api_instance.private_institution_roles_list()
        print("The response of InstitutionsApi->private_institution_roles_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling InstitutionsApi->private_institution_roles_list: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**List[Role]**](Role.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of Roles |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

