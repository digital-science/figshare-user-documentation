# Timeline


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_online** | **str** | Online posted date | [optional] 
**publisher_publication** | **str** | Publish date | [optional] 
**publisher_acceptance** | **str** | Date when the item was accepted for publication | [optional] 

## Example

```python
from openapi_client.models.timeline import Timeline

# TODO update the JSON string below
json = "{}"
# create an instance of Timeline from a JSON string
timeline_instance = Timeline.from_json(json)
# print the JSON string representation of the object
print(Timeline.to_json())

# convert the object into a dict
timeline_dict = timeline_instance.to_dict()
# create an instance of Timeline from a dict
timeline_from_dict = Timeline.from_dict(timeline_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


