# CollectionDOI


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**doi** | **str** | Reserved DOI | 

## Example

```python
from openapi_client.models.collection_doi import CollectionDOI

# TODO update the JSON string below
json = "{}"
# create an instance of CollectionDOI from a JSON string
collection_doi_instance = CollectionDOI.from_json(json)
# print the JSON string representation of the object
print(CollectionDOI.to_json())

# convert the object into a dict
collection_doi_dict = collection_doi_instance.to_dict()
# create an instance of CollectionDOI from a dict
collection_doi_from_dict = CollectionDOI.from_dict(collection_doi_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


