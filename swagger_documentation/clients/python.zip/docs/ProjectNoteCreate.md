# ProjectNoteCreate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **str** | Text of the note | 

## Example

```python
from openapi_client.models.project_note_create import ProjectNoteCreate

# TODO update the JSON string below
json = "{}"
# create an instance of ProjectNoteCreate from a JSON string
project_note_create_instance = ProjectNoteCreate.from_json(json)
# print the JSON string representation of the object
print(ProjectNoteCreate.to_json())

# convert the object into a dict
project_note_create_dict = project_note_create_instance.to_dict()
# create an instance of ProjectNoteCreate from a dict
project_note_create_from_dict = ProjectNoteCreate.from_dict(project_note_create_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


