# AccountReport


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | A unique ID for the AccountRecord | 
**account_id** | **int** | The ID of the account which generated this report. | 
**created_date** | **str** | Date when the AccountReport was requested | 
**status** | **str** | Status of the report | 
**download_url** | **str** | The download link for the generated XLSX | 
**group_id** | **int** | The group ID that was used to filter the report, if any. | 

## Example

```python
from openapi_client.models.account_report import AccountReport

# TODO update the JSON string below
json = "{}"
# create an instance of AccountReport from a JSON string
account_report_instance = AccountReport.from_json(json)
# print the JSON string representation of the object
print(AccountReport.to_json())

# convert the object into a dict
account_report_dict = account_report_instance.to_dict()
# create an instance of AccountReport from a dict
account_report_from_dict = AccountReport.from_dict(account_report_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


