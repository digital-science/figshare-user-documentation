# ArticleCompletePrivate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account_id** | **int** | ID of the account owning the article | 
**curation_status** | **str** | Curation status of the article | 
**figshare_url** | **str** | Article public url | 
**download_disabled** | **bool** | If true, downloading of files for this article is disabled | 
**files** | [**List[PublicFile]**](PublicFile.md) | List of up to 10 article files. | 
**folder_structure** | **object** | Mapping of file ids to folder paths, if folders are used | 
**authors** | [**List[Author]**](Author.md) | List of article authors | 
**custom_fields** | [**List[CustomArticleField]**](CustomArticleField.md) | List of custom fields values | 
**embargo_options** | [**List[GroupEmbargoOptions]**](GroupEmbargoOptions.md) | List of embargo options | 
**citation** | **str** | Article citation | 
**confidential_reason** | **str** | Confidentiality reason | 
**is_confidential** | **bool** | Article Confidentiality | 
**size** | **int** | Article size | 
**funding** | **str** | Article funding | 
**funding_list** | [**List[FundingInformation]**](FundingInformation.md) | Full Article funding information | 
**tags** | **List[str]** | List of article tags. Keywords can be used instead | 
**keywords** | **List[str]** | List of article keywords. Tags can be used instead | 
**version** | **int** | Article version | 
**is_metadata_record** | **bool** | True if article has no files | 
**metadata_reason** | **str** | Article metadata reason | 
**status** | **str** | Article status | 
**description** | **str** | Article description | 
**is_embargoed** | **bool** | True if article is embargoed | 
**is_public** | **bool** | True if article is published | 
**created_date** | **str** | Date when article was created | 
**has_linked_file** | **bool** | True if any files are linked to the article | 
**categories** | [**List[Category]**](Category.md) | List of categories selected for the article | 
**license** | [**License**](License.md) |  | 
**embargo_title** | **str** | Title for embargo | 
**embargo_reason** | **str** | Reason for embargo | 
**references** | **List[str]** | List of references | 
**related_materials** | [**List[RelatedMaterial]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 
**id** | **int** | Unique identifier for article | 
**title** | **str** | Title of article | 
**doi** | **str** | DOI | 
**handle** | **str** | Handle | 
**url** | **str** | Api endpoint for article | 
**url_public_html** | **str** | Public site endpoint for article | 
**url_public_api** | **str** | Public Api endpoint for article | 
**url_private_html** | **str** | Private site endpoint for article | 
**url_private_api** | **str** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) |  | 
**thumb** | **str** | Thumbnail image | 
**defined_type** | **int** | Type of article identifier | 
**defined_type_name** | **str** | Name of the article type identifier | 
**resource_doi** | **str** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to '']
**resource_title** | **str** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to '']

## Example

```python
from openapi_client.models.article_complete_private import ArticleCompletePrivate

# TODO update the JSON string below
json = "{}"
# create an instance of ArticleCompletePrivate from a JSON string
article_complete_private_instance = ArticleCompletePrivate.from_json(json)
# print the JSON string representation of the object
print(ArticleCompletePrivate.to_json())

# convert the object into a dict
article_complete_private_dict = article_complete_private_instance.to_dict()
# create an instance of ArticleCompletePrivate from a dict
article_complete_private_from_dict = ArticleCompletePrivate.from_dict(article_complete_private_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


