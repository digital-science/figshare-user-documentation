# ArticleWithProject


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **int** | Project id for this article. | [default to 0]
**id** | **int** | Unique identifier for article | 
**title** | **str** | Title of article | 
**doi** | **str** | DOI | 
**handle** | **str** | Handle | 
**url** | **str** | Api endpoint for article | 
**url_public_html** | **str** | Public site endpoint for article | 
**url_public_api** | **str** | Public Api endpoint for article | 
**url_private_html** | **str** | Private site endpoint for article | 
**url_private_api** | **str** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) |  | 
**thumb** | **str** | Thumbnail image | 
**defined_type** | **int** | Type of article identifier | 
**defined_type_name** | **str** | Name of the article type identifier | 
**resource_doi** | **str** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to '']
**resource_title** | **str** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to '']
**created_date** | **str** | Date when article was created | 

## Example

```python
from openapi_client.models.article_with_project import ArticleWithProject

# TODO update the JSON string below
json = "{}"
# create an instance of ArticleWithProject from a JSON string
article_with_project_instance = ArticleWithProject.from_json(json)
# print the JSON string representation of the object
print(ArticleWithProject.to_json())

# convert the object into a dict
article_with_project_dict = article_with_project_instance.to_dict()
# create an instance of ArticleWithProject from a dict
article_with_project_from_dict = ArticleWithProject.from_dict(article_with_project_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


