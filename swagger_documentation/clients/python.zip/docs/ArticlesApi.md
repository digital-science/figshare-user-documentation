# openapi_client.ArticlesApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**account_article_publish**](ArticlesApi.md#account_article_publish) | **POST** /account/articles/{article_id}/publish | Private Article Publish
[**account_article_report**](ArticlesApi.md#account_article_report) | **GET** /account/articles/export | Account Article Report
[**account_article_report_generate**](ArticlesApi.md#account_article_report_generate) | **POST** /account/articles/export | Initiate a new Report
[**account_article_unpublish**](ArticlesApi.md#account_article_unpublish) | **POST** /account/articles/{article_id}/unpublish | Public Article Unpublish
[**article_details**](ArticlesApi.md#article_details) | **GET** /articles/{article_id} | View article details
[**article_file_details**](ArticlesApi.md#article_file_details) | **GET** /articles/{article_id}/files/{file_id} | Article file details
[**article_files**](ArticlesApi.md#article_files) | **GET** /articles/{article_id}/files | List article files
[**article_version_confidentiality**](ArticlesApi.md#article_version_confidentiality) | **GET** /articles/{article_id}/versions/{version_id}/confidentiality | Public Article Confidentiality for article version
[**article_version_details**](ArticlesApi.md#article_version_details) | **GET** /articles/{article_id}/versions/{version_id} | Article details for version
[**article_version_embargo**](ArticlesApi.md#article_version_embargo) | **GET** /articles/{article_id}/versions/{version_id}/embargo | Public Article Embargo for article version
[**article_version_files**](ArticlesApi.md#article_version_files) | **GET** /articles/{article_id}/versions/{version_id}/files | Public Article version files
[**article_version_partial_update**](ArticlesApi.md#article_version_partial_update) | **PATCH** /account/articles/{article_id}/versions/{version_id} | Partially update article version
[**article_version_update**](ArticlesApi.md#article_version_update) | **PUT** /account/articles/{article_id}/versions/{version_id} | Update article version
[**article_version_update_thumb**](ArticlesApi.md#article_version_update_thumb) | **PUT** /account/articles/{article_id}/versions/{version_id}/update_thumb | Update article version thumbnail
[**article_versions**](ArticlesApi.md#article_versions) | **GET** /articles/{article_id}/versions | List article versions
[**articles_list**](ArticlesApi.md#articles_list) | **GET** /articles | Public Articles
[**articles_search**](ArticlesApi.md#articles_search) | **POST** /articles/search | Public Articles Search
[**private_article_author_delete**](ArticlesApi.md#private_article_author_delete) | **DELETE** /account/articles/{article_id}/authors/{author_id} | Delete article author
[**private_article_authors_add**](ArticlesApi.md#private_article_authors_add) | **POST** /account/articles/{article_id}/authors | Add article authors
[**private_article_authors_list**](ArticlesApi.md#private_article_authors_list) | **GET** /account/articles/{article_id}/authors | List article authors
[**private_article_authors_replace**](ArticlesApi.md#private_article_authors_replace) | **PUT** /account/articles/{article_id}/authors | Replace article authors
[**private_article_categories_add**](ArticlesApi.md#private_article_categories_add) | **POST** /account/articles/{article_id}/categories | Add article categories
[**private_article_categories_list**](ArticlesApi.md#private_article_categories_list) | **GET** /account/articles/{article_id}/categories | List article categories
[**private_article_categories_replace**](ArticlesApi.md#private_article_categories_replace) | **PUT** /account/articles/{article_id}/categories | Replace article categories
[**private_article_category_delete**](ArticlesApi.md#private_article_category_delete) | **DELETE** /account/articles/{article_id}/categories/{category_id} | Delete article category
[**private_article_confidentiality_delete**](ArticlesApi.md#private_article_confidentiality_delete) | **DELETE** /account/articles/{article_id}/confidentiality | Delete article confidentiality
[**private_article_confidentiality_details**](ArticlesApi.md#private_article_confidentiality_details) | **GET** /account/articles/{article_id}/confidentiality | Article confidentiality details
[**private_article_confidentiality_update**](ArticlesApi.md#private_article_confidentiality_update) | **PUT** /account/articles/{article_id}/confidentiality | Update article confidentiality
[**private_article_create**](ArticlesApi.md#private_article_create) | **POST** /account/articles | Create new Article
[**private_article_delete**](ArticlesApi.md#private_article_delete) | **DELETE** /account/articles/{article_id} | Delete article
[**private_article_details**](ArticlesApi.md#private_article_details) | **GET** /account/articles/{article_id} | Article details
[**private_article_download**](ArticlesApi.md#private_article_download) | **GET** /account/articles/{article_id}/download | Private Article Download
[**private_article_embargo_delete**](ArticlesApi.md#private_article_embargo_delete) | **DELETE** /account/articles/{article_id}/embargo | Delete Article Embargo
[**private_article_embargo_details**](ArticlesApi.md#private_article_embargo_details) | **GET** /account/articles/{article_id}/embargo | Article Embargo Details
[**private_article_embargo_update**](ArticlesApi.md#private_article_embargo_update) | **PUT** /account/articles/{article_id}/embargo | Update Article Embargo
[**private_article_file**](ArticlesApi.md#private_article_file) | **GET** /account/articles/{article_id}/files/{file_id} | Single File
[**private_article_file_delete**](ArticlesApi.md#private_article_file_delete) | **DELETE** /account/articles/{article_id}/files/{file_id} | File Delete
[**private_article_files_list**](ArticlesApi.md#private_article_files_list) | **GET** /account/articles/{article_id}/files | List article files
[**private_article_partial_update**](ArticlesApi.md#private_article_partial_update) | **PATCH** /account/articles/{article_id} | Partially update article
[**private_article_private_link**](ArticlesApi.md#private_article_private_link) | **GET** /account/articles/{article_id}/private_links | List private links
[**private_article_private_link_create**](ArticlesApi.md#private_article_private_link_create) | **POST** /account/articles/{article_id}/private_links | Create private link
[**private_article_private_link_delete**](ArticlesApi.md#private_article_private_link_delete) | **DELETE** /account/articles/{article_id}/private_links/{link_id} | Disable private link
[**private_article_private_link_update**](ArticlesApi.md#private_article_private_link_update) | **PUT** /account/articles/{article_id}/private_links/{link_id} | Update private link
[**private_article_reserve_doi**](ArticlesApi.md#private_article_reserve_doi) | **POST** /account/articles/{article_id}/reserve_doi | Private Article Reserve DOI
[**private_article_reserve_handle**](ArticlesApi.md#private_article_reserve_handle) | **POST** /account/articles/{article_id}/reserve_handle | Private Article Reserve Handle
[**private_article_resource**](ArticlesApi.md#private_article_resource) | **POST** /account/articles/{article_id}/resource | Private Article Resource
[**private_article_update**](ArticlesApi.md#private_article_update) | **PUT** /account/articles/{article_id} | Update article
[**private_article_upload_complete**](ArticlesApi.md#private_article_upload_complete) | **POST** /account/articles/{article_id}/files/{file_id} | Complete Upload
[**private_article_upload_initiate**](ArticlesApi.md#private_article_upload_initiate) | **POST** /account/articles/{article_id}/files | Initiate Upload
[**private_articles_list**](ArticlesApi.md#private_articles_list) | **GET** /account/articles | Private Articles
[**private_articles_search**](ArticlesApi.md#private_articles_search) | **POST** /account/articles/search | Private Articles search
[**public_article_download**](ArticlesApi.md#public_article_download) | **GET** /articles/{article_id}/download | Public Article Download
[**public_article_version_download**](ArticlesApi.md#public_article_version_download) | **GET** /articles/{article_id}/versions/{version_id}/download | Public Article Version Download


# **account_article_publish**
> Location account_article_publish(article_id)

Private Article Publish

- If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.location import Location
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier

    try:
        # Private Article Publish
        api_response = api_instance.account_article_publish(article_id)
        print("The response of ArticlesApi->account_article_publish:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->account_article_publish: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  * Location - Location of project <br>  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **account_article_report**
> List[AccountReport] account_article_report(group_id=group_id)

Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.account_report import AccountReport
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    group_id = 56 # int | A group ID to filter by (optional)

    try:
        # Account Article Report
        api_response = api_instance.account_article_report(group_id=group_id)
        print("The response of ArticlesApi->account_article_report:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->account_article_report: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group_id** | **int**| A group ID to filter by | [optional] 

### Return type

[**List[AccountReport]**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of account report entries |  -  |
**400** | Bad Request |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **account_article_report_generate**
> AccountReport account_article_report_generate()

Initiate a new Report

Initiate a new Article Report for this Account. There is a limit of 1 report per day.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.account_report import AccountReport
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)

    try:
        # Initiate a new Report
        api_response = api_instance.account_article_report_generate()
        print("The response of ArticlesApi->account_article_report_generate:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->account_article_report_generate: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. AccountReport created. |  -  |
**429** | Too Many Requests |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **account_article_unpublish**
> account_article_unpublish(article_id, reason)

Public Article Unpublish

Allows authorized users to unpublish an article.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_unpublish_data import ArticleUnpublishData
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    reason = openapi_client.ArticleUnpublishData() # ArticleUnpublishData | Article unpublish data

    try:
        # Public Article Unpublish
        api_instance.account_article_unpublish(article_id, reason)
    except Exception as e:
        print("Exception when calling ArticlesApi->account_article_unpublish: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **reason** | [**ArticleUnpublishData**](ArticleUnpublishData.md)| Article unpublish data | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_details**
> ArticleComplete article_details(article_id)

View article details

View an article

### Example


```python
import openapi_client
from openapi_client.models.article_complete import ArticleComplete
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article Unique identifier

    try:
        # View article details
        api_response = api_instance.article_details(article_id)
        print("The response of ArticlesApi->article_details:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->article_details: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Article representation |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_file_details**
> PublicFile article_file_details(article_id, file_id)

Article file details

File by id

### Example


```python
import openapi_client
from openapi_client.models.public_file import PublicFile
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article Unique identifier
    file_id = 56 # int | File Unique identifier

    try:
        # Article file details
        api_response = api_instance.article_file_details(article_id, file_id)
        print("The response of ArticlesApi->article_file_details:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->article_file_details: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 
 **file_id** | **int**| File Unique identifier | 

### Return type

[**PublicFile**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. File representation |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_files**
> List[PublicFile] article_files(article_id, page=page, page_size=page_size, limit=limit, offset=offset)

List article files

Files list for article

### Example


```python
import openapi_client
from openapi_client.models.public_file import PublicFile
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article Unique identifier
    page = 56 # int | Page number. Used for pagination with page_size (optional)
    page_size = 10 # int | The number of results included on a page. Used for pagination with page (optional) (default to 10)
    limit = 56 # int | Number of results included on a page. Used for pagination with query (optional)
    offset = 56 # int | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

    try:
        # List article files
        api_response = api_instance.article_files(article_id, page=page, page_size=page_size, limit=limit, offset=offset)
        print("The response of ArticlesApi->article_files:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->article_files: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**List[PublicFile]**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. List of article files |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_version_confidentiality**
> ArticleConfidentiality article_version_confidentiality(article_id, version_id)

Public Article Confidentiality for article version

Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example


```python
import openapi_client
from openapi_client.models.article_confidentiality import ArticleConfidentiality
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article Unique identifier
    version_id = 56 # int | Version Number

    try:
        # Public Article Confidentiality for article version
        api_response = api_instance.article_version_confidentiality(article_id, version_id)
        print("The response of ArticlesApi->article_version_confidentiality:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->article_version_confidentiality: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 
 **version_id** | **int**| Version Number | 

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Confidentiality representation |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_version_details**
> ArticleComplete article_version_details(article_id, version_id)

Article details for version

Article with specified version

### Example


```python
import openapi_client
from openapi_client.models.article_complete import ArticleComplete
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article Unique identifier
    version_id = 56 # int | Article Version Number

    try:
        # Article details for version
        api_response = api_instance.article_version_details(article_id, version_id)
        print("The response of ArticlesApi->article_version_details:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->article_version_details: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 
 **version_id** | **int**| Article Version Number | 

### Return type

[**ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Article representation |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_version_embargo**
> ArticleEmbargo article_version_embargo(article_id, version_id)

Public Article Embargo for article version

Embargo for article version

### Example


```python
import openapi_client
from openapi_client.models.article_embargo import ArticleEmbargo
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article Unique identifier
    version_id = 56 # int | Version Number

    try:
        # Public Article Embargo for article version
        api_response = api_instance.article_version_embargo(article_id, version_id)
        print("The response of ArticlesApi->article_version_embargo:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->article_version_embargo: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 
 **version_id** | **int**| Version Number | 

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Embargo representation |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_version_files**
> List[PublicFile] article_version_files(article_id, version_id, page=page, page_size=page_size, limit=limit, offset=offset)

Public Article version files

Article version file details

### Example


```python
import openapi_client
from openapi_client.models.public_file import PublicFile
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article Unique identifier
    version_id = 56 # int | Article Version Unique identifier
    page = 56 # int | Page number. Used for pagination with page_size (optional)
    page_size = 10 # int | The number of results included on a page. Used for pagination with page (optional) (default to 10)
    limit = 56 # int | Number of results included on a page. Used for pagination with query (optional)
    offset = 56 # int | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

    try:
        # Public Article version files
        api_response = api_instance.article_version_files(article_id, version_id, page=page, page_size=page_size, limit=limit, offset=offset)
        print("The response of ArticlesApi->article_version_files:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->article_version_files: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 
 **version_id** | **int**| Article Version Unique identifier | 
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**List[PublicFile]**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. List of article files |  -  |
**400** | Bad Request |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_version_partial_update**
> LocationWarningsUpdate article_version_partial_update(article_id, version_id, article)

Partially update article version

Partially updating an article version by passing only the fields to change.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_version_update import ArticleVersionUpdate
from openapi_client.models.location_warnings_update import LocationWarningsUpdate
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    version_id = 56 # int | Article version identifier
    article = openapi_client.ArticleVersionUpdate() # ArticleVersionUpdate | Subset of article version fields to update

    try:
        # Partially update article version
        api_response = api_instance.article_version_partial_update(article_id, version_id, article)
        print("The response of ArticlesApi->article_version_partial_update:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->article_version_partial_update: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **version_id** | **int**| Article version identifier | 
 **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md)| Subset of article version fields to update | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  * Location - Location of project <br>  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_version_update**
> LocationWarningsUpdate article_version_update(article_id, version_id, article)

Update article version

Updating an article version by passing body parameters.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_version_update import ArticleVersionUpdate
from openapi_client.models.location_warnings_update import LocationWarningsUpdate
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    version_id = 56 # int | Article version identifier
    article = openapi_client.ArticleVersionUpdate() # ArticleVersionUpdate | Article description

    try:
        # Update article version
        api_response = api_instance.article_version_update(article_id, version_id, article)
        print("The response of ArticlesApi->article_version_update:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->article_version_update: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **version_id** | **int**| Article version identifier | 
 **article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md)| Article description | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  * Location - Location of project <br>  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_version_update_thumb**
> article_version_update_thumb(article_id, version_id, file_id)

Update article version thumbnail

For a given public article version update the article thumbnail by choosing one of the associated files

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.file_id import FileId
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    version_id = 56 # int | Article version identifier
    file_id = openapi_client.FileId() # FileId | File ID

    try:
        # Update article version thumbnail
        api_instance.article_version_update_thumb(article_id, version_id, file_id)
    except Exception as e:
        print("Exception when calling ArticlesApi->article_version_update_thumb: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **version_id** | **int**| Article version identifier | 
 **file_id** | [**FileId**](FileId.md)| File ID | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  * Location - Location of project <br>  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Entity |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **article_versions**
> List[ArticleVersions] article_versions(article_id)

List article versions

List public article versions

### Example


```python
import openapi_client
from openapi_client.models.article_versions import ArticleVersions
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article Unique identifier

    try:
        # List article versions
        api_response = api_instance.article_versions(article_id)
        print("The response of ArticlesApi->article_versions:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->article_versions: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article Unique identifier | 

### Return type

[**List[ArticleVersions]**](ArticleVersions.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Article version representations |  -  |
**400** | Bad Request. Article ID must be an integer and bigger than 0. |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articles_list**
> List[Article] articles_list(x_cursor=x_cursor, page=page, page_size=page_size, limit=limit, offset=offset, order=order, order_direction=order_direction, institution=institution, published_since=published_since, modified_since=modified_since, group=group, resource_doi=resource_doi, item_type=item_type, doi=doi, handle=handle)

Public Articles

Returns a list of public articles

### Example


```python
import openapi_client
from openapi_client.models.article import Article
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    x_cursor = 'x_cursor_example' # str | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
    page = 56 # int | Page number. Used for pagination with page_size (optional)
    page_size = 10 # int | The number of results included on a page. Used for pagination with page (optional) (default to 10)
    limit = 56 # int | Number of results included on a page. Used for pagination with query (optional)
    offset = 56 # int | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)
    order = published_date # str | The field by which to order. Default varies by endpoint/resource. (optional) (default to published_date)
    order_direction = desc # str |  (optional) (default to desc)
    institution = 56 # int | only return articles from this institution (optional)
    published_since = 'published_since_example' # str | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
    modified_since = 'modified_since_example' # str | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ (optional)
    group = 56 # int | only return articles from this group (optional)
    resource_doi = 'resource_doi_example' # str | Deprecated by related materials. Only return articles with this resource_doi (optional)
    item_type = 56 # int | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model (optional)
    doi = 'doi_example' # str | only return articles with this doi (optional)
    handle = 'handle_example' # str | only return articles with this handle (optional)

    try:
        # Public Articles
        api_response = api_instance.articles_list(x_cursor=x_cursor, page=page, page_size=page_size, limit=limit, offset=offset, order=order, order_direction=order_direction, institution=institution, published_since=published_since, modified_since=modified_since, group=group, resource_doi=resource_doi, item_type=item_type, doi=doi, handle=handle)
        print("The response of ArticlesApi->articles_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->articles_list: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **x_cursor** | **str**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
 **order** | **str**| The field by which to order. Default varies by endpoint/resource. | [optional] [default to published_date]
 **order_direction** | **str**|  | [optional] [default to desc]
 **institution** | **int**| only return articles from this institution | [optional] 
 **published_since** | **str**| Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **modified_since** | **str**| Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
 **group** | **int**| only return articles from this group | [optional] 
 **resource_doi** | **str**| Deprecated by related materials. Only return articles with this resource_doi | [optional] 
 **item_type** | **int**| Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
 **doi** | **str**| only return articles with this doi | [optional] 
 **handle** | **str**| only return articles with this handle | [optional] 

### Return type

[**List[Article]**](Article.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of articles |  * X-Cursor - Unique hash used for bypassing the item retrieval limit of 9,000 entities. <br>  |
**400** | Bad Request |  -  |
**422** | Unprocessable Entity. Syntax is correct but one of the parameters isn&#39;t correctly processed |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **articles_search**
> List[ArticleWithProject] articles_search(x_cursor=x_cursor, search=search)

Public Articles Search

Returns a list of public articles, filtered by the search parameters

### Example


```python
import openapi_client
from openapi_client.models.article_search import ArticleSearch
from openapi_client.models.article_with_project import ArticleWithProject
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    x_cursor = 'x_cursor_example' # str | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. (optional)
    search = openapi_client.ArticleSearch() # ArticleSearch | Search Parameters (optional)

    try:
        # Public Articles Search
        api_response = api_instance.articles_search(x_cursor=x_cursor, search=search)
        print("The response of ArticlesApi->articles_search:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->articles_search: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **x_cursor** | **str**| Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. | [optional] 
 **search** | [**ArticleSearch**](ArticleSearch.md)| Search Parameters | [optional] 

### Return type

[**List[ArticleWithProject]**](ArticleWithProject.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of articles |  * X-Cursor - Unique hash used for bypassing the item retrieval limit of 9,000 entities. <br>  |
**400** | Bad Request |  -  |
**422** | Unprocessable Entity. Syntax is correct but one of the parameters isn&#39;t correctly processed |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_author_delete**
> private_article_author_delete(article_id, author_id)

Delete article author

De-associate author from article

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    author_id = 56 # int | Article Author unique identifier

    try:
        # Delete article author
        api_instance.private_article_author_delete(article_id, author_id)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_author_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **author_id** | **int**| Article Author unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_authors_add**
> private_article_authors_add(article_id, authors)

Add article authors

Associate new authors with the article. This will add new authors to the list of already associated authors

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.authors_creator import AuthorsCreator
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    authors = openapi_client.AuthorsCreator() # AuthorsCreator | Authors description

    try:
        # Add article authors
        api_instance.private_article_authors_add(article_id, authors)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_authors_add: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| Authors description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  * Location - Location of article <br>  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_authors_list**
> List[Author] private_article_authors_list(article_id)

List article authors

List article authors

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.author import Author
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier

    try:
        # List article authors
        api_response = api_instance.private_article_authors_list(article_id)
        print("The response of ArticlesApi->private_article_authors_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_authors_list: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**List[Author]**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Authors list for article |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_authors_replace**
> private_article_authors_replace(article_id, authors)

Replace article authors

Associate new authors with the article. This will remove all already associated authors and add these new ones

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.authors_creator import AuthorsCreator
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    authors = openapi_client.AuthorsCreator() # AuthorsCreator | Authors description

    try:
        # Replace article authors
        api_instance.private_article_authors_replace(article_id, authors)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_authors_replace: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **authors** | [**AuthorsCreator**](AuthorsCreator.md)| Authors description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  * Location - Location of article <br>  |
**400** | Bad Request. Article ID must be an integer and bigger than 0. Author with ID Not Found. |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_categories_add**
> private_article_categories_add(article_id, categories)

Add article categories

Associate new categories with the article. This will add new categories to the list of already associated categories

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.categories_creator import CategoriesCreator
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    categories = openapi_client.CategoriesCreator() # CategoriesCreator | 

    try:
        # Add article categories
        api_instance.private_article_categories_add(article_id, categories)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_categories_add: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_categories_list**
> List[Category] private_article_categories_list(article_id)

List article categories

List article categories

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.category import Category
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier

    try:
        # List article categories
        api_response = api_instance.private_article_categories_list(article_id)
        print("The response of ArticlesApi->private_article_categories_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_categories_list: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**List[Category]**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Article categories |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_categories_replace**
> private_article_categories_replace(article_id, categories)

Replace article categories

Associate new categories with the article. This will remove all already associated categories and add these new ones

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.categories_creator import CategoriesCreator
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    categories = openapi_client.CategoriesCreator() # CategoriesCreator | 

    try:
        # Replace article categories
        api_instance.private_article_categories_replace(article_id, categories)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_categories_replace: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **categories** | [**CategoriesCreator**](CategoriesCreator.md)|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_category_delete**
> private_article_category_delete(article_id, category_id)

Delete article category

De-associate category from article

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    category_id = 56 # int | Category unique identifier

    try:
        # Delete article category
        api_instance.private_article_category_delete(article_id, category_id)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_category_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **category_id** | **int**| Category unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_confidentiality_delete**
> private_article_confidentiality_delete(article_id)

Delete article confidentiality

Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier

    try:
        # Delete article confidentiality
        api_instance.private_article_confidentiality_delete(article_id)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_confidentiality_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_confidentiality_details**
> ArticleConfidentiality private_article_confidentiality_details(article_id)

Article confidentiality details

View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_confidentiality import ArticleConfidentiality
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier

    try:
        # Article confidentiality details
        api_response = api_instance.private_article_confidentiality_details(article_id)
        print("The response of ArticlesApi->private_article_confidentiality_details:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_confidentiality_details: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Article categories |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_confidentiality_update**
> private_article_confidentiality_update(article_id, reason)

Update article confidentiality

Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.confidentiality_creator import ConfidentialityCreator
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    reason = openapi_client.ConfidentialityCreator() # ConfidentialityCreator | 

    try:
        # Update article confidentiality
        api_instance.private_article_confidentiality_update(article_id, reason)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_confidentiality_update: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **reason** | [**ConfidentialityCreator**](ConfidentialityCreator.md)|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_create**
> LocationWarnings private_article_create(article)

Create new Article

Create a new Article by sending article information

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_create import ArticleCreate
from openapi_client.models.location_warnings import LocationWarnings
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article = openapi_client.ArticleCreate() # ArticleCreate | Article description

    try:
        # Create new Article
        api_response = api_instance.private_article_create(article)
        print("The response of ArticlesApi->private_article_create:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_create: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article** | [**ArticleCreate**](ArticleCreate.md)| Article description | 

### Return type

[**LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_delete**
> private_article_delete(article_id)

Delete article

Delete an article

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier

    try:
        # Delete article
        api_instance.private_article_delete(article_id)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_details**
> ArticleCompletePrivate private_article_details(article_id)

Article details

View a private article

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_complete_private import ArticleCompletePrivate
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier

    try:
        # Article details
        api_response = api_instance.private_article_details(article_id)
        print("The response of ArticlesApi->private_article_details:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_details: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Article representation |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_download**
> private_article_download(article_id, folder_path=folder_path)

Private Article Download

Download files from a private article preserving the folder structure

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    folder_path = 'folder_path_example' # str | Folder path to download. If not provided, all files from the article will be downloaded (optional)

    try:
        # Private Article Download
        api_instance.private_article_download(article_id, folder_path=folder_path)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_download: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **folder_path** | **str**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**403** | Insufficient permissions |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_embargo_delete**
> private_article_embargo_delete(article_id)

Delete Article Embargo

Will lift the embargo for the specified article

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier

    try:
        # Delete Article Embargo
        api_instance.private_article_embargo_delete(article_id)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_embargo_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_embargo_details**
> ArticleEmbargo private_article_embargo_details(article_id)

Article Embargo Details

View a private article embargo details

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_embargo import ArticleEmbargo
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier

    try:
        # Article Embargo Details
        api_response = api_instance.private_article_embargo_details(article_id)
        print("The response of ArticlesApi->private_article_embargo_details:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_embargo_details: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Embargo for article |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_embargo_update**
> private_article_embargo_update(article_id, embargo)

Update Article Embargo

Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_embargo_updater import ArticleEmbargoUpdater
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    embargo = openapi_client.ArticleEmbargoUpdater() # ArticleEmbargoUpdater | Embargo description

    try:
        # Update Article Embargo
        api_instance.private_article_embargo_update(article_id, embargo)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_embargo_update: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **embargo** | [**ArticleEmbargoUpdater**](ArticleEmbargoUpdater.md)| Embargo description | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  * Location - Location of project <br>  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_file**
> PrivateFile private_article_file(article_id, file_id)

Single File

View details of file for specified article

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.private_file import PrivateFile
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    file_id = 56 # int | File unique identifier

    try:
        # Single File
        api_response = api_instance.private_article_file(article_id, file_id)
        print("The response of ArticlesApi->private_article_file:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_file: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **file_id** | **int**| File unique identifier | 

### Return type

[**PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Article private file |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_file_delete**
> private_article_file_delete(article_id, file_id)

File Delete

Complete file upload

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    file_id = 56 # int | File unique identifier

    try:
        # File Delete
        api_instance.private_article_file_delete(article_id, file_id)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_file_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **file_id** | **int**| File unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_files_list**
> List[PrivateFile] private_article_files_list(article_id, page=page, page_size=page_size, limit=limit, offset=offset)

List article files

List private files

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.private_file import PrivateFile
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    page = 56 # int | Page number. Used for pagination with page_size (optional)
    page_size = 10 # int | The number of results included on a page. Used for pagination with page (optional) (default to 10)
    limit = 56 # int | Number of results included on a page. Used for pagination with query (optional)
    offset = 56 # int | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

    try:
        # List article files
        api_response = api_instance.private_article_files_list(article_id, page=page, page_size=page_size, limit=limit, offset=offset)
        print("The response of ArticlesApi->private_article_files_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_files_list: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**List[PrivateFile]**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Article files list |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_partial_update**
> LocationWarningsUpdate private_article_partial_update(article_id, article)

Partially update article

Partially update an article by sending only the fields to change.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_update import ArticleUpdate
from openapi_client.models.location_warnings_update import LocationWarningsUpdate
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    article = openapi_client.ArticleUpdate() # ArticleUpdate | Subset of article fields to update

    try:
        # Partially update article
        api_response = api_instance.private_article_partial_update(article_id, article)
        print("The response of ArticlesApi->private_article_partial_update:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_partial_update: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **article** | [**ArticleUpdate**](ArticleUpdate.md)| Subset of article fields to update | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  * Location - Location of project <br>  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_private_link**
> List[PrivateLink] private_article_private_link(article_id)

List private links

List private links

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.private_link import PrivateLink
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier

    try:
        # List private links
        api_response = api_instance.private_article_private_link(article_id)
        print("The response of ArticlesApi->private_article_private_link:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_private_link: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**List[PrivateLink]**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Article private links |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_private_link_create**
> PrivateLinkResponse private_article_private_link_create(article_id, private_link=private_link)

Create private link

Create new private link for this article

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.private_link_creator import PrivateLinkCreator
from openapi_client.models.private_link_response import PrivateLinkResponse
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    private_link = openapi_client.PrivateLinkCreator() # PrivateLinkCreator |  (optional)

    try:
        # Create private link
        api_response = api_instance.private_article_private_link_create(article_id, private_link=private_link)
        print("The response of ArticlesApi->private_article_private_link_create:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_private_link_create: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **private_link** | [**PrivateLinkCreator**](PrivateLinkCreator.md)|  | [optional] 

### Return type

[**PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  * Location - Location of article <br>  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Entity |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_private_link_delete**
> private_article_private_link_delete(article_id, link_id)

Disable private link

Disable/delete private link for this article

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    link_id = 'link_id_example' # str | Private link token

    try:
        # Disable private link
        api_instance.private_article_private_link_delete(article_id, link_id)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_private_link_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **link_id** | **str**| Private link token | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_private_link_update**
> private_article_private_link_update(article_id, link_id, private_link=private_link)

Update private link

Update existing private link for this article

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.private_link_creator import PrivateLinkCreator
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    link_id = 'link_id_example' # str | Private link token
    private_link = openapi_client.PrivateLinkCreator() # PrivateLinkCreator |  (optional)

    try:
        # Update private link
        api_instance.private_article_private_link_update(article_id, link_id, private_link=private_link)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_private_link_update: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **link_id** | **str**| Private link token | 
 **private_link** | [**PrivateLinkCreator**](PrivateLinkCreator.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  * Location - Location of article <br>  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Entity |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_reserve_doi**
> ArticleDOI private_article_reserve_doi(article_id)

Private Article Reserve DOI

Reserve DOI for article

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_doi import ArticleDOI
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier

    try:
        # Private Article Reserve DOI
        api_response = api_instance.private_article_reserve_doi(article_id)
        print("The response of ArticlesApi->private_article_reserve_doi:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_reserve_doi: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ArticleDOI**](ArticleDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_reserve_handle**
> ArticleHandle private_article_reserve_handle(article_id)

Private Article Reserve Handle

Reserve Handle for article

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_handle import ArticleHandle
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier

    try:
        # Private Article Reserve Handle
        api_response = api_instance.private_article_reserve_handle(article_id)
        print("The response of ArticlesApi->private_article_reserve_handle:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_reserve_handle: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 

### Return type

[**ArticleHandle**](ArticleHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_resource**
> Location private_article_resource(article_id, resource)

Private Article Resource

Edit article resource data.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.location import Location
from openapi_client.models.resource import Resource
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    resource = openapi_client.Resource() # Resource | Resource data

    try:
        # Private Article Resource
        api_response = api_instance.private_article_resource(article_id, resource)
        print("The response of ArticlesApi->private_article_resource:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_resource: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **resource** | [**Resource**](Resource.md)| Resource data | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  * Location - Location of project <br>  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Entity |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_update**
> LocationWarningsUpdate private_article_update(article_id, article)

Update article

Update an article by passing full body parameters.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_update import ArticleUpdate
from openapi_client.models.location_warnings_update import LocationWarningsUpdate
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    article = openapi_client.ArticleUpdate() # ArticleUpdate | Full article representation

    try:
        # Update article
        api_response = api_instance.private_article_update(article_id, article)
        print("The response of ArticlesApi->private_article_update:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_update: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **article** | [**ArticleUpdate**](ArticleUpdate.md)| Full article representation | 

### Return type

[**LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**205** | Reset Content |  * Location - Location of project <br>  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_upload_complete**
> private_article_upload_complete(article_id, file_id)

Complete Upload

Complete file upload

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    file_id = 56 # int | File unique identifier

    try:
        # Complete Upload
        api_instance.private_article_upload_complete(article_id, file_id)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_upload_complete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **file_id** | **int**| File unique identifier | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**202** | Accepted |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_article_upload_initiate**
> Location private_article_upload_initiate(article_id, file, page=page, page_size=page_size, limit=limit, offset=offset)

Initiate Upload

Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.file_creator import FileCreator
from openapi_client.models.location import Location
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    file = openapi_client.FileCreator() # FileCreator | 
    page = 56 # int | Page number. Used for pagination with page_size (optional)
    page_size = 10 # int | The number of results included on a page. Used for pagination with page (optional) (default to 10)
    limit = 56 # int | Number of results included on a page. Used for pagination with query (optional)
    offset = 56 # int | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

    try:
        # Initiate Upload
        api_response = api_instance.private_article_upload_initiate(article_id, file, page=page, page_size=page_size, limit=limit, offset=offset)
        print("The response of ArticlesApi->private_article_upload_initiate:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_article_upload_initiate: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **file** | [**FileCreator**](FileCreator.md)|  | 
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  * Location - Location of article <br>  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**422** | Unprocessable Entity. Parameters missing or incorrect |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_articles_list**
> List[Article] private_articles_list(page=page, page_size=page_size, limit=limit, offset=offset)

Private Articles

Get Own Articles

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article import Article
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    page = 56 # int | Page number. Used for pagination with page_size (optional)
    page_size = 10 # int | The number of results included on a page. Used for pagination with page (optional) (default to 10)
    limit = 56 # int | Number of results included on a page. Used for pagination with query (optional)
    offset = 56 # int | Where to start the listing (the offset of the first result). Used for pagination with limit (optional)

    try:
        # Private Articles
        api_response = api_instance.private_articles_list(page=page, page_size=page_size, limit=limit, offset=offset)
        print("The response of ArticlesApi->private_articles_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_articles_list: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| Page number. Used for pagination with page_size | [optional] 
 **page_size** | **int**| The number of results included on a page. Used for pagination with page | [optional] [default to 10]
 **limit** | **int**| Number of results included on a page. Used for pagination with query | [optional] 
 **offset** | **int**| Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 

### Return type

[**List[Article]**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of articles belonging to the account |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_articles_search**
> List[ArticleWithProject] private_articles_search(search)

Private Articles search

Returns a list of private articles filtered by the search parameters

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.article_with_project import ArticleWithProject
from openapi_client.models.private_article_search import PrivateArticleSearch
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    search = openapi_client.PrivateArticleSearch() # PrivateArticleSearch | Search Parameters

    try:
        # Private Articles search
        api_response = api_instance.private_articles_search(search)
        print("The response of ArticlesApi->private_articles_search:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ArticlesApi->private_articles_search: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateArticleSearch**](PrivateArticleSearch.md)| Search Parameters | 

### Return type

[**List[ArticleWithProject]**](ArticleWithProject.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of articles |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **public_article_download**
> public_article_download(article_id, folder_path=folder_path)

Public Article Download

Download files from a public article preserving the folder structure

### Example


```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    folder_path = 'folder_path_example' # str | Folder path to download. If not provided, all files from the article will be downloaded (optional)

    try:
        # Public Article Download
        api_instance.public_article_download(article_id, folder_path=folder_path)
    except Exception as e:
        print("Exception when calling ArticlesApi->public_article_download: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **folder_path** | **str**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **public_article_version_download**
> public_article_version_download(article_id, version_id, folder_path=folder_path)

Public Article Version Download

Download files from a certain version of an public article preserving the folder structure

### Example


```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ArticlesApi(api_client)
    article_id = 56 # int | Article unique identifier
    version_id = 56 # int | Version Number
    folder_path = 'folder_path_example' # str | Folder path to download. If not provided, all files from the article will be downloaded (optional)

    try:
        # Public Article Version Download
        api_instance.public_article_version_download(article_id, version_id, folder_path=folder_path)
    except Exception as e:
        print("Exception when calling ArticlesApi->public_article_version_download: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **article_id** | **int**| Article unique identifier | 
 **version_id** | **int**| Version Number | 
 **folder_path** | **str**| Folder path to download. If not provided, all files from the article will be downloaded | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

