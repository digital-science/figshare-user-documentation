# LocationWarnings


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entity_id** | **int** | Figshare ID of the entity | 
**location** | **str** | Url for entity | 
**warnings** | **List[str]** | Issues encountered during the operation | 

## Example

```python
from openapi_client.models.location_warnings import LocationWarnings

# TODO update the JSON string below
json = "{}"
# create an instance of LocationWarnings from a JSON string
location_warnings_instance = LocationWarnings.from_json(json)
# print the JSON string representation of the object
print(LocationWarnings.to_json())

# convert the object into a dict
location_warnings_dict = location_warnings_instance.to_dict()
# create an instance of LocationWarnings from a dict
location_warnings_from_dict = LocationWarnings.from_dict(location_warnings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


