# ArticleDOI


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**doi** | **str** | Reserved DOI | 

## Example

```python
from openapi_client.models.article_doi import ArticleDOI

# TODO update the JSON string below
json = "{}"
# create an instance of ArticleDOI from a JSON string
article_doi_instance = ArticleDOI.from_json(json)
# print the JSON string representation of the object
print(ArticleDOI.to_json())

# convert the object into a dict
article_doi_dict = article_doi_instance.to_dict()
# create an instance of ArticleDOI from a dict
article_doi_from_dict = ArticleDOI.from_dict(article_doi_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


