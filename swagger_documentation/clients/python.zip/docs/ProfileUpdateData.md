# ProfileUpdateData


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_name** | **str** | First name | [optional] 
**last_name** | **str** | Last Name | [optional] 
**orcid** | **str** | User ORCID | [optional] 
**job_title** | **str** | User job title | [optional] 
**fields_of_interest** | **List[int]** | User fields of interest (category ids) | [optional] 
**fields_of_interest_by_source_id** | **List[str]** | User fields of interest (category source IDs), supersedes the fields_of_interest property | [optional] 
**location** | **str** | User location | [optional] 
**facebook** | **str** | User facebook URL | [optional] 
**x** | **str** | User X (twitter) URL | [optional] 
**linkedin** | **str** | User linkedin URL | [optional] 
**bio** | **str** | User biographical information | [optional] 
**personal_profiles** | [**List[ProfileUpdateDataPersonalProfilesInner]**](ProfileUpdateDataPersonalProfilesInner.md) | Add up to 10 additional personal profile links | [optional] 

## Example

```python
from openapi_client.models.profile_update_data import ProfileUpdateData

# TODO update the JSON string below
json = "{}"
# create an instance of ProfileUpdateData from a JSON string
profile_update_data_instance = ProfileUpdateData.from_json(json)
# print the JSON string representation of the object
print(ProfileUpdateData.to_json())

# convert the object into a dict
profile_update_data_dict = profile_update_data_instance.to_dict()
# create an instance of ProfileUpdateData from a dict
profile_update_data_from_dict = ProfileUpdateData.from_dict(profile_update_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


