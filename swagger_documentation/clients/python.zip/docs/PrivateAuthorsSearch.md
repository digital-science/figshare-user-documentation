# PrivateAuthorsSearch


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_for** | **str** | Search term | [optional] 
**page** | **int** | Page number. Used for pagination with page_size | [optional] 
**page_size** | **int** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **int** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **int** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
**institution_id** | **int** | Return only authors associated to this institution | [optional] 
**orcid** | **str** | Orcid of author | [optional] 
**group_id** | **int** | Return only authors in this group or subgroups of the group | [optional] 
**is_active** | **bool** | Return only active authors if True | [optional] 
**is_public** | **bool** | Return only authors that have published items if True | [optional] 

## Example

```python
from openapi_client.models.private_authors_search import PrivateAuthorsSearch

# TODO update the JSON string below
json = "{}"
# create an instance of PrivateAuthorsSearch from a JSON string
private_authors_search_instance = PrivateAuthorsSearch.from_json(json)
# print the JSON string representation of the object
print(PrivateAuthorsSearch.to_json())

# convert the object into a dict
private_authors_search_dict = private_authors_search_instance.to_dict()
# create an instance of PrivateAuthorsSearch from a dict
private_authors_search_from_dict = PrivateAuthorsSearch.from_dict(private_authors_search_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


