# CustomArticleFieldAdd


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Custom  metadata name | 
**value** | **object** | Custom metadata value (can be either a string or an array of strings) | 

## Example

```python
from openapi_client.models.custom_article_field_add import CustomArticleFieldAdd

# TODO update the JSON string below
json = "{}"
# create an instance of CustomArticleFieldAdd from a JSON string
custom_article_field_add_instance = CustomArticleFieldAdd.from_json(json)
# print the JSON string representation of the object
print(CustomArticleFieldAdd.to_json())

# convert the object into a dict
custom_article_field_add_dict = custom_article_field_add_instance.to_dict()
# create an instance of CustomArticleFieldAdd from a dict
custom_article_field_add_from_dict = CustomArticleFieldAdd.from_dict(custom_article_field_add_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


