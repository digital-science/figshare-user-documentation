# ArticleVersionUpdate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supplementary_fields** | **List[object]** | List of supplementary fields to be associated with the article version | [optional] 
**internal_metadata** | **object** | List of supplementary fields to be associated with the article version | [optional] 

## Example

```python
from openapi_client.models.article_version_update import ArticleVersionUpdate

# TODO update the JSON string below
json = "{}"
# create an instance of ArticleVersionUpdate from a JSON string
article_version_update_instance = ArticleVersionUpdate.from_json(json)
# print the JSON string representation of the object
print(ArticleVersionUpdate.to_json())

# convert the object into a dict
article_version_update_dict = article_version_update_instance.to_dict()
# create an instance of ArticleVersionUpdate from a dict
article_version_update_from_dict = ArticleVersionUpdate.from_dict(article_version_update_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


