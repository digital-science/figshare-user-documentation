# GroupEmbargoOptions


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Embargo option id | 
**type** | **str** | Embargo permission type | 
**ip_name** | **str** | IP range name; value appears if type is ip_range | 

## Example

```python
from openapi_client.models.group_embargo_options import GroupEmbargoOptions

# TODO update the JSON string below
json = "{}"
# create an instance of GroupEmbargoOptions from a JSON string
group_embargo_options_instance = GroupEmbargoOptions.from_json(json)
# print the JSON string representation of the object
print(GroupEmbargoOptions.to_json())

# convert the object into a dict
group_embargo_options_dict = group_embargo_options_instance.to_dict()
# create an instance of GroupEmbargoOptions from a dict
group_embargo_options_from_dict = GroupEmbargoOptions.from_dict(group_embargo_options_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


