# UploadInfo


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **str** | token received after initializing a file upload | [optional] 
**md5** | **str** | md5 provided on upload initialization | [optional] 
**size** | **int** | size of file in bytes | [optional] 
**name** | **str** | name of file on upload server | [optional] 
**status** | **str** | Upload status | [optional] 
**parts** | [**List[UploadFilePart]**](UploadFilePart.md) | Uploads parts | [optional] 

## Example

```python
from openapi_client.models.upload_info import UploadInfo

# TODO update the JSON string below
json = "{}"
# create an instance of UploadInfo from a JSON string
upload_info_instance = UploadInfo.from_json(json)
# print the JSON string representation of the object
print(UploadInfo.to_json())

# convert the object into a dict
upload_info_dict = upload_info_instance.to_dict()
# create an instance of UploadInfo from a dict
upload_info_from_dict = UploadInfo.from_dict(upload_info_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


