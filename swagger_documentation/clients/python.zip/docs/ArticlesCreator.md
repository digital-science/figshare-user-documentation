# ArticlesCreator


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | **List[int]** | List of article ids | 

## Example

```python
from openapi_client.models.articles_creator import ArticlesCreator

# TODO update the JSON string below
json = "{}"
# create an instance of ArticlesCreator from a JSON string
articles_creator_instance = ArticlesCreator.from_json(json)
# print the JSON string representation of the object
print(ArticlesCreator.to_json())

# convert the object into a dict
articles_creator_dict = articles_creator_instance.to_dict()
# create an instance of ArticlesCreator from a dict
articles_creator_from_dict = ArticlesCreator.from_dict(articles_creator_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


