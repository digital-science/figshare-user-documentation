# PrivateLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Private link id | 
**is_active** | **bool** | True if private link is active | 
**expires_date** | **str** | Date when link will expire | 
**html_location** | **str** | HTML url for private link | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


