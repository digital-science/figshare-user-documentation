# PrivateLink


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Private link id | 
**is_active** | **bool** | True if private link is active | 
**expires_date** | **str** | Date when link will expire | 
**html_location** | **str** | HTML url for private link | 

## Example

```python
from openapi_client.models.private_link import PrivateLink

# TODO update the JSON string below
json = "{}"
# create an instance of PrivateLink from a JSON string
private_link_instance = PrivateLink.from_json(json)
# print the JSON string representation of the object
print(PrivateLink.to_json())

# convert the object into a dict
private_link_dict = private_link_instance.to_dict()
# create an instance of PrivateLink from a dict
private_link_from_dict = PrivateLink.from_dict(private_link_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


