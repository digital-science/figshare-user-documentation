# CollectionVersions


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **int** | Version number | 
**url** | **str** | Api endpoint for the collection version | 
**funding** | [**List[FundingInformation]**](FundingInformation.md) | Full Collection funding information | 

## Example

```python
from openapi_client.models.collection_versions import CollectionVersions

# TODO update the JSON string below
json = "{}"
# create an instance of CollectionVersions from a JSON string
collection_versions_instance = CollectionVersions.from_json(json)
# print the JSON string representation of the object
print(CollectionVersions.to_json())

# convert the object into a dict
collection_versions_dict = collection_versions_instance.to_dict()
# create an instance of CollectionVersions from a dict
collection_versions_from_dict = CollectionVersions.from_dict(collection_versions_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


