# ProjectUpdate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** | The title for this project - mandatory. 3 - 1000 characters. | [optional] 
**description** | **str** | Project description | [optional] 
**funding** | **str** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional] 
**funding_list** | [**List[FundingCreate]**](FundingCreate.md) | Funding creation / update items | [optional] 
**custom_fields** | **object** | List of key, values pairs to be associated with the project | [optional] 
**custom_fields_list** | [**List[CustomArticleFieldAdd]**](CustomArticleFieldAdd.md) | List of custom fields values, supersedes custom_fields parameter | [optional] 

## Example

```python
from openapi_client.models.project_update import ProjectUpdate

# TODO update the JSON string below
json = "{}"
# create an instance of ProjectUpdate from a JSON string
project_update_instance = ProjectUpdate.from_json(json)
# print the JSON string representation of the object
print(ProjectUpdate.to_json())

# convert the object into a dict
project_update_dict = project_update_instance.to_dict()
# create an instance of ProjectUpdate from a dict
project_update_from_dict = ProjectUpdate.from_dict(project_update_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


