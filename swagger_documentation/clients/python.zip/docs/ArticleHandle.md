# ArticleHandle


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**handle** | **str** | Reserved Handle | 

## Example

```python
from openapi_client.models.article_handle import ArticleHandle

# TODO update the JSON string below
json = "{}"
# create an instance of ArticleHandle from a JSON string
article_handle_instance = ArticleHandle.from_json(json)
# print the JSON string representation of the object
print(ArticleHandle.to_json())

# convert the object into a dict
article_handle_dict = article_handle_instance.to_dict()
# create an instance of ArticleHandle from a dict
article_handle_from_dict = ArticleHandle.from_dict(article_handle_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


