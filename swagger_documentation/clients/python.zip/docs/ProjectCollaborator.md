# ProjectCollaborator


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** | Status of collaborator invitation | 
**role_name** | **str** | Collaborator role | 
**user_id** | **int** | Collaborator id | 
**name** | **str** | Collaborator name | 

## Example

```python
from openapi_client.models.project_collaborator import ProjectCollaborator

# TODO update the JSON string below
json = "{}"
# create an instance of ProjectCollaborator from a JSON string
project_collaborator_instance = ProjectCollaborator.from_json(json)
# print the JSON string representation of the object
print(ProjectCollaborator.to_json())

# convert the object into a dict
project_collaborator_dict = project_collaborator_instance.to_dict()
# create an instance of ProjectCollaborator from a dict
project_collaborator_from_dict = ProjectCollaborator.from_dict(project_collaborator_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


