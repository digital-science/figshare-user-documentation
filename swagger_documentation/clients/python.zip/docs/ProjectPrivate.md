# ProjectPrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **str** | Project title | 
**created_date** | **str** | Date when project was created | 
**modified_date** | **str** | Date when project was last modified | 
**role** | **str** | Role inside this project | 
**storage** | **str** | Project storage type | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


