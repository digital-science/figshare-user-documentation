# ProjectPrivate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | **str** | Role inside this project | 
**storage** | **str** | Project storage type | 
**url** | **str** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **str** | Project title | 
**created_date** | **str** | Date when project was created | 
**modified_date** | **str** | Date when project was last modified | 

## Example

```python
from openapi_client.models.project_private import ProjectPrivate

# TODO update the JSON string below
json = "{}"
# create an instance of ProjectPrivate from a JSON string
project_private_instance = ProjectPrivate.from_json(json)
# print the JSON string representation of the object
print(ProjectPrivate.to_json())

# convert the object into a dict
project_private_dict = project_private_instance.to_dict()
# create an instance of ProjectPrivate from a dict
project_private_from_dict = ProjectPrivate.from_dict(project_private_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


