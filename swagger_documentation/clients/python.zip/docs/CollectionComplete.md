# CollectionComplete


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | [**List[FundingInformation]**](FundingInformation.md) | Full Collection funding information | 
**resource_id** | **str** | Collection resource id | 
**resource_doi** | **str** | Collection resource doi | 
**resource_title** | **str** | Collection resource title | 
**resource_link** | **str** | Collection resource link | 
**resource_version** | **int** | Collection resource version | 
**version** | **int** | Collection version | 
**description** | **str** | Collection description | 
**categories** | [**List[Category]**](Category.md) | List of collection categories | 
**references** | **List[str]** | List of collection references | 
**related_materials** | [**List[RelatedMaterial]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | 
**tags** | **List[str]** | List of collection tags. Keywords can be used instead | 
**keywords** | **List[str]** | List of collection keywords. Tags can be used instead | 
**authors** | [**List[Author]**](Author.md) | List of collection authors | 
**institution_id** | **int** | Collection institution | 
**group_id** | **int** | Collection group | 
**articles_count** | **int** | Number of articles in collection | 
**public** | **bool** | True if collection is published | 
**citation** | **str** | Collection citation | 
**custom_fields** | [**List[CustomArticleField]**](CustomArticleField.md) | Collection custom fields | 
**modified_date** | **str** | Date when collection was last modified | 
**created_date** | **str** | Date when collection was created | 
**timeline** | [**Timeline**](Timeline.md) |  | 
**id** | **int** | Collection id | 
**title** | **str** | Collection title | 
**doi** | **str** | Collection DOI | 
**handle** | **str** | Collection Handle | 
**url** | **str** | Api endpoint | 

## Example

```python
from openapi_client.models.collection_complete import CollectionComplete

# TODO update the JSON string below
json = "{}"
# create an instance of CollectionComplete from a JSON string
collection_complete_instance = CollectionComplete.from_json(json)
# print the JSON string representation of the object
print(CollectionComplete.to_json())

# convert the object into a dict
collection_complete_dict = collection_complete_instance.to_dict()
# create an instance of CollectionComplete from a dict
collection_complete_from_dict = CollectionComplete.from_dict(collection_complete_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


