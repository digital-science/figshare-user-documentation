# CustomArticleField


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Custom  metadata name | 
**value** | **object** | Custom metadata value (can be either a string or an array of strings) | 
**field_type** | **str** | Custom field type | 
**settings** | **object** | Settings for the custom field | 
**order** | **int** | Order of the custom field | 
**is_mandatory** | **bool** | Whether the field is mandatory or not | 

## Example

```python
from openapi_client.models.custom_article_field import CustomArticleField

# TODO update the JSON string below
json = "{}"
# create an instance of CustomArticleField from a JSON string
custom_article_field_instance = CustomArticleField.from_json(json)
# print the JSON string representation of the object
print(CustomArticleField.to_json())

# convert the object into a dict
custom_article_field_dict = custom_article_field_instance.to_dict()
# create an instance of CustomArticleField from a dict
custom_article_field_from_dict = CustomArticleField.from_dict(custom_article_field_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


