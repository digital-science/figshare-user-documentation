# ProjectNote


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Project note id | 
**user_id** | **int** | User who wrote the note | 
**abstract** | **str** | Note Abstract - short/truncated content | 
**user_name** | **str** | Username of the one who wrote the note | 
**created_date** | **str** | Date when note was created | 
**modified_date** | **str** | Date when note was last modified | 

## Example

```python
from openapi_client.models.project_note import ProjectNote

# TODO update the JSON string below
json = "{}"
# create an instance of ProjectNote from a JSON string
project_note_instance = ProjectNote.from_json(json)
# print the JSON string representation of the object
print(ProjectNote.to_json())

# convert the object into a dict
project_note_dict = project_note_instance.to_dict()
# create an instance of ProjectNote from a dict
project_note_from_dict = ProjectNote.from_dict(project_note_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


