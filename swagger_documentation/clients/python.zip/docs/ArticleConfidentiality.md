# ArticleConfidentiality


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_confidential** | **bool** | True if article is confidential | 
**reason** | **str** | Reason for confidentiality | 

## Example

```python
from openapi_client.models.article_confidentiality import ArticleConfidentiality

# TODO update the JSON string below
json = "{}"
# create an instance of ArticleConfidentiality from a JSON string
article_confidentiality_instance = ArticleConfidentiality.from_json(json)
# print the JSON string representation of the object
print(ArticleConfidentiality.to_json())

# convert the object into a dict
article_confidentiality_dict = article_confidentiality_instance.to_dict()
# create an instance of ArticleConfidentiality from a dict
article_confidentiality_from_dict = ArticleConfidentiality.from_dict(article_confidentiality_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


