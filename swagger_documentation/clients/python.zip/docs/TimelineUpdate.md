# TimelineUpdate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_online** | **str** | Online posted date | [optional] 
**publisher_publication** | **str** | Publish date | [optional] 
**publisher_acceptance** | **str** | Date when the item was accepted for publication | [optional] 

## Example

```python
from openapi_client.models.timeline_update import TimelineUpdate

# TODO update the JSON string below
json = "{}"
# create an instance of TimelineUpdate from a JSON string
timeline_update_instance = TimelineUpdate.from_json(json)
# print the JSON string representation of the object
print(TimelineUpdate.to_json())

# convert the object into a dict
timeline_update_dict = timeline_update_instance.to_dict()
# create an instance of TimelineUpdate from a dict
timeline_update_from_dict = TimelineUpdate.from_dict(timeline_update_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


