# Curation


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The review id | 
**group_id** | **int** | The group in which the article is present. | 
**account_id** | **int** | The ID of the account of the owner of the article of this review. | 
**assigned_to** | **int** | The ID of the account to which this review is assigned. | 
**article_id** | **int** | The ID of the article of this review. | 
**version** | **int** | The Version number of the article in review. | 
**comments_count** | **int** | The number of comments in the review. | 
**status** | **str** | The status of the review. | 
**created_date** | **str** | The creation date of the review. | 
**modified_date** | **str** | The date the review has been modified. | 
**request_number** | **int** | The request number of the review. | 
**resolution_comment** | **str** | The resolution comment of the review. | 

## Example

```python
from openapi_client.models.curation import Curation

# TODO update the JSON string below
json = "{}"
# create an instance of Curation from a JSON string
curation_instance = Curation.from_json(json)
# print the JSON string representation of the object
print(Curation.to_json())

# convert the object into a dict
curation_dict = curation_instance.to_dict()
# create an instance of Curation from a dict
curation_from_dict = Curation.from_dict(curation_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


