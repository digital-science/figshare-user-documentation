# CollectionCreate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **str** | Grant number or funding authority | [optional] [default to '']
**funding_list** | [**List[FundingCreate]**](FundingCreate.md) | Funding creation / update items | [optional] 
**title** | **str** | Title of collection | 
**description** | **str** | The collection description. In a publisher case, usually this is the remote collection description | [optional] [default to '']
**articles** | **List[int]** | List of articles to be associated with the collection | [optional] 
**authors** | **List[object]** | List of authors to be associated with the collection. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint. | [optional] 
**categories** | **List[int]** | List of category ids to be associated with the collection(e.g [1, 23, 33, 66]) | [optional] 
**categories_by_source_id** | **List[str]** | List of category source ids to be associated with the collection, supersedes the categories property | [optional] 
**tags** | **List[str]** | List of tags to be associated with the collection. Keywords can be used instead | [optional] 
**keywords** | **List[str]** | List of tags to be associated with the collection. Tags can be used instead | [optional] 
**references** | **List[str]** | List of links to be associated with the collection (e.g [\&quot;http://link1\&quot;, \&quot;http://link2\&quot;, \&quot;http://link3\&quot;]) | [optional] 
**related_materials** | [**List[RelatedMaterial]**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. | [optional] 
**custom_fields** | **object** | List of key, values pairs to be associated with the collection | [optional] 
**custom_fields_list** | [**List[CustomArticleFieldAdd]**](CustomArticleFieldAdd.md) | List of custom fields values, supersedes custom_fields parameter | [optional] 
**doi** | **str** | Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional] [default to '']
**handle** | **str** | Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional] [default to '']
**resource_id** | **str** | Not applicable to regular users. In a publisher case, this is the publisher article id | [optional] 
**resource_doi** | **str** | Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [optional] [default to '']
**resource_link** | **str** | Not applicable to regular users. In a publisher case, this is the publisher article link | [optional] 
**resource_title** | **str** | Not applicable to regular users. In a publisher case, this is the publisher article title. | [optional] [default to '']
**resource_version** | **int** | Not applicable to regular users. In a publisher case, this is the publisher article version | [optional] 
**group_id** | **int** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] 
**timeline** | [**TimelineUpdate**](TimelineUpdate.md) |  | [optional] 

## Example

```python
from openapi_client.models.collection_create import CollectionCreate

# TODO update the JSON string below
json = "{}"
# create an instance of CollectionCreate from a JSON string
collection_create_instance = CollectionCreate.from_json(json)
# print the JSON string representation of the object
print(CollectionCreate.to_json())

# convert the object into a dict
collection_create_dict = collection_create_instance.to_dict()
# create an instance of CollectionCreate from a dict
collection_create_from_dict = CollectionCreate.from_dict(collection_create_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


