# ProjectCompletePrivate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **str** | Project funding | 
**funding_list** | [**List[FundingInformation]**](FundingInformation.md) | Full Project funding information | 
**description** | **str** | Project description | 
**collaborators** | [**List[Collaborator]**](Collaborator.md) | List of project collaborators | 
**quota** | **int** | Project quota | 
**used_quota** | **int** | Project used quota | 
**created_date** | **str** | Date when project was created | 
**modified_date** | **str** | Date when project was last modified | 
**used_quota_private** | **int** | Project private quota used | 
**used_quota_public** | **int** | Project public quota used | 
**group_id** | **int** | Group of project if any | 
**account_id** | **int** | ID of the account owning the project | 
**custom_fields** | [**List[ShortCustomField]**](ShortCustomField.md) | Collection custom fields | 
**role** | **str** | Role inside this project | 
**storage** | **str** | Project storage type | 
**url** | **str** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **str** | Project title | 

## Example

```python
from openapi_client.models.project_complete_private import ProjectCompletePrivate

# TODO update the JSON string below
json = "{}"
# create an instance of ProjectCompletePrivate from a JSON string
project_complete_private_instance = ProjectCompletePrivate.from_json(json)
# print the JSON string representation of the object
print(ProjectCompletePrivate.to_json())

# convert the object into a dict
project_complete_private_dict = project_complete_private_instance.to_dict()
# create an instance of ProjectCompletePrivate from a dict
project_complete_private_from_dict = ProjectCompletePrivate.from_dict(project_complete_private_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


