# ArticleUnpublishData


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason** | **str** | Reason of article unpublishing | 

## Example

```python
from openapi_client.models.article_unpublish_data import ArticleUnpublishData

# TODO update the JSON string below
json = "{}"
# create an instance of ArticleUnpublishData from a JSON string
article_unpublish_data_instance = ArticleUnpublishData.from_json(json)
# print the JSON string representation of the object
print(ArticleUnpublishData.to_json())

# convert the object into a dict
article_unpublish_data_dict = article_unpublish_data_instance.to_dict()
# create an instance of ArticleUnpublishData from a dict
article_unpublish_data_from_dict = ArticleUnpublishData.from_dict(article_unpublish_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


