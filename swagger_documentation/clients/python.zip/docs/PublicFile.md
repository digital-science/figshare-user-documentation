# PublicFile


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | File id | 
**name** | **str** | File name | 
**size** | **int** | File size | 
**is_link_only** | **bool** | True if file is hosted somewhere else | 
**download_url** | **str** | Url for file download | 
**supplied_md5** | **str** | File supplied md5 | 
**computed_md5** | **str** | File computed md5 | 
**mimetype** | **str** | MIME Type of the file, it defaults to an empty string | [optional] 

## Example

```python
from openapi_client.models.public_file import PublicFile

# TODO update the JSON string below
json = "{}"
# create an instance of PublicFile from a JSON string
public_file_instance = PublicFile.from_json(json)
# print the JSON string representation of the object
print(PublicFile.to_json())

# convert the object into a dict
public_file_dict = public_file_instance.to_dict()
# create an instance of PublicFile from a dict
public_file_from_dict = PublicFile.from_dict(public_file_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


