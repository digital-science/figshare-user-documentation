# FileCreator


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | **str** | Url for an existing file that will not be uploaded to Figshare | [optional] 
**md5** | **str** | MD5 sum pre-computed on client side. | [optional] 
**name** | **str** | File name including the extension; can be omitted only for linked files. | [optional] 
**size** | **int** | File size in bytes; can be omitted only for linked files. | [optional] 
**folder_path** | **str** | Unix-style directory path of the file; only available if the file was uploaded within a folder structure | [optional] 

## Example

```python
from openapi_client.models.file_creator import FileCreator

# TODO update the JSON string below
json = "{}"
# create an instance of FileCreator from a JSON string
file_creator_instance = FileCreator.from_json(json)
# print the JSON string representation of the object
print(FileCreator.to_json())

# convert the object into a dict
file_creator_dict = file_creator_instance.to_dict()
# create an instance of FileCreator from a dict
file_creator_from_dict = FileCreator.from_dict(file_creator_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


