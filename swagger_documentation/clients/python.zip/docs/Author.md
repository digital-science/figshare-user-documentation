# Author

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Author id | 
**full_name** | **str** | Author full name | 
**first_name** | **str** | Author first name | 
**last_name** | **str** | Author last name | 
**is_active** | **bool** | True if author has published items | 
**url_name** | **str** | Author url name | 
**orcid_id** | **str** | Author Orcid | 
**group_id** | **int** | Author group id | 
**is_public** | **bool** | True if author is public | 
**institution_id** | **int** | Institution id | 
**job_title** | **str** | Job title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


