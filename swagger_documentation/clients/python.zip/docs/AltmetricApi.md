# openapi_client.AltmetricApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**altmetric_institutions_list**](AltmetricApi.md#altmetric_institutions_list) | **GET** /altmetric/institutions | List Altmetric Institutions


# **altmetric_institutions_list**
> List[AltmetricInstitution] altmetric_institutions_list(offset=offset)

List Altmetric Institutions

Returns a list of institutions available for Altmetric reporting

### Example


```python
import openapi_client
from openapi_client.models.altmetric_institution import AltmetricInstitution
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.AltmetricApi(api_client)
    offset = 0 # int | Where to start the listing. The offset of the first item. (optional) (default to 0)

    try:
        # List Altmetric Institutions
        api_response = api_instance.altmetric_institutions_list(offset=offset)
        print("The response of AltmetricApi->altmetric_institutions_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AltmetricApi->altmetric_institutions_list: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **offset** | **int**| Where to start the listing. The offset of the first item. | [optional] [default to 0]

### Return type

[**List[AltmetricInstitution]**](AltmetricInstitution.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of Altmetric institutions |  -  |
**400** | Bad Request |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

