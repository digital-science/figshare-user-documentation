# User


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | User id | 
**first_name** | **str** | First Name | 
**last_name** | **str** | Last Name | 
**name** | **str** | Full Name | 
**is_active** | **bool** | Account activity status | 
**url_name** | **str** | Name that appears in website url | 
**is_public** | **bool** | Account public status | 
**job_title** | **str** | User Job title | 
**orcid_id** | **str** | Orcid associated to this User | 

## Example

```python
from openapi_client.models.user import User

# TODO update the JSON string below
json = "{}"
# create an instance of User from a JSON string
user_instance = User.from_json(json)
# print the JSON string representation of the object
print(User.to_json())

# convert the object into a dict
user_dict = user_instance.to_dict()
# create an instance of User from a dict
user_from_dict = User.from_dict(user_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


