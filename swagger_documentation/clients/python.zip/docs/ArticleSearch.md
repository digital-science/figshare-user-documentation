# ArticleSearch


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource_doi** | **str** | Only return articles with this resource_doi | [optional] 
**item_type** | **int** | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model | [optional] 
**doi** | **str** | Only return articles with this doi | [optional] 
**handle** | **str** | Only return articles with this handle | [optional] 
**project_id** | **int** | Only return articles in this project | [optional] 
**order** | **str** | The field by which to order | [optional] [default to 'created_date']
**search_for** | **str** | Search term | [optional] 
**page** | **int** | Page number. Used for pagination with page_size | [optional] 
**page_size** | **int** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **int** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **int** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
**order_direction** | **str** | Direction of ordering | [optional] [default to 'desc']
**institution** | **int** | only return collections from this institution | [optional] 
**published_since** | **str** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
**modified_since** | **str** | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
**group** | **int** | only return collections from this group | [optional] 

## Example

```python
from openapi_client.models.article_search import ArticleSearch

# TODO update the JSON string below
json = "{}"
# create an instance of ArticleSearch from a JSON string
article_search_instance = ArticleSearch.from_json(json)
# print the JSON string representation of the object
print(ArticleSearch.to_json())

# convert the object into a dict
article_search_dict = article_search_instance.to_dict()
# create an instance of ArticleSearch from a dict
article_search_from_dict = ArticleSearch.from_dict(article_search_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


