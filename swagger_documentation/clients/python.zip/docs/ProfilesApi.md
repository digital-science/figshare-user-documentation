# openapi_client.ProfilesApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**update_user_profile**](ProfilesApi.md#update_user_profile) | **PUT** /account/profile | Update public profile
[**update_user_profile_picture**](ProfilesApi.md#update_user_profile_picture) | **POST** /account/profile/{user_id}/picture | Update public profile picture


# **update_user_profile**
> object update_user_profile(user_profile_data, user_id=user_id, institution_user_id=institution_user_id)

Update public profile

Updates the fields of the user's public profile.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.profile_update_data import ProfileUpdateData
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ProfilesApi(api_client)
    user_profile_data = openapi_client.ProfileUpdateData() # ProfileUpdateData | 
    user_id = 56 # int | User ID (optional)
    institution_user_id = 'institution_user_id_example' # str | Institutional user ID (optional)

    try:
        # Update public profile
        api_response = api_instance.update_user_profile(user_profile_data, user_id=user_id, institution_user_id=institution_user_id)
        print("The response of ProfilesApi->update_user_profile:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ProfilesApi->update_user_profile: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_profile_data** | [**ProfileUpdateData**](ProfileUpdateData.md)|  | 
 **user_id** | **int**| User ID | [optional] 
 **institution_user_id** | **str**| Institutional user ID | [optional] 

### Return type

**object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_user_profile_picture**
> object update_user_profile_picture(user_id, profile_picture)

Update public profile picture

Updates the profile picture of the user's public profile.

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.ProfilesApi(api_client)
    user_id = 56 # int | User ID
    profile_picture = None # bytearray | User profile picture

    try:
        # Update public profile picture
        api_response = api_instance.update_user_profile_picture(user_id, profile_picture)
        print("The response of ProfilesApi->update_user_profile_picture:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ProfilesApi->update_user_profile_picture: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **int**| User ID | 
 **profile_picture** | **bytearray**| User profile picture | 

### Return type

**object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

