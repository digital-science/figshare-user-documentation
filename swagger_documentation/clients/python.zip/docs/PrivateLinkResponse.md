# PrivateLinkResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **str** | Url for private link | 
**html_location** | **str** | HTML url for private link | 
**token** | **str** | Token for private link | 

## Example

```python
from openapi_client.models.private_link_response import PrivateLinkResponse

# TODO update the JSON string below
json = "{}"
# create an instance of PrivateLinkResponse from a JSON string
private_link_response_instance = PrivateLinkResponse.from_json(json)
# print the JSON string representation of the object
print(PrivateLinkResponse.to_json())

# convert the object into a dict
private_link_response_dict = private_link_response_instance.to_dict()
# create an instance of PrivateLinkResponse from a dict
private_link_response_from_dict = PrivateLinkResponse.from_dict(private_link_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


