# ConfidentialityCreator


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason** | **str** | Reason for confidentiality | 

## Example

```python
from openapi_client.models.confidentiality_creator import ConfidentialityCreator

# TODO update the JSON string below
json = "{}"
# create an instance of ConfidentialityCreator from a JSON string
confidentiality_creator_instance = ConfidentialityCreator.from_json(json)
# print the JSON string representation of the object
print(ConfidentialityCreator.to_json())

# convert the object into a dict
confidentiality_creator_dict = confidentiality_creator_instance.to_dict()
# create an instance of ConfidentialityCreator from a dict
confidentiality_creator_from_dict = ConfidentialityCreator.from_dict(confidentiality_creator_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


