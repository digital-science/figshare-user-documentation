# ProjectComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **str** | Project title | 
**created_date** | **str** | Date when project was created | 
**modified_date** | **str** | Date when project was last modified | 
**funding** | **str** | Project funding | 
**funding_list** | [**list[FundingInformation]**](FundingInformation.md) | Full Project funding information | 
**description** | **str** | Project description | 
**collaborators** | [**list[Collaborator]**](Collaborator.md) | List of project collaborators | 
**custom_fields** | [**list[CustomArticleField]**](CustomArticleField.md) | Project custom fields | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


