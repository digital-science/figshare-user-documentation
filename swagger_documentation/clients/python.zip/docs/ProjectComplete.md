# ProjectComplete


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **str** | Project funding | 
**funding_list** | [**List[FundingInformation]**](FundingInformation.md) | Full Project funding information | 
**description** | **str** | Project description | 
**collaborators** | [**List[Collaborator]**](Collaborator.md) | List of project collaborators | 
**custom_fields** | [**List[CustomArticleField]**](CustomArticleField.md) | Project custom fields | 
**modified_date** | **str** | Date when project was last modified | 
**created_date** | **str** | Date when project was created | 
**url** | **str** | Api endpoint | 
**id** | **int** | Project id | 
**title** | **str** | Project title | 

## Example

```python
from openapi_client.models.project_complete import ProjectComplete

# TODO update the JSON string below
json = "{}"
# create an instance of ProjectComplete from a JSON string
project_complete_instance = ProjectComplete.from_json(json)
# print the JSON string representation of the object
print(ProjectComplete.to_json())

# convert the object into a dict
project_complete_dict = project_complete_instance.to_dict()
# create an instance of ProjectComplete from a dict
project_complete_from_dict = ProjectComplete.from_dict(project_complete_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


