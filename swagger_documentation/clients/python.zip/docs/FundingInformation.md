# FundingInformation


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Funding id | 
**title** | **str** | The funding name | 
**grant_code** | **str** | The grant code | 
**funder_name** | **str** | Funder&#39;s name | 
**is_user_defined** | **int** | Return 1 whether the grant has been introduced manually, 0 otherwise | 
**url** | **str** | The grant url | 

## Example

```python
from openapi_client.models.funding_information import FundingInformation

# TODO update the JSON string below
json = "{}"
# create an instance of FundingInformation from a JSON string
funding_information_instance = FundingInformation.from_json(json)
# print the JSON string representation of the object
print(FundingInformation.to_json())

# convert the object into a dict
funding_information_dict = funding_information_instance.to_dict()
# create an instance of FundingInformation from a dict
funding_information_from_dict = FundingInformation.from_dict(funding_information_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


