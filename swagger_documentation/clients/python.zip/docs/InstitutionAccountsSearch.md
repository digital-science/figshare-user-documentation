# InstitutionAccountsSearch


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_for** | **str** | Search term | [optional] 
**is_active** | **int** | Filter by active status | [optional] 
**page** | **int** | Page number. Used for pagination with page_size | [optional] 
**page_size** | **int** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **int** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **int** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
**institution_user_id** | **str** | filter by institution_user_id | [optional] 
**email** | **str** | filter by email | [optional] 

## Example

```python
from openapi_client.models.institution_accounts_search import InstitutionAccountsSearch

# TODO update the JSON string below
json = "{}"
# create an instance of InstitutionAccountsSearch from a JSON string
institution_accounts_search_instance = InstitutionAccountsSearch.from_json(json)
# print the JSON string representation of the object
print(InstitutionAccountsSearch.to_json())

# convert the object into a dict
institution_accounts_search_dict = institution_accounts_search_instance.to_dict()
# create an instance of InstitutionAccountsSearch from a dict
institution_accounts_search_from_dict = InstitutionAccountsSearch.from_dict(institution_accounts_search_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


