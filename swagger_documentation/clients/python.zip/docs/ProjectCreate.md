# ProjectCreate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** | The title for this project - mandatory. 3 - 1000 characters. | 
**description** | **str** | Project description | [optional] 
**funding** | **str** | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional] 
**funding_list** | [**List[FundingCreate]**](FundingCreate.md) | Funding creation / update items | [optional] 
**group_id** | **int** | Only if project type is group. | [optional] 
**custom_fields** | **object** | List of key, values pairs to be associated with the project | [optional] 
**custom_fields_list** | [**List[CustomArticleFieldAdd]**](CustomArticleFieldAdd.md) | List of custom fields values, supersedes custom_fields parameter | [optional] 

## Example

```python
from openapi_client.models.project_create import ProjectCreate

# TODO update the JSON string below
json = "{}"
# create an instance of ProjectCreate from a JSON string
project_create_instance = ProjectCreate.from_json(json)
# print the JSON string representation of the object
print(ProjectCreate.to_json())

# convert the object into a dict
project_create_dict = project_create_instance.to_dict()
# create an instance of ProjectCreate from a dict
project_create_from_dict = ProjectCreate.from_dict(project_create_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


