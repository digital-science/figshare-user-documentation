# ShortCustomField


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Custom field id | 
**name** | **str** | Custom field name | 
**field_type** | **str** | Custom field type | 
**settings** | **object** | Settings for the custom field | [optional] 
**order** | **int** | Order of the field in the group | [optional] 
**is_mandatory** | **bool** | Whether the field is mandatory or not | [optional] 

## Example

```python
from openapi_client.models.short_custom_field import ShortCustomField

# TODO update the JSON string below
json = "{}"
# create an instance of ShortCustomField from a JSON string
short_custom_field_instance = ShortCustomField.from_json(json)
# print the JSON string representation of the object
print(ShortCustomField.to_json())

# convert the object into a dict
short_custom_field_dict = short_custom_field_instance.to_dict()
# create an instance of ShortCustomField from a dict
short_custom_field_from_dict = ShortCustomField.from_dict(short_custom_field_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


