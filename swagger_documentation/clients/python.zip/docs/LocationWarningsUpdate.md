# LocationWarningsUpdate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | **str** | Url for entity | 
**warnings** | **List[str]** | Issues encountered during the operation | 

## Example

```python
from openapi_client.models.location_warnings_update import LocationWarningsUpdate

# TODO update the JSON string below
json = "{}"
# create an instance of LocationWarningsUpdate from a JSON string
location_warnings_update_instance = LocationWarningsUpdate.from_json(json)
# print the JSON string representation of the object
print(LocationWarningsUpdate.to_json())

# convert the object into a dict
location_warnings_update_dict = location_warnings_update_instance.to_dict()
# create an instance of LocationWarningsUpdate from a dict
location_warnings_update_from_dict = LocationWarningsUpdate.from_dict(location_warnings_update_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


