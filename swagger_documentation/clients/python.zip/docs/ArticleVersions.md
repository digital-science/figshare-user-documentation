# ArticleVersions


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **int** | Version number | 
**url** | **str** | Api endpoint for the item version | 

## Example

```python
from openapi_client.models.article_versions import ArticleVersions

# TODO update the JSON string below
json = "{}"
# create an instance of ArticleVersions from a JSON string
article_versions_instance = ArticleVersions.from_json(json)
# print the JSON string representation of the object
print(ArticleVersions.to_json())

# convert the object into a dict
article_versions_dict = article_versions_instance.to_dict()
# create an instance of ArticleVersions from a dict
article_versions_from_dict = ArticleVersions.from_dict(article_versions_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


