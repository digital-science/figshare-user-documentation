# CurationComment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The ID of the comment. | 
**account_id** | **int** | The ID of the account which generated this comment. | 
**type** | **str** | The ID of the account which generated this comment. | 
**text** | **str** | The value/content of the comment. | 
**created_date** | **str** | The creation date of the comment. | 
**modified_date** | **str** | The date the comment has been modified. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


