# CategoryList


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_selectable** | **bool** | The selectable status | 
**has_children** | **bool** | True if category has children | 
**parent_id** | **int** | Parent category | 
**id** | **int** | Category id | 
**title** | **str** | Category title | 
**path** | **str** | Path to all ancestor ids | 
**source_id** | **str** | ID in original standard taxonomy | 
**taxonomy_id** | **int** | Internal id of taxonomy the category is part of | 

## Example

```python
from openapi_client.models.category_list import CategoryList

# TODO update the JSON string below
json = "{}"
# create an instance of CategoryList from a JSON string
category_list_instance = CategoryList.from_json(json)
# print the JSON string representation of the object
print(CategoryList.to_json())

# convert the object into a dict
category_list_dict = category_list_instance.to_dict()
# create an instance of CategoryList from a dict
category_list_from_dict = CategoryList.from_dict(category_list_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


