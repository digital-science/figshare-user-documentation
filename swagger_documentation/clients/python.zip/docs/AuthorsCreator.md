# AuthorsCreator


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authors** | **List[object]** | List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint. | 

## Example

```python
from openapi_client.models.authors_creator import AuthorsCreator

# TODO update the JSON string below
json = "{}"
# create an instance of AuthorsCreator from a JSON string
authors_creator_instance = AuthorsCreator.from_json(json)
# print the JSON string representation of the object
print(AuthorsCreator.to_json())

# convert the object into a dict
authors_creator_dict = authors_creator_instance.to_dict()
# create an instance of AuthorsCreator from a dict
authors_creator_from_dict = AuthorsCreator.from_dict(authors_creator_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


