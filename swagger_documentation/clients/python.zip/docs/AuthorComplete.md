# AuthorComplete


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**institution_id** | **int** | Institution id | 
**group_id** | **int** | Group id | 
**first_name** | **str** | First Name | 
**last_name** | **str** | Last Name | 
**is_public** | **int** | if 1 then the author has published items | 
**job_title** | **str** | Job title | 
**id** | **int** | Author id | 
**full_name** | **str** | Author full name | 
**is_active** | **bool** | True if author has published items | 
**url_name** | **str** | Author url name | 
**orcid_id** | **str** | Author Orcid | 

## Example

```python
from openapi_client.models.author_complete import AuthorComplete

# TODO update the JSON string below
json = "{}"
# create an instance of AuthorComplete from a JSON string
author_complete_instance = AuthorComplete.from_json(json)
# print the JSON string representation of the object
print(AuthorComplete.to_json())

# convert the object into a dict
author_complete_dict = author_complete_instance.to_dict()
# create an instance of AuthorComplete from a dict
author_complete_from_dict = AuthorComplete.from_dict(author_complete_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


