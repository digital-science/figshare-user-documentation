# CurationCommentCreate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **str** | The contents/value of the comment | 

## Example

```python
from openapi_client.models.curation_comment_create import CurationCommentCreate

# TODO update the JSON string below
json = "{}"
# create an instance of CurationCommentCreate from a JSON string
curation_comment_create_instance = CurationCommentCreate.from_json(json)
# print the JSON string representation of the object
print(CurationCommentCreate.to_json())

# convert the object into a dict
curation_comment_create_dict = curation_comment_create_instance.to_dict()
# create an instance of CurationCommentCreate from a dict
curation_comment_create_from_dict = CurationCommentCreate.from_dict(curation_comment_create_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


