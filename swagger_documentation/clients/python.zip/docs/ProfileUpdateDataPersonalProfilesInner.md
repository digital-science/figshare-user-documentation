# ProfileUpdateDataPersonalProfilesInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label** | **str** | Label for the personal profile link | [optional] 
**url** | **str** | URL for the personal profile link | [optional] 

## Example

```python
from openapi_client.models.profile_update_data_personal_profiles_inner import ProfileUpdateDataPersonalProfilesInner

# TODO update the JSON string below
json = "{}"
# create an instance of ProfileUpdateDataPersonalProfilesInner from a JSON string
profile_update_data_personal_profiles_inner_instance = ProfileUpdateDataPersonalProfilesInner.from_json(json)
# print the JSON string representation of the object
print(ProfileUpdateDataPersonalProfilesInner.to_json())

# convert the object into a dict
profile_update_data_personal_profiles_inner_dict = profile_update_data_personal_profiles_inner_instance.to_dict()
# create an instance of ProfileUpdateDataPersonalProfilesInner from a dict
profile_update_data_personal_profiles_inner_from_dict = ProfileUpdateDataPersonalProfilesInner.from_dict(profile_update_data_personal_profiles_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


