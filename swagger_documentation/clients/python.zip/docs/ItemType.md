# ItemType


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The ID of the item type. | 
**name** | **str** | The name of the item type | 
**string_id** | **str** | The string identifier of the item type. | 
**icon** | **str** | The string identifying the icon of the item type. | 
**public_description** | **str** | The description of the item type. | 
**is_selectable** | **bool** | The selectable status | 
**url_name** | **str** | The URL name of the item type. | 

## Example

```python
from openapi_client.models.item_type import ItemType

# TODO update the JSON string below
json = "{}"
# create an instance of ItemType from a JSON string
item_type_instance = ItemType.from_json(json)
# print the JSON string representation of the object
print(ItemType.to_json())

# convert the object into a dict
item_type_dict = item_type_instance.to_dict()
# create an instance of ItemType from a dict
item_type_from_dict = ItemType.from_dict(item_type_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


