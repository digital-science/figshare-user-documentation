# openapi_client.OauthApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_token**](OauthApi.md#create_token) | **POST** /token | Create OAuth token
[**get_token_info**](OauthApi.md#get_token_info) | **GET** /token | Get OAuth token information


# **create_token**
> OAuthToken create_token(body=body)

Create OAuth token

Creates OAuth token using various grant types

### Example


```python
import openapi_client
from openapi_client.models.create_o_auth_token import CreateOAuthToken
from openapi_client.models.o_auth_token import OAuthToken
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.OauthApi(api_client)
    body = openapi_client.CreateOAuthToken() # CreateOAuthToken | Create OAuth Token Parameters (optional)

    try:
        # Create OAuth token
        api_response = api_instance.create_token(body=body)
        print("The response of OauthApi->create_token:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling OauthApi->create_token: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateOAuthToken**](CreateOAuthToken.md)| Create OAuth Token Parameters | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Token created successfully &lt;a href&#x3D;&#39;http://tools.ietf.org/html/rfc6749#section-5.1&#39; target&#x3D;&#39;_blank&#39;&gt;RFC 6749 Section 5.1&lt;/a&gt;. |  -  |
**400** | Bad Request &lt;a href&#x3D;&#39;http://tools.ietf.org/html/rfc6749#section-5.2&#39; target&#x3D;&#39;_blank&#39;&gt;RFC 6749 Section 5.2&lt;/a&gt;. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_token_info**
> OAuthToken get_token_info(access_token=access_token)

Get OAuth token information

Returns information about the current OAuth token

### Example


```python
import openapi_client
from openapi_client.models.o_auth_token import OAuthToken
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.OauthApi(api_client)
    access_token = 'access_token_example' # str | OAuth access token (optional)

    try:
        # Get OAuth token information
        api_response = api_instance.get_token_info(access_token=access_token)
        print("The response of OauthApi->get_token_info:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling OauthApi->get_token_info: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **access_token** | **str**| OAuth access token | [optional] 

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Token information |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

