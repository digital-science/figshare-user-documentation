# CreateOAuthToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**client_id** | **str** |  | 
**client_secret** | **str** |  | 
**grant_type** | **str** |  | 
**code** | **str** | Required if grant_type is &#39;authorization_code&#39; | [optional] 
**refresh_token** | **str** | Required if grant_type is &#39;refresh_token&#39; | [optional] 
**username** | **str** | Required if grant_type is &#39;password&#39; | [optional] 
**password** | **str** | Required if grant_type is &#39;password&#39; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


