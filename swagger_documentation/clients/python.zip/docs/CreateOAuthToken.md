# CreateOAuthToken


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**client_id** | **str** |  | 
**client_secret** | **str** |  | 
**grant_type** | **str** |  | 
**code** | **str** | Required if grant_type is &#39;authorization_code&#39; | [optional] 
**refresh_token** | **str** | Required if grant_type is &#39;refresh_token&#39; | [optional] 
**username** | **str** | Required if grant_type is &#39;password&#39; | [optional] 
**password** | **str** | Required if grant_type is &#39;password&#39; | [optional] 

## Example

```python
from openapi_client.models.create_o_auth_token import CreateOAuthToken

# TODO update the JSON string below
json = "{}"
# create an instance of CreateOAuthToken from a JSON string
create_o_auth_token_instance = CreateOAuthToken.from_json(json)
# print the JSON string representation of the object
print(CreateOAuthToken.to_json())

# convert the object into a dict
create_o_auth_token_dict = create_o_auth_token_instance.to_dict()
# create an instance of CreateOAuthToken from a dict
create_o_auth_token_from_dict = CreateOAuthToken.from_dict(create_o_auth_token_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


