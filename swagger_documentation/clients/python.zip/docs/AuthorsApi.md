# openapi_client.AuthorsApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**private_author_details**](AuthorsApi.md#private_author_details) | **GET** /account/authors/{author_id} | Author details
[**private_authors_search**](AuthorsApi.md#private_authors_search) | **POST** /account/authors/search | Search Authors


# **private_author_details**
> AuthorComplete private_author_details(author_id)

Author details

View author details

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.author_complete import AuthorComplete
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.AuthorsApi(api_client)
    author_id = 56 # int | Author unique identifier

    try:
        # Author details
        api_response = api_instance.private_author_details(author_id)
        print("The response of AuthorsApi->private_author_details:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthorsApi->private_author_details: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **author_id** | **int**| Author unique identifier | 

### Return type

[**AuthorComplete**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. Article representation |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **private_authors_search**
> List[AuthorComplete] private_authors_search(search=search)

Search Authors

Search for authors

### Example

* OAuth Authentication (OAuth2):

```python
import openapi_client
from openapi_client.models.author_complete import AuthorComplete
from openapi_client.models.private_authors_search import PrivateAuthorsSearch
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.figsh.com/v2
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "https://api.figsh.com/v2"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.AuthorsApi(api_client)
    search = openapi_client.PrivateAuthorsSearch() # PrivateAuthorsSearch | Search Parameters (optional)

    try:
        # Search Authors
        api_response = api_instance.private_authors_search(search=search)
        print("The response of AuthorsApi->private_authors_search:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AuthorsApi->private_authors_search: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | [**PrivateAuthorsSearch**](PrivateAuthorsSearch.md)| Search Parameters | [optional] 

### Return type

[**List[AuthorComplete]**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK. An array of authors |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

