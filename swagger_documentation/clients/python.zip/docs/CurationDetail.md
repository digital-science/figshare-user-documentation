# CurationDetail


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**item** | [**ArticleComplete**](ArticleComplete.md) |  | 
**id** | **int** | The review id | 
**group_id** | **int** | The group in which the article is present. | 
**account_id** | **int** | The ID of the account of the owner of the article of this review. | 
**assigned_to** | **int** | The ID of the account to which this review is assigned. | 
**article_id** | **int** | The ID of the article of this review. | 
**version** | **int** | The Version number of the article in review. | 
**comments_count** | **int** | The number of comments in the review. | 
**status** | **str** | The status of the review. | 
**created_date** | **str** | The creation date of the review. | 
**modified_date** | **str** | The date the review has been modified. | 
**request_number** | **int** | The request number of the review. | 
**resolution_comment** | **str** | The resolution comment of the review. | 

## Example

```python
from openapi_client.models.curation_detail import CurationDetail

# TODO update the JSON string below
json = "{}"
# create an instance of CurationDetail from a JSON string
curation_detail_instance = CurationDetail.from_json(json)
# print the JSON string representation of the object
print(CurationDetail.to_json())

# convert the object into a dict
curation_detail_dict = curation_detail_instance.to_dict()
# create an instance of CurationDetail from a dict
curation_detail_from_dict = CurationDetail.from_dict(curation_detail_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


