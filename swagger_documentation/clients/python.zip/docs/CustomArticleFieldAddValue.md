# CustomArticleFieldAddValue

Custom metadata value (can be either a string, an array of strings, or empty)

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from openapi_client.models.custom_article_field_add_value import CustomArticleFieldAddValue

# TODO update the JSON string below
json = "{}"
# create an instance of CustomArticleFieldAddValue from a JSON string
custom_article_field_add_value_instance = CustomArticleFieldAddValue.from_json(json)
# print the JSON string representation of the object
print(CustomArticleFieldAddValue.to_json())

# convert the object into a dict
custom_article_field_add_value_dict = custom_article_field_add_value_instance.to_dict()
# create an instance of CustomArticleFieldAddValue from a dict
custom_article_field_add_value_from_dict = CustomArticleFieldAddValue.from_dict(custom_article_field_add_value_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


