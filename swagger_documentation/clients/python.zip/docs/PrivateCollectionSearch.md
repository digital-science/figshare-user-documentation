# PrivateCollectionSearch


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource_id** | **str** | only return collections with this resource_id | [optional] 
**resource_doi** | **str** | Only return collections with this resource_doi | [optional] 
**doi** | **str** | Only return collections with this doi | [optional] 
**handle** | **str** | Only return collections with this handle | [optional] 
**order** | **str** | The field by which to order. | [optional] [default to 'created_date']
**search_for** | **str** | Search term | [optional] 
**page** | **int** | Page number. Used for pagination with page_size | [optional] 
**page_size** | **int** | The number of results included on a page. Used for pagination with page | [optional] [default to 10]
**limit** | **int** | Number of results included on a page. Used for pagination with query | [optional] 
**offset** | **int** | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional] 
**order_direction** | **str** | Direction of ordering | [optional] [default to 'desc']
**institution** | **int** | only return collections from this institution | [optional] 
**published_since** | **str** | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
**modified_since** | **str** | Filter by article modified date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional] 
**group** | **int** | only return collections from this group | [optional] 

## Example

```python
from openapi_client.models.private_collection_search import PrivateCollectionSearch

# TODO update the JSON string below
json = "{}"
# create an instance of PrivateCollectionSearch from a JSON string
private_collection_search_instance = PrivateCollectionSearch.from_json(json)
# print the JSON string representation of the object
print(PrivateCollectionSearch.to_json())

# convert the object into a dict
private_collection_search_dict = private_collection_search_instance.to_dict()
# create an instance of PrivateCollectionSearch from a dict
private_collection_search_from_dict = PrivateCollectionSearch.from_dict(private_collection_search_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


