# Resource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | ID of resource item | [optional] [default to '']
**title** | **str** | Title of resource item | [optional] [default to '']
**doi** | **str** | DOI of resource item | [optional] [default to '']
**link** | **str** | Link of resource item | [optional] [default to '']
**status** | **str** | Status of resource item | [optional] [default to '']
**version** | **int** | Version of resource item | [optional] [default to 0]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


