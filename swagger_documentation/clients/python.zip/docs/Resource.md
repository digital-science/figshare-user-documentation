# Resource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | ID of resource item | [optional] [default to '']
**title** | **str** | Title of resource item | [optional] [default to '']
**doi** | **str** | DOI of resource item | [optional] [default to '']
**link** | **str** | Link of resource item | [optional] [default to '']
**status** | **str** | Status of resource item | [optional] [default to '']
**version** | **int** | Version of resource item | [optional] [default to 0]

## Example

```python
from openapi_client.models.resource import Resource

# TODO update the JSON string below
json = "{}"
# create an instance of Resource from a JSON string
resource_instance = Resource.from_json(json)
# print the JSON string representation of the object
print(Resource.to_json())

# convert the object into a dict
resource_dict = resource_instance.to_dict()
# create an instance of Resource from a dict
resource_from_dict = Resource.from_dict(resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


