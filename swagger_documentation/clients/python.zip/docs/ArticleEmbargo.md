# ArticleEmbargo


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_embargoed** | **bool** | True if embargoed | 
**embargo_title** | **str** | Title for embargo | 
**embargo_reason** | **str** | Reason for embargo | 
**embargo_options** | **List[object]** | List of embargo permissions that are associated with the article. If the type is logged_in and the group_ids list is empty, then the whole institution can see the article; if there are multiple group_ids, then only users that are under those groups can see the article. | 

## Example

```python
from openapi_client.models.article_embargo import ArticleEmbargo

# TODO update the JSON string below
json = "{}"
# create an instance of ArticleEmbargo from a JSON string
article_embargo_instance = ArticleEmbargo.from_json(json)
# print the JSON string representation of the object
print(ArticleEmbargo.to_json())

# convert the object into a dict
article_embargo_dict = article_embargo_instance.to_dict()
# create an instance of ArticleEmbargo from a dict
article_embargo_from_dict = ArticleEmbargo.from_dict(article_embargo_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


