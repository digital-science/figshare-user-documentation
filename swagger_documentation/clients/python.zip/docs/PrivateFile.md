# PrivateFile


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**viewer_type** | **str** | File viewer type | 
**preview_state** | **str** | File preview state | 
**upload_url** | **str** | Upload url for file | 
**upload_token** | **str** | Token for file upload | 
**is_attached_to_public_version** | **bool** | True if the file is attached to a public item version | 
**id** | **int** | File id | 
**name** | **str** | File name | 
**size** | **int** | File size | 
**is_link_only** | **bool** | True if file is hosted somewhere else | 
**download_url** | **str** | Url for file download | 
**supplied_md5** | **str** | File supplied md5 | 
**computed_md5** | **str** | File computed md5 | 
**mimetype** | **str** | MIME Type of the file, it defaults to an empty string | [optional] 

## Example

```python
from openapi_client.models.private_file import PrivateFile

# TODO update the JSON string below
json = "{}"
# create an instance of PrivateFile from a JSON string
private_file_instance = PrivateFile.from_json(json)
# print the JSON string representation of the object
print(PrivateFile.to_json())

# convert the object into a dict
private_file_dict = private_file_instance.to_dict()
# create an instance of PrivateFile from a dict
private_file_from_dict = PrivateFile.from_dict(private_file_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


