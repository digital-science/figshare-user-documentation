# AccountCreate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **str** | Email of account | 
**first_name** | **str** | First Name | [optional] [default to '']
**last_name** | **str** | Last Name | [default to '']
**group_id** | **int** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional] 
**institution_user_id** | **str** | Institution user id | [optional] [default to '']
**symplectic_user_id** | **str** | Symplectic user id | [optional] [default to '']
**quota** | **int** | Account quota | [optional] 
**is_active** | **bool** | Is account active | [optional] 

## Example

```python
from openapi_client.models.account_create import AccountCreate

# TODO update the JSON string below
json = "{}"
# create an instance of AccountCreate from a JSON string
account_create_instance = AccountCreate.from_json(json)
# print the JSON string representation of the object
print(AccountCreate.to_json())

# convert the object into a dict
account_create_dict = account_create_instance.to_dict()
# create an instance of AccountCreate from a dict
account_create_from_dict = AccountCreate.from_dict(account_create_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


