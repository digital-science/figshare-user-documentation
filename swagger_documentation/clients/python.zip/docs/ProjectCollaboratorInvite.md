# ProjectCollaboratorInvite


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role_name** | **str** | Role of the the collaborator inside the project | 
**user_id** | **int** | User id of the collaborator | [optional] 
**email** | **str** | Collaborator email | [optional] 
**comment** | **str** | Text sent when inviting the user to the project | [optional] 

## Example

```python
from openapi_client.models.project_collaborator_invite import ProjectCollaboratorInvite

# TODO update the JSON string below
json = "{}"
# create an instance of ProjectCollaboratorInvite from a JSON string
project_collaborator_invite_instance = ProjectCollaboratorInvite.from_json(json)
# print the JSON string representation of the object
print(ProjectCollaboratorInvite.to_json())

# convert the object into a dict
project_collaborator_invite_dict = project_collaborator_invite_instance.to_dict()
# create an instance of ProjectCollaboratorInvite from a dict
project_collaborator_invite_from_dict = ProjectCollaboratorInvite.from_dict(project_collaborator_invite_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


