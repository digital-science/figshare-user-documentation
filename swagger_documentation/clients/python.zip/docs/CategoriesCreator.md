# CategoriesCreator


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categories** | **List[int]** | List of category ids | 

## Example

```python
from openapi_client.models.categories_creator import CategoriesCreator

# TODO update the JSON string below
json = "{}"
# create an instance of CategoriesCreator from a JSON string
categories_creator_instance = CategoriesCreator.from_json(json)
# print the JSON string representation of the object
print(CategoriesCreator.to_json())

# convert the object into a dict
categories_creator_dict = categories_creator_instance.to_dict()
# create an instance of CategoriesCreator from a dict
categories_creator_from_dict = CategoriesCreator.from_dict(categories_creator_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


