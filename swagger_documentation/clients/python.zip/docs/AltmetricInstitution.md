# AltmetricInstitution


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Institution id | 
**name** | **str** | Institution name | 
**custom_domain** | **str** | Custom domain for the institution | [optional] 

## Example

```python
from openapi_client.models.altmetric_institution import AltmetricInstitution

# TODO update the JSON string below
json = "{}"
# create an instance of AltmetricInstitution from a JSON string
altmetric_institution_instance = AltmetricInstitution.from_json(json)
# print the JSON string representation of the object
print(AltmetricInstitution.to_json())

# convert the object into a dict
altmetric_institution_dict = altmetric_institution_instance.to_dict()
# create an instance of AltmetricInstitution from a dict
altmetric_institution_from_dict = AltmetricInstitution.from_dict(altmetric_institution_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


