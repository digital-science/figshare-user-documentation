

# Category


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**parentId** | **Integer** | Parent category |  |
|**id** | **Integer** | Category id |  |
|**title** | **String** | Category title |  |
|**path** | **String** | Path to all ancestor ids |  |
|**sourceId** | **String** | ID in original standard taxonomy |  |
|**taxonomyId** | **Integer** | Internal id of taxonomy the category is part of |  |



