

# ProjectNote


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** | Project note id |  |
|**userId** | **Integer** | User who wrote the note |  |
|**_abstract** | **String** | Note Abstract - short/truncated content |  |
|**userName** | **String** | Username of the one who wrote the note |  |
|**createdDate** | **String** | Date when note was created |  |
|**modifiedDate** | **String** | Date when note was last modified |  |



