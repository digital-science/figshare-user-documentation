
# ProjectComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | Api endpoint | 
**id** | **Long** | Project id | 
**title** | **String** | Project title | 
**createdDate** | **String** | Date when project was created | 
**modifiedDate** | **String** | Date when project was last modified | 
**funding** | **String** | Project funding | 
**fundingList** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Project funding information | 
**description** | **String** | Project description | 
**collaborators** | [**List&lt;Collaborator&gt;**](Collaborator.md) | List of project collaborators | 
**customFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | Project custom fields | 



