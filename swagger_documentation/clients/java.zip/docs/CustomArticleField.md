

# CustomArticleField


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** | Custom  metadata name |  |
|**value** | **Object** | Custom metadata value (can be either a string or an array of strings) |  |
|**fieldType** | [**FieldTypeEnum**](#FieldTypeEnum) | Custom field type |  |
|**settings** | **Object** | Settings for the custom field |  |
|**order** | **Long** | Order of the custom field |  |
|**isMandatory** | **Boolean** | Whether the field is mandatory or not |  |



## Enum: FieldTypeEnum

| Name | Value |
|---- | -----|
| TEXT | &quot;text&quot; |
| TEXTAREA | &quot;textarea&quot; |
| DROPDOWN | &quot;dropdown&quot; |
| URL | &quot;url&quot; |
| EMAIL | &quot;email&quot; |
| DATE | &quot;date&quot; |
| DROPDOWN_LARGE_LIST | &quot;dropdown_large_list&quot; |



