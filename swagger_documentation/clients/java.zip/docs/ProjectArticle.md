
# ProjectArticle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Unique identifier for article | 
**title** | **String** | Title of article | 
**doi** | **String** | DOI | 
**handle** | **String** | Handle | 
**url** | **String** | Api endpoint for article | 
**urlPublicHtml** | **String** | Public site endpoint for article | 
**urlPublicApi** | **String** | Public Api endpoint for article | 
**urlPrivateHtml** | **String** | Private site endpoint for article | 
**urlPrivateApi** | **String** | Private Api endpoint for article | 
**timeline** | [**Timeline**](Timeline.md) | Various timeline dates | 
**thumb** | **String** | Thumbnail image | 
**definedType** | **Long** | Type of article identifier | 
**definedTypeName** | **String** | Name of the article type identifier | 
**resourceDoi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | 
**resourceTitle** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | 
**createdDate** | **String** | Date when article was created | 
**citation** | **String** | Article citation | 
**confidentialReason** | **String** | Confidentiality reason | 
**isConfidential** | **Boolean** | Article Confidentiality | 
**size** | **Long** | Article size | 
**funding** | **String** | Article funding | 
**fundingList** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Article funding information | 
**keywords** | **List&lt;String&gt;** | List of article keywords | 
**version** | **Long** | Article version | 
**isMetadataRecord** | **Boolean** | True if article has no files | 
**metadataReason** | **String** | Article metadata reason | 
**status** | **String** | Article status | 
**description** | **String** | Article description | 
**isEmbargoed** | **Boolean** | True if article is embargoed | 
**isPublic** | **Boolean** | True if article is published | 
**hasLinkedFile** | **Boolean** | True if any files are linked to the article | 
**categories** | [**List&lt;Category&gt;**](Category.md) | List of categories selected for the article | 
**license** | [**License**](License.md) | Article selected license | 
**embargoTitle** | **String** | Title for embargo | 
**embargoReason** | **String** | Reason for embargo | 
**references** | **List&lt;String&gt;** | List of references | 
**relatedMaterials** | [**List&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. |  [optional]



