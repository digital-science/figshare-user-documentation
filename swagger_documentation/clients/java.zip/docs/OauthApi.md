# OauthApi

All URIs are relative to *https://api.figinternal.dev/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createToken**](OauthApi.md#createToken) | **POST** /token | Create OAuth token
[**getTokenInfo**](OauthApi.md#getTokenInfo) | **GET** /token | Get OAuth token information


<a name="createToken"></a>
# **createToken**
> OAuthToken createToken(body)

Create OAuth token

Creates OAuth token using various grant types

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.OauthApi;


OauthApi apiInstance = new OauthApi();
CreateOAuthToken body = new CreateOAuthToken(); // CreateOAuthToken | Create OAuth Token Parameters
try {
    OAuthToken result = apiInstance.createToken(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OauthApi#createToken");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateOAuthToken**](CreateOAuthToken.md)| Create OAuth Token Parameters | [optional]

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getTokenInfo"></a>
# **getTokenInfo**
> OAuthToken getTokenInfo(accessToken)

Get OAuth token information

Returns information about the current OAuth token

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.OauthApi;


OauthApi apiInstance = new OauthApi();
String accessToken = "accessToken_example"; // String | OAuth access token
try {
    OAuthToken result = apiInstance.getTokenInfo(accessToken);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OauthApi#getTokenInfo");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accessToken** | **String**| OAuth access token | [optional]

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

