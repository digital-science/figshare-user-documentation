# OauthApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**createToken**](OauthApi.md#createToken) | **POST** /token | Create OAuth token |
| [**getTokenInfo**](OauthApi.md#getTokenInfo) | **GET** /token | Get OAuth token information |


<a id="createToken"></a>
# **createToken**
> OAuthToken createToken(body)

Create OAuth token

Creates OAuth token using various grant types

### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.models.*;
import org.openapitools.client.api.OauthApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("https://api.figsh.com/v2");

    OauthApi apiInstance = new OauthApi(defaultClient);
    CreateOAuthToken body = new CreateOAuthToken(); // CreateOAuthToken | Create OAuth Token Parameters
    try {
      OAuthToken result = apiInstance.createToken(body);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling OauthApi#createToken");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **body** | [**CreateOAuthToken**](CreateOAuthToken.md)| Create OAuth Token Parameters | [optional] |

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Token created successfully &lt;a href&#x3D;&#39;http://tools.ietf.org/html/rfc6749#section-5.1&#39; target&#x3D;&#39;_blank&#39;&gt;RFC 6749 Section 5.1&lt;/a&gt;. |  -  |
| **400** | Bad Request &lt;a href&#x3D;&#39;http://tools.ietf.org/html/rfc6749#section-5.2&#39; target&#x3D;&#39;_blank&#39;&gt;RFC 6749 Section 5.2&lt;/a&gt;. |  -  |

<a id="getTokenInfo"></a>
# **getTokenInfo**
> OAuthToken getTokenInfo(accessToken)

Get OAuth token information

Returns information about the current OAuth token

### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.models.*;
import org.openapitools.client.api.OauthApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("https://api.figsh.com/v2");

    OauthApi apiInstance = new OauthApi(defaultClient);
    String accessToken = "accessToken_example"; // String | OAuth access token
    try {
      OAuthToken result = apiInstance.getTokenInfo(accessToken);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling OauthApi#getTokenInfo");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **accessToken** | **String**| OAuth access token | [optional] |

### Return type

[**OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. Token information |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |

