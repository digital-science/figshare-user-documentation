

# Institution


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Long** | Institution id |  |
|**name** | **String** | Institution name |  |



