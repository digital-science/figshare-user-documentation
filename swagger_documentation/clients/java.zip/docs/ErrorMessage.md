

# ErrorMessage


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**code** | **Long** | A machine friendly error code, used by the dev team to identify the error. |  [optional] |
|**message** | **String** | A human friendly message explaining the error. |  [optional] |



