

# PrivateAuthorsSearch


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**searchFor** | **String** | Search term |  [optional] |
|**page** | **Long** | Page number. Used for pagination with page_size |  [optional] |
|**pageSize** | **Long** | The number of results included on a page. Used for pagination with page |  [optional] |
|**limit** | **Long** | Number of results included on a page. Used for pagination with query |  [optional] |
|**offset** | **Long** | Where to start the listing (the offset of the first result). Used for pagination with limit |  [optional] |
|**institutionId** | **Long** | Return only authors associated to this institution |  [optional] |
|**orcid** | **String** | Orcid of author |  [optional] |
|**groupId** | **Long** | Return only authors in this group or subgroups of the group |  [optional] |
|**isActive** | **Boolean** | Return only active authors if True |  [optional] |
|**isPublic** | **Boolean** | Return only authors that have published items if True |  [optional] |



