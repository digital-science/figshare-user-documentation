

# PrivateAuthorsSearch


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**searchFor** | **String** | Search term |  [optional] |
|**page** | **Integer** | Page number. Used for pagination with page_size |  [optional] |
|**pageSize** | **Integer** | The number of results included on a page. Used for pagination with page |  [optional] |
|**limit** | **Integer** | Number of results included on a page. Used for pagination with query |  [optional] |
|**offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit |  [optional] |
|**institutionId** | **Integer** | Return only authors associated to this institution |  [optional] |
|**orcid** | **String** | Orcid of author |  [optional] |
|**groupId** | **Integer** | Return only authors in this group or subgroups of the group |  [optional] |
|**isActive** | **Boolean** | Return only active authors if True |  [optional] |
|**isPublic** | **Boolean** | Return only authors that have published items if True |  [optional] |



