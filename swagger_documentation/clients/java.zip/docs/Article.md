

# Article


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** | Unique identifier for article |  |
|**title** | **String** | Title of article |  |
|**doi** | **String** | DOI |  |
|**handle** | **String** | Handle |  |
|**url** | **String** | Api endpoint for article |  |
|**urlPublicHtml** | **String** | Public site endpoint for article |  |
|**urlPublicApi** | **String** | Public Api endpoint for article |  |
|**urlPrivateHtml** | **String** | Private site endpoint for article |  |
|**urlPrivateApi** | **String** | Private Api endpoint for article |  |
|**timeline** | [**Timeline**](Timeline.md) |  |  |
|**thumb** | **String** | Thumbnail image |  |
|**definedType** | **Integer** | Type of article identifier |  |
|**definedTypeName** | **String** | Name of the article type identifier |  |
|**resourceDoi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. |  |
|**resourceTitle** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. |  |
|**createdDate** | **String** | Date when article was created |  |



