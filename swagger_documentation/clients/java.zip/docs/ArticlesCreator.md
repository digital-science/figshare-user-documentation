

# ArticlesCreator


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**articles** | **List&lt;Integer&gt;** | List of article ids |  |



