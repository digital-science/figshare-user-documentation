
# ArticlesCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | **List&lt;Long&gt;** | List of article ids | 



