
# Role

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** | Role id | 
**name** | **String** | Role name | 
**category** | **String** | Role category | 
**description** | **String** | Role description | 



