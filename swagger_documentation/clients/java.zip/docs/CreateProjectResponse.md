

# CreateProjectResponse


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**entityId** | **Integer** | Figshare ID of the entity |  |
|**location** | **String** | Url for entity |  |



