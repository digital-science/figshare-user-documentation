

# Resource


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **String** | ID of resource item |  [optional] |
|**title** | **String** | Title of resource item |  [optional] |
|**doi** | **String** | DOI of resource item |  [optional] |
|**link** | **String** | Link of resource item |  [optional] |
|**status** | **String** | Status of resource item |  [optional] |
|**version** | **Long** | Version of resource item |  [optional] |



