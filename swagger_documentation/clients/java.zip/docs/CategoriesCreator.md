
# CategoriesCreator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categories** | **List&lt;Long&gt;** | List of category ids | 



