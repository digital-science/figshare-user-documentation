

# ArticleVersionUpdate


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**supplementaryFields** | **List&lt;Object&gt;** | List of supplementary fields to be associated with the article version |  [optional] |
|**internalMetadata** | **Object** | List of supplementary fields to be associated with the article version |  [optional] |



