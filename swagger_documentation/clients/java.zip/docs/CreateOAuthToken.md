

# CreateOAuthToken


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**clientId** | **String** |  |  |
|**clientSecret** | **String** |  |  |
|**grantType** | [**GrantTypeEnum**](#GrantTypeEnum) |  |  |
|**code** | **String** | Required if grant_type is &#39;authorization_code&#39; |  [optional] |
|**refreshToken** | **String** | Required if grant_type is &#39;refresh_token&#39; |  [optional] |
|**username** | **String** | Required if grant_type is &#39;password&#39; |  [optional] |
|**password** | **String** | Required if grant_type is &#39;password&#39; |  [optional] |



## Enum: GrantTypeEnum

| Name | Value |
|---- | -----|
| AUTHORIZATION_CODE | &quot;authorization_code&quot; |
| REFRESH_TOKEN | &quot;refresh_token&quot; |
| PASSWORD | &quot;password&quot; |
| CLIENT_CREDENTIALS | &quot;client_credentials&quot; |



