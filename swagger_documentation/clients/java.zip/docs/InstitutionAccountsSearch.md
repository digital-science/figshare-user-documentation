

# InstitutionAccountsSearch


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**searchFor** | **String** | Search term |  [optional] |
|**isActive** | **Integer** | Filter by active status |  [optional] |
|**page** | **Integer** | Page number. Used for pagination with page_size |  [optional] |
|**pageSize** | **Integer** | The number of results included on a page. Used for pagination with page |  [optional] |
|**limit** | **Integer** | Number of results included on a page. Used for pagination with query |  [optional] |
|**offset** | **Integer** | Where to start the listing (the offset of the first result). Used for pagination with limit |  [optional] |
|**institutionUserId** | **String** | filter by institution_user_id |  [optional] |
|**email** | **String** | filter by email |  [optional] |



