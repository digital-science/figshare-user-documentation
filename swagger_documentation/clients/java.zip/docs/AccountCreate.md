

# AccountCreate


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**email** | **String** | Email of account |  |
|**firstName** | **String** | First Name |  [optional] |
|**lastName** | **String** | Last Name |  |
|**groupId** | **Integer** | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups |  [optional] |
|**institutionUserId** | **String** | Institution user id |  [optional] |
|**symplecticUserId** | **String** | Symplectic user id |  [optional] |
|**quota** | **Integer** | Account quota |  [optional] |
|**isActive** | **Boolean** | Is account active |  [optional] |



