

# AuthorComplete


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**institutionId** | **Integer** | Institution id |  |
|**groupId** | **Integer** | Group id |  |
|**firstName** | **String** | First Name |  |
|**lastName** | **String** | Last Name |  |
|**isPublic** | **Integer** | if 1 then the author has published items |  |
|**jobTitle** | **String** | Job title |  |
|**id** | **Integer** | Author id |  |
|**fullName** | **String** | Author full name |  |
|**isActive** | **Boolean** | True if author has published items |  |
|**urlName** | **String** | Author url name |  |
|**orcidId** | **String** | Author Orcid |  |



