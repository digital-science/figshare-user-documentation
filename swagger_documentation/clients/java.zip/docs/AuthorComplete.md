

# AuthorComplete


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**institutionId** | **Long** | Institution id |  |
|**groupId** | **Long** | Group id |  |
|**firstName** | **String** | First Name |  |
|**lastName** | **String** | Last Name |  |
|**isPublic** | **Long** | if 1 then the author has published items |  |
|**jobTitle** | **String** | Job title |  |
|**id** | **Long** | Author id |  |
|**fullName** | **String** | Author full name |  |
|**isActive** | **Boolean** | True if author has published items |  |
|**urlName** | **String** | Author url name |  |
|**orcidId** | **String** | Author Orcid |  |



