

# CollectionCompletePrivate


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**accountId** | **Integer** | ID of the account owning the collection |  |
|**funding** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Collection funding information |  |
|**resourceId** | **String** | Collection resource id |  |
|**resourceDoi** | **String** | Collection resource doi |  |
|**resourceTitle** | **String** | Collection resource title |  |
|**resourceLink** | **String** | Collection resource link |  |
|**resourceVersion** | **Integer** | Collection resource version |  |
|**version** | **Integer** | Collection version |  |
|**description** | **String** | Collection description |  |
|**categories** | [**List&lt;Category&gt;**](Category.md) | List of collection categories |  |
|**references** | **List&lt;String&gt;** | List of collection references |  |
|**relatedMaterials** | [**List&lt;RelatedMaterial&gt;**](RelatedMaterial.md) | List of related materials; supersedes references and resource DOI/title. |  [optional] |
|**tags** | **List&lt;String&gt;** | List of collection tags. Keywords can be used instead |  |
|**keywords** | **List&lt;String&gt;** | List of collection keywords. Tags can be used instead |  |
|**authors** | [**List&lt;Author&gt;**](Author.md) | List of collection authors |  |
|**institutionId** | **Integer** | Collection institution |  |
|**groupId** | **Integer** | Collection group |  |
|**articlesCount** | **Integer** | Number of articles in collection |  |
|**_public** | **Boolean** | True if collection is published |  |
|**citation** | **String** | Collection citation |  |
|**customFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | Collection custom fields |  |
|**modifiedDate** | **String** | Date when collection was last modified |  |
|**createdDate** | **String** | Date when collection was created |  |
|**timeline** | [**Timeline**](Timeline.md) |  |  |
|**id** | **Integer** | Collection id |  |
|**title** | **String** | Collection title |  |
|**doi** | **String** | Collection DOI |  |
|**handle** | **String** | Collection Handle |  |
|**url** | **String** | Api endpoint |  |



