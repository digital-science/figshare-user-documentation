

# ProjectPrivate


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**role** | [**RoleEnum**](#RoleEnum) | Role inside this project |  |
|**storage** | [**StorageEnum**](#StorageEnum) | Project storage type |  |
|**url** | **String** | Api endpoint |  |
|**id** | **Integer** | Project id |  |
|**title** | **String** | Project title |  |
|**createdDate** | **String** | Date when project was created |  |
|**modifiedDate** | **String** | Date when project was last modified |  |



## Enum: RoleEnum

| Name | Value |
|---- | -----|
| OWNER | &quot;Owner&quot; |
| COLLABORATOR | &quot;Collaborator&quot; |
| VIEWER | &quot;Viewer&quot; |



## Enum: StorageEnum

| Name | Value |
|---- | -----|
| INDIVIDUAL | &quot;individual&quot; |
| GROUP | &quot;group&quot; |



