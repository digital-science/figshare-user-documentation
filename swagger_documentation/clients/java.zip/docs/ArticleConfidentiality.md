
# ArticleConfidentiality

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isConfidential** | **Boolean** | True if article is confidential | 
**reason** | **String** | Reason for confidentiality | 



