# AltmetricApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**altmetricInstitutionsList**](AltmetricApi.md#altmetricInstitutionsList) | **GET** /altmetric/institutions | List Altmetric Institutions |


<a id="altmetricInstitutionsList"></a>
# **altmetricInstitutionsList**
> List&lt;AltmetricInstitution&gt; altmetricInstitutionsList(offset)

List Altmetric Institutions

Returns a list of institutions available for Altmetric reporting

### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.models.*;
import org.openapitools.client.api.AltmetricApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");

    AltmetricApi apiInstance = new AltmetricApi(defaultClient);
    Integer offset = 0; // Integer | Where to start the listing. The offset of the first item.
    try {
      List<AltmetricInstitution> result = apiInstance.altmetricInstitutionsList(offset);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling AltmetricApi#altmetricInstitutionsList");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **offset** | **Integer**| Where to start the listing. The offset of the first item. | [optional] [default to 0] |

### Return type

[**List&lt;AltmetricInstitution&gt;**](AltmetricInstitution.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK. An array of Altmetric institutions |  -  |
| **400** | Bad Request |  -  |
| **500** | Internal Server Error |  -  |

