

# ProfileUpdateData


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**firstName** | **String** | First name |  [optional] |
|**lastName** | **String** | Last Name |  [optional] |
|**orcid** | **String** | User ORCID |  [optional] |
|**jobTitle** | **String** | User job title |  [optional] |
|**fieldsOfInterest** | **List&lt;Long&gt;** | User fields of interest (category ids) |  [optional] |
|**fieldsOfInterestBySourceId** | **List&lt;String&gt;** | User fields of interest (category source IDs), supersedes the fields_of_interest property |  [optional] |
|**location** | **String** | User location |  [optional] |
|**facebook** | **String** | User facebook URL |  [optional] |
|**x** | **String** | User X (twitter) URL |  [optional] |
|**linkedin** | **String** | User linkedin URL |  [optional] |
|**bio** | **String** | User biographical information |  [optional] |
|**personalProfiles** | [**List&lt;ProfileUpdateDataPersonalProfilesInner&gt;**](ProfileUpdateDataPersonalProfilesInner.md) | Add up to 10 additional personal profile links |  [optional] |



