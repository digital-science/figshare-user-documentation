

# CollectionVersions


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**version** | **Long** | Version number |  |
|**url** | **String** | Api endpoint for the collection version |  |
|**funding** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Collection funding information |  |



