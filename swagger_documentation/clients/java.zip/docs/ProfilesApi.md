# ProfilesApi

All URIs are relative to *https://api.figsh.com/v2*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**updateUserProfile**](ProfilesApi.md#updateUserProfile) | **PUT** /account/profile | Update public profile |
| [**updateUserProfilePicture**](ProfilesApi.md#updateUserProfilePicture) | **POST** /account/profile/{user_id}/picture | Update public profile picture |


<a id="updateUserProfile"></a>
# **updateUserProfile**
> Object updateUserProfile(userProfileData, userId, institutionUserId)

Update public profile

Updates the fields of the user&#39;s public profile.

### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.auth.*;
import org.openapitools.client.models.*;
import org.openapitools.client.api.ProfilesApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("https://api.figsh.com/v2");
    
    // Configure OAuth2 access token for authorization: OAuth2
    OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
    OAuth2.setAccessToken("YOUR ACCESS TOKEN");

    ProfilesApi apiInstance = new ProfilesApi(defaultClient);
    ProfileUpdateData userProfileData = new ProfileUpdateData(); // ProfileUpdateData | 
    Long userId = 56L; // Long | User ID
    String institutionUserId = "institutionUserId_example"; // String | Institutional user ID
    try {
      Object result = apiInstance.updateUserProfile(userProfileData, userId, institutionUserId);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling ProfilesApi#updateUserProfile");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **userProfileData** | [**ProfileUpdateData**](ProfileUpdateData.md)|  | |
| **userId** | **Long**| User ID | [optional] |
| **institutionUserId** | **String**| Institutional user ID | [optional] |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

<a id="updateUserProfilePicture"></a>
# **updateUserProfilePicture**
> Object updateUserProfilePicture(userId, profilePicture)

Update public profile picture

Updates the profile picture of the user&#39;s public profile.

### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.auth.*;
import org.openapitools.client.models.*;
import org.openapitools.client.api.ProfilesApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("https://api.figsh.com/v2");
    
    // Configure OAuth2 access token for authorization: OAuth2
    OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
    OAuth2.setAccessToken("YOUR ACCESS TOKEN");

    ProfilesApi apiInstance = new ProfilesApi(defaultClient);
    Long userId = 56L; // Long | User ID
    File profilePicture = new File("/path/to/file"); // File | User profile picture
    try {
      Object result = apiInstance.updateUserProfilePicture(userId, profilePicture);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling ProfilesApi#updateUserProfilePicture");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **userId** | **Long**| User ID | |
| **profilePicture** | **File**| User profile picture | |

### Return type

**Object**

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |
| **400** | Bad Request |  -  |
| **403** | Forbidden |  -  |
| **404** | Not Found |  -  |
| **500** | Internal Server Error |  -  |

