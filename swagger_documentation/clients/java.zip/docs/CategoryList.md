

# CategoryList


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**isSelectable** | **Boolean** | The selectable status |  |
|**hasChildren** | **Boolean** | True if category has children |  |
|**parentId** | **Long** | Parent category |  |
|**id** | **Long** | Category id |  |
|**title** | **String** | Category title |  |
|**path** | **String** | Path to all ancestor ids |  |
|**sourceId** | **String** | ID in original standard taxonomy |  |
|**taxonomyId** | **Long** | Internal id of taxonomy the category is part of |  |



