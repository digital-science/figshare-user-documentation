

# GroupEmbargoOptions


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** | Embargo option id |  |
|**type** | [**TypeEnum**](#TypeEnum) | Embargo permission type |  |
|**ipName** | **String** | IP range name; value appears if type is ip_range |  |



## Enum: TypeEnum

| Name | Value |
|---- | -----|
| LOGGED_IN | &quot;logged_in&quot; |
| IP_RANGE | &quot;ip_range&quot; |
| ADMINISTRATOR | &quot;administrator&quot; |



