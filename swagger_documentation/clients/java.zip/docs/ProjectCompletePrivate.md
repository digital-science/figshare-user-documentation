
# ProjectCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | [**RoleEnum**](#RoleEnum) | Role inside this project |  [optional]
**storage** | [**StorageEnum**](#StorageEnum) | Project storage type |  [optional]
**url** | **String** | Api endpoint | 
**id** | **Long** | Project id | 
**title** | **String** | Project title | 
**funding** | **String** | Project funding | 
**fundingList** | [**List&lt;FundingInformation&gt;**](FundingInformation.md) | Full Project funding information | 
**description** | **String** | Project description | 
**collaborators** | [**List&lt;Collaborator&gt;**](Collaborator.md) | List of project collaborators | 
**quota** | **Long** | Project quota | 
**usedQuota** | **Long** | Project used quota | 
**createdDate** | **String** | Date when project was created | 
**modifiedDate** | **String** | Date when project was last modified | 
**usedQuotaPrivate** | **Long** | Project private quota used | 
**usedQuotaPublic** | **Long** | Project public quota used | 
**groupId** | **Long** | Group of project if any | 
**accountId** | **Long** | ID of the account owning the project | 
**customFields** | [**List&lt;CustomArticleField&gt;**](CustomArticleField.md) | Collection custom fields | 


<a name="RoleEnum"></a>
## Enum: RoleEnum
Name | Value
---- | -----
OWNER | &quot;Owner&quot;
COLLABORATOR | &quot;Collaborator&quot;
VIEWER | &quot;Viewer&quot;


<a name="StorageEnum"></a>
## Enum: StorageEnum
Name | Value
---- | -----
INDIVIDUAL | &quot;individual&quot;
GROUP | &quot;group&quot;



