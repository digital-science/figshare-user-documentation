

# ProjectCollaborator


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**status** | **String** | Status of collaborator invitation |  |
|**roleName** | **String** | Collaborator role |  |
|**userId** | **Integer** | Collaborator id |  |
|**name** | **String** | Collaborator name |  |



