(defproject figshare-api "3.0.1"
  :description "Figshare apiv2. Using OpenAPI 3.0.1"
  :dependencies [[org.clojure/clojure "1.9.0"]
                 [metosin/spec-tools "0.7.0"]
                 [clj-http "3.8.0"]
                 [orchestra "2017.11.12-1"]
                 [cheshire "5.8.0"]])