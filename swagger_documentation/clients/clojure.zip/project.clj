(defproject figshare-api "2.0"
  :description "Figshare API v2 - Full REST API documentation for managing articles, collections, projects and more."
  :url "https://support.figshare.com/support/home"
  :license {:name "Apache 2.0"
            :url "https://www.apache.org/licenses/LICENSE-2.0.html"}
  :dependencies [[org.clojure/clojure "1.9.0"]
                 [metosin/spec-tools "0.7.0"]
                 [clj-http "3.8.0"]
                 [orchestra "2017.11.12-1"]
                 [cheshire "5.8.0"]])