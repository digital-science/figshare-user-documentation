(ns figshare-api.api.profiles
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format *api-context*]]
            [clojure.spec.alpha :as s]
            [spec-tools.core :as st]
            [orchestra.core :refer [defn-spec]]
            [figshare-api.specs.custom-article-field :refer :all]
            [figshare-api.specs.file-id :refer :all]
            [figshare-api.specs.project-collaborator-invite :refer :all]
            [figshare-api.specs.projects-search :refer :all]
            [figshare-api.specs.project-collaborator :refer :all]
            [figshare-api.specs.funding-search :refer :all]
            [figshare-api.specs.profile-update-data-personal-profiles-inner :refer :all]
            [figshare-api.specs.custom-article-field-add :refer :all]
            [figshare-api.specs.author-complete :refer :all]
            [figshare-api.specs.collaborator :refer :all]
            [figshare-api.specs.project-note-private :refer :all]
            [figshare-api.specs.private-link-response :refer :all]
            [figshare-api.specs.item-type :refer :all]
            [figshare-api.specs.location-warnings :refer :all]
            [figshare-api.specs.project-note :refer :all]
            [figshare-api.specs.article-create :refer :all]
            [figshare-api.specs.institution-accounts-search :refer :all]
            [figshare-api.specs.funding-create :refer :all]
            [figshare-api.specs.collection-handle :refer :all]
            [figshare-api.specs.authors-creator :refer :all]
            [figshare-api.specs.article-embargo :refer :all]
            [figshare-api.specs.error-message :refer :all]
            [figshare-api.specs.collection-private-link-creator :refer :all]
            [figshare-api.specs.response-message :refer :all]
            [figshare-api.specs.project-create :refer :all]
            [figshare-api.specs.timeline-update :refer :all]
            [figshare-api.specs.project-complete-private :refer :all]
            [figshare-api.specs.role :refer :all]
            [figshare-api.specs.article-project-create :refer :all]
            [figshare-api.specs.funding-information :refer :all]
            [figshare-api.specs.upload-info :refer :all]
            [figshare-api.specs.article-doi :refer :all]
            [figshare-api.specs.project-private :refer :all]
            [figshare-api.specs.project-complete :refer :all]
            [figshare-api.specs.private-project-article :refer :all]
            [figshare-api.specs.article-search :refer :all]
            [figshare-api.specs.account-update :refer :all]
            [figshare-api.specs.category-list :refer :all]
            [figshare-api.specs.private-file :refer :all]
            [figshare-api.specs.collection-complete :refer :all]
            [figshare-api.specs.private-authors-search :refer :all]
            [figshare-api.specs.timeline :refer :all]
            [figshare-api.specs.categories-creator :refer :all]
            [figshare-api.specs.account-report :refer :all]
            [figshare-api.specs.article-unpublish-data :refer :all]
            [figshare-api.specs.article-versions :refer :all]
            [figshare-api.specs.project :refer :all]
            [figshare-api.specs.collection-create :refer :all]
            [figshare-api.specs.related-material :refer :all]
            [figshare-api.specs.institution :refer :all]
            [figshare-api.specs.short-account :refer :all]
            [figshare-api.specs.curation-detail :refer :all]
            [figshare-api.specs.article-handle :refer :all]
            [figshare-api.specs.article-with-project :refer :all]
            [figshare-api.specs.article-complete :refer :all]
            [figshare-api.specs.article-complete-private :refer :all]
            [figshare-api.specs.articles-creator :refer :all]
            [figshare-api.specs.group :refer :all]
            [figshare-api.specs.collection-search :refer :all]
            [figshare-api.specs.account-create-response :refer :all]
            [figshare-api.specs.resource :refer :all]
            [figshare-api.specs.create-project-response :refer :all]
            [figshare-api.specs.collection-complete-private :refer :all]
            [figshare-api.specs.author :refer :all]
            [figshare-api.specs.curation-comment :refer :all]
            [figshare-api.specs.collection :refer :all]
            [figshare-api.specs.article :refer :all]
            [figshare-api.specs.file-creator :refer :all]
            [figshare-api.specs.license :refer :all]
            [figshare-api.specs.private-link-creator :refer :all]
            [figshare-api.specs.public-file :refer :all]
            [figshare-api.specs.upload-file-part :refer :all]
            [figshare-api.specs.create-o-auth-token :refer :all]
            [figshare-api.specs.collection-versions :refer :all]
            [figshare-api.specs.confidentiality-creator :refer :all]
            [figshare-api.specs.article-update :refer :all]
            [figshare-api.specs.collection-update :refer :all]
            [figshare-api.specs.profile-update-data :refer :all]
            [figshare-api.specs.private-article-search :refer :all]
            [figshare-api.specs.short-custom-field :refer :all]
            [figshare-api.specs.curation-comment-create :refer :all]
            [figshare-api.specs.article-confidentiality :refer :all]
            [figshare-api.specs.location-warnings-update :refer :all]
            [figshare-api.specs.project-note-create :refer :all]
            [figshare-api.specs.curation :refer :all]
            [figshare-api.specs.group-embargo-options :refer :all]
            [figshare-api.specs.private-collection-search :refer :all]
            [figshare-api.specs.private-link :refer :all]
            [figshare-api.specs.article-version-update :refer :all]
            [figshare-api.specs.account-create :refer :all]
            [figshare-api.specs.project-article :refer :all]
            [figshare-api.specs.project-update :refer :all]
            [figshare-api.specs.o-auth-token :refer :all]
            [figshare-api.specs.collection-doi :refer :all]
            [figshare-api.specs.location :refer :all]
            [figshare-api.specs.category :refer :all]
            [figshare-api.specs.article-embargo-updater :refer :all]
            [figshare-api.specs.common-search :refer :all]
            [figshare-api.specs.user :refer :all]
            [figshare-api.specs.account :refer :all]
            )
  (:import (java.io File)))


(defn-spec update-user-profile-with-http-info any?
  "Update public profile
  Updates the fields of the user's public profile."
  ([Userprofiledata profile-update-data, ] (update-user-profile-with-http-info Userprofiledata nil))
  ([Userprofiledata profile-update-data, {:keys [user_id institution_user_id]} (s/map-of keyword? any?)]
   (check-required-params Userprofiledata)
   (call-api "/account/profile" :put
             {:path-params   {}
              :header-params {}
              :query-params  {"user_id" user_id "institution_user_id" institution_user_id }
              :form-params   {}
              :body-param    Userprofiledata
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec update-user-profile any?
  "Update public profile
  Updates the fields of the user's public profile."
  ([Userprofiledata profile-update-data, ] (update-user-profile Userprofiledata nil))
  ([Userprofiledata profile-update-data, optional-params any?]
   (let [res (:data (update-user-profile-with-http-info Userprofiledata optional-params))]
     (if (:decode-models *api-context*)
        (st/decode any? res st/string-transformer)
        res))))


(defn-spec update-user-profile-picture-with-http-info any?
  "Update public profile picture
  Updates the profile picture of the user's public profile."
  [user_id int?, ^File profile_picture any?]
  (check-required-params user_id profile_picture)
  (call-api "/account/profile/{user_id}/picture" :post
            {:path-params   {"user_id" user_id }
             :header-params {}
             :query-params  {}
             :form-params   {"profile_picture" profile_picture }
             :content-types ["multipart/form-data"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec update-user-profile-picture any?
  "Update public profile picture
  Updates the profile picture of the user's public profile."
  [user_id int?, ^File profile_picture any?]
  (let [res (:data (update-user-profile-picture-with-http-info user_id profile_picture))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


