(ns figshare-api.api.other
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format *api-context*]]
            [clojure.spec.alpha :as s]
            [spec-tools.core :as st]
            [orchestra.core :refer [defn-spec]]
            [figshare-api.specs.custom-article-field :refer :all]
            [figshare-api.specs.file-id :refer :all]
            [figshare-api.specs.project-collaborator-invite :refer :all]
            [figshare-api.specs.projects-search :refer :all]
            [figshare-api.specs.project-collaborator :refer :all]
            [figshare-api.specs.funding-search :refer :all]
            [figshare-api.specs.profile-update-data-personal-profiles-inner :refer :all]
            [figshare-api.specs.custom-article-field-add :refer :all]
            [figshare-api.specs.author-complete :refer :all]
            [figshare-api.specs.collaborator :refer :all]
            [figshare-api.specs.project-note-private :refer :all]
            [figshare-api.specs.private-link-response :refer :all]
            [figshare-api.specs.item-type :refer :all]
            [figshare-api.specs.location-warnings :refer :all]
            [figshare-api.specs.project-note :refer :all]
            [figshare-api.specs.article-create :refer :all]
            [figshare-api.specs.institution-accounts-search :refer :all]
            [figshare-api.specs.funding-create :refer :all]
            [figshare-api.specs.collection-handle :refer :all]
            [figshare-api.specs.authors-creator :refer :all]
            [figshare-api.specs.article-embargo :refer :all]
            [figshare-api.specs.error-message :refer :all]
            [figshare-api.specs.collection-private-link-creator :refer :all]
            [figshare-api.specs.response-message :refer :all]
            [figshare-api.specs.project-create :refer :all]
            [figshare-api.specs.timeline-update :refer :all]
            [figshare-api.specs.project-complete-private :refer :all]
            [figshare-api.specs.role :refer :all]
            [figshare-api.specs.article-project-create :refer :all]
            [figshare-api.specs.funding-information :refer :all]
            [figshare-api.specs.upload-info :refer :all]
            [figshare-api.specs.article-doi :refer :all]
            [figshare-api.specs.project-private :refer :all]
            [figshare-api.specs.project-complete :refer :all]
            [figshare-api.specs.private-project-article :refer :all]
            [figshare-api.specs.article-search :refer :all]
            [figshare-api.specs.account-update :refer :all]
            [figshare-api.specs.category-list :refer :all]
            [figshare-api.specs.private-file :refer :all]
            [figshare-api.specs.collection-complete :refer :all]
            [figshare-api.specs.private-authors-search :refer :all]
            [figshare-api.specs.timeline :refer :all]
            [figshare-api.specs.categories-creator :refer :all]
            [figshare-api.specs.account-report :refer :all]
            [figshare-api.specs.article-unpublish-data :refer :all]
            [figshare-api.specs.article-versions :refer :all]
            [figshare-api.specs.project :refer :all]
            [figshare-api.specs.collection-create :refer :all]
            [figshare-api.specs.related-material :refer :all]
            [figshare-api.specs.institution :refer :all]
            [figshare-api.specs.short-account :refer :all]
            [figshare-api.specs.curation-detail :refer :all]
            [figshare-api.specs.article-handle :refer :all]
            [figshare-api.specs.article-with-project :refer :all]
            [figshare-api.specs.article-complete :refer :all]
            [figshare-api.specs.article-complete-private :refer :all]
            [figshare-api.specs.articles-creator :refer :all]
            [figshare-api.specs.group :refer :all]
            [figshare-api.specs.collection-search :refer :all]
            [figshare-api.specs.account-create-response :refer :all]
            [figshare-api.specs.resource :refer :all]
            [figshare-api.specs.create-project-response :refer :all]
            [figshare-api.specs.collection-complete-private :refer :all]
            [figshare-api.specs.author :refer :all]
            [figshare-api.specs.curation-comment :refer :all]
            [figshare-api.specs.collection :refer :all]
            [figshare-api.specs.article :refer :all]
            [figshare-api.specs.file-creator :refer :all]
            [figshare-api.specs.license :refer :all]
            [figshare-api.specs.private-link-creator :refer :all]
            [figshare-api.specs.public-file :refer :all]
            [figshare-api.specs.upload-file-part :refer :all]
            [figshare-api.specs.create-o-auth-token :refer :all]
            [figshare-api.specs.collection-versions :refer :all]
            [figshare-api.specs.confidentiality-creator :refer :all]
            [figshare-api.specs.article-update :refer :all]
            [figshare-api.specs.collection-update :refer :all]
            [figshare-api.specs.profile-update-data :refer :all]
            [figshare-api.specs.private-article-search :refer :all]
            [figshare-api.specs.short-custom-field :refer :all]
            [figshare-api.specs.curation-comment-create :refer :all]
            [figshare-api.specs.article-confidentiality :refer :all]
            [figshare-api.specs.location-warnings-update :refer :all]
            [figshare-api.specs.project-note-create :refer :all]
            [figshare-api.specs.curation :refer :all]
            [figshare-api.specs.group-embargo-options :refer :all]
            [figshare-api.specs.private-collection-search :refer :all]
            [figshare-api.specs.private-link :refer :all]
            [figshare-api.specs.article-version-update :refer :all]
            [figshare-api.specs.account-create :refer :all]
            [figshare-api.specs.project-article :refer :all]
            [figshare-api.specs.project-update :refer :all]
            [figshare-api.specs.o-auth-token :refer :all]
            [figshare-api.specs.collection-doi :refer :all]
            [figshare-api.specs.location :refer :all]
            [figshare-api.specs.category :refer :all]
            [figshare-api.specs.article-embargo-updater :refer :all]
            [figshare-api.specs.common-search :refer :all]
            [figshare-api.specs.user :refer :all]
            [figshare-api.specs.account :refer :all]
            )
  (:import (java.io File)))


(defn-spec categories-list-with-http-info any?
  "Public Categories
  Returns a list of public categories"
  []
  (call-api "/categories" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec categories-list (s/coll-of category-list-spec)
  "Public Categories
  Returns a list of public categories"
  []
  (let [res (:data (categories-list-with-http-info))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of category-list-spec) res st/string-transformer)
       res)))


(defn-spec file-download-with-http-info any?
  "Public File Download
  Starts the download of a file"
  [file_id int?]
  (check-required-params file_id)
  (call-api "/file/download/{file_id}" :get
            {:path-params   {"file_id" file_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       []
             :auth-names    []}))

(defn-spec file-download any?
  "Public File Download
  Starts the download of a file"
  [file_id int?]
  (let [res (:data (file-download-with-http-info file_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec item-types-list-with-http-info any?
  "Item Types
  Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare."
  ([] (item-types-list-with-http-info nil))
  ([{:keys [group_id]} (s/map-of keyword? any?)]
   (call-api "/item_types" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"group_id" group_id }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec item-types-list (s/coll-of item-type-spec)
  "Item Types
  Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare."
  ([] (item-types-list nil))
  ([optional-params any?]
   (let [res (:data (item-types-list-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of item-type-spec) res st/string-transformer)
        res))))


(defn-spec licenses-list-with-http-info any?
  "Public Licenses
  Returns a list of public licenses"
  []
  (call-api "/licenses" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec licenses-list (s/coll-of license-spec)
  "Public Licenses
  Returns a list of public licenses"
  []
  (let [res (:data (licenses-list-with-http-info))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of license-spec) res st/string-transformer)
       res)))


(defn-spec private-account-with-http-info any?
  "Private Account information
  Account information for token/personal token"
  []
  (call-api "/account" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-account account-spec
  "Private Account information
  Account information for token/personal token"
  []
  (let [res (:data (private-account-with-http-info))]
    (if (:decode-models *api-context*)
       (st/decode account-spec res st/string-transformer)
       res)))


(defn-spec private-funding-search-with-http-info any?
  "Search Funding
  Search for fundings"
  ([] (private-funding-search-with-http-info nil))
  ([{:keys [search]} (s/map-of keyword? any?)]
   (call-api "/account/funding/search" :post
             {:path-params   {}
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    search
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-funding-search (s/coll-of funding-information-spec)
  "Search Funding
  Search for fundings"
  ([] (private-funding-search nil))
  ([optional-params any?]
   (let [res (:data (private-funding-search-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of funding-information-spec) res st/string-transformer)
        res))))


(defn-spec private-licenses-list-with-http-info any?
  "Private Account Licenses
  This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution."
  []
  (call-api "/account/licenses" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-licenses-list (s/coll-of license-spec)
  "Private Account Licenses
  This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution."
  []
  (let [res (:data (private-licenses-list-with-http-info))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of license-spec) res st/string-transformer)
       res)))


