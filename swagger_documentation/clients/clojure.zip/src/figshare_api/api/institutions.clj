(ns figshare-api.api.institutions
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format *api-context*]]
            [clojure.spec.alpha :as s]
            [spec-tools.core :as st]
            [orchestra.core :refer [defn-spec]]
            [figshare-api.specs.custom-article-field :refer :all]
            [figshare-api.specs.file-id :refer :all]
            [figshare-api.specs.project-collaborator-invite :refer :all]
            [figshare-api.specs.projects-search :refer :all]
            [figshare-api.specs.funding-search :refer :all]
            [figshare-api.specs.project-collaborator :refer :all]
            [figshare-api.specs.profile-update-data-personal-profiles-inner :refer :all]
            [figshare-api.specs.custom-article-field-add :refer :all]
            [figshare-api.specs.author-complete :refer :all]
            [figshare-api.specs.collaborator :refer :all]
            [figshare-api.specs.project-note-private :refer :all]
            [figshare-api.specs.private-link-response :refer :all]
            [figshare-api.specs.item-type :refer :all]
            [figshare-api.specs.location-warnings :refer :all]
            [figshare-api.specs.article-create :refer :all]
            [figshare-api.specs.project-note :refer :all]
            [figshare-api.specs.institution-accounts-search :refer :all]
            [figshare-api.specs.funding-create :refer :all]
            [figshare-api.specs.collection-handle :refer :all]
            [figshare-api.specs.authors-creator :refer :all]
            [figshare-api.specs.article-embargo :refer :all]
            [figshare-api.specs.error-message :refer :all]
            [figshare-api.specs.collection-private-link-creator :refer :all]
            [figshare-api.specs.response-message :refer :all]
            [figshare-api.specs.project-create :refer :all]
            [figshare-api.specs.timeline-update :refer :all]
            [figshare-api.specs.project-complete-private :refer :all]
            [figshare-api.specs.role :refer :all]
            [figshare-api.specs.article-project-create :refer :all]
            [figshare-api.specs.funding-information :refer :all]
            [figshare-api.specs.upload-info :refer :all]
            [figshare-api.specs.article-doi :refer :all]
            [figshare-api.specs.project-private :refer :all]
            [figshare-api.specs.private-project-article :refer :all]
            [figshare-api.specs.project-complete :refer :all]
            [figshare-api.specs.article-search :refer :all]
            [figshare-api.specs.account-update :refer :all]
            [figshare-api.specs.category-list :refer :all]
            [figshare-api.specs.private-file :refer :all]
            [figshare-api.specs.collection-complete :refer :all]
            [figshare-api.specs.private-authors-search :refer :all]
            [figshare-api.specs.timeline :refer :all]
            [figshare-api.specs.categories-creator :refer :all]
            [figshare-api.specs.account-report :refer :all]
            [figshare-api.specs.article-unpublish-data :refer :all]
            [figshare-api.specs.article-versions :refer :all]
            [figshare-api.specs.collection-create :refer :all]
            [figshare-api.specs.project :refer :all]
            [figshare-api.specs.related-material :refer :all]
            [figshare-api.specs.institution :refer :all]
            [figshare-api.specs.short-account :refer :all]
            [figshare-api.specs.curation-detail :refer :all]
            [figshare-api.specs.article-handle :refer :all]
            [figshare-api.specs.article-complete :refer :all]
            [figshare-api.specs.article-complete-private :refer :all]
            [figshare-api.specs.article-with-project :refer :all]
            [figshare-api.specs.articles-creator :refer :all]
            [figshare-api.specs.group :refer :all]
            [figshare-api.specs.collection-search :refer :all]
            [figshare-api.specs.account-create-response :refer :all]
            [figshare-api.specs.create-project-response :refer :all]
            [figshare-api.specs.resource :refer :all]
            [figshare-api.specs.author :refer :all]
            [figshare-api.specs.collection-complete-private :refer :all]
            [figshare-api.specs.curation-comment :refer :all]
            [figshare-api.specs.collection :refer :all]
            [figshare-api.specs.article :refer :all]
            [figshare-api.specs.file-creator :refer :all]
            [figshare-api.specs.license :refer :all]
            [figshare-api.specs.private-link-creator :refer :all]
            [figshare-api.specs.public-file :refer :all]
            [figshare-api.specs.upload-file-part :refer :all]
            [figshare-api.specs.collection-versions :refer :all]
            [figshare-api.specs.create-o-auth-token :refer :all]
            [figshare-api.specs.confidentiality-creator :refer :all]
            [figshare-api.specs.article-update :refer :all]
            [figshare-api.specs.collection-update :refer :all]
            [figshare-api.specs.profile-update-data :refer :all]
            [figshare-api.specs.private-article-search :refer :all]
            [figshare-api.specs.article-confidentiality :refer :all]
            [figshare-api.specs.curation-comment-create :refer :all]
            [figshare-api.specs.location-warnings-update :refer :all]
            [figshare-api.specs.short-custom-field :refer :all]
            [figshare-api.specs.project-note-create :refer :all]
            [figshare-api.specs.curation :refer :all]
            [figshare-api.specs.group-embargo-options :refer :all]
            [figshare-api.specs.private-collection-search :refer :all]
            [figshare-api.specs.private-link :refer :all]
            [figshare-api.specs.article-version-update :refer :all]
            [figshare-api.specs.account-create :refer :all]
            [figshare-api.specs.project-article :refer :all]
            [figshare-api.specs.project-update :refer :all]
            [figshare-api.specs.o-auth-token :refer :all]
            [figshare-api.specs.collection-doi :refer :all]
            [figshare-api.specs.location :refer :all]
            [figshare-api.specs.article-embargo-updater :refer :all]
            [figshare-api.specs.category :refer :all]
            [figshare-api.specs.common-search :refer :all]
            [figshare-api.specs.user :refer :all]
            [figshare-api.specs.account :refer :all]
            )
  (:import (java.io File)))


(defn-spec account-institution-curation-with-http-info any?
  "Institution Curation Review
  Retrieve a certain curation review by its ID"
  [curation_id int?]
  (check-required-params curation_id)
  (call-api "/account/institution/review/{curation_id}" :get
            {:path-params   {"curation_id" curation_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec account-institution-curation curation-detail-spec
  "Institution Curation Review
  Retrieve a certain curation review by its ID"
  [curation_id int?]
  (let [res (:data (account-institution-curation-with-http-info curation_id))]
    (if (:decode-models *api-context*)
       (st/decode curation-detail-spec res st/string-transformer)
       res)))


(defn-spec account-institution-curations-with-http-info any?
  "Institution Curation Reviews
  Retrieve a list of curation reviews for this institution"
  ([] (account-institution-curations-with-http-info nil))
  ([{:keys [group_id article_id status limit offset]} (s/map-of keyword? any?)]
   (call-api "/account/institution/reviews" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"group_id" group_id "article_id" article_id "status" status "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec account-institution-curations curation-spec
  "Institution Curation Reviews
  Retrieve a list of curation reviews for this institution"
  ([] (account-institution-curations nil))
  ([optional-params any?]
   (let [res (:data (account-institution-curations-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode curation-spec res st/string-transformer)
        res))))


(defn-spec custom-fields-list-with-http-info any?
  "Private account institution group custom fields
  Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access."
  ([] (custom-fields-list-with-http-info nil))
  ([{:keys [group_id]} (s/map-of keyword? any?)]
   (call-api "/account/institution/custom_fields" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"group_id" group_id }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec custom-fields-list (s/coll-of short-custom-field-spec)
  "Private account institution group custom fields
  Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access."
  ([] (custom-fields-list nil))
  ([optional-params any?]
   (let [res (:data (custom-fields-list-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of short-custom-field-spec) res st/string-transformer)
        res))))


(defn-spec custom-fields-upload-with-http-info any?
  "Custom fields values files upload
  Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. More details in the <a href=\"#custom_fields\">Custom Fields section</a>"
  ([custom_field_id int?, ] (custom-fields-upload-with-http-info custom_field_id nil))
  ([custom_field_id int?, {:keys [^File external_file]} (s/map-of keyword? any?)]
   (check-required-params custom_field_id)
   (call-api "/account/institution/custom_fields/{custom_field_id}/items/upload" :post
             {:path-params   {"custom_field_id" custom_field_id }
              :header-params {}
              :query-params  {}
              :form-params   {"external_file" external_file }
              :content-types ["multipart/form-data"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec custom-fields-upload any?
  "Custom fields values files upload
  Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. More details in the <a href=\"#custom_fields\">Custom Fields section</a>"
  ([custom_field_id int?, ] (custom-fields-upload custom_field_id nil))
  ([custom_field_id int?, optional-params any?]
   (let [res (:data (custom-fields-upload-with-http-info custom_field_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode any? res st/string-transformer)
        res))))


(defn-spec get-account-institution-curation-comments-with-http-info any?
  "Institution Curation Review Comments
  Retrieve a certain curation review's comments."
  ([curation_id int?, ] (get-account-institution-curation-comments-with-http-info curation_id nil))
  ([curation_id int?, {:keys [limit offset]} (s/map-of keyword? any?)]
   (check-required-params curation_id)
   (call-api "/account/institution/review/{curation_id}/comments" :get
             {:path-params   {"curation_id" curation_id }
              :header-params {}
              :query-params  {"limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec get-account-institution-curation-comments curation-comment-spec
  "Institution Curation Review Comments
  Retrieve a certain curation review's comments."
  ([curation_id int?, ] (get-account-institution-curation-comments curation_id nil))
  ([curation_id int?, optional-params any?]
   (let [res (:data (get-account-institution-curation-comments-with-http-info curation_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode curation-comment-spec res st/string-transformer)
        res))))


(defn-spec institution-articles-with-http-info any?
  "Public Institution Articles
  Returns a list of articles belonging to the institution"
  [institution_string_id string?, resource_id string?, filename string?]
  (check-required-params institution_string_id resource_id filename)
  (call-api "/institutions/{institution_string_id}/articles/filter-by" :get
            {:path-params   {"institution_string_id" institution_string_id }
             :header-params {}
             :query-params  {"resource_id" resource_id "filename" filename }
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec institution-articles (s/coll-of article-spec)
  "Public Institution Articles
  Returns a list of articles belonging to the institution"
  [institution_string_id string?, resource_id string?, filename string?]
  (let [res (:data (institution-articles-with-http-info institution_string_id resource_id filename))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of article-spec) res st/string-transformer)
       res)))


(defn-spec institution-hrfeed-upload-with-http-info any?
  "Private Institution HRfeed Upload
  More info in the <a href=\"#hr_feed\">HR Feed section</a>"
  ([] (institution-hrfeed-upload-with-http-info nil))
  ([{:keys [^File hrfeed]} (s/map-of keyword? any?)]
   (call-api "/institution/hrfeed/upload" :post
             {:path-params   {}
              :header-params {}
              :query-params  {}
              :form-params   {"hrfeed" hrfeed }
              :content-types ["multipart/form-data"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec institution-hrfeed-upload response-message-spec
  "Private Institution HRfeed Upload
  More info in the <a href=\"#hr_feed\">HR Feed section</a>"
  ([] (institution-hrfeed-upload nil))
  ([optional-params any?]
   (let [res (:data (institution-hrfeed-upload-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode response-message-spec res st/string-transformer)
        res))))


(defn-spec post-account-institution-curation-comments-with-http-info any?
  "POST Institution Curation Review Comment
  Add a new comment to the review."
  [curation_id int?, CurationComment curation-comment-create]
  (check-required-params curation_id CurationComment)
  (call-api "/account/institution/review/{curation_id}/comments" :post
            {:path-params   {"curation_id" curation_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    CurationComment
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec post-account-institution-curation-comments any?
  "POST Institution Curation Review Comment
  Add a new comment to the review."
  [curation_id int?, CurationComment curation-comment-create]
  (let [res (:data (post-account-institution-curation-comments-with-http-info curation_id CurationComment))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-account-institution-user-with-http-info any?
  "Private Account Institution User
  Retrieve institution user information using the account_id"
  [account_id int?]
  (check-required-params account_id)
  (call-api "/account/institution/users/{account_id}" :get
            {:path-params   {"account_id" account_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-account-institution-user user-spec
  "Private Account Institution User
  Retrieve institution user information using the account_id"
  [account_id int?]
  (let [res (:data (private-account-institution-user-with-http-info account_id))]
    (if (:decode-models *api-context*)
       (st/decode user-spec res st/string-transformer)
       res)))


(defn-spec private-categories-list-with-http-info any?
  "Private Account Categories
  List institution categories (including parent Categories)"
  []
  (call-api "/account/categories" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-categories-list (s/coll-of category-list-spec)
  "Private Account Categories
  List institution categories (including parent Categories)"
  []
  (let [res (:data (private-categories-list-with-http-info))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of category-list-spec) res st/string-transformer)
       res)))


(defn-spec private-group-embargo-options-details-with-http-info any?
  "Private Account Institution Group Embargo Options
  Account institution group embargo options details"
  [group_id int?]
  (check-required-params group_id)
  (call-api "/account/institution/groups/{group_id}/embargo_options" :get
            {:path-params   {"group_id" group_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-group-embargo-options-details (s/coll-of group-embargo-options-spec)
  "Private Account Institution Group Embargo Options
  Account institution group embargo options details"
  [group_id int?]
  (let [res (:data (private-group-embargo-options-details-with-http-info group_id))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of group-embargo-options-spec) res st/string-transformer)
       res)))


(defn-spec private-institution-account-with-http-info any?
  "Private Institution Account information
  Private Institution Account information"
  [account_id int?]
  (check-required-params account_id)
  (call-api "/account/institution/accounts/{account_id}" :get
            {:path-params   {"account_id" account_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-institution-account account-spec
  "Private Institution Account information
  Private Institution Account information"
  [account_id int?]
  (let [res (:data (private-institution-account-with-http-info account_id))]
    (if (:decode-models *api-context*)
       (st/decode account-spec res st/string-transformer)
       res)))


(defn-spec private-institution-account-group-role-delete-with-http-info any?
  "Delete Institution Account Group Role
  Delete Institution Account Group Role"
  [account_id int?, group_id int?, role_id int?]
  (check-required-params account_id group_id role_id)
  (call-api "/account/institution/roles/{account_id}/{group_id}/{role_id}" :delete
            {:path-params   {"account_id" account_id "group_id" group_id "role_id" role_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-institution-account-group-role-delete any?
  "Delete Institution Account Group Role
  Delete Institution Account Group Role"
  [account_id int?, group_id int?, role_id int?]
  (let [res (:data (private-institution-account-group-role-delete-with-http-info account_id group_id role_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-institution-account-group-roles-with-http-info any?
  "List Institution Account Group Roles
  List Institution Account Group Roles"
  [account_id int?]
  (check-required-params account_id)
  (call-api "/account/institution/roles/{account_id}" :get
            {:path-params   {"account_id" account_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-institution-account-group-roles any?
  "List Institution Account Group Roles
  List Institution Account Group Roles"
  [account_id int?]
  (let [res (:data (private-institution-account-group-roles-with-http-info account_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-institution-account-group-roles-create-with-http-info any?
  "Add Institution Account Group Roles
  Add Institution Account Group Roles"
  [account_id int?, Account any?]
  (check-required-params account_id Account)
  (call-api "/account/institution/roles/{account_id}" :post
            {:path-params   {"account_id" account_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Account
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-institution-account-group-roles-create any?
  "Add Institution Account Group Roles
  Add Institution Account Group Roles"
  [account_id int?, Account any?]
  (let [res (:data (private-institution-account-group-roles-create-with-http-info account_id Account))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-institution-accounts-create-with-http-info any?
  "Create new Institution Account
  Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created."
  [Account account-create]
  (check-required-params Account)
  (call-api "/account/institution/accounts" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Account
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-institution-accounts-create account-create-response-spec
  "Create new Institution Account
  Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created."
  [Account account-create]
  (let [res (:data (private-institution-accounts-create-with-http-info Account))]
    (if (:decode-models *api-context*)
       (st/decode account-create-response-spec res st/string-transformer)
       res)))


(defn-spec private-institution-accounts-list-with-http-info any?
  "Private Account Institution Accounts
  Returns the accounts for which the account has administrative privileges (assigned and inherited)."
  ([] (private-institution-accounts-list-with-http-info nil))
  ([{:keys [page page_size limit offset is_active institution_user_id email id_lte id_gte]} (s/map-of keyword? any?)]
   (call-api "/account/institution/accounts" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset "is_active" is_active "institution_user_id" institution_user_id "email" email "id_lte" id_lte "id_gte" id_gte }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-institution-accounts-list (s/coll-of short-account-spec)
  "Private Account Institution Accounts
  Returns the accounts for which the account has administrative privileges (assigned and inherited)."
  ([] (private-institution-accounts-list nil))
  ([optional-params any?]
   (let [res (:data (private-institution-accounts-list-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of short-account-spec) res st/string-transformer)
        res))))


(defn-spec private-institution-accounts-search-with-http-info any?
  "Private Account Institution Accounts Search
  Returns the accounts for which the account has administrative privileges (assigned and inherited)."
  [search institution-accounts-search]
  (check-required-params search)
  (call-api "/account/institution/accounts/search" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    search
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-institution-accounts-search (s/coll-of short-account-spec)
  "Private Account Institution Accounts Search
  Returns the accounts for which the account has administrative privileges (assigned and inherited)."
  [search institution-accounts-search]
  (let [res (:data (private-institution-accounts-search-with-http-info search))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of short-account-spec) res st/string-transformer)
       res)))


(defn-spec private-institution-accounts-update-with-http-info any?
  "Update Institution Account
  Update Institution Account"
  [account_id int?, Account account-update]
  (check-required-params account_id Account)
  (call-api "/account/institution/accounts/{account_id}" :put
            {:path-params   {"account_id" account_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Account
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-institution-accounts-update any?
  "Update Institution Account
  Update Institution Account"
  [account_id int?, Account account-update]
  (let [res (:data (private-institution-accounts-update-with-http-info account_id Account))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-institution-articles-with-http-info any?
  "Private Institution Articles
  Get Articles from own institution. User must be administrator of the institution"
  ([] (private-institution-articles-with-http-info nil))
  ([{:keys [page page_size limit offset order order_direction published_since modified_since status resource_doi item_type group]} (s/map-of keyword? any?)]
   (call-api "/account/institution/articles" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset "order" order "order_direction" order_direction "published_since" published_since "modified_since" modified_since "status" status "resource_doi" resource_doi "item_type" item_type "group" group }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-institution-articles (s/coll-of article-spec)
  "Private Institution Articles
  Get Articles from own institution. User must be administrator of the institution"
  ([] (private-institution-articles nil))
  ([optional-params any?]
   (let [res (:data (private-institution-articles-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of article-spec) res st/string-transformer)
        res))))


(defn-spec private-institution-details-with-http-info any?
  "Private Account Institutions
  Account institution details"
  []
  (call-api "/account/institution" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-institution-details institution-spec
  "Private Account Institutions
  Account institution details"
  []
  (let [res (:data (private-institution-details-with-http-info))]
    (if (:decode-models *api-context*)
       (st/decode institution-spec res st/string-transformer)
       res)))


(defn-spec private-institution-embargo-options-details-with-http-info any?
  "Private Account Institution embargo options
  Account institution embargo options details"
  []
  (call-api "/account/institution/embargo_options" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-institution-embargo-options-details (s/coll-of group-embargo-options-spec)
  "Private Account Institution embargo options
  Account institution embargo options details"
  []
  (let [res (:data (private-institution-embargo-options-details-with-http-info))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of group-embargo-options-spec) res st/string-transformer)
       res)))


(defn-spec private-institution-groups-list-with-http-info any?
  "Private Account Institution Groups
  Returns the groups for which the account has administrative privileges (assigned and inherited)."
  []
  (call-api "/account/institution/groups" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-institution-groups-list (s/coll-of group-spec)
  "Private Account Institution Groups
  Returns the groups for which the account has administrative privileges (assigned and inherited)."
  []
  (let [res (:data (private-institution-groups-list-with-http-info))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of group-spec) res st/string-transformer)
       res)))


(defn-spec private-institution-roles-list-with-http-info any?
  "Private Account Institution Roles
  Returns the roles available for groups and the institution group."
  []
  (call-api "/account/institution/roles" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-institution-roles-list (s/coll-of role-spec)
  "Private Account Institution Roles
  Returns the roles available for groups and the institution group."
  []
  (let [res (:data (private-institution-roles-list-with-http-info))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of role-spec) res st/string-transformer)
       res)))


