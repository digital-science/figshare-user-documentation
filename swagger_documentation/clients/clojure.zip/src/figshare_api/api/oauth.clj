(ns figshare-api.api.oauth
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn create-token-with-http-info
  "Create OAuth token
  Creates OAuth token using various grant types"
  ([] (create-token-with-http-info nil))
  ([{:keys [body ]}]
   (call-api "/token" :post
             {:path-params   {}
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    body
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn create-token
  "Create OAuth token
  Creates OAuth token using various grant types"
  ([] (create-token nil))
  ([optional-params]
   (:data (create-token-with-http-info optional-params))))

(defn get-token-info-with-http-info
  "Get OAuth token information
  Returns information about the current OAuth token"
  ([] (get-token-info-with-http-info nil))
  ([{:keys [access-token ]}]
   (call-api "/token" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"access_token" access-token }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn get-token-info
  "Get OAuth token information
  Returns information about the current OAuth token"
  ([] (get-token-info nil))
  ([optional-params]
   (:data (get-token-info-with-http-info optional-params))))

