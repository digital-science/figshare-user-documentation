(ns figshare-api.api.articles
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format *api-context*]]
            [clojure.spec.alpha :as s]
            [spec-tools.core :as st]
            [orchestra.core :refer [defn-spec]]
            [figshare-api.specs.custom-article-field :refer :all]
            [figshare-api.specs.file-id :refer :all]
            [figshare-api.specs.project-collaborator-invite :refer :all]
            [figshare-api.specs.projects-search :refer :all]
            [figshare-api.specs.funding-search :refer :all]
            [figshare-api.specs.project-collaborator :refer :all]
            [figshare-api.specs.profile-update-data-personal-profiles-inner :refer :all]
            [figshare-api.specs.custom-article-field-add :refer :all]
            [figshare-api.specs.author-complete :refer :all]
            [figshare-api.specs.collaborator :refer :all]
            [figshare-api.specs.project-note-private :refer :all]
            [figshare-api.specs.private-link-response :refer :all]
            [figshare-api.specs.item-type :refer :all]
            [figshare-api.specs.location-warnings :refer :all]
            [figshare-api.specs.article-create :refer :all]
            [figshare-api.specs.project-note :refer :all]
            [figshare-api.specs.institution-accounts-search :refer :all]
            [figshare-api.specs.funding-create :refer :all]
            [figshare-api.specs.collection-handle :refer :all]
            [figshare-api.specs.authors-creator :refer :all]
            [figshare-api.specs.article-embargo :refer :all]
            [figshare-api.specs.error-message :refer :all]
            [figshare-api.specs.collection-private-link-creator :refer :all]
            [figshare-api.specs.response-message :refer :all]
            [figshare-api.specs.project-create :refer :all]
            [figshare-api.specs.timeline-update :refer :all]
            [figshare-api.specs.project-complete-private :refer :all]
            [figshare-api.specs.role :refer :all]
            [figshare-api.specs.article-project-create :refer :all]
            [figshare-api.specs.funding-information :refer :all]
            [figshare-api.specs.upload-info :refer :all]
            [figshare-api.specs.article-doi :refer :all]
            [figshare-api.specs.project-private :refer :all]
            [figshare-api.specs.private-project-article :refer :all]
            [figshare-api.specs.project-complete :refer :all]
            [figshare-api.specs.article-search :refer :all]
            [figshare-api.specs.account-update :refer :all]
            [figshare-api.specs.category-list :refer :all]
            [figshare-api.specs.private-file :refer :all]
            [figshare-api.specs.collection-complete :refer :all]
            [figshare-api.specs.private-authors-search :refer :all]
            [figshare-api.specs.timeline :refer :all]
            [figshare-api.specs.categories-creator :refer :all]
            [figshare-api.specs.account-report :refer :all]
            [figshare-api.specs.article-unpublish-data :refer :all]
            [figshare-api.specs.article-versions :refer :all]
            [figshare-api.specs.collection-create :refer :all]
            [figshare-api.specs.project :refer :all]
            [figshare-api.specs.related-material :refer :all]
            [figshare-api.specs.institution :refer :all]
            [figshare-api.specs.short-account :refer :all]
            [figshare-api.specs.curation-detail :refer :all]
            [figshare-api.specs.article-handle :refer :all]
            [figshare-api.specs.article-complete :refer :all]
            [figshare-api.specs.article-complete-private :refer :all]
            [figshare-api.specs.article-with-project :refer :all]
            [figshare-api.specs.articles-creator :refer :all]
            [figshare-api.specs.group :refer :all]
            [figshare-api.specs.collection-search :refer :all]
            [figshare-api.specs.account-create-response :refer :all]
            [figshare-api.specs.create-project-response :refer :all]
            [figshare-api.specs.resource :refer :all]
            [figshare-api.specs.author :refer :all]
            [figshare-api.specs.collection-complete-private :refer :all]
            [figshare-api.specs.curation-comment :refer :all]
            [figshare-api.specs.collection :refer :all]
            [figshare-api.specs.article :refer :all]
            [figshare-api.specs.file-creator :refer :all]
            [figshare-api.specs.license :refer :all]
            [figshare-api.specs.private-link-creator :refer :all]
            [figshare-api.specs.public-file :refer :all]
            [figshare-api.specs.upload-file-part :refer :all]
            [figshare-api.specs.collection-versions :refer :all]
            [figshare-api.specs.create-o-auth-token :refer :all]
            [figshare-api.specs.confidentiality-creator :refer :all]
            [figshare-api.specs.article-update :refer :all]
            [figshare-api.specs.collection-update :refer :all]
            [figshare-api.specs.profile-update-data :refer :all]
            [figshare-api.specs.private-article-search :refer :all]
            [figshare-api.specs.article-confidentiality :refer :all]
            [figshare-api.specs.curation-comment-create :refer :all]
            [figshare-api.specs.location-warnings-update :refer :all]
            [figshare-api.specs.short-custom-field :refer :all]
            [figshare-api.specs.project-note-create :refer :all]
            [figshare-api.specs.curation :refer :all]
            [figshare-api.specs.group-embargo-options :refer :all]
            [figshare-api.specs.private-collection-search :refer :all]
            [figshare-api.specs.private-link :refer :all]
            [figshare-api.specs.article-version-update :refer :all]
            [figshare-api.specs.account-create :refer :all]
            [figshare-api.specs.project-article :refer :all]
            [figshare-api.specs.project-update :refer :all]
            [figshare-api.specs.o-auth-token :refer :all]
            [figshare-api.specs.collection-doi :refer :all]
            [figshare-api.specs.location :refer :all]
            [figshare-api.specs.article-embargo-updater :refer :all]
            [figshare-api.specs.category :refer :all]
            [figshare-api.specs.common-search :refer :all]
            [figshare-api.specs.user :refer :all]
            [figshare-api.specs.account :refer :all]
            )
  (:import (java.io File)))


(defn-spec account-article-publish-with-http-info any?
  "Private Article Publish
  - If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted.
- When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed."
  [article_id int?]
  (check-required-params article_id)
  (call-api "/account/articles/{article_id}/publish" :post
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec account-article-publish location-spec
  "Private Article Publish
  - If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted.
- When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed."
  [article_id int?]
  (let [res (:data (account-article-publish-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode location-spec res st/string-transformer)
       res)))


(defn-spec account-article-report-with-http-info any?
  "Account Article Report
  Return status on all reports generated for the account from the oauth credentials"
  ([] (account-article-report-with-http-info nil))
  ([{:keys [group_id]} (s/map-of keyword? any?)]
   (call-api "/account/articles/export" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"group_id" group_id }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec account-article-report (s/coll-of account-report-spec)
  "Account Article Report
  Return status on all reports generated for the account from the oauth credentials"
  ([] (account-article-report nil))
  ([optional-params any?]
   (let [res (:data (account-article-report-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of account-report-spec) res st/string-transformer)
        res))))


(defn-spec account-article-report-generate-with-http-info any?
  "Initiate a new Report
  Initiate a new Article Report for this Account. There is a limit of 1 report per day."
  []
  (call-api "/account/articles/export" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec account-article-report-generate account-report-spec
  "Initiate a new Report
  Initiate a new Article Report for this Account. There is a limit of 1 report per day."
  []
  (let [res (:data (account-article-report-generate-with-http-info))]
    (if (:decode-models *api-context*)
       (st/decode account-report-spec res st/string-transformer)
       res)))


(defn-spec account-article-unpublish-with-http-info any?
  "Public Article Unpublish
  Allows authorized users to unpublish an article."
  [article_id int?, reason article-unpublish-data]
  (check-required-params article_id reason)
  (call-api "/account/articles/{article_id}/unpublish" :post
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    reason
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec account-article-unpublish any?
  "Public Article Unpublish
  Allows authorized users to unpublish an article."
  [article_id int?, reason article-unpublish-data]
  (let [res (:data (account-article-unpublish-with-http-info article_id reason))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec article-details-with-http-info any?
  "View article details
  View an article"
  [article_id int?]
  (check-required-params article_id)
  (call-api "/articles/{article_id}" :get
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec article-details article-complete-spec
  "View article details
  View an article"
  [article_id int?]
  (let [res (:data (article-details-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode article-complete-spec res st/string-transformer)
       res)))


(defn-spec article-file-details-with-http-info any?
  "Article file details
  File by id"
  [article_id int?, file_id int?]
  (check-required-params article_id file_id)
  (call-api "/articles/{article_id}/files/{file_id}" :get
            {:path-params   {"article_id" article_id "file_id" file_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec article-file-details public-file-spec
  "Article file details
  File by id"
  [article_id int?, file_id int?]
  (let [res (:data (article-file-details-with-http-info article_id file_id))]
    (if (:decode-models *api-context*)
       (st/decode public-file-spec res st/string-transformer)
       res)))


(defn-spec article-files-with-http-info any?
  "List article files
  Files list for article"
  ([article_id int?, ] (article-files-with-http-info article_id nil))
  ([article_id int?, {:keys [page page_size limit offset]} (s/map-of keyword? any?)]
   (check-required-params article_id)
   (call-api "/articles/{article_id}/files" :get
             {:path-params   {"article_id" article_id }
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn-spec article-files (s/coll-of public-file-spec)
  "List article files
  Files list for article"
  ([article_id int?, ] (article-files article_id nil))
  ([article_id int?, optional-params any?]
   (let [res (:data (article-files-with-http-info article_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of public-file-spec) res st/string-transformer)
        res))))


(defn-spec article-version-confidentiality-with-http-info any?
  "Public Article Confidentiality for article version
  Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article_id int?, version_id int?]
  (check-required-params article_id version_id)
  (call-api "/articles/{article_id}/versions/{version_id}/confidentiality" :get
            {:path-params   {"article_id" article_id "version_id" version_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec article-version-confidentiality article-confidentiality-spec
  "Public Article Confidentiality for article version
  Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article_id int?, version_id int?]
  (let [res (:data (article-version-confidentiality-with-http-info article_id version_id))]
    (if (:decode-models *api-context*)
       (st/decode article-confidentiality-spec res st/string-transformer)
       res)))


(defn-spec article-version-details-with-http-info any?
  "Article details for version
  Article with specified version"
  [article_id int?, version_id int?]
  (check-required-params article_id version_id)
  (call-api "/articles/{article_id}/versions/{version_id}" :get
            {:path-params   {"article_id" article_id "version_id" version_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec article-version-details article-complete-spec
  "Article details for version
  Article with specified version"
  [article_id int?, version_id int?]
  (let [res (:data (article-version-details-with-http-info article_id version_id))]
    (if (:decode-models *api-context*)
       (st/decode article-complete-spec res st/string-transformer)
       res)))


(defn-spec article-version-embargo-with-http-info any?
  "Public Article Embargo for article version
  Embargo for article version"
  [article_id int?, version_id int?]
  (check-required-params article_id version_id)
  (call-api "/articles/{article_id}/versions/{version_id}/embargo" :get
            {:path-params   {"article_id" article_id "version_id" version_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec article-version-embargo article-embargo-spec
  "Public Article Embargo for article version
  Embargo for article version"
  [article_id int?, version_id int?]
  (let [res (:data (article-version-embargo-with-http-info article_id version_id))]
    (if (:decode-models *api-context*)
       (st/decode article-embargo-spec res st/string-transformer)
       res)))


(defn-spec article-version-files-with-http-info any?
  "Public Article version files
  Article version file details"
  ([article_id int?, version_id int?, ] (article-version-files-with-http-info article_id version_id nil))
  ([article_id int?, version_id int?, {:keys [page page_size limit offset]} (s/map-of keyword? any?)]
   (check-required-params article_id version_id)
   (call-api "/articles/{article_id}/versions/{version_id}/files" :get
             {:path-params   {"article_id" article_id "version_id" version_id }
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn-spec article-version-files (s/coll-of public-file-spec)
  "Public Article version files
  Article version file details"
  ([article_id int?, version_id int?, ] (article-version-files article_id version_id nil))
  ([article_id int?, version_id int?, optional-params any?]
   (let [res (:data (article-version-files-with-http-info article_id version_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of public-file-spec) res st/string-transformer)
        res))))


(defn-spec article-version-partial-update-with-http-info any?
  "Partially update article version
  Partially updating an article version by passing only the fields to change."
  [article_id int?, version_id int?, Article article-version-update]
  (check-required-params article_id version_id Article)
  (call-api "/account/articles/{article_id}/versions/{version_id}" :patch
            {:path-params   {"article_id" article_id "version_id" version_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Article
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec article-version-partial-update location-warnings-update-spec
  "Partially update article version
  Partially updating an article version by passing only the fields to change."
  [article_id int?, version_id int?, Article article-version-update]
  (let [res (:data (article-version-partial-update-with-http-info article_id version_id Article))]
    (if (:decode-models *api-context*)
       (st/decode location-warnings-update-spec res st/string-transformer)
       res)))


(defn-spec article-version-update-with-http-info any?
  "Update article version
  Updating an article version by passing body parameters."
  [article_id int?, version_id int?, Article article-version-update]
  (check-required-params article_id version_id Article)
  (call-api "/account/articles/{article_id}/versions/{version_id}" :put
            {:path-params   {"article_id" article_id "version_id" version_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Article
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec article-version-update location-warnings-update-spec
  "Update article version
  Updating an article version by passing body parameters."
  [article_id int?, version_id int?, Article article-version-update]
  (let [res (:data (article-version-update-with-http-info article_id version_id Article))]
    (if (:decode-models *api-context*)
       (st/decode location-warnings-update-spec res st/string-transformer)
       res)))


(defn-spec article-version-update-thumb-with-http-info any?
  "Update article version thumbnail
  For a given public article version update the article thumbnail by choosing one of the associated files"
  [article_id int?, version_id int?, FileId file-id]
  (check-required-params article_id version_id FileId)
  (call-api "/account/articles/{article_id}/versions/{version_id}/update_thumb" :put
            {:path-params   {"article_id" article_id "version_id" version_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    FileId
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec article-version-update-thumb any?
  "Update article version thumbnail
  For a given public article version update the article thumbnail by choosing one of the associated files"
  [article_id int?, version_id int?, FileId file-id]
  (let [res (:data (article-version-update-thumb-with-http-info article_id version_id FileId))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec article-versions-with-http-info any?
  "List article versions
  List public article versions"
  [article_id int?]
  (check-required-params article_id)
  (call-api "/articles/{article_id}/versions" :get
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec article-versions (s/coll-of article-versions-spec)
  "List article versions
  List public article versions"
  [article_id int?]
  (let [res (:data (article-versions-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of article-versions-spec) res st/string-transformer)
       res)))


(defn-spec articles-list-with-http-info any?
  "Public Articles
  Returns a list of public articles"
  ([] (articles-list-with-http-info nil))
  ([{:keys [X-Cursor page page_size limit offset order order_direction institution published_since modified_since group resource_doi item_type doi handle]} (s/map-of keyword? any?)]
   (call-api "/articles" :get
             {:path-params   {}
              :header-params {"X-Cursor" X-Cursor }
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset "order" order "order_direction" order_direction "institution" institution "published_since" published_since "modified_since" modified_since "group" group "resource_doi" resource_doi "item_type" item_type "doi" doi "handle" handle }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn-spec articles-list (s/coll-of article-spec)
  "Public Articles
  Returns a list of public articles"
  ([] (articles-list nil))
  ([optional-params any?]
   (let [res (:data (articles-list-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of article-spec) res st/string-transformer)
        res))))


(defn-spec articles-search-with-http-info any?
  "Public Articles Search
  Returns a list of public articles, filtered by the search parameters"
  ([] (articles-search-with-http-info nil))
  ([{:keys [X-Cursor search]} (s/map-of keyword? any?)]
   (call-api "/articles/search" :post
             {:path-params   {}
              :header-params {"X-Cursor" X-Cursor }
              :query-params  {}
              :form-params   {}
              :body-param    search
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    []})))

(defn-spec articles-search (s/coll-of article-with-project-spec)
  "Public Articles Search
  Returns a list of public articles, filtered by the search parameters"
  ([] (articles-search nil))
  ([optional-params any?]
   (let [res (:data (articles-search-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of article-with-project-spec) res st/string-transformer)
        res))))


(defn-spec private-article-author-delete-with-http-info any?
  "Delete article author
  De-associate author from article"
  [article_id int?, author_id int?]
  (check-required-params article_id author_id)
  (call-api "/account/articles/{article_id}/authors/{author_id}" :delete
            {:path-params   {"article_id" article_id "author_id" author_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-author-delete any?
  "Delete article author
  De-associate author from article"
  [article_id int?, author_id int?]
  (let [res (:data (private-article-author-delete-with-http-info article_id author_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-authors-add-with-http-info any?
  "Add article authors
  Associate new authors with the article. This will add new authors to the list of already associated authors"
  [article_id int?, Authors authors-creator]
  (check-required-params article_id Authors)
  (call-api "/account/articles/{article_id}/authors" :post
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Authors
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-authors-add any?
  "Add article authors
  Associate new authors with the article. This will add new authors to the list of already associated authors"
  [article_id int?, Authors authors-creator]
  (let [res (:data (private-article-authors-add-with-http-info article_id Authors))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-authors-list-with-http-info any?
  "List article authors
  List article authors"
  [article_id int?]
  (check-required-params article_id)
  (call-api "/account/articles/{article_id}/authors" :get
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-authors-list (s/coll-of author-spec)
  "List article authors
  List article authors"
  [article_id int?]
  (let [res (:data (private-article-authors-list-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of author-spec) res st/string-transformer)
       res)))


(defn-spec private-article-authors-replace-with-http-info any?
  "Replace article authors
  Associate new authors with the article. This will remove all already associated authors and add these new ones"
  [article_id int?, Authors authors-creator]
  (check-required-params article_id Authors)
  (call-api "/account/articles/{article_id}/authors" :put
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Authors
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-authors-replace any?
  "Replace article authors
  Associate new authors with the article. This will remove all already associated authors and add these new ones"
  [article_id int?, Authors authors-creator]
  (let [res (:data (private-article-authors-replace-with-http-info article_id Authors))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-categories-add-with-http-info any?
  "Add article categories
  Associate new categories with the article. This will add new categories to the list of already associated categories"
  [article_id int?, categories categories-creator]
  (check-required-params article_id categories)
  (call-api "/account/articles/{article_id}/categories" :post
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    categories
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-categories-add any?
  "Add article categories
  Associate new categories with the article. This will add new categories to the list of already associated categories"
  [article_id int?, categories categories-creator]
  (let [res (:data (private-article-categories-add-with-http-info article_id categories))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-categories-list-with-http-info any?
  "List article categories
  List article categories"
  [article_id int?]
  (check-required-params article_id)
  (call-api "/account/articles/{article_id}/categories" :get
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-categories-list (s/coll-of category-spec)
  "List article categories
  List article categories"
  [article_id int?]
  (let [res (:data (private-article-categories-list-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of category-spec) res st/string-transformer)
       res)))


(defn-spec private-article-categories-replace-with-http-info any?
  "Replace article categories
  Associate new categories with the article. This will remove all already associated categories and add these new ones"
  [article_id int?, categories categories-creator]
  (check-required-params article_id categories)
  (call-api "/account/articles/{article_id}/categories" :put
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    categories
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-categories-replace any?
  "Replace article categories
  Associate new categories with the article. This will remove all already associated categories and add these new ones"
  [article_id int?, categories categories-creator]
  (let [res (:data (private-article-categories-replace-with-http-info article_id categories))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-category-delete-with-http-info any?
  "Delete article category
  De-associate category from article"
  [article_id int?, category_id int?]
  (check-required-params article_id category_id)
  (call-api "/account/articles/{article_id}/categories/{category_id}" :delete
            {:path-params   {"article_id" article_id "category_id" category_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-category-delete any?
  "Delete article category
  De-associate category from article"
  [article_id int?, category_id int?]
  (let [res (:data (private-article-category-delete-with-http-info article_id category_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-confidentiality-delete-with-http-info any?
  "Delete article confidentiality
  Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article_id int?]
  (check-required-params article_id)
  (call-api "/account/articles/{article_id}/confidentiality" :delete
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-confidentiality-delete any?
  "Delete article confidentiality
  Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article_id int?]
  (let [res (:data (private-article-confidentiality-delete-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-confidentiality-details-with-http-info any?
  "Article confidentiality details
  View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article_id int?]
  (check-required-params article_id)
  (call-api "/account/articles/{article_id}/confidentiality" :get
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-confidentiality-details article-confidentiality-spec
  "Article confidentiality details
  View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article_id int?]
  (let [res (:data (private-article-confidentiality-details-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode article-confidentiality-spec res st/string-transformer)
       res)))


(defn-spec private-article-confidentiality-update-with-http-info any?
  "Update article confidentiality
  Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article_id int?, reason confidentiality-creator]
  (check-required-params article_id reason)
  (call-api "/account/articles/{article_id}/confidentiality" :put
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    reason
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-confidentiality-update any?
  "Update article confidentiality
  Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows."
  [article_id int?, reason confidentiality-creator]
  (let [res (:data (private-article-confidentiality-update-with-http-info article_id reason))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-create-with-http-info any?
  "Create new Article
  Create a new Article by sending article information"
  [Article article-create]
  (check-required-params Article)
  (call-api "/account/articles" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Article
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-create location-warnings-spec
  "Create new Article
  Create a new Article by sending article information"
  [Article article-create]
  (let [res (:data (private-article-create-with-http-info Article))]
    (if (:decode-models *api-context*)
       (st/decode location-warnings-spec res st/string-transformer)
       res)))


(defn-spec private-article-delete-with-http-info any?
  "Delete article
  Delete an article"
  [article_id int?]
  (check-required-params article_id)
  (call-api "/account/articles/{article_id}" :delete
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-delete any?
  "Delete article
  Delete an article"
  [article_id int?]
  (let [res (:data (private-article-delete-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-details-with-http-info any?
  "Article details
  View a private article"
  [article_id int?]
  (check-required-params article_id)
  (call-api "/account/articles/{article_id}" :get
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-details article-complete-private-spec
  "Article details
  View a private article"
  [article_id int?]
  (let [res (:data (private-article-details-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode article-complete-private-spec res st/string-transformer)
       res)))


(defn-spec private-article-download-with-http-info any?
  "Private Article Download
  Download files from a private article preserving the folder structure"
  ([article_id int?, ] (private-article-download-with-http-info article_id nil))
  ([article_id int?, {:keys [folder_path]} (s/map-of keyword? any?)]
   (check-required-params article_id)
   (call-api "/account/articles/{article_id}/download" :get
             {:path-params   {"article_id" article_id }
              :header-params {}
              :query-params  {"folder_path" folder_path }
              :form-params   {}
              :content-types []
              :accepts       []
              :auth-names    ["OAuth2"]})))

(defn-spec private-article-download any?
  "Private Article Download
  Download files from a private article preserving the folder structure"
  ([article_id int?, ] (private-article-download article_id nil))
  ([article_id int?, optional-params any?]
   (let [res (:data (private-article-download-with-http-info article_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode any? res st/string-transformer)
        res))))


(defn-spec private-article-embargo-delete-with-http-info any?
  "Delete Article Embargo
  Will lift the embargo for the specified article"
  [article_id int?]
  (check-required-params article_id)
  (call-api "/account/articles/{article_id}/embargo" :delete
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-embargo-delete any?
  "Delete Article Embargo
  Will lift the embargo for the specified article"
  [article_id int?]
  (let [res (:data (private-article-embargo-delete-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-embargo-details-with-http-info any?
  "Article Embargo Details
  View a private article embargo details"
  [article_id int?]
  (check-required-params article_id)
  (call-api "/account/articles/{article_id}/embargo" :get
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-embargo-details article-embargo-spec
  "Article Embargo Details
  View a private article embargo details"
  [article_id int?]
  (let [res (:data (private-article-embargo-details-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode article-embargo-spec res st/string-transformer)
       res)))


(defn-spec private-article-embargo-update-with-http-info any?
  "Update Article Embargo
  Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality."
  [article_id int?, Embargo article-embargo-updater]
  (check-required-params article_id Embargo)
  (call-api "/account/articles/{article_id}/embargo" :put
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Embargo
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-embargo-update any?
  "Update Article Embargo
  Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality."
  [article_id int?, Embargo article-embargo-updater]
  (let [res (:data (private-article-embargo-update-with-http-info article_id Embargo))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-file-with-http-info any?
  "Single File
  View details of file for specified article"
  [article_id int?, file_id int?]
  (check-required-params article_id file_id)
  (call-api "/account/articles/{article_id}/files/{file_id}" :get
            {:path-params   {"article_id" article_id "file_id" file_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-file private-file-spec
  "Single File
  View details of file for specified article"
  [article_id int?, file_id int?]
  (let [res (:data (private-article-file-with-http-info article_id file_id))]
    (if (:decode-models *api-context*)
       (st/decode private-file-spec res st/string-transformer)
       res)))


(defn-spec private-article-file-delete-with-http-info any?
  "File Delete
  Complete file upload"
  [article_id int?, file_id int?]
  (check-required-params article_id file_id)
  (call-api "/account/articles/{article_id}/files/{file_id}" :delete
            {:path-params   {"article_id" article_id "file_id" file_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-file-delete any?
  "File Delete
  Complete file upload"
  [article_id int?, file_id int?]
  (let [res (:data (private-article-file-delete-with-http-info article_id file_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-files-list-with-http-info any?
  "List article files
  List private files"
  ([article_id int?, ] (private-article-files-list-with-http-info article_id nil))
  ([article_id int?, {:keys [page page_size limit offset]} (s/map-of keyword? any?)]
   (check-required-params article_id)
   (call-api "/account/articles/{article_id}/files" :get
             {:path-params   {"article_id" article_id }
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-article-files-list (s/coll-of private-file-spec)
  "List article files
  List private files"
  ([article_id int?, ] (private-article-files-list article_id nil))
  ([article_id int?, optional-params any?]
   (let [res (:data (private-article-files-list-with-http-info article_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of private-file-spec) res st/string-transformer)
        res))))


(defn-spec private-article-partial-update-with-http-info any?
  "Partially update article
  Partially update an article by sending only the fields to change."
  [article_id int?, Article article-update]
  (check-required-params article_id Article)
  (call-api "/account/articles/{article_id}" :patch
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Article
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-partial-update location-warnings-update-spec
  "Partially update article
  Partially update an article by sending only the fields to change."
  [article_id int?, Article article-update]
  (let [res (:data (private-article-partial-update-with-http-info article_id Article))]
    (if (:decode-models *api-context*)
       (st/decode location-warnings-update-spec res st/string-transformer)
       res)))


(defn-spec private-article-private-link-with-http-info any?
  "List private links
  List private links"
  [article_id int?]
  (check-required-params article_id)
  (call-api "/account/articles/{article_id}/private_links" :get
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-private-link (s/coll-of private-link-spec)
  "List private links
  List private links"
  [article_id int?]
  (let [res (:data (private-article-private-link-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of private-link-spec) res st/string-transformer)
       res)))


(defn-spec private-article-private-link-create-with-http-info any?
  "Create private link
  Create new private link for this article"
  ([article_id int?, ] (private-article-private-link-create-with-http-info article_id nil))
  ([article_id int?, {:keys [private_link]} (s/map-of keyword? any?)]
   (check-required-params article_id)
   (call-api "/account/articles/{article_id}/private_links" :post
             {:path-params   {"article_id" article_id }
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    private_link
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-article-private-link-create private-link-response-spec
  "Create private link
  Create new private link for this article"
  ([article_id int?, ] (private-article-private-link-create article_id nil))
  ([article_id int?, optional-params any?]
   (let [res (:data (private-article-private-link-create-with-http-info article_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode private-link-response-spec res st/string-transformer)
        res))))


(defn-spec private-article-private-link-delete-with-http-info any?
  "Disable private link
  Disable/delete private link for this article"
  [article_id int?, link_id string?]
  (check-required-params article_id link_id)
  (call-api "/account/articles/{article_id}/private_links/{link_id}" :delete
            {:path-params   {"article_id" article_id "link_id" link_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-private-link-delete any?
  "Disable private link
  Disable/delete private link for this article"
  [article_id int?, link_id string?]
  (let [res (:data (private-article-private-link-delete-with-http-info article_id link_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-private-link-update-with-http-info any?
  "Update private link
  Update existing private link for this article"
  ([article_id int?, link_id string?, ] (private-article-private-link-update-with-http-info article_id link_id nil))
  ([article_id int?, link_id string?, {:keys [private_link]} (s/map-of keyword? any?)]
   (check-required-params article_id link_id)
   (call-api "/account/articles/{article_id}/private_links/{link_id}" :put
             {:path-params   {"article_id" article_id "link_id" link_id }
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    private_link
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-article-private-link-update any?
  "Update private link
  Update existing private link for this article"
  ([article_id int?, link_id string?, ] (private-article-private-link-update article_id link_id nil))
  ([article_id int?, link_id string?, optional-params any?]
   (let [res (:data (private-article-private-link-update-with-http-info article_id link_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode any? res st/string-transformer)
        res))))


(defn-spec private-article-reserve-doi-with-http-info any?
  "Private Article Reserve DOI
  Reserve DOI for article"
  [article_id int?]
  (check-required-params article_id)
  (call-api "/account/articles/{article_id}/reserve_doi" :post
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-reserve-doi article-doi-spec
  "Private Article Reserve DOI
  Reserve DOI for article"
  [article_id int?]
  (let [res (:data (private-article-reserve-doi-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode article-doi-spec res st/string-transformer)
       res)))


(defn-spec private-article-reserve-handle-with-http-info any?
  "Private Article Reserve Handle
  Reserve Handle for article"
  [article_id int?]
  (check-required-params article_id)
  (call-api "/account/articles/{article_id}/reserve_handle" :post
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-reserve-handle article-handle-spec
  "Private Article Reserve Handle
  Reserve Handle for article"
  [article_id int?]
  (let [res (:data (private-article-reserve-handle-with-http-info article_id))]
    (if (:decode-models *api-context*)
       (st/decode article-handle-spec res st/string-transformer)
       res)))


(defn-spec private-article-resource-with-http-info any?
  "Private Article Resource
  Edit article resource data."
  [article_id int?, Resource resource]
  (check-required-params article_id Resource)
  (call-api "/account/articles/{article_id}/resource" :post
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Resource
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-resource location-spec
  "Private Article Resource
  Edit article resource data."
  [article_id int?, Resource resource]
  (let [res (:data (private-article-resource-with-http-info article_id Resource))]
    (if (:decode-models *api-context*)
       (st/decode location-spec res st/string-transformer)
       res)))


(defn-spec private-article-update-with-http-info any?
  "Update article
  Update an article by passing full body parameters."
  [article_id int?, Article article-update]
  (check-required-params article_id Article)
  (call-api "/account/articles/{article_id}" :put
            {:path-params   {"article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Article
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-update location-warnings-update-spec
  "Update article
  Update an article by passing full body parameters."
  [article_id int?, Article article-update]
  (let [res (:data (private-article-update-with-http-info article_id Article))]
    (if (:decode-models *api-context*)
       (st/decode location-warnings-update-spec res st/string-transformer)
       res)))


(defn-spec private-article-upload-complete-with-http-info any?
  "Complete Upload
  Complete file upload"
  [article_id int?, file_id int?]
  (check-required-params article_id file_id)
  (call-api "/account/articles/{article_id}/files/{file_id}" :post
            {:path-params   {"article_id" article_id "file_id" file_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-article-upload-complete any?
  "Complete Upload
  Complete file upload"
  [article_id int?, file_id int?]
  (let [res (:data (private-article-upload-complete-with-http-info article_id file_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-article-upload-initiate-with-http-info any?
  "Initiate Upload
  Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size)."
  ([article_id int?, File file-creator, ] (private-article-upload-initiate-with-http-info article_id File nil))
  ([article_id int?, File file-creator, {:keys [page page_size limit offset]} (s/map-of keyword? any?)]
   (check-required-params article_id File)
   (call-api "/account/articles/{article_id}/files" :post
             {:path-params   {"article_id" article_id }
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset }
              :form-params   {}
              :body-param    File
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-article-upload-initiate location-spec
  "Initiate Upload
  Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size)."
  ([article_id int?, File file-creator, ] (private-article-upload-initiate article_id File nil))
  ([article_id int?, File file-creator, optional-params any?]
   (let [res (:data (private-article-upload-initiate-with-http-info article_id File optional-params))]
     (if (:decode-models *api-context*)
        (st/decode location-spec res st/string-transformer)
        res))))


(defn-spec private-articles-list-with-http-info any?
  "Private Articles
  Get Own Articles"
  ([] (private-articles-list-with-http-info nil))
  ([{:keys [page page_size limit offset]} (s/map-of keyword? any?)]
   (call-api "/account/articles" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-articles-list (s/coll-of article-spec)
  "Private Articles
  Get Own Articles"
  ([] (private-articles-list nil))
  ([optional-params any?]
   (let [res (:data (private-articles-list-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of article-spec) res st/string-transformer)
        res))))


(defn-spec private-articles-search-with-http-info any?
  "Private Articles search
  Returns a list of private articles filtered by the search parameters"
  [search private-article-search]
  (check-required-params search)
  (call-api "/account/articles/search" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    search
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-articles-search (s/coll-of article-with-project-spec)
  "Private Articles search
  Returns a list of private articles filtered by the search parameters"
  [search private-article-search]
  (let [res (:data (private-articles-search-with-http-info search))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of article-with-project-spec) res st/string-transformer)
       res)))


(defn-spec public-article-download-with-http-info any?
  "Public Article Download
  Download files from a public article preserving the folder structure"
  ([article_id int?, ] (public-article-download-with-http-info article_id nil))
  ([article_id int?, {:keys [folder_path]} (s/map-of keyword? any?)]
   (check-required-params article_id)
   (call-api "/articles/{article_id}/download" :get
             {:path-params   {"article_id" article_id }
              :header-params {}
              :query-params  {"folder_path" folder_path }
              :form-params   {}
              :content-types []
              :accepts       []
              :auth-names    []})))

(defn-spec public-article-download any?
  "Public Article Download
  Download files from a public article preserving the folder structure"
  ([article_id int?, ] (public-article-download article_id nil))
  ([article_id int?, optional-params any?]
   (let [res (:data (public-article-download-with-http-info article_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode any? res st/string-transformer)
        res))))


(defn-spec public-article-version-download-with-http-info any?
  "Public Article Version Download
  Download files from a certain version of an public article preserving the folder structure"
  ([article_id int?, version_id int?, ] (public-article-version-download-with-http-info article_id version_id nil))
  ([article_id int?, version_id int?, {:keys [folder_path]} (s/map-of keyword? any?)]
   (check-required-params article_id version_id)
   (call-api "/articles/{article_id}/versions/{version_id}/download" :get
             {:path-params   {"article_id" article_id "version_id" version_id }
              :header-params {}
              :query-params  {"folder_path" folder_path }
              :form-params   {}
              :content-types []
              :accepts       []
              :auth-names    []})))

(defn-spec public-article-version-download any?
  "Public Article Version Download
  Download files from a certain version of an public article preserving the folder structure"
  ([article_id int?, version_id int?, ] (public-article-version-download article_id version_id nil))
  ([article_id int?, version_id int?, optional-params any?]
   (let [res (:data (public-article-version-download-with-http-info article_id version_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode any? res st/string-transformer)
        res))))


