(ns figshare-api.api.projects
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format *api-context*]]
            [clojure.spec.alpha :as s]
            [spec-tools.core :as st]
            [orchestra.core :refer [defn-spec]]
            [figshare-api.specs.custom-article-field :refer :all]
            [figshare-api.specs.file-id :refer :all]
            [figshare-api.specs.project-collaborator-invite :refer :all]
            [figshare-api.specs.projects-search :refer :all]
            [figshare-api.specs.funding-search :refer :all]
            [figshare-api.specs.project-collaborator :refer :all]
            [figshare-api.specs.profile-update-data-personal-profiles-inner :refer :all]
            [figshare-api.specs.custom-article-field-add :refer :all]
            [figshare-api.specs.author-complete :refer :all]
            [figshare-api.specs.collaborator :refer :all]
            [figshare-api.specs.project-note-private :refer :all]
            [figshare-api.specs.private-link-response :refer :all]
            [figshare-api.specs.item-type :refer :all]
            [figshare-api.specs.location-warnings :refer :all]
            [figshare-api.specs.article-create :refer :all]
            [figshare-api.specs.project-note :refer :all]
            [figshare-api.specs.institution-accounts-search :refer :all]
            [figshare-api.specs.funding-create :refer :all]
            [figshare-api.specs.collection-handle :refer :all]
            [figshare-api.specs.authors-creator :refer :all]
            [figshare-api.specs.article-embargo :refer :all]
            [figshare-api.specs.error-message :refer :all]
            [figshare-api.specs.collection-private-link-creator :refer :all]
            [figshare-api.specs.response-message :refer :all]
            [figshare-api.specs.project-create :refer :all]
            [figshare-api.specs.timeline-update :refer :all]
            [figshare-api.specs.project-complete-private :refer :all]
            [figshare-api.specs.role :refer :all]
            [figshare-api.specs.article-project-create :refer :all]
            [figshare-api.specs.funding-information :refer :all]
            [figshare-api.specs.upload-info :refer :all]
            [figshare-api.specs.article-doi :refer :all]
            [figshare-api.specs.project-private :refer :all]
            [figshare-api.specs.private-project-article :refer :all]
            [figshare-api.specs.project-complete :refer :all]
            [figshare-api.specs.article-search :refer :all]
            [figshare-api.specs.account-update :refer :all]
            [figshare-api.specs.category-list :refer :all]
            [figshare-api.specs.private-file :refer :all]
            [figshare-api.specs.collection-complete :refer :all]
            [figshare-api.specs.private-authors-search :refer :all]
            [figshare-api.specs.timeline :refer :all]
            [figshare-api.specs.categories-creator :refer :all]
            [figshare-api.specs.account-report :refer :all]
            [figshare-api.specs.article-unpublish-data :refer :all]
            [figshare-api.specs.article-versions :refer :all]
            [figshare-api.specs.collection-create :refer :all]
            [figshare-api.specs.project :refer :all]
            [figshare-api.specs.related-material :refer :all]
            [figshare-api.specs.institution :refer :all]
            [figshare-api.specs.short-account :refer :all]
            [figshare-api.specs.curation-detail :refer :all]
            [figshare-api.specs.article-handle :refer :all]
            [figshare-api.specs.article-complete :refer :all]
            [figshare-api.specs.article-complete-private :refer :all]
            [figshare-api.specs.article-with-project :refer :all]
            [figshare-api.specs.articles-creator :refer :all]
            [figshare-api.specs.group :refer :all]
            [figshare-api.specs.collection-search :refer :all]
            [figshare-api.specs.account-create-response :refer :all]
            [figshare-api.specs.create-project-response :refer :all]
            [figshare-api.specs.resource :refer :all]
            [figshare-api.specs.author :refer :all]
            [figshare-api.specs.collection-complete-private :refer :all]
            [figshare-api.specs.curation-comment :refer :all]
            [figshare-api.specs.collection :refer :all]
            [figshare-api.specs.article :refer :all]
            [figshare-api.specs.file-creator :refer :all]
            [figshare-api.specs.license :refer :all]
            [figshare-api.specs.private-link-creator :refer :all]
            [figshare-api.specs.public-file :refer :all]
            [figshare-api.specs.upload-file-part :refer :all]
            [figshare-api.specs.collection-versions :refer :all]
            [figshare-api.specs.create-o-auth-token :refer :all]
            [figshare-api.specs.confidentiality-creator :refer :all]
            [figshare-api.specs.article-update :refer :all]
            [figshare-api.specs.collection-update :refer :all]
            [figshare-api.specs.profile-update-data :refer :all]
            [figshare-api.specs.private-article-search :refer :all]
            [figshare-api.specs.article-confidentiality :refer :all]
            [figshare-api.specs.curation-comment-create :refer :all]
            [figshare-api.specs.location-warnings-update :refer :all]
            [figshare-api.specs.short-custom-field :refer :all]
            [figshare-api.specs.project-note-create :refer :all]
            [figshare-api.specs.curation :refer :all]
            [figshare-api.specs.group-embargo-options :refer :all]
            [figshare-api.specs.private-collection-search :refer :all]
            [figshare-api.specs.private-link :refer :all]
            [figshare-api.specs.article-version-update :refer :all]
            [figshare-api.specs.account-create :refer :all]
            [figshare-api.specs.project-article :refer :all]
            [figshare-api.specs.project-update :refer :all]
            [figshare-api.specs.o-auth-token :refer :all]
            [figshare-api.specs.collection-doi :refer :all]
            [figshare-api.specs.location :refer :all]
            [figshare-api.specs.article-embargo-updater :refer :all]
            [figshare-api.specs.category :refer :all]
            [figshare-api.specs.common-search :refer :all]
            [figshare-api.specs.user :refer :all]
            [figshare-api.specs.account :refer :all]
            )
  (:import (java.io File)))


(defn-spec private-project-article-delete-with-http-info any?
  "Delete project article
  Delete project article"
  [project_id int?, article_id int?]
  (check-required-params project_id article_id)
  (call-api "/account/projects/{project_id}/articles/{article_id}" :delete
            {:path-params   {"project_id" project_id "article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-article-delete any?
  "Delete project article
  Delete project article"
  [project_id int?, article_id int?]
  (let [res (:data (private-project-article-delete-with-http-info project_id article_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-project-article-details-with-http-info any?
  "Project article details
  Project article details"
  [project_id int?, article_id int?]
  (check-required-params project_id article_id)
  (call-api "/account/projects/{project_id}/articles/{article_id}" :get
            {:path-params   {"project_id" project_id "article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-article-details article-complete-private-spec
  "Project article details
  Project article details"
  [project_id int?, article_id int?]
  (let [res (:data (private-project-article-details-with-http-info project_id article_id))]
    (if (:decode-models *api-context*)
       (st/decode article-complete-private-spec res st/string-transformer)
       res)))


(defn-spec private-project-article-file-with-http-info any?
  "Project article file details
  Project article file details"
  [project_id int?, article_id int?, file_id int?]
  (check-required-params project_id article_id file_id)
  (call-api "/account/projects/{project_id}/articles/{article_id}/files/{file_id}" :get
            {:path-params   {"project_id" project_id "article_id" article_id "file_id" file_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-article-file private-file-spec
  "Project article file details
  Project article file details"
  [project_id int?, article_id int?, file_id int?]
  (let [res (:data (private-project-article-file-with-http-info project_id article_id file_id))]
    (if (:decode-models *api-context*)
       (st/decode private-file-spec res st/string-transformer)
       res)))


(defn-spec private-project-article-files-with-http-info any?
  "Project article list files
  List article files"
  [project_id int?, article_id int?]
  (check-required-params project_id article_id)
  (call-api "/account/projects/{project_id}/articles/{article_id}/files" :get
            {:path-params   {"project_id" project_id "article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-article-files (s/coll-of private-file-spec)
  "Project article list files
  List article files"
  [project_id int?, article_id int?]
  (let [res (:data (private-project-article-files-with-http-info project_id article_id))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of private-file-spec) res st/string-transformer)
       res)))


(defn-spec private-project-articles-create-with-http-info any?
  "Create project article
  Create a new Article and associate it with this project"
  [project_id int?, Article article-project-create]
  (check-required-params project_id Article)
  (call-api "/account/projects/{project_id}/articles" :post
            {:path-params   {"project_id" project_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Article
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-articles-create location-spec
  "Create project article
  Create a new Article and associate it with this project"
  [project_id int?, Article article-project-create]
  (let [res (:data (private-project-articles-create-with-http-info project_id Article))]
    (if (:decode-models *api-context*)
       (st/decode location-spec res st/string-transformer)
       res)))


(defn-spec private-project-articles-list-with-http-info any?
  "List project articles
  List project articles"
  [project_id int?]
  (check-required-params project_id)
  (call-api "/account/projects/{project_id}/articles" :get
            {:path-params   {"project_id" project_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-articles-list (s/coll-of article-spec)
  "List project articles
  List project articles"
  [project_id int?]
  (let [res (:data (private-project-articles-list-with-http-info project_id))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of article-spec) res st/string-transformer)
       res)))


(defn-spec private-project-collaborator-delete-with-http-info any?
  "Remove project collaborator
  Remove project collaborator"
  [project_id int?, user_id int?]
  (check-required-params project_id user_id)
  (call-api "/account/projects/{project_id}/collaborators/{user_id}" :delete
            {:path-params   {"project_id" project_id "user_id" user_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-collaborator-delete any?
  "Remove project collaborator
  Remove project collaborator"
  [project_id int?, user_id int?]
  (let [res (:data (private-project-collaborator-delete-with-http-info project_id user_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-project-collaborators-invite-with-http-info any?
  "Invite project collaborators
  Invite users to collaborate on project or view the project"
  [project_id int?, Collaborator project-collaborator-invite]
  (check-required-params project_id Collaborator)
  (call-api "/account/projects/{project_id}/collaborators" :post
            {:path-params   {"project_id" project_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Collaborator
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-collaborators-invite response-message-spec
  "Invite project collaborators
  Invite users to collaborate on project or view the project"
  [project_id int?, Collaborator project-collaborator-invite]
  (let [res (:data (private-project-collaborators-invite-with-http-info project_id Collaborator))]
    (if (:decode-models *api-context*)
       (st/decode response-message-spec res st/string-transformer)
       res)))


(defn-spec private-project-collaborators-list-with-http-info any?
  "List project collaborators
  List Project collaborators and invited users"
  [project_id int?]
  (check-required-params project_id)
  (call-api "/account/projects/{project_id}/collaborators" :get
            {:path-params   {"project_id" project_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-collaborators-list (s/coll-of project-collaborator-spec)
  "List project collaborators
  List Project collaborators and invited users"
  [project_id int?]
  (let [res (:data (private-project-collaborators-list-with-http-info project_id))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of project-collaborator-spec) res st/string-transformer)
       res)))


(defn-spec private-project-create-with-http-info any?
  "Create project
  Create a new project"
  [Project project-create]
  (check-required-params Project)
  (call-api "/account/projects" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Project
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-create create-project-response-spec
  "Create project
  Create a new project"
  [Project project-create]
  (let [res (:data (private-project-create-with-http-info Project))]
    (if (:decode-models *api-context*)
       (st/decode create-project-response-spec res st/string-transformer)
       res)))


(defn-spec private-project-delete-with-http-info any?
  "Delete project
  A project can be deleted only if: - it is not public - it does not have public articles.

When an individual project is deleted, all the articles are moved to my data of each owner.

When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project."
  [project_id int?]
  (check-required-params project_id)
  (call-api "/account/projects/{project_id}" :delete
            {:path-params   {"project_id" project_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-delete any?
  "Delete project
  A project can be deleted only if: - it is not public - it does not have public articles.

When an individual project is deleted, all the articles are moved to my data of each owner.

When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project."
  [project_id int?]
  (let [res (:data (private-project-delete-with-http-info project_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-project-details-with-http-info any?
  "View project details
  View a private project"
  [project_id int?]
  (check-required-params project_id)
  (call-api "/account/projects/{project_id}" :get
            {:path-params   {"project_id" project_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-details project-complete-private-spec
  "View project details
  View a private project"
  [project_id int?]
  (let [res (:data (private-project-details-with-http-info project_id))]
    (if (:decode-models *api-context*)
       (st/decode project-complete-private-spec res st/string-transformer)
       res)))


(defn-spec private-project-leave-with-http-info any?
  "Private Project Leave
  Please note: project's owner cannot leave the project."
  [project_id int?]
  (check-required-params project_id)
  (call-api "/account/projects/{project_id}/leave" :post
            {:path-params   {"project_id" project_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-leave any?
  "Private Project Leave
  Please note: project's owner cannot leave the project."
  [project_id int?]
  (let [res (:data (private-project-leave-with-http-info project_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-project-note-with-http-info any?
  "Project note details"
  [project_id int?, note_id int?]
  (check-required-params project_id note_id)
  (call-api "/account/projects/{project_id}/notes/{note_id}" :get
            {:path-params   {"project_id" project_id "note_id" note_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-note project-note-private-spec
  "Project note details"
  [project_id int?, note_id int?]
  (let [res (:data (private-project-note-with-http-info project_id note_id))]
    (if (:decode-models *api-context*)
       (st/decode project-note-private-spec res st/string-transformer)
       res)))


(defn-spec private-project-note-delete-with-http-info any?
  "Delete project note"
  [project_id int?, note_id int?]
  (check-required-params project_id note_id)
  (call-api "/account/projects/{project_id}/notes/{note_id}" :delete
            {:path-params   {"project_id" project_id "note_id" note_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-note-delete any?
  "Delete project note"
  [project_id int?, note_id int?]
  (let [res (:data (private-project-note-delete-with-http-info project_id note_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-project-note-update-with-http-info any?
  "Update project note"
  [project_id int?, note_id int?, Note project-note-create]
  (check-required-params project_id note_id Note)
  (call-api "/account/projects/{project_id}/notes/{note_id}" :put
            {:path-params   {"project_id" project_id "note_id" note_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Note
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-note-update any?
  "Update project note"
  [project_id int?, note_id int?, Note project-note-create]
  (let [res (:data (private-project-note-update-with-http-info project_id note_id Note))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-project-notes-create-with-http-info any?
  "Create project note
  Create a new project note"
  [project_id int?, Note project-note-create]
  (check-required-params project_id Note)
  (call-api "/account/projects/{project_id}/notes" :post
            {:path-params   {"project_id" project_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Note
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-notes-create location-spec
  "Create project note
  Create a new project note"
  [project_id int?, Note project-note-create]
  (let [res (:data (private-project-notes-create-with-http-info project_id Note))]
    (if (:decode-models *api-context*)
       (st/decode location-spec res st/string-transformer)
       res)))


(defn-spec private-project-notes-list-with-http-info any?
  "List project notes
  List project notes"
  ([project_id int?, ] (private-project-notes-list-with-http-info project_id nil))
  ([project_id int?, {:keys [page page_size limit offset]} (s/map-of keyword? any?)]
   (check-required-params project_id)
   (call-api "/account/projects/{project_id}/notes" :get
             {:path-params   {"project_id" project_id }
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-project-notes-list (s/coll-of project-note-spec)
  "List project notes
  List project notes"
  ([project_id int?, ] (private-project-notes-list project_id nil))
  ([project_id int?, optional-params any?]
   (let [res (:data (private-project-notes-list-with-http-info project_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of project-note-spec) res st/string-transformer)
        res))))


(defn-spec private-project-partial-update-with-http-info any?
  "Partially update project
  Partially update a project; only provided fields will be changed."
  ([project_id int?, ] (private-project-partial-update-with-http-info project_id nil))
  ([project_id int?, {:keys [Project]} (s/map-of keyword? any?)]
   (check-required-params project_id)
   (call-api "/account/projects/{project_id}" :patch
             {:path-params   {"project_id" project_id }
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    Project
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-project-partial-update any?
  "Partially update project
  Partially update a project; only provided fields will be changed."
  ([project_id int?, ] (private-project-partial-update project_id nil))
  ([project_id int?, optional-params any?]
   (let [res (:data (private-project-partial-update-with-http-info project_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode any? res st/string-transformer)
        res))))


(defn-spec private-project-publish-with-http-info any?
  "Private Project Publish
  Publish a project. Possible after all items inside it are public"
  [project_id int?]
  (check-required-params project_id)
  (call-api "/account/projects/{project_id}/publish" :post
            {:path-params   {"project_id" project_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-publish response-message-spec
  "Private Project Publish
  Publish a project. Possible after all items inside it are public"
  [project_id int?]
  (let [res (:data (private-project-publish-with-http-info project_id))]
    (if (:decode-models *api-context*)
       (st/decode response-message-spec res st/string-transformer)
       res)))


(defn-spec private-project-update-with-http-info any?
  "Update project
  Updating an project by passing body parameters."
  [project_id int?, Project project-update]
  (check-required-params project_id Project)
  (call-api "/account/projects/{project_id}" :put
            {:path-params   {"project_id" project_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Project
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-project-update any?
  "Update project
  Updating an project by passing body parameters."
  [project_id int?, Project project-update]
  (let [res (:data (private-project-update-with-http-info project_id Project))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-projects-list-with-http-info any?
  "Private Projects
  List private projects"
  ([] (private-projects-list-with-http-info nil))
  ([{:keys [page page_size limit offset order order_direction storage roles]} (s/map-of keyword? any?)]
   (call-api "/account/projects" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset "order" order "order_direction" order_direction "storage" storage "roles" roles }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-projects-list (s/coll-of project-private-spec)
  "Private Projects
  List private projects"
  ([] (private-projects-list nil))
  ([optional-params any?]
   (let [res (:data (private-projects-list-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of project-private-spec) res st/string-transformer)
        res))))


(defn-spec private-projects-search-with-http-info any?
  "Private Projects search
  Search inside the private projects"
  ([] (private-projects-search-with-http-info nil))
  ([{:keys [search]} (s/map-of keyword? any?)]
   (call-api "/account/projects/search" :post
             {:path-params   {}
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    search
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    []})))

(defn-spec private-projects-search (s/coll-of project-private-spec)
  "Private Projects search
  Search inside the private projects"
  ([] (private-projects-search nil))
  ([optional-params any?]
   (let [res (:data (private-projects-search-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of project-private-spec) res st/string-transformer)
        res))))


(defn-spec project-articles-with-http-info any?
  "Public Project Articles
  List articles in project"
  ([project_id int?, ] (project-articles-with-http-info project_id nil))
  ([project_id int?, {:keys [page page_size limit offset]} (s/map-of keyword? any?)]
   (check-required-params project_id)
   (call-api "/projects/{project_id}/articles" :get
             {:path-params   {"project_id" project_id }
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn-spec project-articles (s/coll-of article-spec)
  "Public Project Articles
  List articles in project"
  ([project_id int?, ] (project-articles project_id nil))
  ([project_id int?, optional-params any?]
   (let [res (:data (project-articles-with-http-info project_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of article-spec) res st/string-transformer)
        res))))


(defn-spec project-details-with-http-info any?
  "Public Project
  View a project"
  [project_id int?]
  (check-required-params project_id)
  (call-api "/projects/{project_id}" :get
            {:path-params   {"project_id" project_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec project-details project-complete-spec
  "Public Project
  View a project"
  [project_id int?]
  (let [res (:data (project-details-with-http-info project_id))]
    (if (:decode-models *api-context*)
       (st/decode project-complete-spec res st/string-transformer)
       res)))


(defn-spec projects-list-with-http-info any?
  "Public Projects
  Returns a list of public projects"
  ([] (projects-list-with-http-info nil))
  ([{:keys [X-Cursor page page_size limit offset order order_direction institution published_since group]} (s/map-of keyword? any?)]
   (call-api "/projects" :get
             {:path-params   {}
              :header-params {"X-Cursor" X-Cursor }
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset "order" order "order_direction" order_direction "institution" institution "published_since" published_since "group" group }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn-spec projects-list (s/coll-of project-spec)
  "Public Projects
  Returns a list of public projects"
  ([] (projects-list nil))
  ([optional-params any?]
   (let [res (:data (projects-list-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of project-spec) res st/string-transformer)
        res))))


(defn-spec projects-search-with-http-info any?
  "Public Projects Search
  Returns a list of public articles"
  ([] (projects-search-with-http-info nil))
  ([{:keys [X-Cursor search]} (s/map-of keyword? any?)]
   (call-api "/projects/search" :post
             {:path-params   {}
              :header-params {"X-Cursor" X-Cursor }
              :query-params  {}
              :form-params   {}
              :body-param    search
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    []})))

(defn-spec projects-search (s/coll-of project-spec)
  "Public Projects Search
  Returns a list of public articles"
  ([] (projects-search nil))
  ([optional-params any?]
   (let [res (:data (projects-search-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of project-spec) res st/string-transformer)
        res))))


