(ns figshare-api.api.authors
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn private-author-details-with-http-info
  "Author details
  View author details"
  [author-id ]
  (check-required-params author-id)
  (call-api "/account/authors/{author_id}" :get
            {:path-params   {"author_id" author-id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn private-author-details
  "Author details
  View author details"
  [author-id ]
  (:data (private-author-details-with-http-info author-id)))

(defn private-authors-search-with-http-info
  "Search Authors
  Search for authors"
  ([] (private-authors-search-with-http-info nil))
  ([{:keys [search ]}]
   (call-api "/account/authors/search" :post
             {:path-params   {}
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    search
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn private-authors-search
  "Search Authors
  Search for authors"
  ([] (private-authors-search nil))
  ([optional-params]
   (:data (private-authors-search-with-http-info optional-params))))

