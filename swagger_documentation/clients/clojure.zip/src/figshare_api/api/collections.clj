(ns figshare-api.api.collections
  (:require [figshare-api.core :refer [call-api check-required-params with-collection-format *api-context*]]
            [clojure.spec.alpha :as s]
            [spec-tools.core :as st]
            [orchestra.core :refer [defn-spec]]
            [figshare-api.specs.custom-article-field :refer :all]
            [figshare-api.specs.file-id :refer :all]
            [figshare-api.specs.project-collaborator-invite :refer :all]
            [figshare-api.specs.projects-search :refer :all]
            [figshare-api.specs.funding-search :refer :all]
            [figshare-api.specs.project-collaborator :refer :all]
            [figshare-api.specs.profile-update-data-personal-profiles-inner :refer :all]
            [figshare-api.specs.custom-article-field-add :refer :all]
            [figshare-api.specs.author-complete :refer :all]
            [figshare-api.specs.collaborator :refer :all]
            [figshare-api.specs.project-note-private :refer :all]
            [figshare-api.specs.private-link-response :refer :all]
            [figshare-api.specs.item-type :refer :all]
            [figshare-api.specs.location-warnings :refer :all]
            [figshare-api.specs.article-create :refer :all]
            [figshare-api.specs.project-note :refer :all]
            [figshare-api.specs.institution-accounts-search :refer :all]
            [figshare-api.specs.funding-create :refer :all]
            [figshare-api.specs.collection-handle :refer :all]
            [figshare-api.specs.authors-creator :refer :all]
            [figshare-api.specs.article-embargo :refer :all]
            [figshare-api.specs.error-message :refer :all]
            [figshare-api.specs.collection-private-link-creator :refer :all]
            [figshare-api.specs.response-message :refer :all]
            [figshare-api.specs.project-create :refer :all]
            [figshare-api.specs.timeline-update :refer :all]
            [figshare-api.specs.project-complete-private :refer :all]
            [figshare-api.specs.role :refer :all]
            [figshare-api.specs.article-project-create :refer :all]
            [figshare-api.specs.funding-information :refer :all]
            [figshare-api.specs.upload-info :refer :all]
            [figshare-api.specs.article-doi :refer :all]
            [figshare-api.specs.project-private :refer :all]
            [figshare-api.specs.private-project-article :refer :all]
            [figshare-api.specs.project-complete :refer :all]
            [figshare-api.specs.article-search :refer :all]
            [figshare-api.specs.account-update :refer :all]
            [figshare-api.specs.category-list :refer :all]
            [figshare-api.specs.private-file :refer :all]
            [figshare-api.specs.collection-complete :refer :all]
            [figshare-api.specs.private-authors-search :refer :all]
            [figshare-api.specs.timeline :refer :all]
            [figshare-api.specs.categories-creator :refer :all]
            [figshare-api.specs.account-report :refer :all]
            [figshare-api.specs.article-unpublish-data :refer :all]
            [figshare-api.specs.article-versions :refer :all]
            [figshare-api.specs.collection-create :refer :all]
            [figshare-api.specs.project :refer :all]
            [figshare-api.specs.related-material :refer :all]
            [figshare-api.specs.institution :refer :all]
            [figshare-api.specs.short-account :refer :all]
            [figshare-api.specs.curation-detail :refer :all]
            [figshare-api.specs.article-handle :refer :all]
            [figshare-api.specs.article-complete :refer :all]
            [figshare-api.specs.article-complete-private :refer :all]
            [figshare-api.specs.article-with-project :refer :all]
            [figshare-api.specs.articles-creator :refer :all]
            [figshare-api.specs.group :refer :all]
            [figshare-api.specs.collection-search :refer :all]
            [figshare-api.specs.account-create-response :refer :all]
            [figshare-api.specs.create-project-response :refer :all]
            [figshare-api.specs.resource :refer :all]
            [figshare-api.specs.author :refer :all]
            [figshare-api.specs.collection-complete-private :refer :all]
            [figshare-api.specs.curation-comment :refer :all]
            [figshare-api.specs.collection :refer :all]
            [figshare-api.specs.article :refer :all]
            [figshare-api.specs.file-creator :refer :all]
            [figshare-api.specs.license :refer :all]
            [figshare-api.specs.private-link-creator :refer :all]
            [figshare-api.specs.public-file :refer :all]
            [figshare-api.specs.upload-file-part :refer :all]
            [figshare-api.specs.collection-versions :refer :all]
            [figshare-api.specs.create-o-auth-token :refer :all]
            [figshare-api.specs.confidentiality-creator :refer :all]
            [figshare-api.specs.article-update :refer :all]
            [figshare-api.specs.collection-update :refer :all]
            [figshare-api.specs.profile-update-data :refer :all]
            [figshare-api.specs.private-article-search :refer :all]
            [figshare-api.specs.article-confidentiality :refer :all]
            [figshare-api.specs.curation-comment-create :refer :all]
            [figshare-api.specs.location-warnings-update :refer :all]
            [figshare-api.specs.short-custom-field :refer :all]
            [figshare-api.specs.project-note-create :refer :all]
            [figshare-api.specs.curation :refer :all]
            [figshare-api.specs.group-embargo-options :refer :all]
            [figshare-api.specs.private-collection-search :refer :all]
            [figshare-api.specs.private-link :refer :all]
            [figshare-api.specs.article-version-update :refer :all]
            [figshare-api.specs.account-create :refer :all]
            [figshare-api.specs.project-article :refer :all]
            [figshare-api.specs.project-update :refer :all]
            [figshare-api.specs.o-auth-token :refer :all]
            [figshare-api.specs.collection-doi :refer :all]
            [figshare-api.specs.location :refer :all]
            [figshare-api.specs.article-embargo-updater :refer :all]
            [figshare-api.specs.category :refer :all]
            [figshare-api.specs.common-search :refer :all]
            [figshare-api.specs.user :refer :all]
            [figshare-api.specs.account :refer :all]
            )
  (:import (java.io File)))


(defn-spec collection-articles-with-http-info any?
  "Public Collection Articles
  Returns a list of public collection articles"
  ([collection_id int?, ] (collection-articles-with-http-info collection_id nil))
  ([collection_id int?, {:keys [page page_size limit offset]} (s/map-of keyword? any?)]
   (check-required-params collection_id)
   (call-api "/collections/{collection_id}/articles" :get
             {:path-params   {"collection_id" collection_id }
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn-spec collection-articles (s/coll-of article-spec)
  "Public Collection Articles
  Returns a list of public collection articles"
  ([collection_id int?, ] (collection-articles collection_id nil))
  ([collection_id int?, optional-params any?]
   (let [res (:data (collection-articles-with-http-info collection_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of article-spec) res st/string-transformer)
        res))))


(defn-spec collection-details-with-http-info any?
  "Collection details
  View a collection"
  [collection_id int?]
  (check-required-params collection_id)
  (call-api "/collections/{collection_id}" :get
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec collection-details collection-complete-spec
  "Collection details
  View a collection"
  [collection_id int?]
  (let [res (:data (collection-details-with-http-info collection_id))]
    (if (:decode-models *api-context*)
       (st/decode collection-complete-spec res st/string-transformer)
       res)))


(defn-spec collection-version-details-with-http-info any?
  "Collection Version details
  View details for a certain version of a collection"
  [collection_id int?, version_id int?]
  (check-required-params collection_id version_id)
  (call-api "/collections/{collection_id}/versions/{version_id}" :get
            {:path-params   {"collection_id" collection_id "version_id" version_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec collection-version-details collection-complete-spec
  "Collection Version details
  View details for a certain version of a collection"
  [collection_id int?, version_id int?]
  (let [res (:data (collection-version-details-with-http-info collection_id version_id))]
    (if (:decode-models *api-context*)
       (st/decode collection-complete-spec res st/string-transformer)
       res)))


(defn-spec collection-versions-with-http-info any?
  "Collection Versions list
  Returns a list of public collection Versions"
  [collection_id int?]
  (check-required-params collection_id)
  (call-api "/collections/{collection_id}/versions" :get
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    []}))

(defn-spec collection-versions (s/coll-of collection-versions-spec)
  "Collection Versions list
  Returns a list of public collection Versions"
  [collection_id int?]
  (let [res (:data (collection-versions-with-http-info collection_id))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of collection-versions-spec) res st/string-transformer)
       res)))


(defn-spec collections-list-with-http-info any?
  "Public Collections
  Returns a list of public collections"
  ([] (collections-list-with-http-info nil))
  ([{:keys [X-Cursor page page_size limit offset order order_direction institution published_since modified_since group resource_doi doi handle]} (s/map-of keyword? any?)]
   (call-api "/collections" :get
             {:path-params   {}
              :header-params {"X-Cursor" X-Cursor }
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset "order" order "order_direction" order_direction "institution" institution "published_since" published_since "modified_since" modified_since "group" group "resource_doi" resource_doi "doi" doi "handle" handle }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    []})))

(defn-spec collections-list (s/coll-of collection-spec)
  "Public Collections
  Returns a list of public collections"
  ([] (collections-list nil))
  ([optional-params any?]
   (let [res (:data (collections-list-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of collection-spec) res st/string-transformer)
        res))))


(defn-spec collections-search-with-http-info any?
  "Public Collections Search
  Returns a list of public collections"
  ([] (collections-search-with-http-info nil))
  ([{:keys [X-Cursor search]} (s/map-of keyword? any?)]
   (call-api "/collections/search" :post
             {:path-params   {}
              :header-params {"X-Cursor" X-Cursor }
              :query-params  {}
              :form-params   {}
              :body-param    search
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    []})))

(defn-spec collections-search (s/coll-of collection-spec)
  "Public Collections Search
  Returns a list of public collections"
  ([] (collections-search nil))
  ([optional-params any?]
   (let [res (:data (collections-search-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of collection-spec) res st/string-transformer)
        res))))


(defn-spec private-collection-article-delete-with-http-info any?
  "Delete collection article
  De-associate article from collection"
  [collection_id int?, article_id int?]
  (check-required-params collection_id article_id)
  (call-api "/account/collections/{collection_id}/articles/{article_id}" :delete
            {:path-params   {"collection_id" collection_id "article_id" article_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-article-delete any?
  "Delete collection article
  De-associate article from collection"
  [collection_id int?, article_id int?]
  (let [res (:data (private-collection-article-delete-with-http-info collection_id article_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-collection-articles-add-with-http-info any?
  "Add collection articles
  Associate new articles with the collection. This will add new articles to the list of already associated articles"
  [collection_id int?, articles articles-creator]
  (check-required-params collection_id articles)
  (call-api "/account/collections/{collection_id}/articles" :post
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    articles
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-articles-add location-spec
  "Add collection articles
  Associate new articles with the collection. This will add new articles to the list of already associated articles"
  [collection_id int?, articles articles-creator]
  (let [res (:data (private-collection-articles-add-with-http-info collection_id articles))]
    (if (:decode-models *api-context*)
       (st/decode location-spec res st/string-transformer)
       res)))


(defn-spec private-collection-articles-list-with-http-info any?
  "List collection articles
  List collection articles"
  ([collection_id int?, ] (private-collection-articles-list-with-http-info collection_id nil))
  ([collection_id int?, {:keys [page page_size limit offset]} (s/map-of keyword? any?)]
   (check-required-params collection_id)
   (call-api "/account/collections/{collection_id}/articles" :get
             {:path-params   {"collection_id" collection_id }
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-collection-articles-list (s/coll-of article-spec)
  "List collection articles
  List collection articles"
  ([collection_id int?, ] (private-collection-articles-list collection_id nil))
  ([collection_id int?, optional-params any?]
   (let [res (:data (private-collection-articles-list-with-http-info collection_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of article-spec) res st/string-transformer)
        res))))


(defn-spec private-collection-articles-replace-with-http-info any?
  "Replace collection articles
  Associate new articles with the collection. This will remove all already associated articles and add these new ones"
  [collection_id int?, articles articles-creator]
  (check-required-params collection_id articles)
  (call-api "/account/collections/{collection_id}/articles" :put
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    articles
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-articles-replace any?
  "Replace collection articles
  Associate new articles with the collection. This will remove all already associated articles and add these new ones"
  [collection_id int?, articles articles-creator]
  (let [res (:data (private-collection-articles-replace-with-http-info collection_id articles))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-collection-author-delete-with-http-info any?
  "Delete collection author
  Delete collection author"
  [collection_id int?, author_id int?]
  (check-required-params collection_id author_id)
  (call-api "/account/collections/{collection_id}/authors/{author_id}" :delete
            {:path-params   {"collection_id" collection_id "author_id" author_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-author-delete any?
  "Delete collection author
  Delete collection author"
  [collection_id int?, author_id int?]
  (let [res (:data (private-collection-author-delete-with-http-info collection_id author_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-collection-authors-add-with-http-info any?
  "Add collection authors
  Associate new authors with the collection. This will add new authors to the list of already associated authors"
  [collection_id int?, Authors authors-creator]
  (check-required-params collection_id Authors)
  (call-api "/account/collections/{collection_id}/authors" :post
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Authors
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-authors-add location-spec
  "Add collection authors
  Associate new authors with the collection. This will add new authors to the list of already associated authors"
  [collection_id int?, Authors authors-creator]
  (let [res (:data (private-collection-authors-add-with-http-info collection_id Authors))]
    (if (:decode-models *api-context*)
       (st/decode location-spec res st/string-transformer)
       res)))


(defn-spec private-collection-authors-list-with-http-info any?
  "List collection authors
  List collection authors"
  [collection_id int?]
  (check-required-params collection_id)
  (call-api "/account/collections/{collection_id}/authors" :get
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-authors-list (s/coll-of author-spec)
  "List collection authors
  List collection authors"
  [collection_id int?]
  (let [res (:data (private-collection-authors-list-with-http-info collection_id))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of author-spec) res st/string-transformer)
       res)))


(defn-spec private-collection-authors-replace-with-http-info any?
  "Replace collection authors
  Associate new authors with the collection. This will remove all already associated authors and add these new ones"
  [collection_id int?, Authors authors-creator]
  (check-required-params collection_id Authors)
  (call-api "/account/collections/{collection_id}/authors" :put
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Authors
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-authors-replace any?
  "Replace collection authors
  Associate new authors with the collection. This will remove all already associated authors and add these new ones"
  [collection_id int?, Authors authors-creator]
  (let [res (:data (private-collection-authors-replace-with-http-info collection_id Authors))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-collection-categories-add-with-http-info any?
  "Add collection categories
  Associate new categories with the collection. This will add new categories to the list of already associated categories"
  [collection_id int?, categories categories-creator]
  (check-required-params collection_id categories)
  (call-api "/account/collections/{collection_id}/categories" :post
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    categories
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-categories-add location-spec
  "Add collection categories
  Associate new categories with the collection. This will add new categories to the list of already associated categories"
  [collection_id int?, categories categories-creator]
  (let [res (:data (private-collection-categories-add-with-http-info collection_id categories))]
    (if (:decode-models *api-context*)
       (st/decode location-spec res st/string-transformer)
       res)))


(defn-spec private-collection-categories-list-with-http-info any?
  "List collection categories
  List collection categories"
  [collection_id int?]
  (check-required-params collection_id)
  (call-api "/account/collections/{collection_id}/categories" :get
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-categories-list (s/coll-of category-spec)
  "List collection categories
  List collection categories"
  [collection_id int?]
  (let [res (:data (private-collection-categories-list-with-http-info collection_id))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of category-spec) res st/string-transformer)
       res)))


(defn-spec private-collection-categories-replace-with-http-info any?
  "Replace collection categories
  Associate new categories with the collection. This will remove all already associated categories and add these new ones"
  [collection_id int?, categories categories-creator]
  (check-required-params collection_id categories)
  (call-api "/account/collections/{collection_id}/categories" :put
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    categories
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-categories-replace any?
  "Replace collection categories
  Associate new categories with the collection. This will remove all already associated categories and add these new ones"
  [collection_id int?, categories categories-creator]
  (let [res (:data (private-collection-categories-replace-with-http-info collection_id categories))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-collection-category-delete-with-http-info any?
  "Delete collection category
  De-associate category from collection"
  [collection_id int?, category_id int?]
  (check-required-params collection_id category_id)
  (call-api "/account/collections/{collection_id}/categories/{category_id}" :delete
            {:path-params   {"collection_id" collection_id "category_id" category_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-category-delete any?
  "Delete collection category
  De-associate category from collection"
  [collection_id int?, category_id int?]
  (let [res (:data (private-collection-category-delete-with-http-info collection_id category_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-collection-create-with-http-info any?
  "Create collection
  Create a new Collection by sending collection information"
  [Collection collection-create]
  (check-required-params Collection)
  (call-api "/account/collections" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Collection
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-create location-warnings-spec
  "Create collection
  Create a new Collection by sending collection information"
  [Collection collection-create]
  (let [res (:data (private-collection-create-with-http-info Collection))]
    (if (:decode-models *api-context*)
       (st/decode location-warnings-spec res st/string-transformer)
       res)))


(defn-spec private-collection-delete-with-http-info any?
  "Delete collection
  Delete n collection"
  [collection_id int?]
  (check-required-params collection_id)
  (call-api "/account/collections/{collection_id}" :delete
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-delete any?
  "Delete collection
  Delete n collection"
  [collection_id int?]
  (let [res (:data (private-collection-delete-with-http-info collection_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-collection-details-with-http-info any?
  "Collection details
  View a collection"
  [collection_id int?]
  (check-required-params collection_id)
  (call-api "/account/collections/{collection_id}" :get
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-details collection-complete-private-spec
  "Collection details
  View a collection"
  [collection_id int?]
  (let [res (:data (private-collection-details-with-http-info collection_id))]
    (if (:decode-models *api-context*)
       (st/decode collection-complete-private-spec res st/string-transformer)
       res)))


(defn-spec private-collection-patch-with-http-info any?
  "Partially update collection
  Partially update a collection by sending only the fields to change."
  [collection_id int?, Collection collection-update]
  (check-required-params collection_id Collection)
  (call-api "/account/collections/{collection_id}" :patch
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Collection
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-patch location-warnings-update-spec
  "Partially update collection
  Partially update a collection by sending only the fields to change."
  [collection_id int?, Collection collection-update]
  (let [res (:data (private-collection-patch-with-http-info collection_id Collection))]
    (if (:decode-models *api-context*)
       (st/decode location-warnings-update-spec res st/string-transformer)
       res)))


(defn-spec private-collection-private-link-create-with-http-info any?
  "Create collection private link
  Create new private link"
  ([collection_id int?, ] (private-collection-private-link-create-with-http-info collection_id nil))
  ([collection_id int?, {:keys [private_link]} (s/map-of keyword? any?)]
   (check-required-params collection_id)
   (call-api "/account/collections/{collection_id}/private_links" :post
             {:path-params   {"collection_id" collection_id }
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    private_link
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-collection-private-link-create private-link-response-spec
  "Create collection private link
  Create new private link"
  ([collection_id int?, ] (private-collection-private-link-create collection_id nil))
  ([collection_id int?, optional-params any?]
   (let [res (:data (private-collection-private-link-create-with-http-info collection_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode private-link-response-spec res st/string-transformer)
        res))))


(defn-spec private-collection-private-link-delete-with-http-info any?
  "Disable private link
  Disable/delete private link for this collection"
  [collection_id int?, link_id string?]
  (check-required-params collection_id link_id)
  (call-api "/account/collections/{collection_id}/private_links/{link_id}" :delete
            {:path-params   {"collection_id" collection_id "link_id" link_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-private-link-delete any?
  "Disable private link
  Disable/delete private link for this collection"
  [collection_id int?, link_id string?]
  (let [res (:data (private-collection-private-link-delete-with-http-info collection_id link_id))]
    (if (:decode-models *api-context*)
       (st/decode any? res st/string-transformer)
       res)))


(defn-spec private-collection-private-link-details-with-http-info any?
  "View collection private link
  View existing private link for this collection"
  [collection_id int?, link_id string?]
  (check-required-params collection_id link_id)
  (call-api "/account/collections/{collection_id}/private_links/{link_id}" :get
            {:path-params   {"collection_id" collection_id "link_id" link_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-private-link-details private-link-spec
  "View collection private link
  View existing private link for this collection"
  [collection_id int?, link_id string?]
  (let [res (:data (private-collection-private-link-details-with-http-info collection_id link_id))]
    (if (:decode-models *api-context*)
       (st/decode private-link-spec res st/string-transformer)
       res)))


(defn-spec private-collection-private-link-update-with-http-info any?
  "Update collection private link
  Update existing private link for this collection"
  ([collection_id int?, link_id string?, ] (private-collection-private-link-update-with-http-info collection_id link_id nil))
  ([collection_id int?, link_id string?, {:keys [private_link]} (s/map-of keyword? any?)]
   (check-required-params collection_id link_id)
   (call-api "/account/collections/{collection_id}/private_links/{link_id}" :put
             {:path-params   {"collection_id" collection_id "link_id" link_id }
              :header-params {}
              :query-params  {}
              :form-params   {}
              :body-param    private_link
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-collection-private-link-update any?
  "Update collection private link
  Update existing private link for this collection"
  ([collection_id int?, link_id string?, ] (private-collection-private-link-update collection_id link_id nil))
  ([collection_id int?, link_id string?, optional-params any?]
   (let [res (:data (private-collection-private-link-update-with-http-info collection_id link_id optional-params))]
     (if (:decode-models *api-context*)
        (st/decode any? res st/string-transformer)
        res))))


(defn-spec private-collection-private-links-list-with-http-info any?
  "List collection private links
  List article private links"
  [collection_id int?]
  (check-required-params collection_id)
  (call-api "/account/collections/{collection_id}/private_links" :get
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-private-links-list (s/coll-of private-link-spec)
  "List collection private links
  List article private links"
  [collection_id int?]
  (let [res (:data (private-collection-private-links-list-with-http-info collection_id))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of private-link-spec) res st/string-transformer)
       res)))


(defn-spec private-collection-publish-with-http-info any?
  "Private Collection Publish
  When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed."
  [collection_id int?]
  (check-required-params collection_id)
  (call-api "/account/collections/{collection_id}/publish" :post
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-publish location-spec
  "Private Collection Publish
  When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed."
  [collection_id int?]
  (let [res (:data (private-collection-publish-with-http-info collection_id))]
    (if (:decode-models *api-context*)
       (st/decode location-spec res st/string-transformer)
       res)))


(defn-spec private-collection-reserve-doi-with-http-info any?
  "Private Collection Reserve DOI
  Reserve DOI for collection"
  [collection_id int?]
  (check-required-params collection_id)
  (call-api "/account/collections/{collection_id}/reserve_doi" :post
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-reserve-doi collection-doi-spec
  "Private Collection Reserve DOI
  Reserve DOI for collection"
  [collection_id int?]
  (let [res (:data (private-collection-reserve-doi-with-http-info collection_id))]
    (if (:decode-models *api-context*)
       (st/decode collection-doi-spec res st/string-transformer)
       res)))


(defn-spec private-collection-reserve-handle-with-http-info any?
  "Private Collection Reserve Handle
  Reserve Handle for collection"
  [collection_id int?]
  (check-required-params collection_id)
  (call-api "/account/collections/{collection_id}/reserve_handle" :post
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types []
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-reserve-handle collection-handle-spec
  "Private Collection Reserve Handle
  Reserve Handle for collection"
  [collection_id int?]
  (let [res (:data (private-collection-reserve-handle-with-http-info collection_id))]
    (if (:decode-models *api-context*)
       (st/decode collection-handle-spec res st/string-transformer)
       res)))


(defn-spec private-collection-resource-with-http-info any?
  "Private Collection Resource
  Edit collection resource data."
  [collection_id int?, Resource resource]
  (check-required-params collection_id Resource)
  (call-api "/account/collections/{collection_id}/resource" :post
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Resource
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-resource location-spec
  "Private Collection Resource
  Edit collection resource data."
  [collection_id int?, Resource resource]
  (let [res (:data (private-collection-resource-with-http-info collection_id Resource))]
    (if (:decode-models *api-context*)
       (st/decode location-spec res st/string-transformer)
       res)))


(defn-spec private-collection-update-with-http-info any?
  "Update collection
  Update a collection by passing full body parameters."
  [collection_id int?, Collection collection-update]
  (check-required-params collection_id Collection)
  (call-api "/account/collections/{collection_id}" :put
            {:path-params   {"collection_id" collection_id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    Collection
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collection-update location-warnings-update-spec
  "Update collection
  Update a collection by passing full body parameters."
  [collection_id int?, Collection collection-update]
  (let [res (:data (private-collection-update-with-http-info collection_id Collection))]
    (if (:decode-models *api-context*)
       (st/decode location-warnings-update-spec res st/string-transformer)
       res)))


(defn-spec private-collections-list-with-http-info any?
  "Private Collections List
  List private collections"
  ([] (private-collections-list-with-http-info nil))
  ([{:keys [page page_size limit offset order order_direction]} (s/map-of keyword? any?)]
   (call-api "/account/collections" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"page" page "page_size" page_size "limit" limit "offset" offset "order" order "order_direction" order_direction }
              :form-params   {}
              :content-types []
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn-spec private-collections-list (s/coll-of collection-spec)
  "Private Collections List
  List private collections"
  ([] (private-collections-list nil))
  ([optional-params any?]
   (let [res (:data (private-collections-list-with-http-info optional-params))]
     (if (:decode-models *api-context*)
        (st/decode (s/coll-of collection-spec) res st/string-transformer)
        res))))


(defn-spec private-collections-search-with-http-info any?
  "Private Collections Search
  Returns a list of private Collections"
  [search private-collection-search]
  (check-required-params search)
  (call-api "/account/collections/search" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    search
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn-spec private-collections-search (s/coll-of collection-spec)
  "Private Collections Search
  Returns a list of private Collections"
  [search private-collection-search]
  (let [res (:data (private-collections-search-with-http-info search))]
    (if (:decode-models *api-context*)
       (st/decode (s/coll-of collection-spec) res st/string-transformer)
       res)))


