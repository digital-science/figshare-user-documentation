(ns figshare-api.specs.project-note-create
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def project-note-create-data
  {
   (ds/req :text) string?
   })

(def project-note-create-spec
  (ds/spec
    {:name ::project-note-create
     :spec project-note-create-data}))
