(ns figshare-api.specs.related-material
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def related-material-data
  {
   (ds/opt :id) int?
   (ds/opt :identifier) string?
   (ds/opt :title) string?
   (ds/opt :relation) string?
   (ds/opt :identifier_type) string?
   (ds/opt :is_linkout) boolean?
   (ds/opt :link) string?
   })

(def related-material-spec
  (ds/spec
    {:name ::related-material
     :spec related-material-data}))
