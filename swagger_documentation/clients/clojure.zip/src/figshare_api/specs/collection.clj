(ns figshare-api.specs.collection
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.timeline :refer :all]
            )
  (:import (java.io File)))


(def collection-data
  {
   (ds/req :id) int?
   (ds/req :title) string?
   (ds/req :doi) string?
   (ds/req :handle) string?
   (ds/req :url) string?
   (ds/req :timeline) timeline-spec
   })

(def collection-spec
  (ds/spec
    {:name ::collection
     :spec collection-data}))
