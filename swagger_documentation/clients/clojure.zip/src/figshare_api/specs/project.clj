(ns figshare-api.specs.project
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def project-data
  {
   (ds/req :url) string?
   (ds/req :id) int?
   (ds/req :title) string?
   (ds/req :created_date) string?
   (ds/req :modified_date) string?
   })

(def project-spec
  (ds/spec
    {:name ::project
     :spec project-data}))
