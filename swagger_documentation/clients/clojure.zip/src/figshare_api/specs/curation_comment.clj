(ns figshare-api.specs.curation-comment
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def curation-comment-data
  {
   (ds/req :id) int?
   (ds/req :account_id) int?
   (ds/req :type) string?
   (ds/req :text) string?
   (ds/req :created_date) string?
   (ds/req :modified_date) string?
   })

(def curation-comment-spec
  (ds/spec
    {:name ::curation-comment
     :spec curation-comment-data}))
