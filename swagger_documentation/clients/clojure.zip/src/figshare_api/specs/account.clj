(ns figshare-api.specs.account
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def account-data
  {
   (ds/req :id) int?
   (ds/req :first_name) string?
   (ds/req :last_name) string?
   (ds/req :used_quota_private) int?
   (ds/req :modified_date) string?
   (ds/req :used_quota) int?
   (ds/req :created_date) string?
   (ds/req :quota) int?
   (ds/req :group_id) int?
   (ds/req :institution_user_id) string?
   (ds/req :institution_id) int?
   (ds/req :email) string?
   (ds/req :used_quota_public) int?
   (ds/req :pending_quota_request) boolean?
   (ds/req :active) int?
   (ds/req :maximum_file_size) int?
   (ds/req :user_id) int?
   (ds/req :orcid_id) string?
   (ds/req :symplectic_user_id) string?
   })

(def account-spec
  (ds/spec
    {:name ::account
     :spec account-data}))
