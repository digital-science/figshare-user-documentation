(ns figshare-api.specs.collection-complete
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.funding-information :refer :all]
            [figshare-api.specs.category :refer :all]
            [figshare-api.specs.related-material :refer :all]
            [figshare-api.specs.author :refer :all]
            [figshare-api.specs.custom-article-field :refer :all]
            [figshare-api.specs.timeline :refer :all]
            )
  (:import (java.io File)))


(def collection-complete-data
  {
   (ds/req :funding) (s/coll-of funding-information-spec)
   (ds/req :resource_id) string?
   (ds/req :resource_doi) string?
   (ds/req :resource_title) string?
   (ds/req :resource_link) string?
   (ds/req :resource_version) int?
   (ds/req :version) int?
   (ds/req :description) string?
   (ds/req :categories) (s/coll-of category-spec)
   (ds/req :references) (s/coll-of string?)
   (ds/req :related_materials) (s/coll-of related-material-spec)
   (ds/req :tags) (s/coll-of string?)
   (ds/req :keywords) (s/coll-of string?)
   (ds/req :authors) (s/coll-of author-spec)
   (ds/req :institution_id) int?
   (ds/req :group_id) int?
   (ds/req :articles_count) int?
   (ds/req :public) boolean?
   (ds/req :citation) string?
   (ds/req :custom_fields) (s/coll-of custom-article-field-spec)
   (ds/req :modified_date) string?
   (ds/req :created_date) string?
   (ds/req :timeline) timeline-spec
   (ds/req :id) int?
   (ds/req :title) string?
   (ds/req :doi) string?
   (ds/req :handle) string?
   (ds/req :url) string?
   })

(def collection-complete-spec
  (ds/spec
    {:name ::collection-complete
     :spec collection-complete-data}))
