(ns figshare-api.specs.account-create-response
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def account-create-response-data
  {
   (ds/req :account_id) int?
   })

(def account-create-response-spec
  (ds/spec
    {:name ::account-create-response
     :spec account-create-response-data}))
