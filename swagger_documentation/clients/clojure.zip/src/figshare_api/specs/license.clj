(ns figshare-api.specs.license
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def license-data
  {
   (ds/req :value) int?
   (ds/req :name) string?
   (ds/req :url) string?
   })

(def license-spec
  (ds/spec
    {:name ::license
     :spec license-data}))
