(ns figshare-api.specs.account-report
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def account-report-data
  {
   (ds/req :id) int?
   (ds/req :account_id) int?
   (ds/req :created_date) string?
   (ds/req :status) string?
   (ds/req :download_url) string?
   (ds/req :group_id) int?
   })

(def account-report-spec
  (ds/spec
    {:name ::account-report
     :spec account-report-data}))
