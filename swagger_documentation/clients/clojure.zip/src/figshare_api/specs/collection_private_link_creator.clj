(ns figshare-api.specs.collection-private-link-creator
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def collection-private-link-creator-data
  {
   (ds/opt :expires_date) string?
   })

(def collection-private-link-creator-spec
  (ds/spec
    {:name ::collection-private-link-creator
     :spec collection-private-link-creator-data}))
