(ns figshare-api.specs.account-create
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def account-create-data
  {
   (ds/req :email) string?
   (ds/opt :first_name) string?
   (ds/req :last_name) string?
   (ds/opt :group_id) int?
   (ds/opt :institution_user_id) string?
   (ds/opt :symplectic_user_id) string?
   (ds/opt :quota) int?
   (ds/opt :is_active) boolean?
   })

(def account-create-spec
  (ds/spec
    {:name ::account-create
     :spec account-create-data}))
