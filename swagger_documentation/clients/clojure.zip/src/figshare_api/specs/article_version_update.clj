(ns figshare-api.specs.article-version-update
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs. :refer :all]
            )
  (:import (java.io File)))


(def article-version-update-data
  {
   (ds/opt :supplementary_fields) (s/coll-of any?)
   (ds/opt :internal_metadata) any?
   })

(def article-version-update-spec
  (ds/spec
    {:name ::article-version-update
     :spec article-version-update-data}))
