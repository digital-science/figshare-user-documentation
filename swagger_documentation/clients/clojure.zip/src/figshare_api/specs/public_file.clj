(ns figshare-api.specs.public-file
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def public-file-data
  {
   (ds/req :id) int?
   (ds/req :name) string?
   (ds/req :size) int?
   (ds/req :is_link_only) boolean?
   (ds/req :download_url) string?
   (ds/req :supplied_md5) string?
   (ds/req :computed_md5) string?
   (ds/opt :mimetype) string?
   })

(def public-file-spec
  (ds/spec
    {:name ::public-file
     :spec public-file-data}))
