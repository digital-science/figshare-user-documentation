(ns figshare-api.specs.group
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def group-data
  {
   (ds/req :id) int?
   (ds/req :name) string?
   (ds/req :resource_id) string?
   (ds/req :parent_id) int?
   (ds/req :association_criteria) string?
   })

(def group-spec
  (ds/spec
    {:name ::group
     :spec group-data}))
