(ns figshare-api.specs.create-o-auth-token
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def create-o-auth-token-data
  {
   (ds/req :client_id) string?
   (ds/req :client_secret) string?
   (ds/req :grant_type) string?
   (ds/opt :code) string?
   (ds/opt :refresh_token) string?
   (ds/opt :username) string?
   (ds/opt :password) string?
   })

(def create-o-auth-token-spec
  (ds/spec
    {:name ::create-o-auth-token
     :spec create-o-auth-token-data}))
