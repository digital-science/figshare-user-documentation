(ns figshare-api.specs.article-confidentiality
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def article-confidentiality-data
  {
   (ds/req :is_confidential) boolean?
   (ds/req :reason) string?
   })

(def article-confidentiality-spec
  (ds/spec
    {:name ::article-confidentiality
     :spec article-confidentiality-data}))
