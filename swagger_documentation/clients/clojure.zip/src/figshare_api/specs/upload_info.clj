(ns figshare-api.specs.upload-info
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.upload-file-part :refer :all]
            )
  (:import (java.io File)))


(def upload-info-data
  {
   (ds/opt :token) string?
   (ds/opt :md5) string?
   (ds/opt :size) int?
   (ds/opt :name) string?
   (ds/opt :status) string?
   (ds/opt :parts) (s/coll-of upload-file-part-spec)
   })

(def upload-info-spec
  (ds/spec
    {:name ::upload-info
     :spec upload-info-data}))
