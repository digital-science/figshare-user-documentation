(ns figshare-api.specs.group-embargo-options
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def group-embargo-options-data
  {
   (ds/req :id) int?
   (ds/req :type) string?
   (ds/req :ip_name) string?
   })

(def group-embargo-options-spec
  (ds/spec
    {:name ::group-embargo-options
     :spec group-embargo-options-data}))
