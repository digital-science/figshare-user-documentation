(ns figshare-api.specs.collaborator
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def collaborator-data
  {
   (ds/req :role_name) string?
   (ds/req :user_id) int?
   (ds/req :name) string?
   })

(def collaborator-spec
  (ds/spec
    {:name ::collaborator
     :spec collaborator-data}))
