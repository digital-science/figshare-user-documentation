(ns figshare-api.specs.create-project-response
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def create-project-response-data
  {
   (ds/req :entity_id) int?
   (ds/req :location) string?
   })

(def create-project-response-spec
  (ds/spec
    {:name ::create-project-response
     :spec create-project-response-data}))
