(ns figshare-api.specs.article-embargo-updater
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def article-embargo-updater-data
  {
   (ds/req :is_embargoed) boolean?
   (ds/req :embargo_date) string?
   (ds/req :embargo_type) string?
   (ds/opt :embargo_title) string?
   (ds/opt :embargo_reason) string?
   (ds/opt :embargo_options) (s/coll-of any?)
   })

(def article-embargo-updater-spec
  (ds/spec
    {:name ::article-embargo-updater
     :spec article-embargo-updater-data}))
