(ns figshare-api.specs.curation
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def curation-data
  {
   (ds/req :id) int?
   (ds/req :group_id) int?
   (ds/req :account_id) int?
   (ds/req :assigned_to) int?
   (ds/req :article_id) int?
   (ds/req :version) int?
   (ds/req :comments_count) int?
   (ds/req :status) string?
   (ds/req :created_date) string?
   (ds/req :modified_date) string?
   (ds/req :request_number) int?
   (ds/req :resolution_comment) string?
   })

(def curation-spec
  (ds/spec
    {:name ::curation
     :spec curation-data}))
