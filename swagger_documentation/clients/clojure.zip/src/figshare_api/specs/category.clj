(ns figshare-api.specs.category
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def category-data
  {
   (ds/req :parent_id) int?
   (ds/req :id) int?
   (ds/req :title) string?
   (ds/req :path) string?
   (ds/req :source_id) string?
   (ds/req :taxonomy_id) int?
   })

(def category-spec
  (ds/spec
    {:name ::category
     :spec category-data}))
