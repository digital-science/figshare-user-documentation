(ns figshare-api.specs.project-update
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.funding-create :refer :all]
            [figshare-api.specs. :refer :all]
            [figshare-api.specs.custom-article-field-add :refer :all]
            )
  (:import (java.io File)))


(def project-update-data
  {
   (ds/opt :title) string?
   (ds/opt :description) string?
   (ds/opt :funding) string?
   (ds/opt :funding_list) (s/coll-of funding-create-spec)
   (ds/opt :custom_fields) any?
   (ds/opt :custom_fields_list) (s/coll-of custom-article-field-add-spec)
   })

(def project-update-spec
  (ds/spec
    {:name ::project-update
     :spec project-update-data}))
