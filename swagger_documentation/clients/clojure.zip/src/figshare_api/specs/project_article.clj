(ns figshare-api.specs.project-article
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.funding-information :refer :all]
            [figshare-api.specs.category :refer :all]
            [figshare-api.specs.license :refer :all]
            [figshare-api.specs.related-material :refer :all]
            [figshare-api.specs.timeline :refer :all]
            )
  (:import (java.io File)))


(def project-article-data
  {
   (ds/req :citation) string?
   (ds/req :confidential_reason) string?
   (ds/req :is_confidential) boolean?
   (ds/req :size) int?
   (ds/req :funding) string?
   (ds/req :funding_list) (s/coll-of funding-information-spec)
   (ds/req :tags) (s/coll-of string?)
   (ds/req :keywords) (s/coll-of string?)
   (ds/req :version) int?
   (ds/req :is_metadata_record) boolean?
   (ds/req :metadata_reason) string?
   (ds/req :status) string?
   (ds/req :description) string?
   (ds/req :is_embargoed) boolean?
   (ds/req :is_public) boolean?
   (ds/req :created_date) string?
   (ds/req :has_linked_file) boolean?
   (ds/req :categories) (s/coll-of category-spec)
   (ds/req :license) license-spec
   (ds/req :embargo_title) string?
   (ds/req :embargo_reason) string?
   (ds/req :references) (s/coll-of string?)
   (ds/opt :related_materials) (s/coll-of related-material-spec)
   (ds/req :id) int?
   (ds/req :title) string?
   (ds/req :doi) string?
   (ds/req :handle) string?
   (ds/req :url) string?
   (ds/req :url_public_html) string?
   (ds/req :url_public_api) string?
   (ds/req :url_private_html) string?
   (ds/req :url_private_api) string?
   (ds/req :timeline) timeline-spec
   (ds/req :thumb) string?
   (ds/req :defined_type) int?
   (ds/req :defined_type_name) string?
   (ds/req :resource_doi) string?
   (ds/req :resource_title) string?
   })

(def project-article-spec
  (ds/spec
    {:name ::project-article
     :spec project-article-data}))
