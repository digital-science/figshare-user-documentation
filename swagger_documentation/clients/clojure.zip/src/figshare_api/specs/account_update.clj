(ns figshare-api.specs.account-update
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def account-update-data
  {
   (ds/req :group_id) int?
   (ds/req :is_active) boolean?
   })

(def account-update-spec
  (ds/spec
    {:name ::account-update
     :spec account-update-data}))
