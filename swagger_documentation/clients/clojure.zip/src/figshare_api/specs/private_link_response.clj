(ns figshare-api.specs.private-link-response
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def private-link-response-data
  {
   (ds/req :location) string?
   (ds/req :html_location) string?
   (ds/req :token) string?
   })

(def private-link-response-spec
  (ds/spec
    {:name ::private-link-response
     :spec private-link-response-data}))
