(ns figshare-api.specs.o-auth-token
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def o-auth-token-data
  {
   (ds/req :access_token) string?
   (ds/opt :token) string?
   (ds/req :token_type) string?
   (ds/req :expires_in) int?
   (ds/opt :refresh_token) string?
   (ds/opt :scope) string?
   })

(def o-auth-token-spec
  (ds/spec
    {:name ::o-auth-token
     :spec o-auth-token-data}))
