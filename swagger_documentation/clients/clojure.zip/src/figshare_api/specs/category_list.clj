(ns figshare-api.specs.category-list
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def category-list-data
  {
   (ds/req :is_selectable) boolean?
   (ds/req :has_children) boolean?
   (ds/req :parent_id) int?
   (ds/req :id) int?
   (ds/req :title) string?
   (ds/req :path) string?
   (ds/req :source_id) string?
   (ds/req :taxonomy_id) int?
   })

(def category-list-spec
  (ds/spec
    {:name ::category-list
     :spec category-list-data}))
