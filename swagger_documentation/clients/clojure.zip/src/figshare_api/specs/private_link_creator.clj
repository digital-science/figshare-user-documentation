(ns figshare-api.specs.private-link-creator
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def private-link-creator-data
  {
   (ds/opt :expires_date) string?
   })

(def private-link-creator-spec
  (ds/spec
    {:name ::private-link-creator
     :spec private-link-creator-data}))
