(ns figshare-api.specs.project-note-private
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def project-note-private-data
  {
   (ds/req :text) string?
   (ds/req :id) int?
   (ds/req :user_id) int?
   (ds/req :abstract) string?
   (ds/req :user_name) string?
   (ds/req :created_date) string?
   (ds/req :modified_date) string?
   })

(def project-note-private-spec
  (ds/spec
    {:name ::project-note-private
     :spec project-note-private-data}))
