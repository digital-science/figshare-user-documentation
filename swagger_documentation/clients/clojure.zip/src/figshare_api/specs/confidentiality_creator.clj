(ns figshare-api.specs.confidentiality-creator
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def confidentiality-creator-data
  {
   (ds/req :reason) string?
   })

(def confidentiality-creator-spec
  (ds/spec
    {:name ::confidentiality-creator
     :spec confidentiality-creator-data}))
