(ns figshare-api.specs.articles-creator
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def articles-creator-data
  {
   (ds/req :articles) (s/coll-of int?)
   })

(def articles-creator-spec
  (ds/spec
    {:name ::articles-creator
     :spec articles-creator-data}))
