(ns figshare-api.specs.collection-versions
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.funding-information :refer :all]
            )
  (:import (java.io File)))


(def collection-versions-data
  {
   (ds/req :version) int?
   (ds/req :url) string?
   (ds/req :funding) (s/coll-of funding-information-spec)
   })

(def collection-versions-spec
  (ds/spec
    {:name ::collection-versions
     :spec collection-versions-data}))
