(ns figshare-api.specs.collection-create
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.funding-create :refer :all]
            [figshare-api.specs.related-material :refer :all]
            [figshare-api.specs. :refer :all]
            [figshare-api.specs.custom-article-field-add :refer :all]
            [figshare-api.specs.timeline-update :refer :all]
            )
  (:import (java.io File)))


(def collection-create-data
  {
   (ds/opt :funding) string?
   (ds/opt :funding_list) (s/coll-of funding-create-spec)
   (ds/req :title) string?
   (ds/opt :description) string?
   (ds/opt :articles) (s/coll-of int?)
   (ds/opt :authors) (s/coll-of any?)
   (ds/opt :categories) (s/coll-of int?)
   (ds/opt :categories_by_source_id) (s/coll-of string?)
   (ds/opt :tags) (s/coll-of string?)
   (ds/opt :keywords) (s/coll-of string?)
   (ds/opt :references) (s/coll-of string?)
   (ds/opt :related_materials) (s/coll-of related-material-spec)
   (ds/opt :custom_fields) any?
   (ds/opt :custom_fields_list) (s/coll-of custom-article-field-add-spec)
   (ds/opt :doi) string?
   (ds/opt :handle) string?
   (ds/opt :resource_id) string?
   (ds/opt :resource_doi) string?
   (ds/opt :resource_link) string?
   (ds/opt :resource_title) string?
   (ds/opt :resource_version) int?
   (ds/opt :group_id) int?
   (ds/opt :timeline) timeline-update-spec
   })

(def collection-create-spec
  (ds/spec
    {:name ::collection-create
     :spec collection-create-data}))
