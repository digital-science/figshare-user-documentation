(ns figshare-api.specs.curation-detail
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.article-complete :refer :all]
            )
  (:import (java.io File)))


(def curation-detail-data
  {
   (ds/req :item) article-complete-spec
   (ds/req :id) int?
   (ds/req :group_id) int?
   (ds/req :account_id) int?
   (ds/req :assigned_to) int?
   (ds/req :article_id) int?
   (ds/req :version) int?
   (ds/req :comments_count) int?
   (ds/req :status) string?
   (ds/req :created_date) string?
   (ds/req :modified_date) string?
   (ds/req :request_number) int?
   (ds/req :resolution_comment) string?
   })

(def curation-detail-spec
  (ds/spec
    {:name ::curation-detail
     :spec curation-detail-data}))
