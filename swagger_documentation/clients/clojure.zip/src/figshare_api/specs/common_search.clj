(ns figshare-api.specs.common-search
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def common-search-data
  {
   (ds/opt :search_for) string?
   (ds/opt :page) int?
   (ds/opt :page_size) int?
   (ds/opt :limit) int?
   (ds/opt :offset) int?
   (ds/opt :order_direction) string?
   (ds/opt :institution) int?
   (ds/opt :published_since) string?
   (ds/opt :modified_since) string?
   (ds/opt :group) int?
   })

(def common-search-spec
  (ds/spec
    {:name ::common-search
     :spec common-search-data}))
