(ns figshare-api.specs.timeline-update
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def timeline-update-data
  {
   (ds/opt :firstOnline) string?
   (ds/opt :publisherPublication) string?
   (ds/opt :publisherAcceptance) string?
   })

(def timeline-update-spec
  (ds/spec
    {:name ::timeline-update
     :spec timeline-update-data}))
