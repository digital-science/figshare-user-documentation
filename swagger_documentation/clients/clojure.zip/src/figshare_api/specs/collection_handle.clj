(ns figshare-api.specs.collection-handle
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def collection-handle-data
  {
   (ds/req :handle) string?
   })

(def collection-handle-spec
  (ds/spec
    {:name ::collection-handle
     :spec collection-handle-data}))
