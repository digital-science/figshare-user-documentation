(ns figshare-api.specs.user
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def user-data
  {
   (ds/req :id) int?
   (ds/req :first_name) string?
   (ds/req :last_name) string?
   (ds/req :name) string?
   (ds/req :is_active) boolean?
   (ds/req :url_name) string?
   (ds/req :is_public) boolean?
   (ds/req :job_title) string?
   (ds/req :orcid_id) string?
   })

(def user-spec
  (ds/spec
    {:name ::user
     :spec user-data}))
