(ns figshare-api.specs.project-complete-private
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.funding-information :refer :all]
            [figshare-api.specs.collaborator :refer :all]
            [figshare-api.specs.short-custom-field :refer :all]
            )
  (:import (java.io File)))


(def project-complete-private-data
  {
   (ds/req :funding) string?
   (ds/req :funding_list) (s/coll-of funding-information-spec)
   (ds/req :description) string?
   (ds/req :collaborators) (s/coll-of collaborator-spec)
   (ds/req :quota) int?
   (ds/req :used_quota) int?
   (ds/req :created_date) string?
   (ds/req :modified_date) string?
   (ds/req :used_quota_private) int?
   (ds/req :used_quota_public) int?
   (ds/req :group_id) int?
   (ds/req :account_id) int?
   (ds/req :custom_fields) (s/coll-of short-custom-field-spec)
   (ds/req :role) string?
   (ds/req :storage) string?
   (ds/req :url) string?
   (ds/req :id) int?
   (ds/req :title) string?
   })

(def project-complete-private-spec
  (ds/spec
    {:name ::project-complete-private
     :spec project-complete-private-data}))
