(ns figshare-api.specs.authors-creator
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def authors-creator-data
  {
   (ds/req :authors) (s/coll-of any?)
   })

(def authors-creator-spec
  (ds/spec
    {:name ::authors-creator
     :spec authors-creator-data}))
