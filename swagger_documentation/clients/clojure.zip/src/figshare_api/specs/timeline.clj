(ns figshare-api.specs.timeline
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def timeline-data
  {
   (ds/opt :firstOnline) string?
   (ds/opt :publisherPublication) string?
   (ds/opt :publisherAcceptance) string?
   })

(def timeline-spec
  (ds/spec
    {:name ::timeline
     :spec timeline-data}))
