(ns figshare-api.specs.article-with-project
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.timeline :refer :all]
            )
  (:import (java.io File)))


(def article-with-project-data
  {
   (ds/req :project_id) int?
   (ds/req :id) int?
   (ds/req :title) string?
   (ds/req :doi) string?
   (ds/req :handle) string?
   (ds/req :url) string?
   (ds/req :url_public_html) string?
   (ds/req :url_public_api) string?
   (ds/req :url_private_html) string?
   (ds/req :url_private_api) string?
   (ds/req :timeline) timeline-spec
   (ds/req :thumb) string?
   (ds/req :defined_type) int?
   (ds/req :defined_type_name) string?
   (ds/req :resource_doi) string?
   (ds/req :resource_title) string?
   (ds/req :created_date) string?
   })

(def article-with-project-spec
  (ds/spec
    {:name ::article-with-project
     :spec article-with-project-data}))
