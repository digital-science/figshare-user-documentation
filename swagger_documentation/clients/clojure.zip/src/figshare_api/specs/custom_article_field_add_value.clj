(ns figshare-api.specs.custom-article-field-add-value
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def custom-article-field-add-value-data
  {
   })

(def custom-article-field-add-value-spec
  (ds/spec
    {:name ::custom-article-field-add-value
     :spec custom-article-field-add-value-data}))
