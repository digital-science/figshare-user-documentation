(ns figshare-api.specs.custom-article-field
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs. :refer :all]
            [figshare-api.specs. :refer :all]
            )
  (:import (java.io File)))


(def custom-article-field-data
  {
   (ds/req :name) string?
   (ds/req :value) any?
   (ds/req :field_type) string?
   (ds/req :settings) any?
   (ds/req :order) int?
   (ds/req :is_mandatory) boolean?
   })

(def custom-article-field-spec
  (ds/spec
    {:name ::custom-article-field
     :spec custom-article-field-data}))
