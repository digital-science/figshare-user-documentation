(ns figshare-api.specs.project-create
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.funding-create :refer :all]
            [figshare-api.specs. :refer :all]
            [figshare-api.specs.custom-article-field-add :refer :all]
            )
  (:import (java.io File)))


(def project-create-data
  {
   (ds/req :title) string?
   (ds/opt :description) string?
   (ds/opt :funding) string?
   (ds/opt :funding_list) (s/coll-of funding-create-spec)
   (ds/opt :group_id) int?
   (ds/opt :custom_fields) any?
   (ds/opt :custom_fields_list) (s/coll-of custom-article-field-add-spec)
   })

(def project-create-spec
  (ds/spec
    {:name ::project-create
     :spec project-create-data}))
