(ns figshare-api.specs.categories-creator
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def categories-creator-data
  {
   (ds/req :categories) (s/coll-of int?)
   })

(def categories-creator-spec
  (ds/spec
    {:name ::categories-creator
     :spec categories-creator-data}))
