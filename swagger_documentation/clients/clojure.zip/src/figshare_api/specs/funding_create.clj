(ns figshare-api.specs.funding-create
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def funding-create-data
  {
   (ds/opt :id) int?
   (ds/opt :title) string?
   })

(def funding-create-spec
  (ds/spec
    {:name ::funding-create
     :spec funding-create-data}))
