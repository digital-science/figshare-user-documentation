(ns figshare-api.specs.short-account
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def short-account-data
  {
   (ds/req :id) int?
   (ds/req :first_name) string?
   (ds/req :last_name) string?
   (ds/req :institution_id) int?
   (ds/req :email) string?
   (ds/req :active) int?
   (ds/req :institution_user_id) string?
   (ds/req :quota) int?
   (ds/req :used_quota) int?
   (ds/req :user_id) int?
   (ds/req :orcid_id) string?
   (ds/req :symplectic_user_id) string?
   })

(def short-account-spec
  (ds/spec
    {:name ::short-account
     :spec short-account-data}))
