(ns figshare-api.specs.projects-search
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def projects-search-data
  {
   (ds/opt :order) string?
   (ds/opt :search_for) string?
   (ds/opt :page) int?
   (ds/opt :page_size) int?
   (ds/opt :limit) int?
   (ds/opt :offset) int?
   (ds/opt :order_direction) string?
   (ds/opt :institution) int?
   (ds/opt :published_since) string?
   (ds/opt :modified_since) string?
   (ds/opt :group) int?
   })

(def projects-search-spec
  (ds/spec
    {:name ::projects-search
     :spec projects-search-data}))
