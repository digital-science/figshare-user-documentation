(ns figshare-api.specs.profile-update-data
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.profile-update-data-personal-profiles-inner :refer :all]
            )
  (:import (java.io File)))


(def profile-update-data-data
  {
   (ds/opt :first_name) string?
   (ds/opt :last_name) string?
   (ds/opt :orcid) string?
   (ds/opt :job_title) string?
   (ds/opt :fields_of_interest) (s/coll-of int?)
   (ds/opt :fields_of_interest_by_source_id) (s/coll-of string?)
   (ds/opt :location) string?
   (ds/opt :facebook) string?
   (ds/opt :x) string?
   (ds/opt :linkedin) string?
   (ds/opt :bio) string?
   (ds/opt :personal_profiles) (s/coll-of profile-update-data-personal-profiles-inner-spec)
   })

(def profile-update-data-spec
  (ds/spec
    {:name ::profile-update-data
     :spec profile-update-data-data}))
