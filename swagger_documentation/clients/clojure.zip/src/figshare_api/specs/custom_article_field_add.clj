(ns figshare-api.specs.custom-article-field-add
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.custom-article-field-add-value :refer :all]
            )
  (:import (java.io File)))


(def custom-article-field-add-data
  {
   (ds/req :name) string?
   (ds/req :value) custom-article-field-add-value-spec
   })

(def custom-article-field-add-spec
  (ds/spec
    {:name ::custom-article-field-add
     :spec custom-article-field-add-data}))
