(ns figshare-api.specs.author
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def author-data
  {
   (ds/req :id) int?
   (ds/req :full_name) string?
   (ds/req :first_name) string?
   (ds/req :last_name) string?
   (ds/req :is_active) boolean?
   (ds/req :url_name) string?
   (ds/req :orcid_id) string?
   })

(def author-spec
  (ds/spec
    {:name ::author
     :spec author-data}))
