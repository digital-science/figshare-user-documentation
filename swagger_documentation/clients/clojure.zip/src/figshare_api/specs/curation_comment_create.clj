(ns figshare-api.specs.curation-comment-create
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def curation-comment-create-data
  {
   (ds/req :text) string?
   })

(def curation-comment-create-spec
  (ds/spec
    {:name ::curation-comment-create
     :spec curation-comment-create-data}))
