(ns figshare-api.specs.institution
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def institution-data
  {
   (ds/req :id) int?
   (ds/req :name) string?
   })

(def institution-spec
  (ds/spec
    {:name ::institution
     :spec institution-data}))
