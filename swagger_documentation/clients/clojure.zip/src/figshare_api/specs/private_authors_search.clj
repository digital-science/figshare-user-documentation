(ns figshare-api.specs.private-authors-search
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def private-authors-search-data
  {
   (ds/opt :search_for) string?
   (ds/opt :page) int?
   (ds/opt :page_size) int?
   (ds/opt :limit) int?
   (ds/opt :offset) int?
   (ds/opt :institution_id) int?
   (ds/opt :orcid) string?
   (ds/opt :group_id) int?
   (ds/opt :is_active) boolean?
   (ds/opt :is_public) boolean?
   })

(def private-authors-search-spec
  (ds/spec
    {:name ::private-authors-search
     :spec private-authors-search-data}))
