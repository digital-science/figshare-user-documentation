(ns figshare-api.specs.article-embargo
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def article-embargo-data
  {
   (ds/req :is_embargoed) boolean?
   (ds/req :embargo_title) string?
   (ds/req :embargo_reason) string?
   (ds/req :embargo_options) (s/coll-of any?)
   })

(def article-embargo-spec
  (ds/spec
    {:name ::article-embargo
     :spec article-embargo-data}))
