(ns figshare-api.specs.institution-accounts-search
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def institution-accounts-search-data
  {
   (ds/opt :search_for) string?
   (ds/opt :is_active) int?
   (ds/opt :page) int?
   (ds/opt :page_size) int?
   (ds/opt :limit) int?
   (ds/opt :offset) int?
   (ds/opt :institution_user_id) string?
   (ds/opt :email) string?
   })

(def institution-accounts-search-spec
  (ds/spec
    {:name ::institution-accounts-search
     :spec institution-accounts-search-data}))
