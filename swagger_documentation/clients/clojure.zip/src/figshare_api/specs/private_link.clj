(ns figshare-api.specs.private-link
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def private-link-data
  {
   (ds/req :id) string?
   (ds/req :is_active) boolean?
   (ds/req :expires_date) string?
   (ds/req :html_location) string?
   })

(def private-link-spec
  (ds/spec
    {:name ::private-link
     :spec private-link-data}))
