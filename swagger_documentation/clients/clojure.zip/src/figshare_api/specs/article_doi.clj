(ns figshare-api.specs.article-doi
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def article-doi-data
  {
   (ds/req :doi) string?
   })

(def article-doi-spec
  (ds/spec
    {:name ::article-doi
     :spec article-doi-data}))
