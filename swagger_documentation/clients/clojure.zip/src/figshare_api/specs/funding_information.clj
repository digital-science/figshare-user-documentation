(ns figshare-api.specs.funding-information
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def funding-information-data
  {
   (ds/req :id) int?
   (ds/req :title) string?
   (ds/req :grant_code) string?
   (ds/req :funder_name) string?
   (ds/req :is_user_defined) int?
   (ds/req :url) string?
   })

(def funding-information-spec
  (ds/spec
    {:name ::funding-information
     :spec funding-information-data}))
