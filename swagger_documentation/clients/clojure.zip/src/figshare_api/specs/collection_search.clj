(ns figshare-api.specs.collection-search
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def collection-search-data
  {
   (ds/opt :resource_doi) string?
   (ds/opt :doi) string?
   (ds/opt :handle) string?
   (ds/opt :order) string?
   (ds/opt :search_for) string?
   (ds/opt :page) int?
   (ds/opt :page_size) int?
   (ds/opt :limit) int?
   (ds/opt :offset) int?
   (ds/opt :order_direction) string?
   (ds/opt :institution) int?
   (ds/opt :published_since) string?
   (ds/opt :modified_since) string?
   (ds/opt :group) int?
   })

(def collection-search-spec
  (ds/spec
    {:name ::collection-search
     :spec collection-search-data}))
