(ns figshare-api.specs.project-complete
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.funding-information :refer :all]
            [figshare-api.specs.collaborator :refer :all]
            [figshare-api.specs.custom-article-field :refer :all]
            )
  (:import (java.io File)))


(def project-complete-data
  {
   (ds/req :funding) string?
   (ds/req :funding_list) (s/coll-of funding-information-spec)
   (ds/req :description) string?
   (ds/req :collaborators) (s/coll-of collaborator-spec)
   (ds/req :custom_fields) (s/coll-of custom-article-field-spec)
   (ds/req :modified_date) string?
   (ds/req :created_date) string?
   (ds/req :url) string?
   (ds/req :id) int?
   (ds/req :title) string?
   })

(def project-complete-spec
  (ds/spec
    {:name ::project-complete
     :spec project-complete-data}))
