(ns figshare-api.specs.file-creator
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def file-creator-data
  {
   (ds/opt :link) string?
   (ds/opt :md5) string?
   (ds/opt :name) string?
   (ds/opt :size) int?
   (ds/opt :folder_path) string?
   })

(def file-creator-spec
  (ds/spec
    {:name ::file-creator
     :spec file-creator-data}))
