(ns figshare-api.specs.file-id
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def file-id-data
  {
   (ds/opt :file_id) int?
   })

(def file-id-spec
  (ds/spec
    {:name ::file-id
     :spec file-id-data}))
