(ns figshare-api.specs.location
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def location-data
  {
   (ds/req :location) string?
   })

(def location-spec
  (ds/spec
    {:name ::location
     :spec location-data}))
