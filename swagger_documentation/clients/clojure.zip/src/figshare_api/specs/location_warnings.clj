(ns figshare-api.specs.location-warnings
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def location-warnings-data
  {
   (ds/req :entity_id) int?
   (ds/req :location) string?
   (ds/req :warnings) (s/coll-of string?)
   })

(def location-warnings-spec
  (ds/spec
    {:name ::location-warnings
     :spec location-warnings-data}))
