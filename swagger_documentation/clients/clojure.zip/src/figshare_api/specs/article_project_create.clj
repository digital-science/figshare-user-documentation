(ns figshare-api.specs.article-project-create
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs.related-material :refer :all]
            [figshare-api.specs. :refer :all]
            [figshare-api.specs.custom-article-field-add :refer :all]
            [figshare-api.specs.funding-create :refer :all]
            [figshare-api.specs.timeline-update :refer :all]
            )
  (:import (java.io File)))


(def article-project-create-data
  {
   (ds/req :title) string?
   (ds/opt :description) string?
   (ds/opt :tags) (s/coll-of string?)
   (ds/opt :keywords) (s/coll-of string?)
   (ds/opt :references) (s/coll-of string?)
   (ds/opt :related_materials) (s/coll-of related-material-spec)
   (ds/opt :categories) (s/coll-of int?)
   (ds/opt :categories_by_source_id) (s/coll-of string?)
   (ds/opt :authors) (s/coll-of any?)
   (ds/opt :custom_fields) any?
   (ds/opt :custom_fields_list) (s/coll-of custom-article-field-add-spec)
   (ds/opt :defined_type) string?
   (ds/opt :funding) string?
   (ds/opt :funding_list) (s/coll-of funding-create-spec)
   (ds/opt :license) int?
   (ds/opt :doi) string?
   (ds/opt :handle) string?
   (ds/opt :resource_doi) string?
   (ds/opt :resource_title) string?
   (ds/opt :timeline) timeline-update-spec
   })

(def article-project-create-spec
  (ds/spec
    {:name ::article-project-create
     :spec article-project-create-data}))
