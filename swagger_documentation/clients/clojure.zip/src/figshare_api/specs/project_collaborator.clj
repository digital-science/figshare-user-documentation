(ns figshare-api.specs.project-collaborator
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def project-collaborator-data
  {
   (ds/req :status) string?
   (ds/req :role_name) string?
   (ds/req :user_id) int?
   (ds/req :name) string?
   })

(def project-collaborator-spec
  (ds/spec
    {:name ::project-collaborator
     :spec project-collaborator-data}))
