(ns figshare-api.specs.location-warnings-update
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def location-warnings-update-data
  {
   (ds/req :location) string?
   (ds/req :warnings) (s/coll-of string?)
   })

(def location-warnings-update-spec
  (ds/spec
    {:name ::location-warnings-update
     :spec location-warnings-update-data}))
