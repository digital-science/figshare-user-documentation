(ns figshare-api.specs.profile-update-data-personal-profiles-inner
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def profile-update-data-personal-profiles-inner-data
  {
   (ds/opt :label) string?
   (ds/opt :url) string?
   })

(def profile-update-data-personal-profiles-inner-spec
  (ds/spec
    {:name ::profile-update-data-personal-profiles-inner
     :spec profile-update-data-personal-profiles-inner-data}))
