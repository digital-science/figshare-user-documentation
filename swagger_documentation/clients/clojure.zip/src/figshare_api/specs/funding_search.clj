(ns figshare-api.specs.funding-search
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def funding-search-data
  {
   (ds/opt :search_for) string?
   })

(def funding-search-spec
  (ds/spec
    {:name ::funding-search
     :spec funding-search-data}))
