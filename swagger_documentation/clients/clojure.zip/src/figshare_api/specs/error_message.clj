(ns figshare-api.specs.error-message
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def error-message-data
  {
   (ds/opt :code) int?
   (ds/opt :message) string?
   })

(def error-message-spec
  (ds/spec
    {:name ::error-message
     :spec error-message-data}))
