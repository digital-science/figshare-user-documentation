(ns figshare-api.specs.private-file
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def private-file-data
  {
   (ds/req :viewer_type) string?
   (ds/req :preview_state) string?
   (ds/req :upload_url) string?
   (ds/req :upload_token) string?
   (ds/req :is_attached_to_public_version) boolean?
   (ds/req :id) int?
   (ds/req :name) string?
   (ds/req :size) int?
   (ds/req :is_link_only) boolean?
   (ds/req :download_url) string?
   (ds/req :supplied_md5) string?
   (ds/req :computed_md5) string?
   (ds/opt :mimetype) string?
   })

(def private-file-spec
  (ds/spec
    {:name ::private-file
     :spec private-file-data}))
