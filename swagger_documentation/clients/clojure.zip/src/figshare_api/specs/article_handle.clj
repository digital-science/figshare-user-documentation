(ns figshare-api.specs.article-handle
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def article-handle-data
  {
   (ds/req :handle) string?
   })

(def article-handle-spec
  (ds/spec
    {:name ::article-handle
     :spec article-handle-data}))
