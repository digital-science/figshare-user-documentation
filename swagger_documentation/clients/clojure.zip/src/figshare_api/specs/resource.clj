(ns figshare-api.specs.resource
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def resource-data
  {
   (ds/opt :id) string?
   (ds/opt :title) string?
   (ds/opt :doi) string?
   (ds/opt :link) string?
   (ds/opt :status) string?
   (ds/opt :version) int?
   })

(def resource-spec
  (ds/spec
    {:name ::resource
     :spec resource-data}))
