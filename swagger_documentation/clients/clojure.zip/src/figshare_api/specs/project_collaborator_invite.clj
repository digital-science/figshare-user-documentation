(ns figshare-api.specs.project-collaborator-invite
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def project-collaborator-invite-data
  {
   (ds/req :role_name) string?
   (ds/opt :user_id) int?
   (ds/opt :email) string?
   (ds/opt :comment) string?
   })

(def project-collaborator-invite-spec
  (ds/spec
    {:name ::project-collaborator-invite
     :spec project-collaborator-invite-data}))
