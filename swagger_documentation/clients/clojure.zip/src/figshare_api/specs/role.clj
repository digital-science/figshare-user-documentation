(ns figshare-api.specs.role
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def role-data
  {
   (ds/req :id) int?
   (ds/req :name) string?
   (ds/req :category) string?
   (ds/req :description) string?
   })

(def role-spec
  (ds/spec
    {:name ::role
     :spec role-data}))
