(ns figshare-api.specs.author-complete
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def author-complete-data
  {
   (ds/req :institution_id) int?
   (ds/req :group_id) int?
   (ds/req :first_name) string?
   (ds/req :last_name) string?
   (ds/req :is_public) int?
   (ds/req :job_title) string?
   (ds/req :id) int?
   (ds/req :full_name) string?
   (ds/req :is_active) boolean?
   (ds/req :url_name) string?
   (ds/req :orcid_id) string?
   })

(def author-complete-spec
  (ds/spec
    {:name ::author-complete
     :spec author-complete-data}))
