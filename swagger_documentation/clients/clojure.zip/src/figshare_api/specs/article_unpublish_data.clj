(ns figshare-api.specs.article-unpublish-data
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def article-unpublish-data-data
  {
   (ds/req :reason) string?
   })

(def article-unpublish-data-spec
  (ds/spec
    {:name ::article-unpublish-data
     :spec article-unpublish-data-data}))
