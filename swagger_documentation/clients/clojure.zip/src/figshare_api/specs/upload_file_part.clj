(ns figshare-api.specs.upload-file-part
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def upload-file-part-data
  {
   (ds/opt :partNo) int?
   (ds/opt :startOffset) int?
   (ds/opt :endOffset) int?
   (ds/opt :status) string?
   (ds/opt :locked) boolean?
   })

(def upload-file-part-spec
  (ds/spec
    {:name ::upload-file-part
     :spec upload-file-part-data}))
