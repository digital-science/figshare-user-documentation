(ns figshare-api.specs.project-private
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def project-private-data
  {
   (ds/req :role) string?
   (ds/req :storage) string?
   (ds/req :url) string?
   (ds/req :id) int?
   (ds/req :title) string?
   (ds/req :created_date) string?
   (ds/req :modified_date) string?
   })

(def project-private-spec
  (ds/spec
    {:name ::project-private
     :spec project-private-data}))
