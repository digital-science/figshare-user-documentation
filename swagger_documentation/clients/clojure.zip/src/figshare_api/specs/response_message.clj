(ns figshare-api.specs.response-message
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def response-message-data
  {
   (ds/req :message) string?
   })

(def response-message-spec
  (ds/spec
    {:name ::response-message
     :spec response-message-data}))
