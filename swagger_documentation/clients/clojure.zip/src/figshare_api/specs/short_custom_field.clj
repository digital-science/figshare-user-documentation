(ns figshare-api.specs.short-custom-field
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [figshare-api.specs. :refer :all]
            )
  (:import (java.io File)))


(def short-custom-field-data
  {
   (ds/req :id) int?
   (ds/req :name) string?
   (ds/req :field_type) string?
   (ds/opt :settings) any?
   (ds/opt :order) int?
   (ds/opt :is_mandatory) boolean?
   })

(def short-custom-field-spec
  (ds/spec
    {:name ::short-custom-field
     :spec short-custom-field-data}))
