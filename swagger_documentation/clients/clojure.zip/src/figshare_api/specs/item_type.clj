(ns figshare-api.specs.item-type
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def item-type-data
  {
   (ds/req :id) int?
   (ds/req :name) string?
   (ds/req :string_id) string?
   (ds/req :icon) string?
   (ds/req :public_description) string?
   (ds/req :is_selectable) boolean?
   (ds/req :url_name) string?
   })

(def item-type-spec
  (ds/spec
    {:name ::item-type
     :spec item-type-data}))
