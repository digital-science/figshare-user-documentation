(ns figshare-api.specs.collection-doi
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def collection-doi-data
  {
   (ds/req :doi) string?
   })

(def collection-doi-spec
  (ds/spec
    {:name ::collection-doi
     :spec collection-doi-data}))
