(ns figshare-api.specs.article-versions
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def article-versions-data
  {
   (ds/req :version) int?
   (ds/req :url) string?
   })

(def article-versions-spec
  (ds/spec
    {:name ::article-versions
     :spec article-versions-data}))
