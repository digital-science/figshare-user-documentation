# ArticleConfidentiality

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_confidential** | **bool** | True if article is confidential | 
**reason** | **String** | Reason for confidentiality | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


