# Resource

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> | ID of resource item | [optional][default to ]
**title** | Option<**String**> | Title of resource item | [optional][default to ]
**doi** | Option<**String**> | DOI of resource item | [optional][default to ]
**link** | Option<**String**> | Link of resource item | [optional][default to ]
**status** | Option<**String**> | Status of resource item | [optional][default to ]
**version** | Option<**i64**> | Version of resource item | [optional][default to 0]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


