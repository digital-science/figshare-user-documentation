# InstitutionAccountsSearch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_for** | Option<**String**> | Search term | [optional]
**is_active** | Option<**i64**> | Filter by active status | [optional]
**page** | Option<**i64**> | Page number. Used for pagination with page_size | [optional]
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page | [optional][default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query | [optional]
**offset** | Option<**i64**> | Where to start the listing(the offset of the first result). Used for pagination with limit | [optional]
**institution_user_id** | Option<**String**> | filter by institution_user_id | [optional]
**email** | Option<**String**> | filter by email | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


