# ShortAccount

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i32** | Account id | 
**first_name** | **String** | First Name | 
**last_name** | **String** | Last Name | 
**institution_id** | **i32** | Account institution | 
**email** | **String** | User email | 
**active** | **i32** | Account activity status | 
**institution_user_id** | **String** | Account institution user id | 
**quota** | **i32** | Total storage available to account, in bytes | 
**used_quota** | **i32** | Storage used by the account, in bytes | 
**user_id** | **i32** | User id associated with account, useful for example for adding the account as an author to an item | 
**orcid_id** | **String** | ORCID iD associated to account | 
**symplectic_user_id** | **String** | Symplectic ID associated to account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


