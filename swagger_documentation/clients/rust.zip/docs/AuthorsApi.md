# \AuthorsApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**private_author_details**](AuthorsApi.md#private_author_details) | **GET** /account/authors/{author_id} | Author details
[**private_authors_search**](AuthorsApi.md#private_authors_search) | **POST** /account/authors/search | Search Authors



## private_author_details

> models::AuthorComplete private_author_details(author_id)
Author details

View author details

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**author_id** | **i64** | Author unique identifier | [required] |

### Return type

[**models::AuthorComplete**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_authors_search

> Vec<models::AuthorComplete> private_authors_search(search)
Search Authors

Search for authors

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**search** | Option<[**PrivateAuthorsSearch**](PrivateAuthorsSearch.md)> | Search Parameters |  |

### Return type

[**Vec<models::AuthorComplete>**](AuthorComplete.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

