# FileId

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file_id** | Option<**i64**> | File ID | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


