# CreateOAuthToken

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**client_id** | **String** |  | 
**client_secret** | **String** |  | 
**grant_type** | **String** |  | 
**code** | Option<**String**> | Required if grant_type is 'authorization_code' | [optional]
**refresh_token** | Option<**String**> | Required if grant_type is 'refresh_token' | [optional]
**username** | Option<**String**> | Required if grant_type is 'password' | [optional]
**password** | Option<**String**> | Required if grant_type is 'password' | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


