# ProfileUpdateData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_name** | Option<**String**> | First name | [optional]
**last_name** | Option<**String**> | Last Name | [optional]
**orcid** | Option<**String**> | User ORCID | [optional]
**job_title** | Option<**String**> | User job title | [optional]
**fields_of_interest** | Option<**Vec<i64>**> | User fields of interest (category ids) | [optional]
**fields_of_interest_by_source_id** | Option<**Vec<String>**> | User fields of interest (category source IDs), supersedes the fields_of_interest property | [optional]
**location** | Option<**String**> | User location | [optional]
**facebook** | Option<**String**> | User facebook URL | [optional]
**x** | Option<**String**> | User X (twitter) URL | [optional]
**linkedin** | Option<**String**> | User linkedin URL | [optional]
**bio** | Option<**String**> | User biographical information | [optional]
**personal_profiles** | Option<[**Vec<models::ProfileUpdateDataPersonalProfilesInner>**](ProfileUpdateData_personal_profiles_inner.md)> | Add up to 10 additional personal profile links | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


