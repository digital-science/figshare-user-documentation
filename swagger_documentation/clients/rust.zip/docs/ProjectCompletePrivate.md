# ProjectCompletePrivate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **String** | Project funding | 
**funding_list** | [**Vec<models::FundingInformation>**](FundingInformation.md) | Full Project funding information | 
**description** | **String** | Project description | 
**collaborators** | [**Vec<models::Collaborator>**](Collaborator.md) | List of project collaborators | 
**quota** | **i64** | Project quota | 
**used_quota** | **i64** | Project used quota | 
**created_date** | **String** | Date when project was created | 
**modified_date** | **String** | Date when project was last modified | 
**used_quota_private** | **i64** | Project private quota used | 
**used_quota_public** | **i64** | Project public quota used | 
**group_id** | **i64** | Group of project if any | 
**account_id** | **i64** | ID of the account owning the project | 
**custom_fields** | [**Vec<models::ShortCustomField>**](ShortCustomField.md) | Collection custom fields | 
**role** | **String** | Role inside this project | 
**storage** | **String** | Project storage type | 
**url** | **String** | Api endpoint | 
**id** | **i64** | Project id | 
**title** | **String** | Project title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


