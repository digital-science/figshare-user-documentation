# \ArticlesApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**account_article_publish**](ArticlesApi.md#account_article_publish) | **POST** /account/articles/{article_id}/publish | Private Article Publish
[**account_article_report**](ArticlesApi.md#account_article_report) | **GET** /account/articles/export | Account Article Report
[**account_article_report_generate**](ArticlesApi.md#account_article_report_generate) | **POST** /account/articles/export | Initiate a new Report
[**account_article_unpublish**](ArticlesApi.md#account_article_unpublish) | **POST** /account/articles/{article_id}/unpublish | Public Article Unpublish
[**article_details**](ArticlesApi.md#article_details) | **GET** /articles/{article_id} | View article details
[**article_file_details**](ArticlesApi.md#article_file_details) | **GET** /articles/{article_id}/files/{file_id} | Article file details
[**article_files**](ArticlesApi.md#article_files) | **GET** /articles/{article_id}/files | List article files
[**article_version_confidentiality**](ArticlesApi.md#article_version_confidentiality) | **GET** /articles/{article_id}/versions/{version_id}/confidentiality | Public Article Confidentiality for article version
[**article_version_details**](ArticlesApi.md#article_version_details) | **GET** /articles/{article_id}/versions/{version_id} | Article details for version
[**article_version_embargo**](ArticlesApi.md#article_version_embargo) | **GET** /articles/{article_id}/versions/{version_id}/embargo | Public Article Embargo for article version
[**article_version_files**](ArticlesApi.md#article_version_files) | **GET** /articles/{article_id}/versions/{version_id}/files | Public Article version files
[**article_version_partial_update**](ArticlesApi.md#article_version_partial_update) | **PATCH** /account/articles/{article_id}/versions/{version_id} | Partially update article version
[**article_version_update**](ArticlesApi.md#article_version_update) | **PUT** /account/articles/{article_id}/versions/{version_id} | Update article version
[**article_version_update_thumb**](ArticlesApi.md#article_version_update_thumb) | **PUT** /account/articles/{article_id}/versions/{version_id}/update_thumb | Update article version thumbnail
[**article_versions**](ArticlesApi.md#article_versions) | **GET** /articles/{article_id}/versions | List article versions
[**articles_list**](ArticlesApi.md#articles_list) | **GET** /articles | Public Articles
[**articles_search**](ArticlesApi.md#articles_search) | **POST** /articles/search | Public Articles Search
[**private_article_author_delete**](ArticlesApi.md#private_article_author_delete) | **DELETE** /account/articles/{article_id}/authors/{author_id} | Delete article author
[**private_article_authors_add**](ArticlesApi.md#private_article_authors_add) | **POST** /account/articles/{article_id}/authors | Add article authors
[**private_article_authors_list**](ArticlesApi.md#private_article_authors_list) | **GET** /account/articles/{article_id}/authors | List article authors
[**private_article_authors_replace**](ArticlesApi.md#private_article_authors_replace) | **PUT** /account/articles/{article_id}/authors | Replace article authors
[**private_article_categories_add**](ArticlesApi.md#private_article_categories_add) | **POST** /account/articles/{article_id}/categories | Add article categories
[**private_article_categories_list**](ArticlesApi.md#private_article_categories_list) | **GET** /account/articles/{article_id}/categories | List article categories
[**private_article_categories_replace**](ArticlesApi.md#private_article_categories_replace) | **PUT** /account/articles/{article_id}/categories | Replace article categories
[**private_article_category_delete**](ArticlesApi.md#private_article_category_delete) | **DELETE** /account/articles/{article_id}/categories/{category_id} | Delete article category
[**private_article_confidentiality_delete**](ArticlesApi.md#private_article_confidentiality_delete) | **DELETE** /account/articles/{article_id}/confidentiality | Delete article confidentiality
[**private_article_confidentiality_details**](ArticlesApi.md#private_article_confidentiality_details) | **GET** /account/articles/{article_id}/confidentiality | Article confidentiality details
[**private_article_confidentiality_update**](ArticlesApi.md#private_article_confidentiality_update) | **PUT** /account/articles/{article_id}/confidentiality | Update article confidentiality
[**private_article_create**](ArticlesApi.md#private_article_create) | **POST** /account/articles | Create new Article
[**private_article_delete**](ArticlesApi.md#private_article_delete) | **DELETE** /account/articles/{article_id} | Delete article
[**private_article_details**](ArticlesApi.md#private_article_details) | **GET** /account/articles/{article_id} | Article details
[**private_article_download**](ArticlesApi.md#private_article_download) | **GET** /account/articles/{article_id}/download | Private Article Download
[**private_article_embargo_delete**](ArticlesApi.md#private_article_embargo_delete) | **DELETE** /account/articles/{article_id}/embargo | Delete Article Embargo
[**private_article_embargo_details**](ArticlesApi.md#private_article_embargo_details) | **GET** /account/articles/{article_id}/embargo | Article Embargo Details
[**private_article_embargo_update**](ArticlesApi.md#private_article_embargo_update) | **PUT** /account/articles/{article_id}/embargo | Update Article Embargo
[**private_article_file**](ArticlesApi.md#private_article_file) | **GET** /account/articles/{article_id}/files/{file_id} | Single File
[**private_article_file_delete**](ArticlesApi.md#private_article_file_delete) | **DELETE** /account/articles/{article_id}/files/{file_id} | File Delete
[**private_article_files_list**](ArticlesApi.md#private_article_files_list) | **GET** /account/articles/{article_id}/files | List article files
[**private_article_partial_update**](ArticlesApi.md#private_article_partial_update) | **PATCH** /account/articles/{article_id} | Partially update article
[**private_article_private_link**](ArticlesApi.md#private_article_private_link) | **GET** /account/articles/{article_id}/private_links | List private links
[**private_article_private_link_create**](ArticlesApi.md#private_article_private_link_create) | **POST** /account/articles/{article_id}/private_links | Create private link
[**private_article_private_link_delete**](ArticlesApi.md#private_article_private_link_delete) | **DELETE** /account/articles/{article_id}/private_links/{link_id} | Disable private link
[**private_article_private_link_update**](ArticlesApi.md#private_article_private_link_update) | **PUT** /account/articles/{article_id}/private_links/{link_id} | Update private link
[**private_article_reserve_doi**](ArticlesApi.md#private_article_reserve_doi) | **POST** /account/articles/{article_id}/reserve_doi | Private Article Reserve DOI
[**private_article_reserve_handle**](ArticlesApi.md#private_article_reserve_handle) | **POST** /account/articles/{article_id}/reserve_handle | Private Article Reserve Handle
[**private_article_resource**](ArticlesApi.md#private_article_resource) | **POST** /account/articles/{article_id}/resource | Private Article Resource
[**private_article_update**](ArticlesApi.md#private_article_update) | **PUT** /account/articles/{article_id} | Update article
[**private_article_upload_complete**](ArticlesApi.md#private_article_upload_complete) | **POST** /account/articles/{article_id}/files/{file_id} | Complete Upload
[**private_article_upload_initiate**](ArticlesApi.md#private_article_upload_initiate) | **POST** /account/articles/{article_id}/files | Initiate Upload
[**private_articles_list**](ArticlesApi.md#private_articles_list) | **GET** /account/articles | Private Articles
[**private_articles_search**](ArticlesApi.md#private_articles_search) | **POST** /account/articles/search | Private Articles search
[**public_article_download**](ArticlesApi.md#public_article_download) | **GET** /articles/{article_id}/download | Public Article Download
[**public_article_version_download**](ArticlesApi.md#public_article_version_download) | **GET** /articles/{article_id}/versions/{version_id}/download | Public Article Version Download



## account_article_publish

> models::Location account_article_publish(article_id)
Private Article Publish

- If the whole article is under embargo, it will not be published immediately, but when the embargo expires or is lifted. - When an article is published, a new public version will be generated. Any further updates to the article will affect the private article data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |

### Return type

[**models::Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## account_article_report

> Vec<models::AccountReport> account_article_report(group_id)
Account Article Report

Return status on all reports generated for the account from the oauth credentials

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**group_id** | Option<**i64**> | A group ID to filter by |  |

### Return type

[**Vec<models::AccountReport>**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## account_article_report_generate

> models::AccountReport account_article_report_generate()
Initiate a new Report

Initiate a new Article Report for this Account. There is a limit of 1 report per day.

### Parameters

This endpoint does not need any parameter.

### Return type

[**models::AccountReport**](AccountReport.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## account_article_unpublish

> account_article_unpublish(article_id, reason)
Public Article Unpublish

Allows authorized users to unpublish an article.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**reason** | [**ArticleUnpublishData**](ArticleUnpublishData.md) | Article unpublish data | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## article_details

> models::ArticleComplete article_details(article_id)
View article details

View an article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article Unique identifier | [required] |

### Return type

[**models::ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## article_file_details

> models::PublicFile article_file_details(article_id, file_id)
Article file details

File by id

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article Unique identifier | [required] |
**file_id** | **i64** | File Unique identifier | [required] |

### Return type

[**models::PublicFile**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## article_files

> Vec<models::PublicFile> article_files(article_id, page, page_size, limit, offset)
List article files

Files list for article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article Unique identifier | [required] |
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |

### Return type

[**Vec<models::PublicFile>**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## article_version_confidentiality

> models::ArticleConfidentiality article_version_confidentiality(article_id, version_id)
Public Article Confidentiality for article version

Confidentiality for article version. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article Unique identifier | [required] |
**version_id** | **i64** | Version Number | [required] |

### Return type

[**models::ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## article_version_details

> models::ArticleComplete article_version_details(article_id, version_id)
Article details for version

Article with specified version

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article Unique identifier | [required] |
**version_id** | **i64** | Article Version Number | [required] |

### Return type

[**models::ArticleComplete**](ArticleComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## article_version_embargo

> models::ArticleEmbargo article_version_embargo(article_id, version_id)
Public Article Embargo for article version

Embargo for article version

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article Unique identifier | [required] |
**version_id** | **i64** | Version Number | [required] |

### Return type

[**models::ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## article_version_files

> Vec<models::PublicFile> article_version_files(article_id, version_id, page, page_size, limit, offset)
Public Article version files

Article version file details

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article Unique identifier | [required] |
**version_id** | **i64** | Article Version Unique identifier | [required] |
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |

### Return type

[**Vec<models::PublicFile>**](PublicFile.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## article_version_partial_update

> models::LocationWarningsUpdate article_version_partial_update(article_id, version_id, article)
Partially update article version

Partially updating an article version by passing only the fields to change.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**version_id** | **i64** | Article version identifier | [required] |
**article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md) | Subset of article version fields to update | [required] |

### Return type

[**models::LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## article_version_update

> models::LocationWarningsUpdate article_version_update(article_id, version_id, article)
Update article version

Updating an article version by passing body parameters.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**version_id** | **i64** | Article version identifier | [required] |
**article** | [**ArticleVersionUpdate**](ArticleVersionUpdate.md) | Article description | [required] |

### Return type

[**models::LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## article_version_update_thumb

> article_version_update_thumb(article_id, version_id, file_id)
Update article version thumbnail

For a given public article version update the article thumbnail by choosing one of the associated files

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**version_id** | **i64** | Article version identifier | [required] |
**file_id** | [**FileId**](FileId.md) | File ID | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## article_versions

> Vec<models::ArticleVersions> article_versions(article_id)
List article versions

List public article versions

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article Unique identifier | [required] |

### Return type

[**Vec<models::ArticleVersions>**](ArticleVersions.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## articles_list

> Vec<models::Article> articles_list(x_cursor, page, page_size, limit, offset, order, order_direction, institution, published_since, modified_since, group, resource_doi, item_type, doi, handle)
Public Articles

Returns a list of public articles

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**x_cursor** | Option<**uuid::Uuid**> | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. |  |
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |
**order** | Option<**String**> | The field by which to order. Default varies by endpoint/resource. |  |[default to published_date]
**order_direction** | Option<**String**> |  |  |[default to desc]
**institution** | Option<**i64**> | only return articles from this institution |  |
**published_since** | Option<**String**> | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ |  |
**modified_since** | Option<**String**> | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ |  |
**group** | Option<**i64**> | only return articles from this group |  |
**resource_doi** | Option<**String**> | Deprecated by related materials. Only return articles with this resource_doi |  |
**item_type** | Option<**i64**> | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model |  |
**doi** | Option<**String**> | only return articles with this doi |  |
**handle** | Option<**String**> | only return articles with this handle |  |

### Return type

[**Vec<models::Article>**](Article.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## articles_search

> Vec<models::ArticleWithProject> articles_search(x_cursor, search)
Public Articles Search

Returns a list of public articles, filtered by the search parameters

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**x_cursor** | Option<**uuid::Uuid**> | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. |  |
**search** | Option<[**ArticleSearch**](ArticleSearch.md)> | Search Parameters |  |

### Return type

[**Vec<models::ArticleWithProject>**](ArticleWithProject.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_author_delete

> private_article_author_delete(article_id, author_id)
Delete article author

De-associate author from article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**author_id** | **i64** | Article Author unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_authors_add

> private_article_authors_add(article_id, authors)
Add article authors

Associate new authors with the article. This will add new authors to the list of already associated authors

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**authors** | [**AuthorsCreator**](AuthorsCreator.md) | Authors description | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_authors_list

> Vec<models::Author> private_article_authors_list(article_id)
List article authors

List article authors

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |

### Return type

[**Vec<models::Author>**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_authors_replace

> private_article_authors_replace(article_id, authors)
Replace article authors

Associate new authors with the article. This will remove all already associated authors and add these new ones

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**authors** | [**AuthorsCreator**](AuthorsCreator.md) | Authors description | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_categories_add

> private_article_categories_add(article_id, categories)
Add article categories

Associate new categories with the article. This will add new categories to the list of already associated categories

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**categories** | [**CategoriesCreator**](CategoriesCreator.md) |  | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_categories_list

> Vec<models::Category> private_article_categories_list(article_id)
List article categories

List article categories

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |

### Return type

[**Vec<models::Category>**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_categories_replace

> private_article_categories_replace(article_id, categories)
Replace article categories

Associate new categories with the article. This will remove all already associated categories and add these new ones

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**categories** | [**CategoriesCreator**](CategoriesCreator.md) |  | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_category_delete

> private_article_category_delete(article_id, category_id)
Delete article category

De-associate category from article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**category_id** | **i64** | Category unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_confidentiality_delete

> private_article_confidentiality_delete(article_id)
Delete article confidentiality

Delete confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_confidentiality_details

> models::ArticleConfidentiality private_article_confidentiality_details(article_id)
Article confidentiality details

View confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |

### Return type

[**models::ArticleConfidentiality**](ArticleConfidentiality.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_confidentiality_update

> private_article_confidentiality_update(article_id, reason)
Update article confidentiality

Update confidentiality settings. The confidentiality feature is now deprecated. This has been replaced by the new extended embargo functionality and all items that used to be confidential have now been migrated to items with a permanent embargo on files. All API endpoints related to this functionality will remain for backwards compatibility, but will now be attached to the new extended embargo workflows.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**reason** | [**ConfidentialityCreator**](ConfidentialityCreator.md) |  | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_create

> models::LocationWarnings private_article_create(article)
Create new Article

Create a new Article by sending article information

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article** | [**ArticleCreate**](ArticleCreate.md) | Article description | [required] |

### Return type

[**models::LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_delete

> private_article_delete(article_id)
Delete article

Delete an article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_details

> models::ArticleCompletePrivate private_article_details(article_id)
Article details

View a private article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |

### Return type

[**models::ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_download

> private_article_download(article_id, folder_path)
Private Article Download

Download files from a private article preserving the folder structure

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**folder_path** | Option<**String**> | Folder path to download. If not provided, all files from the article will be downloaded |  |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_embargo_delete

> private_article_embargo_delete(article_id)
Delete Article Embargo

Will lift the embargo for the specified article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_embargo_details

> models::ArticleEmbargo private_article_embargo_details(article_id)
Article Embargo Details

View a private article embargo details

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |

### Return type

[**models::ArticleEmbargo**](ArticleEmbargo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_embargo_update

> private_article_embargo_update(article_id, embargo)
Update Article Embargo

Note: setting an article under whole embargo does not imply that the article will be published when the embargo will expire. You must explicitly call the publish endpoint to enable this functionality.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**embargo** | [**ArticleEmbargoUpdater**](ArticleEmbargoUpdater.md) | Embargo description | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_file

> models::PrivateFile private_article_file(article_id, file_id)
Single File

View details of file for specified article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**file_id** | **i64** | File unique identifier | [required] |

### Return type

[**models::PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_file_delete

> private_article_file_delete(article_id, file_id)
File Delete

Complete file upload

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**file_id** | **i64** | File unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_files_list

> Vec<models::PrivateFile> private_article_files_list(article_id, page, page_size, limit, offset)
List article files

List private files

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |

### Return type

[**Vec<models::PrivateFile>**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_partial_update

> models::LocationWarningsUpdate private_article_partial_update(article_id, article)
Partially update article

Partially update an article by sending only the fields to change.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**article** | [**ArticleUpdate**](ArticleUpdate.md) | Subset of article fields to update | [required] |

### Return type

[**models::LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_private_link

> Vec<models::PrivateLink> private_article_private_link(article_id)
List private links

List private links

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |

### Return type

[**Vec<models::PrivateLink>**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_private_link_create

> models::PrivateLinkResponse private_article_private_link_create(article_id, private_link)
Create private link

Create new private link for this article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**private_link** | Option<[**PrivateLinkCreator**](PrivateLinkCreator.md)> |  |  |

### Return type

[**models::PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_private_link_delete

> private_article_private_link_delete(article_id, link_id)
Disable private link

Disable/delete private link for this article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**link_id** | **String** | Private link token | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_private_link_update

> private_article_private_link_update(article_id, link_id, private_link)
Update private link

Update existing private link for this article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**link_id** | **String** | Private link token | [required] |
**private_link** | Option<[**PrivateLinkCreator**](PrivateLinkCreator.md)> |  |  |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_reserve_doi

> models::ArticleDoi private_article_reserve_doi(article_id)
Private Article Reserve DOI

Reserve DOI for article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |

### Return type

[**models::ArticleDoi**](ArticleDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_reserve_handle

> models::ArticleHandle private_article_reserve_handle(article_id)
Private Article Reserve Handle

Reserve Handle for article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |

### Return type

[**models::ArticleHandle**](ArticleHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_resource

> models::Location private_article_resource(article_id, resource)
Private Article Resource

Edit article resource data.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**resource** | [**Resource**](Resource.md) | Resource data | [required] |

### Return type

[**models::Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_update

> models::LocationWarningsUpdate private_article_update(article_id, article)
Update article

Update an article by passing full body parameters.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**article** | [**ArticleUpdate**](ArticleUpdate.md) | Full article representation | [required] |

### Return type

[**models::LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_upload_complete

> private_article_upload_complete(article_id, file_id)
Complete Upload

Complete file upload

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**file_id** | **i64** | File unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_article_upload_initiate

> models::Location private_article_upload_initiate(article_id, file, page, page_size, limit, offset)
Initiate Upload

Initiate a new file upload within the article. Either use the link property to point to an existing file that resides elsewhere and will not be uploaded to Figshare or use the other 3 parameters (md5, name, size).

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**file** | [**FileCreator**](FileCreator.md) |  | [required] |
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |

### Return type

[**models::Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_articles_list

> Vec<models::Article> private_articles_list(page, page_size, limit, offset)
Private Articles

Get Own Articles

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |

### Return type

[**Vec<models::Article>**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_articles_search

> Vec<models::ArticleWithProject> private_articles_search(search)
Private Articles search

Returns a list of private articles filtered by the search parameters

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**search** | [**PrivateArticleSearch**](PrivateArticleSearch.md) | Search Parameters | [required] |

### Return type

[**Vec<models::ArticleWithProject>**](ArticleWithProject.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## public_article_download

> public_article_download(article_id, folder_path)
Public Article Download

Download files from a public article preserving the folder structure

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**folder_path** | Option<**String**> | Folder path to download. If not provided, all files from the article will be downloaded |  |

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## public_article_version_download

> public_article_version_download(article_id, version_id, folder_path)
Public Article Version Download

Download files from a certain version of an public article preserving the folder structure

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i64** | Article unique identifier | [required] |
**version_id** | **i64** | Version Number | [required] |
**folder_path** | Option<**String**> | Folder path to download. If not provided, all files from the article will be downloaded |  |

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

