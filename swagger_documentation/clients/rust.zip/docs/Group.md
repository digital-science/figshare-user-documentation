# Group

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i64** | Group id | 
**name** | **String** | Group name | 
**resource_id** | **String** | Group resource id | 
**parent_id** | **i64** | Parent group if any | 
**association_criteria** | **String** | HR code associated with group, if code exists | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


