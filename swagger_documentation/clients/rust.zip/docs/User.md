# User

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i64** | User id | 
**first_name** | **String** | First Name | 
**last_name** | **String** | Last Name | 
**name** | **String** | Full Name | 
**is_active** | **bool** | Account activity status | 
**url_name** | **String** | Name that appears in website url | 
**is_public** | **bool** | Account public status | 
**job_title** | **String** | User Job title | 
**orcid_id** | **String** | Orcid associated to this User | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


