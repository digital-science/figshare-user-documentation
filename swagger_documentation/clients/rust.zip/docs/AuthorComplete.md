# AuthorComplete

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**institution_id** | **i64** | Institution id | 
**group_id** | **i64** | Group id | 
**first_name** | **String** | First Name | 
**last_name** | **String** | Last Name | 
**is_public** | **i64** | if 1 then the author has published items | 
**job_title** | **String** | Job title | 
**id** | **i64** | Author id | 
**full_name** | **String** | Author full name | 
**is_active** | **bool** | True if author has published items | 
**url_name** | **String** | Author url name | 
**orcid_id** | **String** | Author Orcid | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


