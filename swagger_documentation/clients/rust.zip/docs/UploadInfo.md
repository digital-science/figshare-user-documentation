# UploadInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | Option<**String**> | token received after initializing a file upload | [optional]
**md5** | Option<**String**> | md5 provided on upload initialization | [optional]
**size** | Option<**i64**> | size of file in bytes | [optional]
**name** | Option<**String**> | name of file on upload server | [optional]
**status** | Option<**String**> | Upload status | [optional]
**parts** | Option<[**Vec<models::UploadFilePart>**](UploadFilePart.md)> | Uploads parts | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


