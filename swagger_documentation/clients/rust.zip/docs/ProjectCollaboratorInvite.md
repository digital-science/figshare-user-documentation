# ProjectCollaboratorInvite

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role_name** | **String** | Role of the the collaborator inside the project | 
**user_id** | Option<**i64**> | User id of the collaborator | [optional]
**email** | Option<**String**> | Collaborator email | [optional]
**comment** | Option<**String**> | Text sent when inviting the user to the project | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


