# \SymplecticApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**symplectic_account_articles**](SymplecticApi.md#symplectic_account_articles) | **GET** /symplectic/accounts/{external_user_id}/articles | Get articles for a specific account
[**symplectic_accounts_ids**](SymplecticApi.md#symplectic_accounts_ids) | **GET** /symplectic/accounts | Get changed accounts for Symplectic Elements
[**symplectic_article**](SymplecticApi.md#symplectic_article) | **GET** /symplectic/articles/{article_id} | Get article details for Symplectic Elements
[**symplectic_changed_articles**](SymplecticApi.md#symplectic_changed_articles) | **GET** /symplectic/articles | Get changed articles for Symplectic Elements
[**symplectic_user_id**](SymplecticApi.md#symplectic_user_id) | **GET** /symplectic/users/{user_id} | Get institutional user ID for a user



## symplectic_account_articles

> Vec<serde_json::Value> symplectic_account_articles(external_user_id, offset, limit, status, is_embargoed)
Get articles for a specific account

Returns a list of articles for a specific user account identified by external_user_id (symplectic_user_id or institution_user_id).

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**external_user_id** | **String** | External user ID (symplectic_user_id or institution_user_id) | [required] |
**offset** | Option<**i32**> | Number of results to skip for pagination |  |[default to 0]
**limit** | Option<**i32**> | Maximum number of results to return |  |[default to 10]
**status** | Option<**String**> | Filter by article status |  |
**is_embargoed** | Option<**String**> | Filter by embargo status |  |

### Return type

[**Vec<serde_json::Value>**](serde_json::Value.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## symplectic_accounts_ids

> Vec<models::SymplecticAccountsIds200ResponseInner> symplectic_accounts_ids(since)
Get changed accounts for Symplectic Elements

Returns a list of accounts that have been modified since the specified date for Symplectic Elements integration.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**since** | **String** | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | [required] |

### Return type

[**Vec<models::SymplecticAccountsIds200ResponseInner>**](symplectic_accounts_ids_200_response_inner.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## symplectic_article

> serde_json::Value symplectic_article(article_id)
Get article details for Symplectic Elements

Returns detailed information about a specific article for Symplectic Elements integration, including full metadata and author account information.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**article_id** | **i32** | Article ID | [required] |

### Return type

[**serde_json::Value**](serde_json::Value.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## symplectic_changed_articles

> Vec<serde_json::Value> symplectic_changed_articles(since, offset, limit, status, is_embargoed)
Get changed articles for Symplectic Elements

Returns a list of articles for Symplectic Elements integration to synchronize article data.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**since** | **String** | ISO 8601 datetime string indicating the start of the search window (format: YYYY-MM-DD HH:MM:SS) | [required] |
**offset** | Option<**i32**> | Number of results to skip for pagination |  |[default to 0]
**limit** | Option<**i32**> | Maximum number of results to return |  |[default to 10]
**status** | Option<**String**> | Filter by article status |  |
**is_embargoed** | Option<**String**> | Filter by embargo status. When true, only returns articles with EMBARGO_ARTICLE type |  |

### Return type

[**Vec<serde_json::Value>**](serde_json::Value.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## symplectic_user_id

> models::SymplecticUserId200Response symplectic_user_id(user_id)
Get institutional user ID for a user

Returns the institution user ID for a given user within the authenticated account's institution.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**user_id** | **i32** | User ID | [required] |

### Return type

[**models::SymplecticUserId200Response**](symplectic_user_id_200_response.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

