# ArticleEmbargoUpdater

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_embargoed** | **bool** | Embargo status | 
**embargo_date** | **String** | Date when the embargo expires and the article gets published, '0' value will set up permanent embargo | 
**embargo_type** | **String** | Embargo can be enabled at the article or the file level. Possible values: article, file | 
**embargo_title** | Option<**String**> | Title for embargo | [optional]
**embargo_reason** | Option<**String**> | Reason for setting embargo | [optional]
**embargo_options** | Option<[**Vec<serde_json::Value>**](serde_json::Value.md)> | List of embargo permissions to be associated with the article. The list must contain `id` and can also contain `group_ids`(a field that only applies to 'logged_in' permissions). The new list replaces old options in the database, and an empty list removes all permissions for this article. Administration permission has to be set up alone but logged in and IP range permissions can be set up together. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


