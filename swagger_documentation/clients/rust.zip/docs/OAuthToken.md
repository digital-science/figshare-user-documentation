# OAuthToken

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_token** | **String** | The OAuth access token | 
**token** | Option<**String**> | The OAuth access token | [optional]
**token_type** | **String** | The type of token issued | 
**expires_in** | **i64** | Token expiration time in seconds | 
**refresh_token** | Option<**String**> | The refresh token (only provided for certain grant types) | [optional]
**scope** | Option<**String**> | The scope of the access token | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


