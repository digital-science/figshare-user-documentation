# ArticleCompletePrivate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account_id** | **i64** | ID of the account owning the article | 
**curation_status** | **String** | Curation status of the article | 
**figshare_url** | **String** | Article public url | 
**download_disabled** | **bool** | If true, downloading of files for this article is disabled | 
**files** | [**Vec<models::PublicFile>**](PublicFile.md) | List of up to 10 article files. | 
**folder_structure** | [**serde_json::Value**](.md) | Mapping of file ids to folder paths, if folders are used | 
**authors** | [**Vec<models::Author>**](Author.md) | List of article authors | 
**custom_fields** | [**Vec<models::CustomArticleField>**](CustomArticleField.md) | List of custom fields values | 
**embargo_options** | [**Vec<models::GroupEmbargoOptions>**](GroupEmbargoOptions.md) | List of embargo options | 
**citation** | **String** | Article citation | 
**confidential_reason** | **String** | Confidentiality reason | 
**is_confidential** | **bool** | Article Confidentiality | 
**size** | **i64** | Article size | 
**funding** | **String** | Article funding | 
**funding_list** | [**Vec<models::FundingInformation>**](FundingInformation.md) | Full Article funding information | 
**tags** | **Vec<String>** | List of article tags. Keywords can be used instead | 
**keywords** | **Vec<String>** | List of article keywords. Tags can be used instead | 
**version** | **i64** | Article version | 
**is_metadata_record** | **bool** | True if article has no files | 
**metadata_reason** | **String** | Article metadata reason | 
**status** | **String** | Article status | 
**description** | **String** | Article description | 
**is_embargoed** | **bool** | True if article is embargoed | 
**is_public** | **bool** | True if article is published | 
**created_date** | **String** | Date when article was created | 
**has_linked_file** | **bool** | True if any files are linked to the article | 
**categories** | [**Vec<models::Category>**](Category.md) | List of categories selected for the article | 
**license** | [**models::License**](License.md) |  | 
**embargo_title** | **String** | Title for embargo | 
**embargo_reason** | **String** | Reason for embargo | 
**references** | **Vec<String>** | List of references | 
**related_materials** | Option<[**Vec<models::RelatedMaterial>**](RelatedMaterial.md)> | List of related materials; supersedes references and resource DOI/title. | [optional]
**id** | **i64** | Unique identifier for article | 
**title** | **String** | Title of article | 
**doi** | **String** | DOI | 
**handle** | **String** | Handle | 
**url** | **String** | Api endpoint for article | 
**url_public_html** | **String** | Public site endpoint for article | 
**url_public_api** | **String** | Public Api endpoint for article | 
**url_private_html** | **String** | Private site endpoint for article | 
**url_private_api** | **String** | Private Api endpoint for article | 
**timeline** | [**models::Timeline**](Timeline.md) |  | 
**thumb** | **String** | Thumbnail image | 
**defined_type** | **i64** | Type of article identifier | 
**defined_type_name** | **String** | Name of the article type identifier | 
**resource_doi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to ]
**resource_title** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


