# ProjectComplete

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **String** | Project funding | 
**funding_list** | [**Vec<models::FundingInformation>**](FundingInformation.md) | Full Project funding information | 
**description** | **String** | Project description | 
**collaborators** | [**Vec<models::Collaborator>**](Collaborator.md) | List of project collaborators | 
**custom_fields** | [**Vec<models::CustomArticleField>**](CustomArticleField.md) | Project custom fields | 
**modified_date** | **String** | Date when project was last modified | 
**created_date** | **String** | Date when project was created | 
**url** | **String** | Api endpoint | 
**id** | **i64** | Project id | 
**title** | **String** | Project title | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


