# CollectionVersions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **i64** | Version number | 
**url** | **String** | Api endpoint for the collection version | 
**funding** | [**Vec<models::FundingInformation>**](FundingInformation.md) | Full Collection funding information | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


