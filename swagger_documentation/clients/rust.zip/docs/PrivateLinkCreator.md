# PrivateLinkCreator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expires_date** | Option<**String**> | Date when this private link should expire - optional. By default private links expire in 365 days. | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


