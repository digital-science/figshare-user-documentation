# \AltmetricApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**altmetric_institutions_list**](AltmetricApi.md#altmetric_institutions_list) | **GET** /altmetric/institutions | List Altmetric Institutions



## altmetric_institutions_list

> Vec<models::AltmetricInstitution> altmetric_institutions_list(offset)
List Altmetric Institutions

Returns a list of institutions available for Altmetric reporting

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**offset** | Option<**i32**> | Where to start the listing. The offset of the first item. |  |[default to 0]

### Return type

[**Vec<models::AltmetricInstitution>**](AltmetricInstitution.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

