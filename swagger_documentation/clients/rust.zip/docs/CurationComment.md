# CurationComment

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i64** | The ID of the comment. | 
**account_id** | **i64** | The ID of the account which generated this comment. | 
**r#type** | **String** | The ID of the account which generated this comment. | 
**text** | **String** | The value/content of the comment. | 
**created_date** | **String** | The creation date of the comment. | 
**modified_date** | **String** | The date the comment has been modified. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


