# Category

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent_id** | **i32** | Parent category | 
**id** | **i32** | Category id | 
**title** | **String** | Category title | 
**path** | **String** | Path to all ancestor ids | 
**source_id** | **String** | ID in original standard taxonomy | 
**taxonomy_id** | **i32** | Internal id of taxonomy the category is part of | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


