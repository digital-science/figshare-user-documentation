# Category

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent_id** | **i64** | Parent category | 
**id** | **i64** | Category id | 
**title** | **String** | Category title | 
**path** | **String** | Path to all ancestor ids | 
**source_id** | **String** | ID in original standard taxonomy | 
**taxonomy_id** | **i64** | Internal id of taxonomy the category is part of | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


