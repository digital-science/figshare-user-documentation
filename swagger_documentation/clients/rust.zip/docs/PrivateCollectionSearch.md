# PrivateCollectionSearch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource_id** | Option<**String**> | only return collections with this resource_id | [optional]
**resource_doi** | Option<**String**> | Only return collections with this resource_doi | [optional]
**doi** | Option<**String**> | Only return collections with this doi | [optional]
**handle** | Option<**String**> | Only return collections with this handle | [optional]
**order** | Option<**String**> | The field by which to order. | [optional][default to CreatedDate]
**search_for** | Option<**String**> | Search term | [optional]
**page** | Option<**i64**> | Page number. Used for pagination with page_size | [optional]
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page | [optional][default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query | [optional]
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]
**order_direction** | Option<**String**> | Direction of ordering | [optional][default to Desc]
**institution** | Option<**i32**> | only return collections from this institution | [optional]
**published_since** | Option<**String**> | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional]
**modified_since** | Option<**String**> | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ | [optional]
**group** | Option<**i32**> | only return collections from this group | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


