# ArticleUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | Option<**String**> | Title of article | [optional]
**description** | Option<**String**> | The article description. In a publisher case, usually this is the remote article description | [optional][default to ]
**is_metadata_record** | Option<**bool**> | True if article has no files | [optional]
**metadata_reason** | Option<**String**> | Article metadata reason | [optional]
**tags** | Option<**Vec<String>**> | List of tags to be associated with the article. Keywords can be used instead | [optional]
**keywords** | Option<**Vec<String>**> | List of tags to be associated with the article. Tags can be used instead | [optional]
**references** | Option<**Vec<String>**> | List of links to be associated with the article (e.g [\"http://link1\", \"http://link2\", \"http://link3\"]) | [optional]
**related_materials** | Option<[**Vec<models::RelatedMaterial>**](RelatedMaterial.md)> | List of related materials; supersedes references and resource DOI/title. | [optional]
**categories** | Option<**Vec<i64>**> | List of category ids to be associated with the article(e.g [1, 23, 33, 66]) | [optional]
**categories_by_source_id** | Option<**Vec<String>**> | List of category source ids to be associated with the article, supersedes the categories property | [optional]
**authors** | Option<[**Vec<serde_json::Value>**](serde_json::Value.md)> | List of authors to be associated with the article. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint. | [optional]
**custom_fields** | Option<[**serde_json::Value**](.md)> | List of key, values pairs to be associated with the article | [optional]
**custom_fields_list** | Option<[**Vec<models::CustomArticleFieldAdd>**](CustomArticleFieldAdd.md)> | List of custom fields values, supersedes custom_fields parameter | [optional]
**defined_type** | Option<**String**> | <b>One of:</b> <code>figure</code> <code>online resource</code> <code>preprint</code> <code>book</code> <code>conference contribution</code> <code>media</code> <code>dataset</code> <code>poster</code> <code>journal contribution</code> <code>presentation</code> <code>thesis</code> <code>software</code> | [optional]
**funding** | Option<**String**> | Grant number or funding authority | [optional][default to ]
**funding_list** | Option<[**Vec<models::FundingCreate>**](FundingCreate.md)> | Funding creation / update items | [optional]
**license** | Option<**i64**> | License id for this article. | [optional][default to 0]
**doi** | Option<**String**> | Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional][default to ]
**handle** | Option<**String**> | Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional][default to ]
**resource_doi** | Option<**String**> | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [optional][default to ]
**resource_title** | Option<**String**> | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [optional][default to ]
**timeline** | Option<[**models::TimelineUpdate**](TimelineUpdate.md)> |  | [optional]
**download_disabled** | Option<**bool**> | If true, downloading of files for this article is disabled | [optional]
**group_id** | Option<**i64**> | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


