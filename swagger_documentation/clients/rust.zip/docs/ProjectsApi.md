# \ProjectsApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**private_project_article_delete**](ProjectsApi.md#private_project_article_delete) | **DELETE** /account/projects/{project_id}/articles/{article_id} | Delete project article
[**private_project_article_details**](ProjectsApi.md#private_project_article_details) | **GET** /account/projects/{project_id}/articles/{article_id} | Project article details
[**private_project_article_file**](ProjectsApi.md#private_project_article_file) | **GET** /account/projects/{project_id}/articles/{article_id}/files/{file_id} | Project article file details
[**private_project_article_files**](ProjectsApi.md#private_project_article_files) | **GET** /account/projects/{project_id}/articles/{article_id}/files | Project article list files
[**private_project_articles_create**](ProjectsApi.md#private_project_articles_create) | **POST** /account/projects/{project_id}/articles | Create project article
[**private_project_articles_list**](ProjectsApi.md#private_project_articles_list) | **GET** /account/projects/{project_id}/articles | List project articles
[**private_project_collaborator_delete**](ProjectsApi.md#private_project_collaborator_delete) | **DELETE** /account/projects/{project_id}/collaborators/{user_id} | Remove project collaborator
[**private_project_collaborators_invite**](ProjectsApi.md#private_project_collaborators_invite) | **POST** /account/projects/{project_id}/collaborators | Invite project collaborators
[**private_project_collaborators_list**](ProjectsApi.md#private_project_collaborators_list) | **GET** /account/projects/{project_id}/collaborators | List project collaborators
[**private_project_create**](ProjectsApi.md#private_project_create) | **POST** /account/projects | Create project
[**private_project_delete**](ProjectsApi.md#private_project_delete) | **DELETE** /account/projects/{project_id} | Delete project
[**private_project_details**](ProjectsApi.md#private_project_details) | **GET** /account/projects/{project_id} | View project details
[**private_project_leave**](ProjectsApi.md#private_project_leave) | **POST** /account/projects/{project_id}/leave | Private Project Leave
[**private_project_note**](ProjectsApi.md#private_project_note) | **GET** /account/projects/{project_id}/notes/{note_id} | Project note details
[**private_project_note_delete**](ProjectsApi.md#private_project_note_delete) | **DELETE** /account/projects/{project_id}/notes/{note_id} | Delete project note
[**private_project_note_update**](ProjectsApi.md#private_project_note_update) | **PUT** /account/projects/{project_id}/notes/{note_id} | Update project note
[**private_project_notes_create**](ProjectsApi.md#private_project_notes_create) | **POST** /account/projects/{project_id}/notes | Create project note
[**private_project_notes_list**](ProjectsApi.md#private_project_notes_list) | **GET** /account/projects/{project_id}/notes | List project notes
[**private_project_partial_update**](ProjectsApi.md#private_project_partial_update) | **PATCH** /account/projects/{project_id} | Partially update project
[**private_project_publish**](ProjectsApi.md#private_project_publish) | **POST** /account/projects/{project_id}/publish | Private Project Publish
[**private_project_update**](ProjectsApi.md#private_project_update) | **PUT** /account/projects/{project_id} | Update project
[**private_projects_list**](ProjectsApi.md#private_projects_list) | **GET** /account/projects | Private Projects
[**private_projects_search**](ProjectsApi.md#private_projects_search) | **POST** /account/projects/search | Private Projects search
[**project_articles**](ProjectsApi.md#project_articles) | **GET** /projects/{project_id}/articles | Public Project Articles
[**project_details**](ProjectsApi.md#project_details) | **GET** /projects/{project_id} | Public Project
[**projects_list**](ProjectsApi.md#projects_list) | **GET** /projects | Public Projects
[**projects_search**](ProjectsApi.md#projects_search) | **POST** /projects/search | Public Projects Search



## private_project_article_delete

> private_project_article_delete(project_id, article_id)
Delete project article

Delete project article

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**article_id** | **i64** | Project Article unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_article_details

> models::ArticleCompletePrivate private_project_article_details(project_id, article_id)
Project article details

Project article details

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**article_id** | **i64** | Project Article unique identifier | [required] |

### Return type

[**models::ArticleCompletePrivate**](ArticleCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_article_file

> models::PrivateFile private_project_article_file(project_id, article_id, file_id)
Project article file details

Project article file details

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**article_id** | **i64** | Project Article unique identifier | [required] |
**file_id** | **i64** | File unique identifier | [required] |

### Return type

[**models::PrivateFile**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_article_files

> Vec<models::PrivateFile> private_project_article_files(project_id, article_id)
Project article list files

List article files

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**article_id** | **i64** | Project Article unique identifier | [required] |

### Return type

[**Vec<models::PrivateFile>**](PrivateFile.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_articles_create

> models::Location private_project_articles_create(project_id, article)
Create project article

Create a new Article and associate it with this project

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**article** | [**ArticleProjectCreate**](ArticleProjectCreate.md) | Article description | [required] |

### Return type

[**models::Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_articles_list

> Vec<models::Article> private_project_articles_list(project_id)
List project articles

List project articles

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |

### Return type

[**Vec<models::Article>**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_collaborator_delete

> private_project_collaborator_delete(project_id, user_id)
Remove project collaborator

Remove project collaborator

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**user_id** | **i64** | User unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_collaborators_invite

> models::ResponseMessage private_project_collaborators_invite(project_id, collaborator)
Invite project collaborators

Invite users to collaborate on project or view the project

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**collaborator** | [**ProjectCollaboratorInvite**](ProjectCollaboratorInvite.md) | viewer or collaborator role. User user_id or email of user | [required] |

### Return type

[**models::ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_collaborators_list

> Vec<models::ProjectCollaborator> private_project_collaborators_list(project_id)
List project collaborators

List Project collaborators and invited users

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |

### Return type

[**Vec<models::ProjectCollaborator>**](ProjectCollaborator.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_create

> models::CreateProjectResponse private_project_create(project)
Create project

Create a new project

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project** | [**ProjectCreate**](ProjectCreate.md) | Project  description | [required] |

### Return type

[**models::CreateProjectResponse**](CreateProjectResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_delete

> private_project_delete(project_id)
Delete project

A project can be deleted only if: - it is not public - it does not have public articles.  When an individual project is deleted, all the articles are moved to my data of each owner.  When a group project is deleted, all the articles and files are deleted as well. Only project owner, group admin and above can delete a project. 

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_details

> models::ProjectCompletePrivate private_project_details(project_id)
View project details

View a private project

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |

### Return type

[**models::ProjectCompletePrivate**](ProjectCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_leave

> private_project_leave(project_id)
Private Project Leave

Please note: project's owner cannot leave the project.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_note

> models::ProjectNotePrivate private_project_note(project_id, note_id)
Project note details

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**note_id** | **i64** | Note unique identifier | [required] |

### Return type

[**models::ProjectNotePrivate**](ProjectNotePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_note_delete

> private_project_note_delete(project_id, note_id)
Delete project note

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**note_id** | **i64** | Note unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_note_update

> private_project_note_update(project_id, note_id, note)
Update project note

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**note_id** | **i64** | Note unique identifier | [required] |
**note** | [**ProjectNoteCreate**](ProjectNoteCreate.md) | Note message | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_notes_create

> models::Location private_project_notes_create(project_id, note)
Create project note

Create a new project note

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**note** | [**ProjectNoteCreate**](ProjectNoteCreate.md) | Note message | [required] |

### Return type

[**models::Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_notes_list

> Vec<models::ProjectNote> private_project_notes_list(project_id, page, page_size, limit, offset)
List project notes

List project notes

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |

### Return type

[**Vec<models::ProjectNote>**](ProjectNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_partial_update

> private_project_partial_update(project_id, project)
Partially update project

Partially update a project; only provided fields will be changed.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**project** | Option<[**ProjectUpdate**](ProjectUpdate.md)> | Fields to update |  |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_publish

> models::ResponseMessage private_project_publish(project_id)
Private Project Publish

Publish a project. Possible after all items inside it are public

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |

### Return type

[**models::ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_project_update

> private_project_update(project_id, project)
Update project

Updating an project by passing body parameters.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project unique identifier | [required] |
**project** | [**ProjectUpdate**](ProjectUpdate.md) | Project description | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_projects_list

> Vec<models::ProjectPrivate> private_projects_list(page, page_size, limit, offset, order, order_direction, storage, roles)
Private Projects

List private projects

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |
**order** | Option<**String**> | The field by which to order. |  |[default to published_date]
**order_direction** | Option<**String**> |  |  |[default to desc]
**storage** | Option<**String**> | only return collections from this institution |  |
**roles** | Option<**String**> | Any combination of owner, collaborator, viewer separated by comma. Examples: \"owner\" or \"owner,collaborator\". |  |

### Return type

[**Vec<models::ProjectPrivate>**](ProjectPrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_projects_search

> Vec<models::ProjectPrivate> private_projects_search(search)
Private Projects search

Search inside the private projects

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**search** | Option<[**ProjectsSearch**](ProjectsSearch.md)> | Search Parameters |  |

### Return type

[**Vec<models::ProjectPrivate>**](ProjectPrivate.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## project_articles

> Vec<models::Article> project_articles(project_id, page, page_size, limit, offset)
Public Project Articles

List articles in project

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project Unique identifier | [required] |
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |

### Return type

[**Vec<models::Article>**](Article.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## project_details

> models::ProjectComplete project_details(project_id)
Public Project

View a project

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**project_id** | **i64** | Project Unique identifier | [required] |

### Return type

[**models::ProjectComplete**](ProjectComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## projects_list

> Vec<models::Project> projects_list(x_cursor, page, page_size, limit, offset, order, order_direction, institution, published_since, group)
Public Projects

Returns a list of public projects

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**x_cursor** | Option<**uuid::Uuid**> | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. |  |
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |
**order** | Option<**String**> | The field by which to order. Default varies by endpoint/resource. |  |[default to published_date]
**order_direction** | Option<**String**> |  |  |[default to desc]
**institution** | Option<**i64**> | only return collections from this institution |  |
**published_since** | Option<**String**> | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD |  |
**group** | Option<**i64**> | only return collections from this group |  |

### Return type

[**Vec<models::Project>**](Project.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## projects_search

> Vec<models::Project> projects_search(x_cursor, search)
Public Projects Search

Returns a list of public articles

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**x_cursor** | Option<**uuid::Uuid**> | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. |  |
**search** | Option<[**ProjectsSearch**](ProjectsSearch.md)> | Search Parameters |  |

### Return type

[**Vec<models::Project>**](Project.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

