# ProjectNotePrivate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** | Full text of note | 
**id** | **i64** | Project note id | 
**user_id** | **i64** | User who wrote the note | 
**r#abstract** | **String** | Note Abstract - short/truncated content | 
**user_name** | **String** | Username of the one who wrote the note | 
**created_date** | **String** | Date when note was created | 
**modified_date** | **String** | Date when note was last modified | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


