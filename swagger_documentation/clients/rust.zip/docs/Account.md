# Account

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i64** | Account id | 
**first_name** | **String** | First Name | 
**last_name** | **String** | Last Name | 
**used_quota_private** | **i64** | Account used private quota | 
**modified_date** | **String** | Date of last account modification | 
**used_quota** | **i64** | Account total used quota | 
**created_date** | **String** | Date when account was created | 
**quota** | **i64** | Account quota | 
**group_id** | **i64** | Account group id | 
**institution_user_id** | **String** | Account institution user id | 
**institution_id** | **i64** | Account institution | 
**email** | **String** | User email | 
**used_quota_public** | **i64** | Account public used quota | 
**pending_quota_request** | **bool** | True if a quota request is pending | 
**active** | **i64** | Account activity status | 
**maximum_file_size** | **i64** | Maximum upload size for account | 
**user_id** | **i64** | User id associated with account, useful for example for adding the account as an author to an item | 
**orcid_id** | **String** | ORCID iD associated to account | 
**symplectic_user_id** | **String** | Symplectic ID associated to account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


