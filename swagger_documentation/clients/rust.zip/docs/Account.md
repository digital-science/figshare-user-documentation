# Account

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i32** | Account id | 
**first_name** | **String** | First Name | 
**last_name** | **String** | Last Name | 
**used_quota_private** | **i32** | Account used private quota | 
**modified_date** | **String** | Date of last account modification | 
**used_quota** | **i32** | Account total used quota | 
**created_date** | **String** | Date when account was created | 
**quota** | **i32** | Account quota | 
**group_id** | **i32** | Account group id | 
**institution_user_id** | **String** | Account institution user id | 
**institution_id** | **i32** | Account institution | 
**email** | **String** | User email | 
**used_quota_public** | **i32** | Account public used quota | 
**pending_quota_request** | **bool** | True if a quota request is pending | 
**active** | **i32** | Account activity status | 
**maximum_file_size** | **i32** | Maximum upload size for account | 
**user_id** | **i32** | User id associated with account, useful for example for adding the account as an author to an item | 
**orcid_id** | **String** | ORCID iD associated to account | 
**symplectic_user_id** | **String** | Symplectic ID associated to account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


