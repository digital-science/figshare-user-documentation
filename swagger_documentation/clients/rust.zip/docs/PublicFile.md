# PublicFile

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i64** | File id | 
**name** | **String** | File name | 
**size** | **i64** | File size | 
**is_link_only** | **bool** | True if file is hosted somewhere else | 
**download_url** | **String** | Url for file download | 
**supplied_md5** | **String** | File supplied md5 | 
**computed_md5** | **String** | File computed md5 | 
**mimetype** | Option<**String**> | MIME Type of the file, it defaults to an empty string | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


