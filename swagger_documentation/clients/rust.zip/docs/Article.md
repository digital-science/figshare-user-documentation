# Article

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i64** | Unique identifier for article | 
**title** | **String** | Title of article | 
**doi** | **String** | DOI | 
**handle** | **String** | Handle | 
**url** | **String** | Api endpoint for article | 
**url_public_html** | **String** | Public site endpoint for article | 
**url_public_api** | **String** | Public Api endpoint for article | 
**url_private_html** | **String** | Private site endpoint for article | 
**url_private_api** | **String** | Private Api endpoint for article | 
**timeline** | [**models::Timeline**](Timeline.md) |  | 
**thumb** | **String** | Thumbnail image | 
**defined_type** | **i64** | Type of article identifier | 
**defined_type_name** | **String** | Name of the article type identifier | 
**resource_doi** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [default to ]
**resource_title** | **String** | Deprecated by related materials. Not applicable to regular users. In a publisher case, this is the publisher article title. | [default to ]
**created_date** | **String** | Date when article was created | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


