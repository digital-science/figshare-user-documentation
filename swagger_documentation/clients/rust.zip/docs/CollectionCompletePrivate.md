# CollectionCompletePrivate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account_id** | **i64** | ID of the account owning the collection | 
**funding** | [**Vec<models::FundingInformation>**](FundingInformation.md) | Full Collection funding information | 
**resource_id** | **String** | Collection resource id | 
**resource_doi** | **String** | Collection resource doi | 
**resource_title** | **String** | Collection resource title | 
**resource_link** | **String** | Collection resource link | 
**resource_version** | **i64** | Collection resource version | 
**version** | **i64** | Collection version | 
**description** | **String** | Collection description | 
**categories** | [**Vec<models::Category>**](Category.md) | List of collection categories | 
**references** | **Vec<String>** | List of collection references | 
**related_materials** | Option<[**Vec<models::RelatedMaterial>**](RelatedMaterial.md)> | List of related materials; supersedes references and resource DOI/title. | [optional]
**tags** | **Vec<String>** | List of collection tags. Keywords can be used instead | 
**keywords** | **Vec<String>** | List of collection keywords. Tags can be used instead | 
**authors** | [**Vec<models::Author>**](Author.md) | List of collection authors | 
**institution_id** | **i64** | Collection institution | 
**group_id** | **i64** | Collection group | 
**articles_count** | **i64** | Number of articles in collection | 
**public** | **bool** | True if collection is published | 
**citation** | **String** | Collection citation | 
**custom_fields** | [**Vec<models::CustomArticleField>**](CustomArticleField.md) | Collection custom fields | 
**modified_date** | **String** | Date when collection was last modified | 
**created_date** | **String** | Date when collection was created | 
**timeline** | [**models::Timeline**](Timeline.md) |  | 
**id** | **i64** | Collection id | 
**title** | **String** | Collection title | 
**doi** | **String** | Collection DOI | 
**handle** | **String** | Collection Handle | 
**url** | **String** | Api endpoint | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


