# Collaborator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role_name** | **String** | Collaborator role | 
**user_id** | **i32** | Collaborator id | 
**name** | **String** | Collaborator name | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


