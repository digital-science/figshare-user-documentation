# Author

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i64** | Author id | 
**full_name** | **String** | Author full name | 
**first_name** | **String** | Author first name | 
**last_name** | **String** | Author last name | 
**is_active** | **bool** | True if author has published items | 
**url_name** | **String** | Author url name | 
**orcid_id** | **String** | Author Orcid | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


