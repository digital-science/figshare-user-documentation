# PrivateAuthorsSearch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_for** | Option<**String**> | Search term | [optional]
**page** | Option<**i64**> | Page number. Used for pagination with page_size | [optional]
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page | [optional][default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query | [optional]
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit | [optional]
**institution_id** | Option<**i64**> | Return only authors associated to this institution | [optional]
**orcid** | Option<**String**> | Orcid of author | [optional]
**group_id** | Option<**i64**> | Return only authors in this group or subgroups of the group | [optional]
**is_active** | Option<**bool**> | Return only active authors if True | [optional]
**is_public** | Option<**bool**> | Return only authors that have published items if True | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


