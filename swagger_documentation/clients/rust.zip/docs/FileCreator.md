# FileCreator

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | Option<**String**> | Url for an existing file that will not be uploaded to Figshare | [optional]
**md5** | Option<**String**> | MD5 sum pre-computed on client side. | [optional]
**name** | Option<**String**> | File name including the extension; can be omitted only for linked files. | [optional]
**size** | Option<**i32**> | File size in bytes; can be omitted only for linked files. | [optional]
**folder_path** | Option<**String**> | Unix-style directory path of the file; only available if the file was uploaded within a folder structure | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


