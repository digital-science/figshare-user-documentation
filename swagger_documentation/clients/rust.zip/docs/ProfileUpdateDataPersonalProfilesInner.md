# ProfileUpdateDataPersonalProfilesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label** | Option<**String**> | Label for the personal profile link | [optional]
**url** | Option<**String**> | URL for the personal profile link | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


