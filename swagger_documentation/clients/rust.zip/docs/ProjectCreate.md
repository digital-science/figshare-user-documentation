# ProjectCreate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** | The title for this project - mandatory. 3 - 1000 characters. | 
**description** | Option<**String**> | Project description | [optional]
**funding** | Option<**String**> | Grant number or organization(s) that funded this project. Up to 2000 characters permitted. | [optional]
**funding_list** | Option<[**Vec<models::FundingCreate>**](FundingCreate.md)> | Funding creation / update items | [optional]
**group_id** | Option<**i64**> | Only if project type is group. | [optional]
**custom_fields** | Option<[**serde_json::Value**](.md)> | List of key, values pairs to be associated with the project | [optional]
**custom_fields_list** | Option<[**Vec<models::CustomArticleFieldAdd>**](CustomArticleFieldAdd.md)> | List of custom fields values, supersedes custom_fields parameter | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


