# \OauthApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_token**](OauthApi.md#create_token) | **POST** /token | Create OAuth token
[**get_token_info**](OauthApi.md#get_token_info) | **GET** /token | Get OAuth token information



## create_token

> models::OAuthToken create_token(body)
Create OAuth token

Creates OAuth token using various grant types

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**body** | Option<[**CreateOAuthToken**](CreateOAuthToken.md)> | Create OAuth Token Parameters |  |

### Return type

[**models::OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_token_info

> models::OAuthToken get_token_info(access_token)
Get OAuth token information

Returns information about the current OAuth token

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**access_token** | Option<**String**> | OAuth access token |  |

### Return type

[**models::OAuthToken**](OAuthToken.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

