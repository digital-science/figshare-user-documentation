# Timeline

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_online** | Option<**String**> | Online posted date | [optional]
**publisher_publication** | Option<**String**> | Publish date | [optional]
**publisher_acceptance** | Option<**String**> | Date when the item was accepted for publication | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


