# FundingSearch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_for** | Option<**String**> | Search term | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


