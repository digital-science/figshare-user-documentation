# \InstitutionsApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**account_institution_curation**](InstitutionsApi.md#account_institution_curation) | **GET** /account/institution/review/{curation_id} | Institution Curation Review
[**account_institution_curations**](InstitutionsApi.md#account_institution_curations) | **GET** /account/institution/reviews | Institution Curation Reviews
[**custom_fields_list**](InstitutionsApi.md#custom_fields_list) | **GET** /account/institution/custom_fields | Private account institution group custom fields
[**custom_fields_upload**](InstitutionsApi.md#custom_fields_upload) | **POST** /account/institution/custom_fields/{custom_field_id}/items/upload | Custom fields values files upload
[**get_account_institution_curation_comments**](InstitutionsApi.md#get_account_institution_curation_comments) | **GET** /account/institution/review/{curation_id}/comments | Institution Curation Review Comments
[**institution_articles**](InstitutionsApi.md#institution_articles) | **GET** /institutions/{institution_string_id}/articles/filter-by | Public Institution Articles
[**institution_hrfeed_upload**](InstitutionsApi.md#institution_hrfeed_upload) | **POST** /institution/hrfeed/upload | Private Institution HRfeed Upload
[**post_account_institution_curation_comments**](InstitutionsApi.md#post_account_institution_curation_comments) | **POST** /account/institution/review/{curation_id}/comments | POST Institution Curation Review Comment
[**private_account_institution_user**](InstitutionsApi.md#private_account_institution_user) | **GET** /account/institution/users/{account_id} | Private Account Institution User
[**private_categories_list**](InstitutionsApi.md#private_categories_list) | **GET** /account/categories | Private Account Categories
[**private_group_embargo_options_details**](InstitutionsApi.md#private_group_embargo_options_details) | **GET** /account/institution/groups/{group_id}/embargo_options | Private Account Institution Group Embargo Options
[**private_institution_account**](InstitutionsApi.md#private_institution_account) | **GET** /account/institution/accounts/{account_id} | Private Institution Account information
[**private_institution_account_group_role_delete**](InstitutionsApi.md#private_institution_account_group_role_delete) | **DELETE** /account/institution/roles/{account_id}/{group_id}/{role_id} | Delete Institution Account Group Role
[**private_institution_account_group_roles**](InstitutionsApi.md#private_institution_account_group_roles) | **GET** /account/institution/roles/{account_id} | List Institution Account Group Roles
[**private_institution_account_group_roles_create**](InstitutionsApi.md#private_institution_account_group_roles_create) | **POST** /account/institution/roles/{account_id} | Add Institution Account Group Roles
[**private_institution_accounts_create**](InstitutionsApi.md#private_institution_accounts_create) | **POST** /account/institution/accounts | Create new Institution Account
[**private_institution_accounts_list**](InstitutionsApi.md#private_institution_accounts_list) | **GET** /account/institution/accounts | Private Account Institution Accounts
[**private_institution_accounts_search**](InstitutionsApi.md#private_institution_accounts_search) | **POST** /account/institution/accounts/search | Private Account Institution Accounts Search
[**private_institution_accounts_update**](InstitutionsApi.md#private_institution_accounts_update) | **PUT** /account/institution/accounts/{account_id} | Update Institution Account
[**private_institution_articles**](InstitutionsApi.md#private_institution_articles) | **GET** /account/institution/articles | Private Institution Articles
[**private_institution_details**](InstitutionsApi.md#private_institution_details) | **GET** /account/institution | Private Account Institutions
[**private_institution_embargo_options_details**](InstitutionsApi.md#private_institution_embargo_options_details) | **GET** /account/institution/embargo_options | Private Account Institution embargo options
[**private_institution_groups_list**](InstitutionsApi.md#private_institution_groups_list) | **GET** /account/institution/groups | Private Account Institution Groups
[**private_institution_roles_list**](InstitutionsApi.md#private_institution_roles_list) | **GET** /account/institution/roles | Private Account Institution Roles



## account_institution_curation

> models::CurationDetail account_institution_curation(curation_id)
Institution Curation Review

Retrieve a certain curation review by its ID

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**curation_id** | **i64** | ID of the curation | [required] |

### Return type

[**models::CurationDetail**](CurationDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## account_institution_curations

> models::Curation account_institution_curations(group_id, article_id, status, limit, offset)
Institution Curation Reviews

Retrieve a list of curation reviews for this institution

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**group_id** | Option<**i64**> | Filter by the group ID |  |
**article_id** | Option<**i64**> | Retrieve the reviews for this article |  |
**status** | Option<**String**> | Filter by the status of the review |  |
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |

### Return type

[**models::Curation**](Curation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## custom_fields_list

> Vec<models::ShortCustomField> custom_fields_list(group_id)
Private account institution group custom fields

Returns the custom fields in the group the user belongs to, or the ones in the group specified, if the user has access.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**group_id** | Option<**i64**> | Group_id |  |

### Return type

[**Vec<models::ShortCustomField>**](ShortCustomField.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## custom_fields_upload

> serde_json::Value custom_fields_upload(custom_field_id, external_file)
Custom fields values files upload

Uploads a CSV containing values for a specific custom field of type <b>dropdown_large_list</b>. More details in the <a href=\"#custom_fields\">Custom Fields section</a>

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**custom_field_id** | **i64** | Custom field identifier | [required] |
**external_file** | Option<**std::path::PathBuf**> | CSV file to be uploaded |  |

### Return type

[**serde_json::Value**](serde_json::Value.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: multipart/form-data
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## get_account_institution_curation_comments

> models::CurationComment get_account_institution_curation_comments(curation_id, limit, offset)
Institution Curation Review Comments

Retrieve a certain curation review's comments.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**curation_id** | **i64** | ID of the curation | [required] |
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |

### Return type

[**models::CurationComment**](CurationComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## institution_articles

> Vec<models::Article> institution_articles(institution_string_id, resource_id, filename)
Public Institution Articles

Returns a list of articles belonging to the institution

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**institution_string_id** | **String** |  | [required] |
**resource_id** | **String** |  | [required] |
**filename** | **String** |  | [required] |

### Return type

[**Vec<models::Article>**](Article.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## institution_hrfeed_upload

> models::ResponseMessage institution_hrfeed_upload(hrfeed)
Private Institution HRfeed Upload

More info in the <a href=\"#hr_feed\">HR Feed section</a>

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**hrfeed** | Option<**std::path::PathBuf**> | You can find an example in the Hr Feed section |  |

### Return type

[**models::ResponseMessage**](ResponseMessage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: multipart/form-data
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## post_account_institution_curation_comments

> post_account_institution_curation_comments(curation_id, curation_comment)
POST Institution Curation Review Comment

Add a new comment to the review.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**curation_id** | **i64** | ID of the curation | [required] |
**curation_comment** | [**CurationCommentCreate**](CurationCommentCreate.md) | The content/value of the comment. | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_account_institution_user

> models::User private_account_institution_user(account_id)
Private Account Institution User

Retrieve institution user information using the account_id

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**account_id** | **i64** | Account identifier the user is associated to | [required] |

### Return type

[**models::User**](User.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_categories_list

> Vec<models::CategoryList> private_categories_list()
Private Account Categories

List institution categories (including parent Categories)

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::CategoryList>**](CategoryList.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_group_embargo_options_details

> Vec<models::GroupEmbargoOptions> private_group_embargo_options_details(group_id)
Private Account Institution Group Embargo Options

Account institution group embargo options details

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**group_id** | **i64** | Group identifier | [required] |

### Return type

[**Vec<models::GroupEmbargoOptions>**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_account

> models::Account private_institution_account(account_id)
Private Institution Account information

Private Institution Account information

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**account_id** | **i64** | Account identifier the user is associated to | [required] |

### Return type

[**models::Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_account_group_role_delete

> private_institution_account_group_role_delete(account_id, group_id, role_id)
Delete Institution Account Group Role

Delete Institution Account Group Role

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**account_id** | **i64** | Account identifier for which to remove the role | [required] |
**group_id** | **i64** | Group identifier for which to remove the role | [required] |
**role_id** | **i64** | Role identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_account_group_roles

> serde_json::Value private_institution_account_group_roles(account_id)
List Institution Account Group Roles

List Institution Account Group Roles

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**account_id** | **i64** | Account identifier the user is associated to | [required] |

### Return type

[**serde_json::Value**](serde_json::Value.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_account_group_roles_create

> private_institution_account_group_roles_create(account_id, account)
Add Institution Account Group Roles

Add Institution Account Group Roles

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**account_id** | **i64** | Account identifier the user is associated to | [required] |
**account** | **serde_json::Value** | Account description | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_accounts_create

> models::AccountCreateResponse private_institution_accounts_create(account)
Create new Institution Account

Create a new Account by sending account information. When the institution_user_id is provided, no verification email will be sent. The email_verified flag will automatically be set to true. If the institution_user_id is not provided, a verification email will be sent. The email_verified flag will be set to true once the account is created.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**account** | [**AccountCreate**](AccountCreate.md) | Account description | [required] |

### Return type

[**models::AccountCreateResponse**](AccountCreateResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_accounts_list

> Vec<models::ShortAccount> private_institution_accounts_list(page, page_size, limit, offset, is_active, institution_user_id, email, id_lte, id_gte)
Private Account Institution Accounts

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |
**is_active** | Option<**i64**> | Filter by active status |  |
**institution_user_id** | Option<**String**> | Filter by institution_user_id |  |
**email** | Option<**String**> | Filter by email |  |
**id_lte** | Option<**i64**> | Retrieve accounts with an ID lower or equal to the specified value |  |
**id_gte** | Option<**i64**> | Retrieve accounts with an ID greater or equal to the specified value |  |

### Return type

[**Vec<models::ShortAccount>**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_accounts_search

> Vec<models::ShortAccount> private_institution_accounts_search(search)
Private Account Institution Accounts Search

Returns the accounts for which the account has administrative privileges (assigned and inherited).

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**search** | [**InstitutionAccountsSearch**](InstitutionAccountsSearch.md) | Search Parameters | [required] |

### Return type

[**Vec<models::ShortAccount>**](ShortAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_accounts_update

> private_institution_accounts_update(account_id, account)
Update Institution Account

Update Institution Account

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**account_id** | **i64** | Account identifier the user is associated to | [required] |
**account** | [**AccountUpdate**](AccountUpdate.md) | Account description | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_articles

> Vec<models::Article> private_institution_articles(page, page_size, limit, offset, order, order_direction, published_since, modified_since, status, resource_doi, item_type, group)
Private Institution Articles

Get Articles from own institution. User must be administrator of the institution

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |
**order** | Option<**String**> | The field by which to order. Default varies by endpoint/resource. |  |[default to published_date]
**order_direction** | Option<**String**> |  |  |[default to desc]
**published_since** | Option<**String**> | Filter by article publishing date. Will only return articles published after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ |  |
**modified_since** | Option<**String**> | Filter by article modified date. Will only return articles modified after the date. date(ISO 8601) YYYY-MM-DD or date-time(ISO 8601) YYYY-MM-DDTHH:mm:ssZ |  |
**status** | Option<**i64**> | only return collections with this status |  |
**resource_doi** | Option<**String**> | only return collections with this resource_doi |  |
**item_type** | Option<**i64**> | Only return articles with the respective type. Mapping for item_type is: 1 - Figure, 2 - Media, 3 - Dataset, 5 - Poster, 6 - Journal contribution, 7 - Presentation, 8 - Thesis, 9 - Software, 11 - Online resource, 12 - Preprint, 13 - Book, 14 - Conference contribution, 15 - Chapter, 16 - Peer review, 17 - Educational resource, 18 - Report, 19 - Standard, 20 - Composition, 21 - Funding, 22 - Physical object, 23 - Data management plan, 24 - Workflow, 25 - Monograph, 26 - Performance, 27 - Event, 28 - Service, 29 - Model |  |
**group** | Option<**i64**> | only return articles from this group |  |

### Return type

[**Vec<models::Article>**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_details

> models::Institution private_institution_details()
Private Account Institutions

Account institution details

### Parameters

This endpoint does not need any parameter.

### Return type

[**models::Institution**](Institution.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_embargo_options_details

> Vec<models::GroupEmbargoOptions> private_institution_embargo_options_details()
Private Account Institution embargo options

Account institution embargo options details

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::GroupEmbargoOptions>**](GroupEmbargoOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_groups_list

> Vec<models::Group> private_institution_groups_list()
Private Account Institution Groups

Returns the groups for which the account has administrative privileges (assigned and inherited).

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::Group>**](Group.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_institution_roles_list

> Vec<models::Role> private_institution_roles_list()
Private Account Institution Roles

Returns the roles available for groups and the institution group.

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::Role>**](Role.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

