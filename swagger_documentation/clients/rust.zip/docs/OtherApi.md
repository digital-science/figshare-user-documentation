# \OtherApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categories_list**](OtherApi.md#categories_list) | **GET** /categories | Public Categories
[**file_download**](OtherApi.md#file_download) | **GET** /file/download/{file_id} | Public File Download
[**item_types_list**](OtherApi.md#item_types_list) | **GET** /item_types | Item Types
[**licenses_list**](OtherApi.md#licenses_list) | **GET** /licenses | Public Licenses
[**private_account**](OtherApi.md#private_account) | **GET** /account | Private Account information
[**private_funding_search**](OtherApi.md#private_funding_search) | **POST** /account/funding/search | Search Funding
[**private_licenses_list**](OtherApi.md#private_licenses_list) | **GET** /account/licenses | Private Account Licenses



## categories_list

> Vec<models::CategoryList> categories_list()
Public Categories

Returns a list of public categories

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::CategoryList>**](CategoryList.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## file_download

> file_download(file_id)
Public File Download

Starts the download of a file

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**file_id** | **i64** |  | [required] |

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## item_types_list

> Vec<models::ItemType> item_types_list(group_id)
Item Types

Returns the list of Item Types of the requested group. If no user is authenticated, returns the item types available for Figshare.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**group_id** | Option<**i64**> | Identifier of the group for which the item types are requested |  |[default to 0]

### Return type

[**Vec<models::ItemType>**](ItemType.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## licenses_list

> Vec<models::License> licenses_list()
Public Licenses

Returns a list of public licenses

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::License>**](License.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_account

> models::Account private_account()
Private Account information

Account information for token/personal token

### Parameters

This endpoint does not need any parameter.

### Return type

[**models::Account**](Account.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_funding_search

> Vec<models::FundingInformation> private_funding_search(search)
Search Funding

Search for fundings

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**search** | Option<[**FundingSearch**](FundingSearch.md)> | Search Parameters |  |

### Return type

[**Vec<models::FundingInformation>**](FundingInformation.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_licenses_list

> Vec<models::License> private_licenses_list()
Private Account Licenses

This is a private endpoint that requires OAuth. It will return a list with figshare public licenses AND licenses defined for account's institution.

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::License>**](License.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

