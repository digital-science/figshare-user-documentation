# \ProfilesApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**update_user_profile**](ProfilesApi.md#update_user_profile) | **PUT** /account/profile | Update public profile
[**update_user_profile_picture**](ProfilesApi.md#update_user_profile_picture) | **POST** /account/profile/{user_id}/picture | Update public profile picture



## update_user_profile

> serde_json::Value update_user_profile(user_profile_data, user_id, institution_user_id)
Update public profile

Updates the fields of the user's public profile.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**user_profile_data** | [**ProfileUpdateData**](ProfileUpdateData.md) |  | [required] |
**user_id** | Option<**i64**> | User ID |  |
**institution_user_id** | Option<**String**> | Institutional user ID |  |

### Return type

[**serde_json::Value**](serde_json::Value.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## update_user_profile_picture

> serde_json::Value update_user_profile_picture(user_id, profile_picture)
Update public profile picture

Updates the profile picture of the user's public profile.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**user_id** | **i64** | User ID | [required] |
**profile_picture** | **std::path::PathBuf** | User profile picture | [required] |

### Return type

[**serde_json::Value**](serde_json::Value.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: multipart/form-data
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

