# CollectionUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | Option<**String**> | Grant number or funding authority | [optional][default to ]
**funding_list** | Option<[**Vec<models::FundingCreate>**](FundingCreate.md)> | Funding creation / update items | [optional]
**title** | Option<**String**> | Title of collection | [optional]
**description** | Option<**String**> | The collection description. In a publisher case, usually this is the remote collection description | [optional][default to ]
**articles** | Option<**Vec<i32>**> | List of articles to be associated with the collection | [optional]
**authors** | Option<[**Vec<serde_json::Value>**](serde_json::Value.md)> | List of authors to be associated with the collection. The list can contain the following fields: id, name, first_name, last_name, email, orcid_id. If an id is supplied, it will take priority and everything else will be ignored. For adding more authors use the specific authors endpoint. | [optional]
**categories** | Option<**Vec<i64>**> | List of category ids to be associated with the collection (e.g [1, 23, 33, 66]) | [optional]
**categories_by_source_id** | Option<**Vec<String>**> | List of category source ids to be associated with the article, supersedes the categories property | [optional]
**tags** | Option<**Vec<String>**> | List of tags to be associated with the collection. Keywords can be used instead | [optional]
**keywords** | Option<**Vec<String>**> | List of tags to be associated with the collection. Tags can be used instead | [optional]
**references** | Option<**Vec<String>**> | List of links to be associated with the collection (e.g [\"http://link1\", \"http://link2\", \"http://link3\"]) | [optional]
**related_materials** | Option<[**Vec<models::RelatedMaterial>**](RelatedMaterial.md)> | List of related materials; supersedes references and resource DOI/title. | [optional]
**custom_fields** | Option<[**serde_json::Value**](.md)> | List of key, values pairs to be associated with the collection | [optional]
**custom_fields_list** | Option<[**Vec<models::CustomArticleFieldAdd>**](CustomArticleFieldAdd.md)> | List of custom fields values, supersedes custom_fields parameter | [optional]
**doi** | Option<**String**> | Not applicable for regular users. In an institutional case, make sure your group supports setting DOIs. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional][default to ]
**handle** | Option<**String**> | Not applicable for regular users. In an institutional case, make sure your group supports setting Handles. This setting is applied by figshare via opening a ticket through our support/helpdesk system. | [optional][default to ]
**resource_id** | Option<**String**> | Not applicable to regular users. In a publisher case, this is the publisher article id | [optional]
**resource_doi** | Option<**String**> | Not applicable to regular users. In a publisher case, this is the publisher article DOI. | [optional][default to ]
**resource_link** | Option<**String**> | Not applicable to regular users. In a publisher case, this is the publisher article link | [optional]
**resource_title** | Option<**String**> | Not applicable to regular users. In a publisher case, this is the publisher article title. | [optional][default to ]
**resource_version** | Option<**i32**> | Not applicable to regular users. In a publisher case, this is the publisher article version | [optional]
**group_id** | Option<**i64**> | Not applicable to regular users. This field is reserved to institutions/publishers with access to assign to specific groups | [optional]
**timeline** | Option<[**models::TimelineUpdate**](TimelineUpdate.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


