# \CollectionsApi

All URIs are relative to *https://api.figsh.com/v2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**collection_articles**](CollectionsApi.md#collection_articles) | **GET** /collections/{collection_id}/articles | Public Collection Articles
[**collection_details**](CollectionsApi.md#collection_details) | **GET** /collections/{collection_id} | Collection details
[**collection_version_details**](CollectionsApi.md#collection_version_details) | **GET** /collections/{collection_id}/versions/{version_id} | Collection Version details
[**collection_versions**](CollectionsApi.md#collection_versions) | **GET** /collections/{collection_id}/versions | Collection Versions list
[**collections_list**](CollectionsApi.md#collections_list) | **GET** /collections | Public Collections
[**collections_search**](CollectionsApi.md#collections_search) | **POST** /collections/search | Public Collections Search
[**private_collection_article_delete**](CollectionsApi.md#private_collection_article_delete) | **DELETE** /account/collections/{collection_id}/articles/{article_id} | Delete collection article
[**private_collection_articles_add**](CollectionsApi.md#private_collection_articles_add) | **POST** /account/collections/{collection_id}/articles | Add collection articles
[**private_collection_articles_list**](CollectionsApi.md#private_collection_articles_list) | **GET** /account/collections/{collection_id}/articles | List collection articles
[**private_collection_articles_replace**](CollectionsApi.md#private_collection_articles_replace) | **PUT** /account/collections/{collection_id}/articles | Replace collection articles
[**private_collection_author_delete**](CollectionsApi.md#private_collection_author_delete) | **DELETE** /account/collections/{collection_id}/authors/{author_id} | Delete collection author
[**private_collection_authors_add**](CollectionsApi.md#private_collection_authors_add) | **POST** /account/collections/{collection_id}/authors | Add collection authors
[**private_collection_authors_list**](CollectionsApi.md#private_collection_authors_list) | **GET** /account/collections/{collection_id}/authors | List collection authors
[**private_collection_authors_replace**](CollectionsApi.md#private_collection_authors_replace) | **PUT** /account/collections/{collection_id}/authors | Replace collection authors
[**private_collection_categories_add**](CollectionsApi.md#private_collection_categories_add) | **POST** /account/collections/{collection_id}/categories | Add collection categories
[**private_collection_categories_list**](CollectionsApi.md#private_collection_categories_list) | **GET** /account/collections/{collection_id}/categories | List collection categories
[**private_collection_categories_replace**](CollectionsApi.md#private_collection_categories_replace) | **PUT** /account/collections/{collection_id}/categories | Replace collection categories
[**private_collection_category_delete**](CollectionsApi.md#private_collection_category_delete) | **DELETE** /account/collections/{collection_id}/categories/{category_id} | Delete collection category
[**private_collection_create**](CollectionsApi.md#private_collection_create) | **POST** /account/collections | Create collection
[**private_collection_delete**](CollectionsApi.md#private_collection_delete) | **DELETE** /account/collections/{collection_id} | Delete collection
[**private_collection_details**](CollectionsApi.md#private_collection_details) | **GET** /account/collections/{collection_id} | Collection details
[**private_collection_patch**](CollectionsApi.md#private_collection_patch) | **PATCH** /account/collections/{collection_id} | Partially update collection
[**private_collection_private_link_create**](CollectionsApi.md#private_collection_private_link_create) | **POST** /account/collections/{collection_id}/private_links | Create collection private link
[**private_collection_private_link_delete**](CollectionsApi.md#private_collection_private_link_delete) | **DELETE** /account/collections/{collection_id}/private_links/{link_id} | Disable private link
[**private_collection_private_link_details**](CollectionsApi.md#private_collection_private_link_details) | **GET** /account/collections/{collection_id}/private_links/{link_id} | View collection private link
[**private_collection_private_link_update**](CollectionsApi.md#private_collection_private_link_update) | **PUT** /account/collections/{collection_id}/private_links/{link_id} | Update collection private link
[**private_collection_private_links_list**](CollectionsApi.md#private_collection_private_links_list) | **GET** /account/collections/{collection_id}/private_links | List collection private links
[**private_collection_publish**](CollectionsApi.md#private_collection_publish) | **POST** /account/collections/{collection_id}/publish | Private Collection Publish
[**private_collection_reserve_doi**](CollectionsApi.md#private_collection_reserve_doi) | **POST** /account/collections/{collection_id}/reserve_doi | Private Collection Reserve DOI
[**private_collection_reserve_handle**](CollectionsApi.md#private_collection_reserve_handle) | **POST** /account/collections/{collection_id}/reserve_handle | Private Collection Reserve Handle
[**private_collection_resource**](CollectionsApi.md#private_collection_resource) | **POST** /account/collections/{collection_id}/resource | Private Collection Resource
[**private_collection_update**](CollectionsApi.md#private_collection_update) | **PUT** /account/collections/{collection_id} | Update collection
[**private_collections_list**](CollectionsApi.md#private_collections_list) | **GET** /account/collections | Private Collections List
[**private_collections_search**](CollectionsApi.md#private_collections_search) | **POST** /account/collections/search | Private Collections Search



## collection_articles

> Vec<models::Article> collection_articles(collection_id, page, page_size, limit, offset)
Public Collection Articles

Returns a list of public collection articles

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection Unique identifier | [required] |
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |

### Return type

[**Vec<models::Article>**](Article.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## collection_details

> models::CollectionComplete collection_details(collection_id)
Collection details

View a collection

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection Unique identifier | [required] |

### Return type

[**models::CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## collection_version_details

> models::CollectionComplete collection_version_details(collection_id, version_id)
Collection Version details

View details for a certain version of a collection

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection Unique identifier | [required] |
**version_id** | **i64** | Version Number | [required] |

### Return type

[**models::CollectionComplete**](CollectionComplete.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## collection_versions

> Vec<models::CollectionVersions> collection_versions(collection_id)
Collection Versions list

Returns a list of public collection Versions

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection Unique identifier | [required] |

### Return type

[**Vec<models::CollectionVersions>**](CollectionVersions.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## collections_list

> Vec<models::Collection> collections_list(x_cursor, page, page_size, limit, offset, order, order_direction, institution, published_since, modified_since, group, resource_doi, doi, handle)
Public Collections

Returns a list of public collections

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**x_cursor** | Option<**uuid::Uuid**> | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. |  |
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |
**order** | Option<**String**> | The field by which to order. Default varies by endpoint/resource. |  |[default to published_date]
**order_direction** | Option<**String**> |  |  |[default to desc]
**institution** | Option<**i64**> | only return collections from this institution |  |
**published_since** | Option<**String**> | Filter by collection publishing date. Will only return collections published after the date. date(ISO 8601) YYYY-MM-DD |  |
**modified_since** | Option<**String**> | Filter by collection modified date. Will only return collections modified after the date. date(ISO 8601) YYYY-MM-DD |  |
**group** | Option<**i64**> | only return collections from this group |  |
**resource_doi** | Option<**String**> | only return collections with this resource_doi |  |
**doi** | Option<**String**> | only return collections with this doi |  |
**handle** | Option<**String**> | only return collections with this handle |  |

### Return type

[**Vec<models::Collection>**](Collection.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## collections_search

> Vec<models::Collection> collections_search(x_cursor, search)
Public Collections Search

Returns a list of public collections

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**x_cursor** | Option<**uuid::Uuid**> | Unique hash used for bypassing the item retrieval limit of 9,000 entities. When using this parameter, please note that the offset parameter will not be available, but the limit parameter will still work as expected. |  |
**search** | Option<[**CollectionSearch**](CollectionSearch.md)> | Search Parameters |  |

### Return type

[**Vec<models::Collection>**](Collection.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_article_delete

> private_collection_article_delete(collection_id, article_id)
Delete collection article

De-associate article from collection

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**article_id** | **i64** | Collection article unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_articles_add

> models::Location private_collection_articles_add(collection_id, articles)
Add collection articles

Associate new articles with the collection. This will add new articles to the list of already associated articles

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**articles** | [**ArticlesCreator**](ArticlesCreator.md) | Articles list | [required] |

### Return type

[**models::Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_articles_list

> Vec<models::Article> private_collection_articles_list(collection_id, page, page_size, limit, offset)
List collection articles

List collection articles

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |

### Return type

[**Vec<models::Article>**](Article.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_articles_replace

> private_collection_articles_replace(collection_id, articles)
Replace collection articles

Associate new articles with the collection. This will remove all already associated articles and add these new ones

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**articles** | [**ArticlesCreator**](ArticlesCreator.md) | Articles List | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_author_delete

> private_collection_author_delete(collection_id, author_id)
Delete collection author

Delete collection author

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**author_id** | **i64** | Collection Author unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_authors_add

> models::Location private_collection_authors_add(collection_id, authors)
Add collection authors

Associate new authors with the collection. This will add new authors to the list of already associated authors

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**authors** | [**AuthorsCreator**](AuthorsCreator.md) | List of authors | [required] |

### Return type

[**models::Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_authors_list

> Vec<models::Author> private_collection_authors_list(collection_id)
List collection authors

List collection authors

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |

### Return type

[**Vec<models::Author>**](Author.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_authors_replace

> private_collection_authors_replace(collection_id, authors)
Replace collection authors

Associate new authors with the collection. This will remove all already associated authors and add these new ones

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**authors** | [**AuthorsCreator**](AuthorsCreator.md) | List of authors | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_categories_add

> models::Location private_collection_categories_add(collection_id, categories)
Add collection categories

Associate new categories with the collection. This will add new categories to the list of already associated categories

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**categories** | [**CategoriesCreator**](CategoriesCreator.md) | Categories list | [required] |

### Return type

[**models::Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_categories_list

> Vec<models::Category> private_collection_categories_list(collection_id)
List collection categories

List collection categories

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |

### Return type

[**Vec<models::Category>**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_categories_replace

> private_collection_categories_replace(collection_id, categories)
Replace collection categories

Associate new categories with the collection. This will remove all already associated categories and add these new ones

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**categories** | [**CategoriesCreator**](CategoriesCreator.md) | Categories list | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_category_delete

> private_collection_category_delete(collection_id, category_id)
Delete collection category

De-associate category from collection

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**category_id** | **i64** | Collection category unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_create

> models::LocationWarnings private_collection_create(collection)
Create collection

Create a new Collection by sending collection information

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection** | [**CollectionCreate**](CollectionCreate.md) | Collection description | [required] |

### Return type

[**models::LocationWarnings**](LocationWarnings.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_delete

> private_collection_delete(collection_id)
Delete collection

Delete n collection

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection Unique identifier | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_details

> models::CollectionCompletePrivate private_collection_details(collection_id)
Collection details

View a collection

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection Unique identifier | [required] |

### Return type

[**models::CollectionCompletePrivate**](CollectionCompletePrivate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_patch

> models::LocationWarningsUpdate private_collection_patch(collection_id, collection)
Partially update collection

Partially update a collection by sending only the fields to change.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection Unique identifier | [required] |
**collection** | [**CollectionUpdate**](CollectionUpdate.md) | Subset of collection fields to update | [required] |

### Return type

[**models::LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_private_link_create

> models::PrivateLinkResponse private_collection_private_link_create(collection_id, private_link)
Create collection private link

Create new private link

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**private_link** | Option<[**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md)> |  |  |

### Return type

[**models::PrivateLinkResponse**](PrivateLinkResponse.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_private_link_delete

> private_collection_private_link_delete(collection_id, link_id)
Disable private link

Disable/delete private link for this collection

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**link_id** | **String** | Private link token | [required] |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_private_link_details

> models::PrivateLink private_collection_private_link_details(collection_id, link_id)
View collection private link

View existing private link for this collection

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**link_id** | **String** | Private link token | [required] |

### Return type

[**models::PrivateLink**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_private_link_update

> private_collection_private_link_update(collection_id, link_id, private_link)
Update collection private link

Update existing private link for this collection

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**link_id** | **String** | Private link token | [required] |
**private_link** | Option<[**CollectionPrivateLinkCreator**](CollectionPrivateLinkCreator.md)> |  |  |

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_private_links_list

> Vec<models::PrivateLink> private_collection_private_links_list(collection_id)
List collection private links

List article private links

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |

### Return type

[**Vec<models::PrivateLink>**](PrivateLink.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_publish

> models::Location private_collection_publish(collection_id)
Private Collection Publish

When a collection is published, a new public version will be generated. Any further updates to the collection will affect the private collection data. In order to make these changes publicly visible, an explicit publish operation is needed.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection Unique identifier | [required] |

### Return type

[**models::Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_reserve_doi

> models::CollectionDoi private_collection_reserve_doi(collection_id)
Private Collection Reserve DOI

Reserve DOI for collection

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection Unique identifier | [required] |

### Return type

[**models::CollectionDoi**](CollectionDOI.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_reserve_handle

> models::CollectionHandle private_collection_reserve_handle(collection_id)
Private Collection Reserve Handle

Reserve Handle for collection

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection Unique identifier | [required] |

### Return type

[**models::CollectionHandle**](CollectionHandle.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_resource

> models::Location private_collection_resource(collection_id, resource)
Private Collection Resource

Edit collection resource data.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection unique identifier | [required] |
**resource** | [**Resource**](Resource.md) | Resource data | [required] |

### Return type

[**models::Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collection_update

> models::LocationWarningsUpdate private_collection_update(collection_id, collection)
Update collection

Update a collection by passing full body parameters.

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**collection_id** | **i64** | Collection Unique identifier | [required] |
**collection** | [**CollectionUpdate**](CollectionUpdate.md) | Collection description | [required] |

### Return type

[**models::LocationWarningsUpdate**](LocationWarningsUpdate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collections_list

> Vec<models::Collection> private_collections_list(page, page_size, limit, offset, order, order_direction)
Private Collections List

List private collections

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**page** | Option<**i64**> | Page number. Used for pagination with page_size |  |
**page_size** | Option<**i64**> | The number of results included on a page. Used for pagination with page |  |[default to 10]
**limit** | Option<**i64**> | Number of results included on a page. Used for pagination with query |  |
**offset** | Option<**i64**> | Where to start the listing (the offset of the first result). Used for pagination with limit |  |
**order** | Option<**String**> | The field by which to order. Default varies by endpoint/resource. |  |[default to published_date]
**order_direction** | Option<**String**> |  |  |[default to desc]

### Return type

[**Vec<models::Collection>**](Collection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


## private_collections_search

> Vec<models::Collection> private_collections_search(search)
Private Collections Search

Returns a list of private Collections

### Parameters


Name | Type | Description  | Required | Notes
------------- | ------------- | ------------- | ------------- | -------------
**search** | [**PrivateCollectionSearch**](PrivateCollectionSearch.md) | Search Parameters | [required] |

### Return type

[**Vec<models::Collection>**](Collection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

