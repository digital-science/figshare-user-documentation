# Curation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **i64** | The review id | 
**group_id** | **i64** | The group in which the article is present. | 
**account_id** | **i64** | The ID of the account of the owner of the article of this review. | 
**assigned_to** | **i64** | The ID of the account to which this review is assigned. | 
**article_id** | **i64** | The ID of the article of this review. | 
**version** | **i64** | The Version number of the article in review. | 
**comments_count** | **i64** | The number of comments in the review. | 
**status** | **String** | The status of the review. | 
**created_date** | **String** | The creation date of the review. | 
**modified_date** | **String** | The date the review has been modified. | 
**request_number** | **i64** | The request number of the review. | 
**resolution_comment** | **String** | The resolution comment of the review. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


